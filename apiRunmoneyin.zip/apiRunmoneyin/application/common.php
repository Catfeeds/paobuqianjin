<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
function md5user($password)
{
    return md5(md5($password) . '4LZ7esyS');
}

/**
 * 返回分页后数据
 * @param  integer $page       当前页码
 * @param  integer $pageSize   每页显示条数
 * @param  integer $totalCount 总条数
 * @param  array   $data       当前页数据
 * @return array               格式化后数据
 */
function returnData($page = 0, $pageSize = 0, $totalCount = 0, $data = array())
{
    $totalPage = ceil($totalCount / $pageSize);    //总页数

	return array(
		'pagenation' => array(
            'page'       => intval($page),
            'pageSize'   => intval($pageSize),
            'totalPage'  => intval($totalPage),
            'totalCount' => intval($totalCount),
		),
		'data' => $data
	);
}

/**
 * @param $data array  无限层评论
 * @param $parent  string 父级元素的名称 如 parent_id
 * @param $son     string 子级元素的名称 如 comm_id
 * @param $pid     int    父级元素的id 实际上传递元素的主键
 * @return array
 */
function getSubTree($data, $parent, $son, $pid = 0) 
{
    $tmp = array();

    foreach ($data as $key => $value) {
        if ($value[$parent] == $pid) {
            $value['child'] =  getSubTree($data, $parent, $son, $value[$son]);

            if ($value['child'] == null) {
                unset($value['child']);
            }

            $tmp[] = $value;
        }
    }

    return $tmp;
}

/**
 * @param $total 红包总金额
 * @param $count 红包个数
 * @return array
 */
function getRedBag($total, $count)
{
    //红包总金额
    $total = 100;
    //红包个数
    $count = 10;
    $num   = 0;

    //随机不确切红包
    $mintotal = 0;
    $arr1 = array();
    $arr2 = array();

    for ($i=1; $i<=$count; $i++) {
        $randNum = mt_rand(1, 10);
        array_push($arr1, $randNum);
        $num = $num + $randNum;
    }

    $avg = $num*10;
    $avg = $avg/10;

    foreach ($arr1 as $v) {

        $money = $v/$avg;
        $money = $money*$total;
        //截取两位数小数点，不四舍五入
        $res = sprintf( "%.2f ", $money);
        array_push($arr2, $res);
        $mintotal = $mintotal+$res;
    }

    $m = $mintotal-$arr2['0'];
    $arr2['0'] = strval($total-$m);

    return $arr2;
}

/**
 * 根据经纬度和半径计算出范围
 * @param string $lat 纬度
 * @param String $lng 经度
 * @param float $radius 半径
 * @return Array 范围数组
 */
function calcScope($lat, $lng, $radius) 
{
    $degree = (24901*1609)/360.0;
    $dpmLat = 1/$degree;

    $radiusLat = $dpmLat*$radius;
    $minLat = $lat - $radiusLat;       // 最小纬度
    $maxLat = $lat + $radiusLat;       // 最大纬度

    $mpdLng = $degree*cos($lat * (3.141592/180));
    $dpmLng = 1 / $mpdLng;
    $radiusLng = $dpmLng*$radius;

    $minLng = $lng - $radiusLng;      // 最小经度
    $maxLng = $lng + $radiusLng;      // 最大经度

    /** 返回范围数组 */
    $scope = array(
        'minLat'    =>  $minLat,
        'maxLat'    =>  $maxLat,
        'minLng'    =>  $minLng,
        'maxLng'    =>  $maxLng
    );

    return $scope;
}

/**
 * 获取两个经纬度之间的距离
 * @param  string $lat1 纬一
 * @param  String $lng1 经一
 * @param  String $lat2 纬二
 * @param  String $lng2 经二
 * @return float  返回两点之间的距离
 */
function calcDistance($lat1, $lng1, $lat2, $lng2) 
{
    if (empty($lat1) || empty($lng1) || empty($lat2) || empty($lng2)) {
        return false;
    }

    /** 转换数据类型为 double */
    $lat1 = doubleval($lat1);
    $lng1 = doubleval($lng1);
    $lat2 = doubleval($lat2);
    $lng2 = doubleval($lng2);

    /** 以下算法是 Google 出来的，与大多数经纬度计算工具结果一致 */
    $theta = $lng1 - $lng2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;

    return ($miles * 1.609344);
}

/**
 * 根据keys键值排序数组
 * @author chenjie 2018-01-09
 * @param  array $array 要排序的数组
 * @param  string $keys  要用来排序的键名
 * @param  string $type  默认为升序排序
 * @return array  返回排序后数据
 */
function arraySort($array, $keys, $type = 'asc')
{
    $keysvalue = $new_array = array();

    foreach ($array as $k => $v) {
        $keysvalue[$k] = $v[$keys];
    }
    unset($k, $v);

    if ($type == 'asc') {
        asort($keysvalue);
    } else {
        arsort($keysvalue);
    }

    reset($keysvalue);

    foreach ($keysvalue as $k => $v) {
        $new_array[] = $array[$k];
    }
    unset($k, $v);

    return $new_array;
}

/**
 * 随机生成红包
 * @author chenjie 2018-01-09
 * @param  integer $min 最小红包
 * @param  integer $max 最大红包
 * @return double 随机的红包金额
 */
function randomRedPacket($min = 0, $max = 10)
{
    $num = $min + mt_rand() / mt_getrandmax() * ($max - $min);
    return sprintf("%.2f",$num);
}

/**
 * 创建订单
 * @author chenjie 2018-01-30
 * @return [type] [description]
 */
function createOrder($params = array(), $notify_url = '')
{
    $appid  = 'wx1ed4ccc9a2226a73';
    $mch_id = '1495263342';
    $key    = '3FN8WHOH9e2PXmJRZiPnNoJ576AxMmwQ';

    $wechatAppPay = new \wxpay\wechatAppPay($appid,$mch_id,$notify_url,$key);
    $unifiedOrder = $wechatAppPay->unifiedOrder( $params );

    // 如果失败返回错误
    if($unifiedOrder['return_code'] == 'FAIL'){
        return $this->sendError(-1, $order['return_msg'], 400);
    }

    $retData = array(
        'appid'     => $unifiedOrder['appid'],
        'partnerid' => $unifiedOrder['mch_id'],
        'prepayid'  => $unifiedOrder['prepay_id'],
        'package'   => 'Sign=WXPay',
        'noncestr'  => $unifiedOrder['nonce_str'],
        'timestamp' => time(),
    );

    $retData['sign'] = $wechatAppPay->MakeSign($retData);
    $retData['out_trade_no'] = $params['out_trade_no'];

    return $retData;
}

/**
 * 随机生成红包（单个封顶200）
 * @author wensen  2018-03-27
 * @param  integer $total 红包总金额
 * @param  integer $num   红包个数
 * @return array   红包金额数组
 */
function redPacketGenerate($Allmoney, $Allnum)
{   
    $Allmoney = round($Allmoney, 2);
    $Allnum   = intval($Allnum);

    // 如果刚好是200元的一个红包直接均分
    if ($Allmoney >= ($Allnum * 200)) {
        return array_pad([], $Allnum, 200);
    }

    if ($Allmoney < ($Allnum * 0.01)) {
        exit('钱太少');
    }

    // 获取总红包数据数
    $rand_arr = [];
    for ($i = 0; $i < $Allnum; $i++) {
        $rand_arr[] = rand(1, 100);
    }
    unset($i);

    $chip = $Allmoney / array_sum($rand_arr);    // 均分
    $more = 0.00;                                // 超过两百的余额

    foreach ($rand_arr as $key => $value) {
        $chip_cache = round(($chip * $value), 2);

        if ($chip_cache > 200) {
            $chip_cache_arr[$key] = 200.00;
            $more += $chip_cache - 200.00;
        } else if ($chip_cache <= 0.01) {
            $chip_cache_arr[$key] = 0.01;
        } else {
            $chip_cache_arr[$key] = $chip_cache;
        }

        unset($chip_cache);
    }
    unset($key, $value);

    // 如果有大于200的单个红包则再均分一下（将小的补大）
    if ($more > 0) {
        sort($chip_cache_arr);
        $i = 0;
    
        while (($more > 0) && ($i < $Allnum)) {
            if (($chip_cache_arr[$i] + $more) > 200.00) {
                $more = $more - (200.00 - $chip_cache_arr[$i]);
                $chip_cache_arr[$i] = 200.00;
                ++$i;
            } else {
                $chip_cache_arr[$i] = $chip_cache_arr[$i] + $more;
                $more = 0;
            }
        }
    }

    sort($chip_cache_arr);

    // 用加减法平衡精度
    if (array_sum($chip_cache_arr) > $Allmoney) {
        $chip_cache_arr[0] -= array_sum($chip_cache_arr) - $Allmoney;
    } elseif (array_sum($chip_cache_arr) < $Allmoney) {
        $chip_cache_arr[0] += $Allmoney - array_sum($chip_cache_arr);
    }

    shuffle($chip_cache_arr);

    return $chip_cache_arr;
}

/**
 * 随机生成红包（无封顶）
 * @author wensen  2018-05-15
 * @param  integer $total 红包总金额
 * @param  integer $num   红包个数
 * @return array   红包金额数组
 */
function randRedPacket($Allmoney, $Allnum)
{   
    $Allmoney = round($Allmoney, 2);
    $Allnum   = intval($Allnum);

    if ($Allmoney / $Allnum < 1) {
        return [];
    }

    // 如果刚好是1元的一个红包直接均分
    if ($Allmoney == $Allnum) {
        return array_pad([], $Allnum, 1);
    }

    $Canrand = $Allmoney - $Allnum;

    // 获取总红包数据数
    $rand_arr = [];
    for ($i = 0; $i < $Allnum; $i++) {
        $rand_arr[] = rand(1, 100);
    }
    unset($i);

    $chip = $Canrand / array_sum($rand_arr);    // 均分
    $more = 0.00;                                // 超过两百的余额

    foreach ($rand_arr as $key => $value) {
        $chip_cache = round(($chip * $value), 2);

        $chip_cache_arr[$key] = $chip_cache + 1;

        unset($chip_cache);
    }
    unset($key, $value);


    // 用加减法平衡精度
    $Sumchip = array_sum($chip_cache_arr);
    if ($Sumchip > $Allmoney) {
// dump('大了');        
        $Max = max($chip_cache_arr);
        $chip_cache_arr = array_diff($chip_cache_arr, [$Max]);
        array_push($chip_cache_arr, $Max - ($Sumchip - $Allmoney));
    } elseif ($Sumchip < $Allmoney) {
// dump('小了');  
        $Min = min($chip_cache_arr);
        $chip_cache_arr = array_diff($chip_cache_arr, [$Min]);
        array_push($chip_cache_arr, $Min + ($Allmoney - $Sumchip));
    }

    shuffle($chip_cache_arr);

    return $chip_cache_arr;
}

/**
 * 产生一个指定长度的随机字符串,并返回给用户 
 * @param type $len 产生字符串的长度
 * @return string 随机字符串
 */
function genRandomString($len = 32) 
{
    $chars = array(
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",
    "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",
    "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G",
    "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",
    "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2",
    "3", "4", "5", "6", "7", "8", "9"
    );

    $charsLen = count($chars) - 1;

    // 将数组打乱 
    shuffle($chars);
    $output = "";

    for ($i = 0; $i < $len; $i++) {
        $output .= $chars[mt_rand(0, $charsLen)];
    }

    return $output;
}

/**
 * 从身份证中提取生日,包括15位和18位身份证 
 * @author chenjie 2018-02-06
 * @param  int $IDCard 身份证号码
 * @return array
 */
function getIDCardInfo($IDCard, $format = 1)
{ 
    $result['error'] = 0;     //0：未知错误，1：身份证格式错误，2：无错误 
    $result['flag']  = '';    //0标示成年，1标示未成年 
    $result['tdate'] = '';    //生日，格式如：2012-11-15 

    if(!preg_match("/^(\d{15}$|^\d{18}$|^\d{17}(\d|X|x))$/",$IDCard)){ 
        $result['error'] = 1; 
        return $result; 
    }else{ 
        if(strlen($IDCard) == 18)
        { 
           $tyear  = intval(substr($IDCard,6,4)); 
           $tmonth = intval(substr($IDCard,10,2)); 
           $tday   = intval(substr($IDCard,12,2));
        } else if (strlen($IDCard) == 15){ 
           $tyear  = intval("19".substr($IDCard,6,2)); 
           $tmonth = intval(substr($IDCard,8,2)); 
           $tday   = intval(substr($IDCard,10,2)); 
        }
   
        if($tyear > date("Y") || $tyear < (date("Y")-100)){
            $flag = 0; 
        }elseif($tmonth < 0 || $tmonth > 12){ 
            $flag = 0; 
        }elseif($tday < 0 || $tday > 31){ 
            $flag = 0; 
        }else{ 
            if($format)
            {
                $tdate = $tyear."-".$tmonth."-".$tday; 
            }else{
                $tdate = $tmonth."-".$tday; 
            }
     
            if((time()-mktime(0,0,0,$tmonth,$tday,$tyear)) > 18*365*24*60*60)
            { 
                $flag=0; 
            }else{ 
                $flag=1; 
            } 
        }  
    } 

    $result['error']    = 2;       // 0：未知错误，1：身份证格式错误，2：无错误 
    $result['isAdult']  = $flag;   // 0标示成年，1标示未成年 
    $result['birthday'] = $tdate;  // 生日日期
    $result['tyear']    = $tyear;  //出生年份
    $result['tmonth']   = $tmonth; //出生月份
    $result['tday']     = $tday;   //出生日

    return $result; 
}

/**
 * @uses   根据生日计算年龄，年龄的格式是：2016-09-23
 * @param  string $birthday
 * @return string|number
 */
function calcAge($birthday) 
{
    $dayarray = explode('-', $birthday);
    $dayarray = array_filter($dayarray);

    if (count($dayarray) < 3) {
        return 0;
    }

    $iage = 0;

    if (!empty($birthday)) {
        $year  = date('Y', strtotime($birthday));
        $month = date('m', strtotime($birthday));
        $day   = date('d', strtotime($birthday));

        $now_year  = date('Y');
        $now_month = date('m');
        $now_day   = date('d');

        if ($now_year > $year) {
            $iage = $now_year - $year - 1;

            if ($now_month > $month) {
                $iage++;
            } else if ($now_month == $month) {
                if ($now_day >= $day) {
                    $iage++;
                }
            }
        }
    }
    return $iage;
}

// /**
//  * @title 对字符串的表情进行编码
//  * @author wensen 2018-03-16
//  * @param string str 带有表情的字符串
//  * @return string  编码后的字符串
//  * @desc 对字符串的表情进行编码
//  */
// function emoji2str($str)
// { 
//     $strEncode = '';
//     $length    = mb_strlen($str,'utf-8');
    
//     for ($i=0; $i < $length; $i++) { 
//         $_tmpStr = mb_substr($str,$i,1,'utf-8'); 

//         if(strlen($_tmpStr) >= 4){ 
//             $strEncode .= '[[EMOJI:'.rawurlencode($_tmpStr).']]'; 
//         }else{
//             $strEncode .= $_tmpStr; 
//         } 
//     }

//     return $strEncode; 
// } 

// /**
//  * @title 对字符串的表情进行反编码
//  * @author wensen 2018-03-16
//  * @param string str 带有编码后表情的字符串
//  * @return string  原来带表情的字符串
//  * @desc 将字符串中的编码后的表情进行反编码
//  */
// function str2emoji($str)
// { 
//     $strDecode = preg_replace_callback("/[[EMOJI:(.*?)]]/", function($matches){ 
//         return rawurldecode($matches[1]); 
//     }, $str); 

//     return $strDecode; 
// }

// /**
//  * 生成平分红包
//  * @author wensen 2018-03-16
//  * @param  integer $total 红包总金额
//  * @param  integer $num   红包个数
//  * @return array 金额数组
//  */
// function avgRedPacketGenerate($money_total, $num)
// {
//     if ($money_total < ($num * 0.01)) {
//         return false;
//     }

//     $chip = round(($money_total / $num), 2);

//     if ($money_total == ($chip * $num)) {
//         for ($i=0; $i < $num; $i++) { 
//             $res[] = $chip;
//         }
//     } else {
//         for ($i=0; $i < $num - 1; $i++) { 
//             $res[] = $chip;
//         }

//         $res[] = $money_total - ($chip * ($num - 1));
//     }

//     shuffle($res);   // 打乱数组

//     return $res;
// }

/** 
 * 过滤特殊字符串
 * @author wensen 2018-03-30
 * @access public 
 * @param  string   $str   字符串
 * @return string   数据库数据或者处理后数据
 */
function strFilter($str) 
{
    $str = str_replace(' ', '', $str);
    $str = str_replace('', '', $str);
    $str = str_replace('`', '', $str);
    $str = str_replace('·', '', $str);
    $str = str_replace('~', '', $str);
    $str = str_replace('!', '', $str);
    $str = str_replace('！', '', $str);
    $str = str_replace('@', '', $str);
    $str = str_replace('#', '', $str);
    $str = str_replace('$', '', $str);
    $str = str_replace('￥', '', $str);
    $str = str_replace('%', '', $str);
    $str = str_replace('^', '', $str);
    $str = str_replace('……', '', $str);
    $str = str_replace('&', '', $str);
    $str = str_replace('*', '', $str);
    $str = str_replace('(', '', $str);
    $str = str_replace(')', '', $str);
    $str = str_replace('（', '', $str);
    $str = str_replace('）', '', $str);
    $str = str_replace('-', '', $str);
    $str = str_replace('——', '', $str);
    $str = str_replace('+', '', $str);
    $str = str_replace('=', '', $str);
    $str = str_replace('|', '', $str);
    $str = str_replace('\\', '', $str);
    $str = str_replace('[', '', $str);
    $str = str_replace(']', '', $str);
    $str = str_replace('【', '', $str);
    $str = str_replace('】', '', $str);
    $str = str_replace('{', '', $str);
    $str = str_replace('}', '', $str);
    $str = str_replace(';', '', $str);
    $str = str_replace('；', '', $str);
    $str = str_replace(':', '', $str);
    $str = str_replace('：', '', $str);
    $str = str_replace('\'', '', $str);
    $str = str_replace('"', '', $str);
    $str = str_replace('“', '', $str);
    $str = str_replace('”', '', $str);
    $str = str_replace(',', '', $str);
    $str = str_replace('，', '', $str);
    $str = str_replace('<', '', $str);
    $str = str_replace('>', '', $str);
    $str = str_replace('《', '', $str);
    $str = str_replace('》', '', $str);
    $str = str_replace('.', '', $str);
    $str = str_replace('。', '', $str);
    $str = str_replace('/', '', $str);
    $str = str_replace('、', '', $str);
    $str = str_replace('?', '', $str);
    $str = str_replace('？', '', $str);

    return trim($str);
}

/** 
 * 根据生日获取年龄
 * @author wensen 2018-04-02
 * @access public 
 * @param  string  birthday   字符串 2018-04-02
 * @return int     age        年龄
 */
function birthdayToAge($birthday)
{
    list($year, $month, $day) = explode("-", $birthday);

    $year_diff  = date("Y") - $year;
    $month_diff = date("m") - $month;
    $day_diff   = date("d") - $day;

    if ($day_diff < 0 || $month_diff < 0)
        $year_diff--;

    return $year_diff;
}

// /**
//  * 预留豹子号，并返回用户id 
//  * @return int 新用户id
//  */
// function getNewUserid() 
// {
//     // 获取最后一个用户ID
//     $LastUserid = db('user')->where('delete_id', 0)->limit(1)->order('id desc')->lock(true)->value('id');

//     if (empty($LastUserid)) {
//         return false;
//     }

//     if (chcekBaozi($LastUserid + 1) == true) {
//         $NewUserid = $LastUserid + 2;
//     } else {
//         $NewUserid = $LastUserid + 1;
//     }

//     return $NewUserid;
// }

/**
 * 预留豹子号，并返回用户编号 
 * @return int 新用户id
 */
function getNewUserNo() 
{
    $Userno = 0;

    // 获取最后一个用户ID
    $LastUserid = db('user')->where('delete_id', 0)->limit(1)->order('id desc')->lock(true)->value('id');

    if (empty($LastUserid)) {
        $LastUserid = 10001;
    }

    if (intval($LastUserid) < 10000) {
        $Userno = 10000 + $LastUserid;
    } else {
        $Userno = $LastUserid + 1;
    }

    while (true) {
        $cache = db('user')
            ->where('no', $Userno)
            ->where('delete_id', 0)
            ->lock(true)
            ->value('id');

        if (empty($cache) && (chcekList($Userno) == false) && (chcekBaozi($Userno) == false)) {
            break;
        } else {
            ++$Userno;
        }
    }
    
    return $Userno;
}

/**
 * 预留用户编号
 * @return bool 是否为预留编号：true是|false否
 */
function chcekList($Number) 
{
    if (empty($Number)) {
        return false;
    }

    $str = [
        '168',
        '168168',
        '168168168',
        '888168',
        '888188',
        '22224',
    ];

    if (!in_array($Number, $str)) {
        return false;
    }

    return true;
}

/**
 * 判断数字是否为豹子号
 * @return bool 是否为豹子号：true是|false否
 */
function chcekBaozi($Number) 
{
    $str = strval($Number);
    if (empty($str) || (strlen($str) < 5)) {
        return false;
    }

    for ($i=1; $i < strlen($str); $i++) {
        $First = $str[0];
        if ($First != $str[$i]) {
            return false;
        }
    }

    return true;
}

/**
 * 生成唯一受理单号
 * @table 需要检测唯一订单号的表名
 * @file  对应查询字段名
 * @return string
 */
function build_accept_no($table = NULL, $file = 'order_no') {
    $no = date('Ymd') . substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);

    // 检测是否存在
    if ($table) {
        $db = db($table);
        $info = $db->where(array($file => $no))->find();
    }

    $info && $no = build_accept_no($table, $file);

    return $no;
}
 
/**
 * 判断是否为合法的身份证号码
 * @param $vStr
 * @return int
 */
function isCreditNo($vStr) {
    $vCity = array(
        '11','12','13','14','15','21','22',
        '23','31','32','33','34','35','36',
        '37','41','42','43','44','45','46',
        '50','51','52','53','54','61','62',
        '63','64','65','71','81','82','91'
    );
    if (!preg_match('/^([\d]{17}[xX\d]|[\d]{15})$/', $vStr)) return false;

    if (!in_array(substr($vStr, 0, 2), $vCity)) return false;

    $vStr    = preg_replace('/[xX]$/i', 'a', $vStr);
    $vLength = strlen($vStr);

    if ($vLength == 18) {
        $vBirthday = substr($vStr, 6, 4) . '-' . substr($vStr, 10, 2) . '-' . substr($vStr, 12, 2);
    } else {
        $vBirthday = '19' . substr($vStr, 6, 2) . '-' . substr($vStr, 8, 2) . '-' . substr($vStr, 10, 2);
    }

    if (date('Y-m-d', strtotime($vBirthday)) != $vBirthday) return false;

    if ($vLength == 18) {
        $vSum = 0;
        for ($i = 17 ; $i >= 0 ; $i--) {
            $vSubStr = substr($vStr, 17 - $i, 1);
            $vSum += (pow(2, $i) % 11) * (($vSubStr == 'a') ? 10 : intval($vSubStr , 11));
        }
        
        if($vSum % 11 != 1) return false;
    }

    return true;
}
