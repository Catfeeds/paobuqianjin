<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | Company: YG | User: ShouKun Liu  |  Email:24147287@qq.com  | Time:2017/2/28 18:13
// +----------------------------------------------------------------------
// | TITLE:文档列表
// +----------------------------------------------------------------------

return [
    '1' => ['name' => '跑步钱进文档', 'id' => '1', 'parent' => '0', 'class' => '', 'readme' => ''],//下面有子列表为一级目录
    '2' => ['name' => '圈子相关接口文档', 'id' => '2', 'parent' => '1', 'readme' => '', 'class' => ''], //Index接口文档
	'3' => ['name' => '圈子接口', 'id' => '3', 'parent' => '2', 'readme' => '', 'class' => \app\v1\controller\Circle::class],           //圈子接口文档
	'4' => ['name' => '圈子类型接口', 'id' => '4', 'parent' => '2', 'readme' => '', 'class' => \app\v1\controller\CircleType::class],   //圈子类型接口文档
	'5' => ['name' => '圈子目标接口', 'id' => '5', 'parent' => '2', 'readme' => '', 'class' => \app\v1\controller\CircleTarget::class], //圈子目标接口文档
	'6' => ['name' => '圈子成员接口', 'id' => '6', 'parent' => '2', 'readme' => '', 'class' => \app\v1\controller\CircleMember::class], //圈子成员接口文档
	'7' => ['name' => '圈子订单接口', 'id' => '7', 'parent' => '2', 'readme' => '', 'class' => \app\v1\controller\CircleOrder::class],  //圈子订单接口文档
	'8' => ['name' => '订单类型接口', 'id' => '8', 'parent' => '2', 'readme' => '', 'class' => \app\v1\controller\OrderType::class],
	'9' => ['name' => '圈子标签接口', 'id' => '9', 'parent' => '2', 'readme' => '', 'class' => \app\v1\controller\CircleTags::class],
    '10' => ['name' => '圈子封面接口', 'id' => '10', 'parent' => '2', 'readme' => '', 'class' => \app\v1\controller\CircleCover::class],

	'11' => ['name' => '动态相关接口文档', 'id' => '11', 'parent' => '1', 'readme' => '', 'class' => ''],
	'12' => ['name' => '动态接口', 'id' => '12', 'parent' => '11', 'readme' => '', 'class' => \app\v1\controller\Dynamic::class],
	'13' => ['name' => '动态评论接口', 'id' => '13', 'parent' => '11', 'readme' => '', 'class' => \app\v1\controller\DynamicComment::class],
	'14' => ['name' => '动态点赞接口', 'id' => '14', 'parent' => '11', 'readme' => '', 'class' => \app\v1\controller\DynamicVote::class],

    '15' => ['name' => '用户相关接口文档', 'id' => '15', 'parent' => '1', 'readme' => '', 'class' => ''], //User接口文档
    '16' => ['name' => '用户相关接口', 'id' => '16', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\User::class],
    '17' => ['name' => '用户步数接口', 'id' => '17', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserStep::class],
    '18' => ['name' => '用户认证接口', 'id' => '18', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserAuthentication::class],
    '19' => ['name' => '用户步币记录接口', 'id' => '19', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserCredit::class],
    '20' => ['name' => '用户关注接口', 'id' => '20', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserFollow::class],
    '21' => ['name' => '用户好友接口', 'id' => '21', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserFriends::class], //用户好友接口
    '22' => ['name' => '用户消息接口', 'id' => '22', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserMessages::class],
    '23' => ['name' => '用户消息类型接口', 'id' => '23', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserMessagesType::class],
    

    '25' => ['name' => '我的钱包相关接口', 'id' => '25', 'parent' => '1', 'readme' => '', 'class' => ''], //用户提现接口
    '26' => ['name' => '用户收益接口', 'id' => '26', 'parent' => '25', 'readme' => '', 'class' => \app\v1\controller\Income::class],
    '27' => ['name' => '用户提现接口', 'id' => '27', 'parent' => '25', 'readme' => '', 'class' => \app\v1\controller\WithDraw::class],
    '28' => ['name' => '我的邀请接口', 'id' => '28', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserInviter::class],
    '29' => ['name' => '用户收益类型接口', 'id' => '29', 'parent' => '25', 'readme' => '', 'class' => \app\v1\controller\IncomeType::class],

    '30' => ['name' => '其它接口文档', 'id' => '30', 'parent' => '1', 'readme' => '', 'class' => ''], //反馈接口文档
    '31' => ['name' => '用户反馈信息接口', 'id' => '31', 'parent' => '30', 'readme' => '', 'class' => \app\v1\controller\FeedBack::class],
    '32' => ['name' => '获取反馈类型接口', 'id' => '32', 'parent' => '30', 'readme' => '', 'class' => \app\v1\controller\FeedBackType::class],
    '33' => ['name' => '关于我们类型接口', 'id' => '33', 'parent' => '30', 'readme' => '', 'class' => \app\v1\controller\AboutType::class],
    '34' => ['name' => '关于我们内容接口', 'id' => '34', 'parent' => '30', 'readme' => '', 'class' => \app\v1\controller\About::class],

    '35' => ['name' => '商户相关接口文档', 'id' => '35', 'parent' => '1', 'readme' => '', 'class' => ''], //商户相关接口文档
    '36' => ['name' => '商户接口', 'id' => '36', 'parent' => '35', 'readme' => '', 'class' => \app\v1\controller\Business::class], //商户接口

    '37' => ['name' => '任务相关接口文档', 'id' => '37', 'parent' => '1', 'readme' => '', 'class' => ''], //商户相关接口文档
    '38' => ['name' => '发布任务接口', 'id' => '38', 'parent' => '37', 'readme' => '', 'class' => \app\v1\controller\Task::class], //商户接口
    '39' => ['name' => '我的任务接口', 'id' => '39', 'parent' => '37', 'readme' => '', 'class' => \app\v1\controller\TaskRecord::class], //商户接口
    '40' => ['name' => '通用支付接口', 'id' => '40', 'parent' => '30', 'readme' => '', 'class' => \app\v1\controller\Pay::class],

    '41' => ['name' => '用户银行卡接口', 'id' => '41', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserBankCard::class],
    '42' => ['name' => '第三方接口', 'id' => '42', 'parent' => '30', 'readme' => '', 'class' => \app\v1\controller\ThirdParty::class],
    '43' => ['name' => '用户段位接口', 'id' => '43', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserLevel::class],

    '44' => ['name' => '活动数据接口文档', 'id' => '44', 'parent' => '1', 'readme' => '', 'class' => ''],
    '45' => ['name' => '活动数据接口', 'id' => '45', 'parent' => '44', 'readme' => '', 'class' => \app\v1\controller\Activity::class],

    '47' => ['name' => '复合接口文档', 'id' => '47', 'parent' => '1', 'readme' => '', 'class' => ''],
    '48' => ['name' => '复合接口', 'id' => '48', 'parent' => '47', 'readme' => '', 'class' => \app\v1\controller\Zcomposite::class],

    '49' => ['name' => '协议文档接口', 'id' => '49', 'parent' => '30', 'readme' => '', 'class' => \app\v1\controller\Zfile::class],

    '24' => ['name' => '用户位置接口', 'id' => '24', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserLocation::class],
    '51' => ['name' => '用户登录记录接口', 'id' => '51', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserRecord::class],

    '52' => ['name' => '红包接口文档', 'id' => '52', 'parent' => '1', 'readme' => '', 'class' => ''], 
    '53' => ['name' => '红包接口', 'id' => '53', 'parent' => '52', 'readme' => '', 'class' => \app\v1\controller\Redpacket::class], 
   
    '54' => ['name' => '小程序登录文档', 'id' => '54', 'parent' => '1', 'readme' => '', 'class' => ''], 
    '55' => ['name' => '小程序登录接口', 'id' => '55', 'parent' => '54', 'readme' => '', 'class' => \app\v1\controller\Wxsmall::class], 

    '56' => ['name' => '会员接口', 'id' => '56', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserVip::class], 
    '57' => ['name' => '商户会员接口', 'id' => '57', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\UserVipCus::class], 


    '58' => ['name' => '苹果内购文档', 'id' => '58', 'parent' => '1', 'readme' => '', 'class' => ''], 
    '59' => ['name' => '苹果内购接口', 'id' => '59', 'parent' => '58', 'readme' => '', 'class' => \app\v1\controller\AppleInternal::class], 

    '60' => ['name' => '支付密码接口', 'id' => '60', 'parent' => '15', 'readme' => '', 'class' => \app\v1\controller\PayPassword::class],

    '61' => ['name' => '红包记录接口', 'id' => '61', 'parent' => '52', 'readme' => '', 'class' => \app\v1\controller\RedpacketRecord::class], 


];
