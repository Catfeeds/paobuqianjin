<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

use think\Route;

//首页
Route::any('/', function() {
    return redirect('wiki');
});

Route::group('v1', function() {
    // 获取活动列表
    Route::any('Activity/getActivityList', 'v1/Activity/getActivityList');
    // 加入活动
    Route::post('Activity/joinActivity', 'v1/Activity/joinActivity');
    // 领取活动奖励（红包）
    Route::post('Activity/redActivity', 'v1/Activity/redActivity');
    // 活动路由
    Route::resource('Activity', 'v1/Activity');

    // 用户登录接口
    Route::any('user/login', 'v1/User/login');
    // 用户退出接口
    Route::any('user/logOut', 'v1/User/logOut');
    // 刷新秘钥接口
    Route::any('user/refreshToken', 'v1/User/refreshToken');
    // 用户登录接口
    Route::any('user/weixinlogin', 'v1/User/weixinLogin');
    // 消息详情路由
    Route::any('usermessages/detail', 'v1/UserMessages/detail');
    // 获取附近的人
    Route::get('user/getNearbyPeople', 'v1/User/getNearbyPeople');
    // 根据手机号修改密码
    Route::post('user/modifyPasswordByMobile', 'v1/User/modifyPasswordByMobile');
    // 根据原密码修改密码
    Route::post('user/modifyPasswordByOldPassword', 'v1/User/modifyPasswordByOldPassword');
    // 判断手机号码是否已经注册
    Route::post('user/chcekMobile', 'v1/User/chcekMobile');
    // 绑定手机号
    Route::post('user/bindMobile', 'v1/User/bindMobile');
    // 绑定已存在的手机号（强制绑定，并清掉openid）
    Route::post('user/forceBindMobile', 'v1/User/forceBindMobile');
    // 绑定登陆方式
    Route::post('user/bindOpenid', 'v1/User/bindOpenid');
    // 手机号登陆
    Route::post('user/login', 'v1/User/login');
    // 第三方登陆
    Route::post('user/thirdPartyLogin', 'v1/User/thirdPartyLogin');
    // 手机验证码登录
    Route::post('user/mobileCodeRegister', 'v1/User/mobileCodeRegister');
    // 手机验证码登录
    Route::get('user/checkUserStatus', 'v1/User/checkUserStatus');
    // 解绑账号（手机、微信、qq）
    Route::post('user/userUntie', 'v1/User/userUntie');
    // 用户资源路由
    Route::resource('user', 'v1/User');

    // 小程序登录（post）
    Route::post('Wxsmall/smallLogin', 'v1/Wxsmall/smallLogin');
    // 小程序登录（get）
    Route::get('Wxsmall/getSmallLogin', 'v1/Wxsmall/getSmallLogin');
    // 根据encrypted和iv获取数据
    Route::post('Wxsmall/getUserStep', 'v1/Wxsmall/getUserStep');
    // 获取小程序二维码
    Route::post('Wxsmall/getQrcode', 'v1/Wxsmall/getQrcode');
    // 手机验证码登录（并注册）
    Route::post('Wxsmall/mobileCodeRegister', 'v1/Wxsmall/mobileCodeRegister');
    // 小程序开关
    Route::get('Wxsmall/getSwitch', 'v1/Wxsmall/getSwitch');
    // 获取分享的模板
    Route::get('Wxsmall/getShare', 'v1/Wxsmall/getShare');

    // 获取腾讯云cos签名
    Route::get('Cosauth/getCosAuth', 'v1/Cosauth/getCosAuth');

    // 用户登录记录资源路由
    Route::resource('userrecord', 'v1/UserRecord');

    // 会员资源路由
    Route::resource('UserVip', 'v1/UserVip');

    // 商户会员资源路由
    Route::resource('UserVipCus', 'v1/UserVipCus');

    // 用户位置
    Route::post('userlocation/setLocation', 'v1/UserLocation/setLocation');
    // 用户位置资源路由
    Route::resource('userlocation', 'v1/UserLocation');

    // 用户步数资源路由
    Route::post('UserStep/updateStep', 'v1/UserStep/updateStep');
    // 用户步数资源路由
    Route::resource('UserStep', 'v1/UserStep');

    // 充值创建订单
    Route::post('income/Recharge', 'v1/Income/Recharge');
    // 根据用户ID获取充值记录
    Route::get('income/getRecharge', 'v1/Income/getRecharge');
    // 用户收益记录资源路由
    Route::resource('income', 'v1/Income');
    // 用户收益类型记录资源路由
    Route::resource('incometype', 'v1/IncomeType');

    // 手机银行卡身份证用户名认证
    Route::post('userauthentication/realAuth', 'v1/UserAuthentication/realAuth');
    // 获取用户认证状态
    Route::get('userauthentication/userAuthState', 'v1/UserAuthentication/userAuthState');
    // 合利宝wap支付
    Route::post('userauthentication/wapPay', 'v1/UserAuthentication/wapPay');
    // 合利宝云闪付
    //Route::post('userauthentication/quickSdkMerchant', 'v1/UserAuthentication/quickSdkMerchant');
    
    // 合利宝云闪付支付订单查询
    Route::post('Pay/quickPayQuery', 'v1/Pay/quickPayQuery');
    // 合利宝云闪付支付回调
    Route::post('Pay/quickPayNotify', 'v1/Pay/quickPayNotify');
    // 合利宝微信wap支付回调
    Route::post('Pay/wxWapPayNotify', 'v1/Pay/wxWapPayNotify');

    // 合利宝提现
    Route::post('userauthentication/withDrawToBank', 'v1/UserAuthentication/withDrawToBank');

    // 用户身份验证资源路由
    Route::resource('userauthentication', 'v1/UserAuthentication');

    // 用户步币信息资源路由
    Route::resource('usercredit', 'v1/UserCredit');
    
    // 用户反馈资源路由
    Route::resource('feedback', 'v1/FeedBack');
    // 获取反馈类型资源路由
    Route::resource('feedbacktype', 'v1/FeedBackType');
    // 获取段位列表资源路由
    Route::resource('userlevel', 'v1/UserLevel');

    
    // 获取我的邀请码
    Route::get('UserInviter/getMyCode', 'v1/UserInviter/getMyCode');
    // 发短信邀请好友（手机通讯录）
    Route::post('UserInviter/inviteMsg', 'v1/UserInviter/inviteMsg');
    // 获取我的邀请数据和我的邀请人列表
    Route::post('UserInviter/postRegister', 'v1/UserInviter/postRegister');
    // 好友注册（被邀请）
    Route::any('UserInviter/getMyInviter', 'v1/UserInviter/getMyInviter');
    // 邀请排行榜资源路由
    Route::resource('UserInviter', 'v1/UserInviter');

    // 充值记录
    Route::post('withdraw/rechargeList', 'v1/WithDraw/rechargeList');
    // 旧提现
    Route::post('withdraw/withdrawOld', 'v1/WithDraw/withdrawOld');
    // 自动提现到公司账户
    Route::get('AutoWithdraw/withdrawToCompany', 'v1/AutoWithdraw/withdrawToCompany');
    // 提现信息资源路由
    Route::resource('withdraw', 'v1/WithDraw');

    // 提现信息资源路由
    Route::resource('withdrawtype', 'v1/WithDrawType');
    // 关于我们资源路由
    Route::resource('about', 'v1/About');
    // 关于我们类型资源路由
    Route::resource('abouttype', 'v1/AboutType');
    // 消息类型资源路由
    Route::resource('usermessagestype', 'v1/UserMessagesType');
    // 消息资源路由
    Route::resource('usermessages', 'v1/UserMessages');
    // 圈子排行路由
    Route::get('Circle/getRank', 'v1/Circle/getRank');
    // 圈子排行路由
    Route::get('Circle/getUserCircleRank', 'v1/Circle/getUserCircleRank');
    // 红包路由
    Route::any('Circle/sendRedBag', 'v1/Circle/sendRedBag');
    // 用户在圈子中的排行榜
    Route::any('Circle/UserCircleWeekRank', 'v1/Circle/UserCircleWeekRank');
    // 用户在圈子中的排行名次
    Route::any('Circle/UserCircleWeekNum', 'v1/Circle/UserCircleWeekNum');
    // 获取圈子基本信息（跳过验证）
    Route::any('Circle/getCircleBase', 'v1/Circle/getCircleBase');
    // 圈子路由
    Route::resource('Circle', 'v1/Circle');
    // 圈子类型路由
    Route::resource('CircleType', 'v1/CircleType');
    // 圈子成员退出圈子路由
    Route::post('CircleMember/signOutCirscle', 'v1/CircleMember/signOutCirscle');
    // 圈子成员退出圈子路由(get方法)
    Route::get('CircleMember/signOutCirscleGet', 'v1/CircleMember/signOutCirscleGet');
    // 圈子成员路由
    Route::resource('CircleMember', 'v1/CircleMember');
    // 圈子创建订单路由
    Route::post('CircleOrder/CreateOrder', 'v1/CircleOrder/CreateOrder');
    // 圈子订单路由
    Route::resource('CircleOrder', 'v1/CircleOrder');
    // 圈子订单目标路由
    Route::resource('CircleTarget', 'v1/CircleTarget');
    // 订单类型路由
    Route::resource('OrderType', 'v1/OrderType');
    // 圈子标签路由
    Route::resource('CircleTags', 'v1/CircleTags');
    // 圈子封面路由
    Route::resource('CircleCover', 'v1/CircleCover');

    // 获取用户个人动态
    Route::get('Dynamic/getUserDynamic', 'v1/Dynamic/getUserDynamic');

    // 动态路由
    Route::resource('Dynamic', 'v1/Dynamic');
    // 动态评论路由
    Route::any('DynamicComment/getComment', 'v1/DynamicComment/getComment');
    // 动态评论路由
    Route::resource('DynamicComment', 'v1/DynamicComment');

    // 动态点赞路由
    Route::resource('DynamicVote', 'v1/DynamicVote');
    // 圈子标签记录路由
    Route::resource('CircleTagsRecord', 'v1/CircleTagsRecord');
    // 关注状态
    Route::post('UserFollow/followStatus', 'v1/UserFollow/followStatus');
    // 关注状态
    Route::post('UserFollow/addressBook', 'v1/UserFollow/addressBook');
    // 用户我的粉丝路由
    Route::resource('UserFollow', 'v1/UserFollow');
    // 我的好友周榜单路由
    Route::get('UserFriends/getUserFriendSort', 'v1/UserFriends/getUserFriendSort');
    // 我的好友周排名路由
    Route::get('UserFriends/getUserSort', 'v1/UserFriends/getUserSort');
    // 我的好友路由
    Route::resource('UserFriends', 'v1/UserFriends');
    // 验证码校验
    Route::post('UserBankCard/checkCode', 'v1/UserBankCard/checkCode');
    // 根据银行卡号获取详细信息
    Route::get('UserBankCard/getBankCardData', 'v1/UserBankCard/getBankCardData');
    // 获取用户的银行卡列表
    Route::get('UserBankCard/getCardList', 'v1/UserBankCard/getCardList');
    // 银行卡路由
    Route::resource('UserBankCard', 'v1/UserBankCard');

    // 获取用户商户列表
    Route::post('Business/getUserBusiness', 'v1/Business/getUserBusiness');
    // 创建商户
    Route::post('Business/addBusiness', 'v1/Business/addBusiness');
    // 删除商户图片（伪删除）
    Route::post('Business/deleteBusImg', 'v1/Business/deleteBusImg');
    // 设置默认商户
    Route::post('Business/setDefaultBusiness', 'v1/Business/setDefaultBusiness');
    // 修改商户信息（自动判断图片增删）
    Route::post('Business/updateBusiness', 'v1/Business/updateBusiness');
    // 商户路由
    Route::resource('Business', 'v1/Business');

    // 领取红包
    Route::post('Redpacket/receiveRed', 'v1/Redpacket/receiveRed');
    // 红包资源路由
    Route::resource('Redpacket', 'v1/Redpacket');

    // 获取红包领取记录
    Route::get('RedpacketRecord/letRedList', 'v1/RedpacketRecord/letRedList');
    // 红包记录资源路由
    Route::resource('RedpacketRecord', 'v1/RedpacketRecord');

    // 任务发布路由
    Route::resource('Task', 'v1/Task');
    // 发布任务选择好友
    Route::get('TaskRecord/getFriends', 'v1/TaskRecord/getFriends');
    // 我的任务路由
    Route::resource('TaskRecord', 'v1/TaskRecord');
    // 微信支付创建订单
    Route::post('Pay/createOrder', 'v1/Pay/createOrder');

    // 微信小程序支付
    Route::post('Pay/createRechargeOrder', 'v1/Pay/createRechargeOrder');
    // 小程序支付回调
    Route::post('Pay/notifyUrlApi', 'v1/Pay/notifyUrlApi');
    // 微信支付回调
    Route::post('Pay/WxNotify', 'v1/Pay/WxNotify');
    // 微信支付回调
    Route::post('Pay/AliNotify', 'v1/Pay/AliNotify');
    // 微信订单查询
    Route::get('Pay/orderQuery', 'v1/Pay/orderQuery');
    // 微信支付路由
    Route::resource('Payment', 'v1/Payment');
    
    // 第三方接口 天气查询
    Route::get('ThirdParty/getWeather', 'v1/ThirdParty/getWeather');
    // 第三方接口 短信发送接口
    Route::get('ThirdParty/sendMsg', 'v1/ThirdParty/sendMsg');

    // 将未完成任务金额退回用户余额中
    Route::get('Refund/refundTask', 'v1/Refund/refundTask');
    // 将未领取的商户红包退回用户余额中
    Route::get('Refund/refundRedpacket', 'v1/Refund/refundRedpacket');
    
    // 首页（复合数据接口）
    Route::post('Zcomposite/homePage', 'v1/Zcomposite/homePage');
    // 圈子（复合数据接口）
    Route::post('Zcomposite/circleData', 'v1/Zcomposite/circleData');
    // 任务（复合数据接口）
    Route::post('Zcomposite/taskData', 'v1/Zcomposite/taskData');
    // 榜单（复合数据接口）
    Route::post('Zcomposite/rankData', 'v1/Zcomposite/rankData');
    // 榜单-圈子榜单（复合数据接口）
    Route::post('Zcomposite/rankCircleData', 'v1/Zcomposite/rankCircleData');
    // 我的（复合数据接口）
    Route::post('Zcomposite/myData', 'v1/Zcomposite/myData');
    // 用户主页（复合数据接口）
    Route::post('Zcomposite/ouserData', 'v1/Zcomposite/ouserData');

    // 获取协议
    Route::post('Zfile/getFile', 'v1/Zfile/getFile');
    // 测试表情
    Route::post('Zfile/testLook', 'v1/Zfile/testLook');

    // 苹果内购验证
    Route::post('AppleInternal/appleValidate', 'v1/AppleInternal/appleValidate');

    // 检测是否设置支付密码（支付密码）
    Route::get('PayPassword/chcekPw', 'v1/PayPassword/chcekPw');
    // 验证支付密码（支付密码）
    Route::post('PayPassword/validatePw', 'v1/PayPassword/validatePw');
    // 修改支付密码（支付密码）
    Route::post('PayPassword/modifyPw', 'v1/PayPassword/modifyPw');
    // 强制修改支付密码（支付密码）
    Route::post('PayPassword/powerModifyPw', 'v1/PayPassword/powerModifyPw');
    // 添加支付密码（支付密码）
    Route::post('PayPassword/addPw', 'v1/PayPassword/addPw');
    // 添加支付密码，验证实名（支付密码）
    Route::post('PayPassword/realAddPw', 'v1/PayPassword/realAddPw');
    // 验证银行卡信息（支付密码）
    Route::post('PayPassword/validateUserBank', 'v1/PayPassword/validateUserBank');
    // 添加并验证银行卡信息（支付密码）
    Route::post('PayPassword/addUserBank', 'v1/PayPassword/addUserBank');

});

Route::any('accessToken', 'v1/auth/accessToken');    // Oauth

// 文档
\DawnApi\route\DawnRoute::wiki();

return [
    '__pattern__' => [
        'name' => '\w+',
    ],
];
