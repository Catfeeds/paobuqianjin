<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/4/3 17:11:50
// +----------------------------------------------------------------------
// | TITLE: 秘钥类（用于生成token、匹配token）
// +----------------------------------------------------------------------

namespace app\v1\auth;

use RandomLib\Factory;
use think\Cache;
use think\Request;
use think\Db;

class AccessToken
{
    /**
     * 过期时间秒数（7天）
     *
     * @var int
     */
    public static $expires = 604800;

    /**
     * accessToken存储前缀
     *
     * @var string
     */
    public static $accessTokenPrefix = 'paobuqianjin_Token_';

    /**
     * accessTokenAndClientPrefix存储前缀
     *
     * @var string
     */
    public static $accessTokenAndClientPrefix = 'paobuqianjin_TokenAndClient_';

    /**
     * 根据用户id端获取access_token
     * @param  int    Userid       用户id
     * @return string access_token 客户端秘钥
     */
    public function getToken($Userid)
    {   
        $Userid = intval($Userid);

        if (empty($Userid)) {
            return false;
        }

        // 通过下放令牌
        $access_token = $this->setAccessToken($Userid);

        if (empty($access_token)) {
            return false;
        } else {
            return $access_token;
        }
    }

    /**
     * 设置AccessToken
     * @param $clientInfo
     * @return int
     */
    public function setAccessToken($Userid)
    {
        // 生成令牌
        $accessToken = self::buildAccessToken();

        $accessTokenInfo = [
            'access_token' => $accessToken,             // 访问令牌
            'expires_time' => time() + self::$expires,  // 过期时间时间戳
            'userid'       => $Userid,                  // 用户信息
        ];

        self::saveAccessToken($accessToken, $accessTokenInfo);

        return $Userid . ':' . $accessToken;
    }

    /**
     * 生成AccessToken
     * @return string
     */
    public static function buildAccessToken()
    {
        //生成AccessToken
        $factory = new Factory();
        $generator = $factory->getMediumStrengthGenerator();

        return $generator->generateString(32, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
    }

    /**
     * 存储
     * @param $accessToken
     * @param $accessTokenInfo
     */
    protected static function saveAccessToken($accessToken, $accessTokenInfo)
    {
        //存储accessToken
        Cache::set(self::$accessTokenPrefix . $accessTokenInfo['userid'], $accessToken, self::$expires);
        //存储用户与信息索引 用于比较
        Cache::set(self::$accessTokenAndClientPrefix . $accessTokenInfo['userid'], $accessTokenInfo, self::$expires);
    }

    /**
     * 匹配Token
     * @return bool
     */
    public function chcekAccessToken(Request $request)
    {  
        $Headtoken = self::graspTheHead($request);

        // 手动生成测试的token
        //存储accessToken
        // Cache::set(self::$accessTokenPrefix . $Headtoken['userid'], $Headtoken['token'], self::$expires);
        // //存储用户与信息索引 用于比较
        // // $Headtoken['expires'] = self::$expires + time();
        // Cache::set(self::$accessTokenAndClientPrefix . $Headtoken['userid'], $Headtoken, self::$expires);

        // 抓不到token
        if (empty($Headtoken)) {
            $error = [
                'error'   => -100,
                'message' => '秘钥为空',
                'code'    => 400,
            ];
            exit(json_encode($error, JSON_UNESCAPED_UNICODE));
        }

        $old_Token = Cache::get(self::$accessTokenPrefix . $Headtoken['userid']);
        $old_Token_key = Cache::get(self::$accessTokenAndClientPrefix . $Headtoken['userid']);

        $old_Token2 = Cache::get(self::$accessTokenPrefix . 215);
        $old_Token_key2 = Cache::get(self::$accessTokenAndClientPrefix . 215);

        // $old_Token = Cache::get(self::$accessTokenPrefix . 61);
        // $old_Token_key = Cache::get(self::$accessTokenAndClientPrefix . 61);

        // 对比token
        if ($old_Token !== $Headtoken['token']) {
            // return false;
            $error = [
                'error'   => -100,
                'message' => '秘钥匹配失败',
                'code'    => 400,
            ];

            exit(json_encode($error, JSON_UNESCAPED_UNICODE));
        }

        // 对比token过期时间
        if (time() > $old_Token_key['expires_time']) {
            // return false;
            $error = [
                'error'   => -100,
                'message' => '秘钥过期',
                'code'    => 400,
            ];
            exit(json_encode($error, JSON_UNESCAPED_UNICODE));
        }

        return $Headtoken['userid'];
    }

    /**
     * 获取http的头部token数据
     * @param  Request $request
     * @return array Headtoken
     */
    public function graspTheHead(Request $request)
    {   
        $Headtoken = '';

        // 抓取get的token
        $Headtoken = $request->param('headtoken', '');
// echo '抓到的完整秘钥：' . $Headtoken;
        if (empty($Headtoken)) {
            // 抓取头的token
            $Headtoken = $request->header('headtoken') ? $request->header('headtoken') : '';
        }

        if (empty($Headtoken)) {
            return '';
        }

        $token_cache = explode(':', $Headtoken);
// echo '抓到的完整秘钥token_cache[0]：' . $token_cache[0];
        if (empty($token_cache[0]) || empty($token_cache[1])) {
            $error = [
                'error'   => -100,
                'message' => '秘钥解析失败',
                'code'    => 400,
            ];
            exit(json_encode($error, JSON_UNESCAPED_UNICODE));
        }

        $res['userid'] = $token_cache[0];
        $res['token']  = trim($token_cache[1]);
// echo '抓到的完整秘钥token_cache[0]：' . $token_cache[0];
// echo '抓到的完整秘钥res[userid]：' . $res['userid'];
        return $res;
    }

    /**
     * 销毁Token
     * @return bool
     */
    public function destroyToken($Userid)
    {
        $token = Cache::pull(self::$accessTokenPrefix . $Userid);
        $token_key = Cache::pull(self::$accessTokenAndClientPrefix . $Userid);

        if (!empty($token)) {
            return true;
        } else {
            return false;
        }
    }

}
