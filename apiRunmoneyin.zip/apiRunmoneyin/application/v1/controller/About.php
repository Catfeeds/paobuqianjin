<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 关于我们接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;

/**
 * Class About
 * @title 关于我们接口
 * @url   v1/about
 * @desc  关于我们相关接口：获取关于我们列表、获取关于我们详情
 * @version 1.0
 * @readme
 */
class About extends Base
{
    /**
     * @title 获取关于我们列表
     * @return int id 关于我们文章内容id
     * @return int typeid 关于我们文章内容类型id
     * @return string title 关于我们文章内容标题
     * @return int create_time 关于我们文章内容添加时间
     * @desc 请求方式：GET <br/>请求示例：v1/about?typeid=2&page=1&pagesize=5
     */
    public function index()
    {
        $typeid = input('get.typeid');
        $page = input('get.page') ? input('get.page') : 1;
        $pagesize = input('get.pagesize') ? input('get.pagesize') : 10;

        if(!$typeid){
            $this->sendError(1, '关于我们类型ID必填', 400);
        }

        $about = db('about')
               ->field('content', true)
               ->where('typeid', $typeid)
               ->page($page, $pagesize)
               ->select();

        $totalCount = db('about')
               ->field('content',true)
               ->where('typeid',$typeid)
               ->count();

        $retData = returnData($page,$pagesize,$totalCount,$about);
        
        if ($about) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 获取关于我们详情
     * @return int id 关于我们文章内容id
     * @return string title 关于我们文章标题                                              
     * @return string content 关于我们文章内容
     * @return int creat_time 关于我们文章内容添加时间
     * @desc 请求方式：GET<br/>请求示例：v1/about/2
     */
    public function read($id)
    {
        $detail = db('about')
                ->field('typeid',true)
                ->where('id',$id)
                ->find();

        if($detail){
            return $this->sendSuccess($detail, 'success', 200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [],
            'read' => [
                'id' => [
                    'name' => 'id', 
                    'type' => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc' => '内容id', 
                    'range' => '',
                ],
            ],
        ];
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }

}