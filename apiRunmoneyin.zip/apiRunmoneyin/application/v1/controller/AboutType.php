<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 关于我们类型接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;

/**
 * Class AboutType
 * @title 关于我们类型
 * @url   v1/abouttype
 * @desc  关于我们类型接口
 * @version 1.0
 */
class AboutType extends Base
{
    /**
     * @title 获取关于我们的类型列表
     * @return int id 关于我们类型id
     * @return string name 关于我们类型名称
     * @desc 请求方式：GET <br/> 请求示例：v1/abouttype
     */
    public function index()
    {
        $aboutType = db('about_type')
                   ->field(true)
                   ->select();

        if($aboutType){
            return $this->sendSuccess($aboutType, 'success', 200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }


    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [],

        ];
        //可以合并公共参数
        return $rules;
    }

    
    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}