<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 活动接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;

/**
 * Class  Activity
 * @title 活动接口
 * @url   v1/Activity
 * @desc  活动接口：获取活动列表、获取关我参加的活动
 * @version 1.0
 * @readme
 */
class Activity extends Base
{

    // 附加方法
    protected $extraActionList = ['getActivityList', 'joinActivity', 'redActivity'];

    // /**
    //  * @title 获取活动列表
    //  * @return int id          活动id
    //  * @return int target      步数目标
    //  * @return string title    活动标题
    //  * @return string conver   活动封面
    //  * @return int starttime   活动开始时间
    //  * @return int endtime     活动结束时间deail
    //  * @return int deail       活动描述
    //  * @return int create_time 添加时间
    //  * @desc 请求方式：GET <br/>请求示例：v1/Activity?action=all
    //  */
    // public function index()
    // {
    //     $typeid = input('get.typeid');
    //     $page = input('get.page') ? input('get.page') : 1;
    //     $pagesize = input('get.pagesize') ? input('get.pagesize') : 10;

    //     if(!$typeid){
    //         $this->sendError(1, '关于我们类型ID必填', 400);
    //     }

    //     $about = db('about')
    //         ->field('content', true)
    //         ->where('typeid', $typeid)
    //         ->page($page, $pagesize)
    //         ->select();

    //     $totalCount = db('about')
    //         ->field('content',true)
    //         ->where('typeid',$typeid)
    //         ->count();

    //     $retData = returnData($page,$pagesize,$totalCount,$about);
        
    //     if ($about) {
    //         return $this->sendSuccess($retData, 'success', 200);
    //     } else {
    //         return $this->sendError(1, 'Not found Data', 200);
    //     }
    // }

    /**
     * @title 获取活动列表
     * @return int id             活动id
     * @return int target         步数目标
     * @return string title       活动标题
     * @return string conver      活动封面
     * @return int starttime      活动开始时间
     * @return int endtime        活动结束时间
     * @return int create_time    添加时间
     * @return string remote_url  H5地址
     * @return int read_total     阅读次数
     * @return int read_total     阅读次数
     * @return int is_process     活动状态：0未开始 1进行中 2已结束 3已经被领完
     * @return int is_receive     领取状态：0未领 1已领
     * @return int is_step        步数状态：0步数未达标 1已达标
     * @return int is_number      领取奖励人数
     * @desc 请求方式：GET <br/>请求示例：v1/Activity/getActivityList
     */
    public function getActivityList()
    {
        // $typeid = input('get.typeid');
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        $page     = input('get.page') ? input('get.page') : 1;
        $pagesize = input('get.pagesize') ? input('get.pagesize') : 10;

        // if(!$typeid) {
        //     $this->sendError(1, '关于我们类型ID必填', 400);
        // }
        
        // 获取用户当天步数
        $userstep = Db::name('user_step')
            ->where('create_day', date('Y-m-d'))
            ->where('userid', $Userid)
            ->value('step_number');

        if (empty($userstep)) {
            $Userstep = 0;
        } else {
            $Userstep = intval($userstep);
        }
        
        $totalCount = db('activity')->where('delete_id', 0)->count('id');

        if (empty($totalCount)) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        $activity = db('activity')
            ->alias('activity')
            ->field('
                id,target,title,conver,starttime,endtime,
                create_time,remote_url,read_total,allmoney,number
            ')
            ->where('delete_id', 0)
            ->page($page, $pagesize)
            ->order('activity.id desc')
            ->select();
            // deail,

        foreach ($activity as $key => $value) {
            $activity[$key]['starttime']   = date("Y-m-d H:i:s", $value['starttime']);
            $activity[$key]['endtime']     = date("Y-m-d H:i:s", $value['endtime']);
            $activity[$key]['create_time'] = date("Y-m-d H:i:s", $value['create_time']);
            $activity[$key]['remote_url']  = $value['remote_url'].'&uid='.$Userid;

            if ($value['starttime'] > time()) {    
                $activity[$key]['is_process'] = 0;  // 未开始
            } elseif (($value['starttime'] < time()) && ($value['endtime'] >= time())) {
                $activity[$key]['is_process'] = 1;  // 进行中
            } else {
                $activity[$key]['is_process'] = 2;  // 已结束 
            }

            // 已经领奖人数
            $Sumactred = db('activity_record')->where('activityid', $value['id'])->count('id');

            if(($value['starttime'] < time()) && ($value['endtime'] >= time())) {
                if ($Sumactred >= $value['number']) {
                    $activity[$key]['is_process'] = 3;  // 已经被领完 
                }
            }
            
            $activity[$key]['is_number'] = intval($Sumactred);

            $mystatus_WHERE['activityid'] = $value['id'];
            $mystatus_WHERE['userid'] = $Userid;
            $mystatus = db('activity_record')->field(true)->where($mystatus_WHERE)->find();

            if (empty($mystatus)) {
                $activity[$key]['is_receive'] = 0;
            } else {
                $activity[$key]['is_receive'] = 1;
            }

            if ($Userstep >= $value['target']) {
                $activity[$key]['is_step'] = 1;
            } else {
                $activity[$key]['is_step'] = 0;
            }
        }
        unset($key, $value);

        $retData = returnData($page, $pagesize, $totalCount, $activity);
        
        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title  加入活动（现在用不到）
     * @return int    error    错误码: 0成功 1失败
     * @return string massge   错误信息
     * @return array  data     返回数据
     * @desc 请求方式：POST <br/>请求示例：v1/Activity/joinActivity
     */
    public function joinActivity()
    {
        $Userid     = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Activityid = input('actid');

        // 判断邀请码是否存在
        $Userdata = Db::name('user')->field('id,vip')->where('id', $Userid)->find();
        if (empty($Userdata)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        // 获取活动数据
        $Activitydata = db('activity')->field(true)->where('id', $Activityid)->where('delete_id', 0)->find();

        if (empty($Activitydata)) {
            return $this->sendError(1, '活动不存在', 200);
        }

        // 检测是否加入活动
        $member_WHERE['userid']     = $Userid;
        $member_WHERE['activityid'] = $Activityid;
        $checkInAct = db('activity_member')->field(true)->where($member_WHERE)->find();

        // 已经加入的直接返回成功
        if (!empty($checkInAc)) {
            return $this->sendSuccess(0, 'success', 200);
        }

        $here_INSERT['userid']     = $Userid;
        $here_INSERT['activityid'] = $Activityid;
        $res = db('activity_member')->field(true)->where($member_WHERE)->insert($here_INSERT);

        if ($res) {
            return $this->sendSuccess(0, 'success', 200);
        } else {
            return $this->sendError(1, 'error', 200);
        }
    }

    /**
     * @title  领取活动奖励（红包）
     * @return int    error    错误码: 0成功 1失败
     * @return string massge   错误信息
     * @return array  data     返回数据
     * @desc 请求方式：POST <br/>请求示例：v1/Activity/redActivity
     */
    public function redActivity()
    {
        $Userid     = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Activityid = input('actid');

        // 判断邀请码是否存在
        $Userdata = Db::name('user')->field('id,vip')->where('id', $Userid)->find();
        if (empty($Userdata)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        // 获取活动数据
        $Activitydata = db('activity')->field(true)->where('id', $Activityid)->where('delete_id', 0)->find();

        if (empty($Activitydata)) {
            return $this->sendError(1, '活动不存在', 200);
        }

        $Allmoney  = $Activitydata['allmoney'];
        $Allnumber = $Activitydata['number'];
        $Avgmomey  = round($Allmoney / $Allnumber, 2);

        if ($Avgmomey < 0.01) {
            return $this->sendError(1, '活动红包不足', 200);
        }
        
// dump($Allmoney);
// dump($Allnumber);
// dump($Avgmomey);
// exit();

        $Nowtime = time();
        if ($Activitydata['starttime'] > $Nowtime) {    
            return $this->sendError(1, '活动未开始', 200);
        } elseif ($Activitydata['endtime'] < $Nowtime) {
            return $this->sendError(1, '活动已结束', 200);
        }

        // 检测是否领过奖励
        $record_WHERE['userid']     = $Userid;
        $record_WHERE['activityid'] = $Activityid;
        $checkInAct = db('activity_record')->field(true)->where($record_WHERE)->find();

        if (!empty($checkInAct)) {
            return $this->sendError(1, '已经领过奖励', 200);
        }

        // 已领红包总数
        unset($record_WHERE);
        $record_WHERE['activityid'] = $Activityid;
        $Sumactred = db('activity_record')->where($record_WHERE)->count('id');

        if (intval($Sumactred) >= intval($Activitydata['number'])) {
            return $this->sendError(1, '奖励发放完毕', 200);
        }

        if (empty($Sumactred) && ($Allnumber > 1)) {
            $redmoney = $Allmoney - ($Avgmomey * ($Allnumber - 1));
        } else {
            $redmoney = $Avgmomey;
        }

        Db::startTrans();
        
        try {
            $act_record_INSERT['amount']      = $redmoney;
            $act_record_INSERT['userid']      = $Userid;
            $act_record_INSERT['activityid']  = $Activityid;
            $act_record_INSERT['status']      = 1;
            $act_record_INSERT['create_time'] = time();
            $act_record_INSERT['receivetime'] = time();

            // 添加红包记录
            Db::name('activity_record')->insert($act_record_INSERT);

            // 添加用户钱包
            Db::name('user')->where('id', $Userid)->setInc('balance', $redmoney);

            // 更新收益表收益记录
            $income = Db::name('income')
                ->insert([
                    'userid'      => $Userid,
                    'typeid'      => 5,
                    'amount'      => $redmoney,
                    'source_id'   => $Activityid,
                    'create_time' => time()
                ]);

            // 提交事务
            Db::commit();
            return $this->sendSuccess(0, 'success', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(1, '录入邀请码失败', 200);
        }
    }


    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            // 'index' => [
            //     'circleid' => [
            //         'name'    => 'circleid',
            //         'type'    => 'int',
            //         'require' => 'true',
            //         'default' => '',
            //         'desc'    => '圈子ID',
            //         'range'   => ''
            //     ],
            // ],
            'getActivityList' => [
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'joinActivity' => [
                'actid'   => [
                    'name'    => 'actid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '活动id',
                    'range'   => ''
                ],
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
            ],
            'redActivity' => [
                'actid'   => [
                    'name'    => 'actid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '活动id',
                    'range'   => ''
                ],
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }

}
