<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/05/24 19:00
// +----------------------------------------------------------------------
// | TITLE: 苹果内购接口
// +----------------------------------------------------------------------

/**
 * @link http://chenkby.com
 * @copyright Copyright (c) 2018 ChenGuanQun
 * @license http://opensource.org/licenses/BSD-3-Clause
 */

namespace app\v1\controller;

use app\v1\extend\ApplePay;
use think\Db;

/**
 * 苹果内购
 * 错误码
 * 21000 App Store不能读取你提供的JSON对象
 * 21002 receipt-data域的数据有问题
 * 21003 receipt无法通过验证
 * 21004 提供的shared secret不匹配你账号中的shared secret
 * 21005 receipt服务器当前不可用
 * 21006 receipt合法，但是订阅已过期。服务器接收到这个状态码时，receipt数据仍然会解码并一起发送
 * 21007 receipt是Sandbox receipt，但却发送至生产系统的验证服务
 * 21008 receipt是生产receipt，但却发送至Sandbox环境的验证服务
 *
 * @author Chen GuanQun <99912250@qq.com>
 */
class AppleInternal extends Base
{
    // 附加方法
    protected $extraActionList = ['appleValidate'];

    // 验证次数
    static $statusTimes = 0;

    // 验证次数
    private $appSecret  = '1e55967f7eb241a4a231745ab14738dd';

    /**
     * @title  支付回调
     * @return int    error     错误代码：0成功 1失败
     * @return string message   消息提醒
     * @return array  data      返回数组
     * @desc 请求方式: POST <br/>请求示例：v1/AppleInternal/appleValidate
     */
    public function appleValidate() 
    {
        $Type   = input('post.type');
        $Userid = intval($this->userId);

        // return self::saveData($Type, $Userid);

        if (!in_array($Type, ['vip', 'cvip'])) {
            return $this->sendError(1, '充值类型必填', 200);
        }

        //苹果内购的验证收据
        $receipt_data = input('post.receipt');

        while (self::$statusTimes <= 5) {
            $result = self::validate_apple_pay($receipt_data);    // 验证支付状态

            if ($result['status']) {
                return self::saveData($Type, $Userid);
                break;
            }

            ++self::$statusTimes;
        }

        $res['receipt'] = $receipt_data;
        $res['result']  = $result;

        return $this->sendError(1, '充值失败', 200);
        // return $this->sendSuccess($result, '充值失败', 200);
    }

    /**
     * 验证AppStore内付
     * @param  string $receipt_data 付款后凭证
     * @return array                验证是否成功
     */
    private function validate_apple_pay($receipt_data)
    {
        // 验证参数
        if (strlen($receipt_data) < 20) {
            $result = array(
                'status'  => false,
                'message' => '非法参数'
            );

            return $result;
        }

        // 请求验证
        $html = self::acurl($receipt_data);
        $data = json_decode($html, true);
     
        // 如果是沙盒数据 则验证沙盒模式
        if($data['status']=='21007') {
            // 请求验证
            $html = self::acurl($receipt_data, 1);
            $data = json_decode($html, true);
            $data['sandbox'] = '1';
        }
     
        if (isset($_GET['debug'])) {
            exit(json_encode($data));
        }
         
        // 判断是否购买成功
        if (intval($data['status']) === 0) {
            $result = array(
                'status'  => true,
                'message' => '购买成功'
            );
        } else {
            $result = array(
                'status'  => false,
                'message' => '购买失败 status:' . $data['status']
            );
        }
        return $result;
    }


    /**
     * 21000 App Store不能读取你提供的JSON对象
     * 21002 receipt-data域的数据有问题
     * 21003 receipt无法通过验证
     * 21004 提供的shared secret不匹配你账号中的shared secret
     * 21005 receipt服务器当前不可用
     * 21006 receipt合法，但是订阅已过期。服务器接收到这个状态码时，receipt数据仍然会解码并一起发送
     * 21007 receipt是Sandbox receipt，但却发送至生产系统的验证服务
     * 21008 receipt是生产receipt，但却发送至Sandbox环境的验证服务
     */
    private function acurl($receipt_data, $sandbox=0) 
    {
        //小票信息
        $POSTFIELDS = array("receipt-data" => $receipt_data, 'password' => $this->appSecret);
        $POSTFIELDS = json_encode($POSTFIELDS);
 
        //正式购买地址 沙盒购买地址
        $url_buy     = "https://buy.itunes.apple.com/verifyReceipt";
        $url_sandbox = "https://sandbox.itunes.apple.com/verifyReceipt";
        $url = $sandbox ? $url_sandbox : $url_buy;

        //简单的curl
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $POSTFIELDS);

        // if (1 == strpos("$".$url, "https://")) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        // }

        $result = curl_exec($curl);

// dump($url);
// dump($result);
// die;

        curl_close($curl);
        return $result;
    }

    // 执行充值
    private function saveData($Type, $Userid, $Day = 365)
    {
        if ($Type == 'vip') {
            $vip['vip_table']    = 'user_vip';
            $vip['record_table'] = 'user_vip_record';
            $vip['user_field']   = 'vip';
            $vip['no']           = 'vip_no';
            $vip['order_type']   = 3;
            $vip['body_string']  = '会员充值_';
            $vip['money']        = 3 * 0.70;
            $vip['apple']        = 3;
            $vip['resstring']    = '已经是会员';
            
            $is_WHERE['id']      = $Userid;
            $is_WHERE['vip']     = 1;
        } else {
            $vip['vip_table']    = 'user_vipcus';
            $vip['record_table'] = 'user_vipcus_record';
            $vip['user_field']   = 'cusvip';
            $vip['no']           = 'cvip_no';
            $vip['order_type']   = 6;
            $vip['body_string']  = '商家会员充值_';
            $vip['money']        = 25 * 0.70;
            $vip['apple']        = 25;
            $vip['resstring']    = '已经是商家会员';

            $is_WHERE['id']      = $Userid;
            $is_WHERE['cusvip']  = 1;
        }

        
        $Isvip   = 0;   // 是否为vip：0否 1是
        $Uservip = Db::name('user')->where($is_WHERE)->find();
        if (!empty($Uservip)) {    // 检测是否为vip
            $Isvip = 1;
        }

// dump($Uservip);
// die;

        Db::startTrans();    // 开启事务

        try {
            // 订单编号
            $Orderno = date("Ymdhis") . rand(1000, 9999);

            $Vipno   = date("Ymdhis") . rand(1000, 9999);

            // 添加vip充值订单
            $order_INSERT['userid']       = $Userid;
            $order_INSERT['payment_type'] = 7;
            $order_INSERT['order_no']     = $Orderno;
            $order_INSERT['total_fee']    = $vip['money'];
            $order_INSERT['apple_pay']    = $vip['apple'];
            $order_INSERT['order_type']   = $vip['order_type'];
            $order_INSERT['body']         = $vip['body_string'] . $Orderno;
            $order_INSERT['status']       = 1;
            $order_INSERT['create_time']  = time();

            $order_record_INSERT = [
                'order_no'    => $Orderno,
                'userid'      => $Userid,
                $vip['no']    => $Vipno,
                'create_time' => time()
            ];

            // 添加充值订单
            $Neworderid = Db::name('order')->insertGetId($order_INSERT);  

            // 添加充值订单记录
            $Neworderrecordid = Db::name('order_recharge_record')->insertGetId($order_record_INSERT);

            // 计算充值时间起点
            $Viptimestart = time();
            if ($Isvip == 1) {    // 如果是续费
                $history = Db::name($vip['record_table'])
                    ->field(true)
                    ->where('userid', $Userid)
                    ->where('ok', 1)
                    ->order('end_time desc')
                    ->limit(1)
                    ->find();

                if (isset($history['end_time']) && ($history['end_time'] > time())) {
                    $Viptimestart = $history['end_time'];
                }
            }

            // 添加充值订单
            $vip_INSERT['addid']       = $Userid;
            $vip_INSERT['type']        = 1;
            $vip_INSERT[$vip['no']]    = $Vipno;
            $vip_INSERT['spend']       = $vip['money'];
            $vip_INSERT['apple']       = $vip['apple'];
            $vip_INSERT['day']         = $Day;
            $vip_INSERT['create_day']  = date('Y-m-d');
            $vip_INSERT['create_time'] = time();
            $vip_INSERT['end_time']    = $Viptimestart + $Day * 24 * 60 * 60;
            $vip_INSERT['ok']          = 1;
            $vip_INSERT['ok_time']     = $vip_INSERT['create_time'];

            $vip_record_INSERT['userid']      = $Userid;
            $vip_record_INSERT[$vip['no']]    = $Vipno;
            $vip_record_INSERT['spend']       = $vip['money'];
            $vip_record_INSERT['apple']       = $vip['apple'];
            $vip_record_INSERT['create_day']  = $vip_INSERT['create_day'];
            $vip_record_INSERT['create_time'] = $vip_INSERT['create_time'];
            $vip_record_INSERT['end_time']    = $vip_INSERT['end_time'];
            $vip_record_INSERT['ok']          = $vip_INSERT['ok'];
            $vip_record_INSERT['ok_time']     = $vip_INSERT['ok_time'];

// dump($vip_INSERT);
// dump($vip_record_INSERT);
// dump(date('Y-m-d', $vip_record_INSERT['end_time']));
// die;

            $Newvipid = Db::name($vip['vip_table'])->insertGetId($vip_INSERT);

            $Newviprecordid = Db::name($vip['record_table'])->insertGetId($vip_record_INSERT);

            // 修改用户会员状态
            if ($Isvip == 0) {
                $Userupdate = Db::name('user')->where('id', $Userid)->update([$vip['user_field'] => 1]);
            }
            
            Db::commit();      // 提交事务
            return $this->sendSuccess(0, '充值成功', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(1, '添加充值数据失败', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'appleValidate' => [
                'receipt' => [
                    'name'    => 'receipt', 
                    'type'    => 'array', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '苹果内购返回数据（一定是base64加密后的数据）', 
                    'range'   => '',
                ],
                'type' => [
                    'name'    => 'type', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '充值类型：vip用户会员|cvip商户会员', 
                    'range'   => '',
                ],
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户ID（尽量别传，后端根据token获取）', 
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
