<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 秘钥匹配处理
// +----------------------------------------------------------------------

namespace app\demo\controller;

use app\demo\auth\BasicAuth;
use app\demo\auth\OauthAuth;
use think\Request;

/**
 * Class Index
 * @title 商户接口
 * @url   v1/Business
 * @desc  商户相关接口
 * @version 1.0
 * @readme
 */
class Auth
{
    public function accessToken()
    {
        $request = Request::instance();
        $OauthAuth = new OauthAuth();
        return $OauthAuth->accessToken($request);
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
