<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/03/29 16:40
// +----------------------------------------------------------------------
// | TITLE: 自动提现到公司对公账户接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Db;
use think\Request;
use think\Validate;
use think\Log;
use app\v1\extend\JuheIdcardQuery;
use app\v1\extend\AliyunVerifyIdcard;
use app\v1\extend\HelibaoInt;
use app\v1\extend\BankCarData;
use helibao\Crypt_RSA;

/**
 * Class  AutoWithdraw
 * @title 自动提现
 * @url   v1/AutoWithdraw
 * @desc  自动提现到公司对公账户
 * @version 1.0
 */
class AutoWithdraw extends Base
{
    // 附加方法
    protected $extraActionList = ['withdrawToCompany'];

    // 跳过验证方法
    protected $skipAuthActionList = ['withdrawToCompany'];

    static $withdrawLimit = 1000;       // 合利宝每次提现限额

    // public function __construct() {
        
    // }

    /**
     * @title  自动提现到公司对公账户
     * @return int error          错误代码：0成功 1失败
     * @return string message     消息提醒
     * @return object data        用户认证对象
     * @return int    userid      用户ID
     
     * @desc 自动提现到公司对公账户，请求方式：post <br/> 地址：v1/AutoWithDraw/withdrawToCompany
    */
    public function withdrawToCompany() {

        $incomeArr = array(3,6);    // 3.个人会员 6.商家会员

        // 公司对公账户信息
        $companyAcc = Db::name('company_account')
            ->field(true)
            ->where('power', 1)
            ->where('delete_id', 0)
            ->find();

        $todayTim = (int)strtotime("today");             // 今日凌晨
        $yesterday = $todayTim-60*60*24;                 // 昨日凌晨
        
        // $todayTim = 1528905600;
        // $yesterday = 1528819200;        // 14号

        $map['order_type'] = array('IN',$incomeArr);    
        $map['status'] = 1;
        $map['payment_type'] = array('NEQ',7);
        $map['create_time'] = array([">=", $yesterday],["<", $todayTim],'and');            

        $fields = 'order_type';
        $orderList = Db::name('order')
            ->where($map)
            ->select();

        // 会员充值昨日总和
        $totalSum = 0;
        foreach($orderList as $keys=>$val) {
            $totalSum += $val['total_fee'];
        }
        
        // $totalSum = 1;      // 测试定时金额转入

        $incomeIds = array_column($orderList,'id');     // 昨日会员充值id集

        // 昨日收益大于0，则记录并提现
        if($orderList && $totalSum > 0) {

            $insert_data['bank_account'] = $companyAcc['account'];            // 银行账户
            $insert_data['bank_card'] = $companyAcc['bank_card'];             // 银行卡号
            $insert_data['bank_name'] = $companyAcc['bank_name'];             // 银行卡名称
            $insert_data['bankUnionCode'] = $companyAcc['couplet'];           // 银行联行号
            $insert_data['bank_code'] = $companyAcc['bank_code'];             // 银行编码

            $insert_data['type'] = 1;                                   // 收入类型: 1.会员充值  2.提现扣费
            $insert_data['withdraw_way'] = 1;                           // 提现方式: 1.自动转    2.手动转
            $insert_data['create_day'] = date('Y-m-d');

            // 昨日收益总和大于1000元
            if($totalSum >= (self::$withdrawLimit)) {

                $withdrawSize = floor($totalSum/(self::$withdrawLimit));    // 每次1000提现总次数

                // 循环插入数据库/提现
                for($i=0; $i<$withdrawSize; $i++) {            

                    $insert_data['order_no'] = date('YmdHis') . rand(100000, 999999);
                    $insert_data['amount'] = self::$withdrawLimit;      // 1000元
                    $insert_data['create_time'] = time();

                    $insertResult = Db::name('company_income')->insert($insert_data);

                    $withdrawResult = $this->withdrawCommon($insert_data);    // 提现到卡

                    if($withdrawResult) {
                        $res = $this->updateOrderState($incomeIds);
                    }

                    if($res) {
                        return $this->sendSuccess($incomeIds, 'success', 200);
                    }else {
                        return $this->sendError(1, '提现失败或更新订单状态出错', 200);
                    }
                }

                // 不是1000元的整数倍
                if($totalSum%(self::$withdrawLimit) != 0) {

                    $insert_data['order_no'] = date('YmdHis') . rand(100000, 999999);
                    $insert_data['amount'] = ($totalSum-$withdrawSize*(self::$withdrawLimit));      // 1000元余下
                    $insert_data['create_time'] = time();

                    $insertResult = Db::name('company_income')->insert($insert_data);

                    $withdrawResult = $this->withdrawCommon($insert_data);    // 提现到卡

                    if($withdrawResult) {
                        $res = $this->updateOrderState($incomeIds);
                    }

                    if($res) {
                        return $this->sendSuccess($incomeIds, 'success', 200);
                    }else{
                        return $this->sendError(1, '提现失败或更新订单状态出错', 200);
                    }
                }

            }else{

                $insert_data['order_no'] = date('YmdHis') . rand(100000, 999999);
                $insert_data['amount'] = $totalSum;                        // 1000元
                $insert_data['create_time'] = time();

                $insertResult = Db::name('company_income')->insert($insert_data);

                $withdrawResult = $this->withdrawCommon($insert_data);    // 提现到卡

                // 更新order表
                if($withdrawResult) {
                    $res = $this->updateOrderState($incomeIds);
                }

                if($res) {
                    return $this->sendSuccess($incomeIds, 'success', 200);
                }else{
                    return $this->sendError(1, '提现失败或更新订单状态出错', 200);
                }
            }
        }
    }

    // 更新订单表(会员充值)状态
    protected function updateOrderState($ids) {
        $map['id'] = array('IN',$ids);
        $results = Db::name('order')->where($map)->update(['status'=>3]);

        return $results;
    }

    // 对公账户银行卡提现
    protected function withdrawCommon($withdrawArr) {

        $withdrawArrNew = array(
            'orderNo' => $withdrawArr['order_no'],
            'amount' => $withdrawArr['amount'],
            'bankCode' => $withdrawArr['bank_code'],
            'bankCard' => $withdrawArr['bank_card'],
            'account' => $withdrawArr['bank_account'],
            'bankUnionCode' => $withdrawArr['bankUnionCode'],
            'remark' => '结算',
        );

// return true;    // 记住删除

        $helibao_obj = new HelibaoInt();                                                // 合利宝集成类

        $withDrawRes = $helibao_obj->transfer($withdrawArrNew,true);                    // 单笔代付(对公账户)

        if(!$withDrawRes) {
            Db::name('company_income')->where('order_no',$withdrawArr['order_no'])->update(['remark'=>'参数不足']);
            return false;
        }

        if($withDrawRes['rt2_retCode'] != '0000') {   
            Db::name('company_income')->where('order_no',$withdrawArr['order_no'])->update(['remark'=>$withDrawRes['rt3_retMsg']]);
            return false;
        }else {
            Db::name('company_income')->where('order_no',$withdrawArr['order_no'])->update(['status'=>1,'remark'=>'提现成功','actual_amount'=>$withdrawArrNew['amount']]);
            return true;
        }

        //return ['code'=>0,'msg'=>'提现成功'];
    }


    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'userAuthState' => [
                'userid' => [
                  'name' => 'userid', 
                  'type' => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc' => '用户id（不填最好）', 
                  'range' => '',
                ],
            ],
        ];
        
        //可以合并公共参数
        return $rules;
    }

}
