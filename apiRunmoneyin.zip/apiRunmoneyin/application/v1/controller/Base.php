<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 接口基础类
// +----------------------------------------------------------------------

namespace app\v1\controller;

use DawnApi\facade\ApiController;
use \app\v1\auth\AccessToken;
use think\Config;
use think\Request;

/**
 * Class  Base
 * @title 接口基础类（控制器）
 * @desc  基类,所有的控制器都继承这个类
 * @version 1.0
 */
class Base extends ApiController
{
	/**
     * 默认关闭验证
     * @var bool
     */
    public $apiAuth = false;

    /**
     * 跳过验证方法
     * @var array
     */
    protected $userId = 0;

    /**
     * 跳过验证方法
     * @var array
     */
    protected $skipAuthActionList = [];

    public function __construct()
    {	
        // dump('服务器调试中！');
	
	    // 验证token
        $this->userId = self::checkToken();
	
        $is_open = db('scan_log')->where(array('user_id'=>1))->find();
        if ($is_open['content']){
            self::scan();
        }

    }

    /**
	 * @title  检测token
	 * @param  none
	 * @return bool
	 * @desc  
	 */
    protected function checkToken()
    {
    	// 获取访问方法名
    	$action = request()->action();

    	// 检测是否是跳过的方法（存在就跳过检测）
    	if (in_array($action, $this->skipAuthActionList)) {
    		return 0;
    	}

    	// token处理类
    	$request = Request::instance();
    	$accessToken = new AccessToken();
    	$chcek = $accessToken->chcekAccessToken($request);

    	if ($chcek != false) {
    		return $chcek;
    	} else {
    		return false;
    	}
    }

    protected function scan()
    {
        \app\v1\extend\Scan::setUserId($this->userId);
        \app\v1\extend\Scan::setScanLog(true);
        \app\v1\extend\Scan::setScanAction(array('post', 'get'));
        \app\v1\extend\Scan::scanRequestContent(__NAMESPACE__);
    }

}
