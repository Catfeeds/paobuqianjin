<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 商户接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use checkimages\QcloudImage\Conf;
use think\Request;
use think\Db;
use think\Validate;
use think\Action;
use think\Cache;
use think\Config;

/**
 * Class  Index
 * @title 商户接口
 * @url   v1/Business
 * @desc  商户相关接口
 * @version 1.0
 */
class Business extends Base
{
    //附加方法
    protected $extraActionList = [ 'getUserBusiness', 'addBusiness', 'updateBusiness','deleteBusImg', 'setDefaultBusiness'];

    /**
     * @title 获取附近广告商户
     * @return int    error              错误代码：0失败 1成功
     * @return string message            消息提醒
     * @return object data               商户对象
     * @return int    id                 商户ID
     * @return string logo               商户LOGO
     * @return string name               商户名称
     * @return string hours              营业时间
     * @return string tel                固定电话
     * @return string address            地址
     * @return int    longitude          经度
     * @return float  latitude           纬度
     * @return float  total_money        总金额
     * @return string environment_images 环境图片
     * @return string goods_images       商品图片
     * @return int    distance           距离（单位：米）
     * @return int    red_packet         红包金额
     * @desc 请求方式:GET <br/> 请求示例: v1/Business
     */
    // public function index()
    // {
    //     $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
    //     // $Userid = intval(input('get.userid'));

    //     if (empty($Userid)) {
    //         return $this->sendError(-1, '用户ID必填', 400);
    //     }

    //     // 获取用户的经纬度
    //     $user = Db::name('user_record')
    //         ->where('userid', $Userid)
    //         ->order('create_time desc')
    //         ->find();

    //     // 计算附近10公里经纬度
    //     $scope = calcScope($user['latitude'], $user['longitude'], 10000);

    //     // 查询附近商户
    //     $map['latitude']    = ['between', [$scope['minLat'], $scope['maxLat']]];
    //     $map['longitude']   = ['between', [$scope['minLng'], $scope['maxLng']]];
    //     $map['total_money'] = ['>', 1];

    //     // 获取范围内的商户
    //     $business = Db::name('business')
    //         ->where($map)
    //         ->limit(10)
    //         ->select();

    //     foreach ($business as $key => $value) {
    //         if (!empty($value['environment_images'])) {
    //             $business[$key]['environment_images'] = unserialize($value['environment_images']);
    //         } else {
    //             $business[$key]['environment_images'] = [];
    //         }

    //         if (!empty($value['goods_images'])) {
    //             $business[$key]['goods_images'] = unserialize($value['goods_images']);
    //         } else {
    //             $business[$key]['goods_images'] = [];
    //         }
    //     }

    //     // 追加距离到商户
    //     $total_red_packet = 0;   // 红包总金额
    //     foreach ($business as $key => $value) {
    //         $red_packet = floatval(randomRedPacket(0.01, 1));
    //         $business[$key]['distance'] = calcDistance(
    //             $user['latitude'],
    //             $user['longitude'],
    //             $value['latitude'],
    //             $value['longitude']
    //         ) * 1000;

    //         $business[$key]['red_packet'] = $red_packet;
    //         $total_red_packet = $total_red_packet + $red_packet;

    //         $sameDay = strtotime('today');    // 当日时间戳
    //         $nextDay = $sameDay + 86400;      // 次日时间戳

    //         $map_two = array();
    //         $map_two['userid'] = $Userid;
    //         $map_two['create_time'] = ['between', [$sameDay, $nextDay]];

    //         // 添加红包记录
    //         $business_record = Db::name('business_record')
    //             ->where($map_two)
    //             ->count();

    //         if ($business_record < count($business)) {
    //             $data = array(
    //                 'business_id' => $value['id'],
    //                 'userid'      => $Userid,
    //                 'money'       => $red_packet,
    //                 'is_receive'  => 0,
    //                 'create_time' => time(),
    //             );

    //             Db::name('business_record')->insert($data);
    //         }
    //     }

    //     // 根据距离排序
    //     $newBusiness = arraySort($business, 'distance', 'asc');

    //     if ($newBusiness) {
    //         return $this->sendSuccess(array('total_red_packet'=>$total_red_packet,'data'=>$newBusiness), 'success', 200);
    //     } else {
    //         return $this->sendError(1, 'Not found Data', 200);
    //     }
    // }

    /**
     * @title  获取单个商户信息
     * @return int    error              错误代码：0失败 1成功
     * @return string message            消息提醒
     * @return object data               商户对象
     * @return int    id                 商户ID
     * @return string logo               商户LOGO
     * @return string name               商户名称
     * @return string hours              营业时间
     * @return string tel                固定电话
     * @return string address            地址
     * @return int    longitude          经度
     * @return float  latitude           纬度
     * @return float  total_money        总金额
     * @return int    distance           距离 单位:米
     * @return array  environment_images 环境图片
     * @return array  goods_images       商品图片
     * @return array  img_id             图片数组元素：图片id
     * @return array  type               图片数组元素：图片类型: 1logo|2商品|3环境
     * @return array  url                图片数组元素：链接
     * @return array  status             图片数组元素：状态：0刚上传|1不通过审核|10通过审核
     * @desc 请求方式:GET <br/> 请求示例地址: v1/Business/1 
     */
    public function read($id)
    {   
        $Businessid = intval($id);

        $res = Db::name('business')
            // ->field(true)
            ->field('
                id as businessid,userid,logo,name,tel,addra,address,
                longitude,latitude,total_money,create_time,
                do_day,s_do_time,e_do_time,default
            ')
            ->where('id', $Businessid)
            // ->where('delete_id', 0)
            ->order('id desc')
            ->find();
// dump($res);
        if (empty($res)) {
            return $this->sendError(1, 'Not Found Data', 200);
        } 

        // 追加照片数据
        if ($res['do_day']) {
            $week  = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
            $cache = explode(',', $res['do_day']);
            $cache = array_filter($cache);

            $res['do_day'] = '';
            if (count($cache) > 0) {
                foreach ($cache as $i => $j) {
                    $res['do_day'] .= $week[$j - 1] . ',';
                }
                unset($i, $j);

                $res['do_day'] = substr($res['do_day'], 0, -1);
            }
        }
        // if ($res['s_do_time']) {
        //     $res['s_do_time'] = date('H:i', strtotime($res['s_do_time']));
        // }
        // if ($res['e_do_time']) {
        //     $res['e_do_time'] = date('H:i', strtotime($res['e_do_time']));
        // }

        // 所有照片
        $img_WHERE['business_id'] = $res['businessid'];
        $img_WHERE['delete_id']   = 0;
        $img_WHERE['auto_scan']   = 1;
        $img_WHERE['status']      = ['<>', 10];    // 图片状态：0刚提交；1通过审核；10未通过审核；

        $Allbusinessimg = Db::name('business_img')
            // ->field(true)
            ->field('img_id,type,url,status')
            ->where($img_WHERE)
            ->select();

        $Logoimg                 = '';
        $res['logo_imgs']        = [];
        $res['goods_imgs']       = [];
        $res['environment_imgs'] = [];
        foreach ($Allbusinessimg as $k => $v) {
            // 图片类型：0未定义；1封面；2商品；3环境
            if ($v['type'] == 1) {
                $Logoimg = $v;
                $res['logo_imgs'][] = $v;
            } elseif ($v['type'] == 2) {
                $res['goods_imgs'][] = $v;
            } elseif ($v['type'] == 3) {
                $res['environment_imgs'][] = $v;
            }
        }
        unset($k, $v, $Allbusinessimg);

        if (empty($res['logo']) && empty($Logoimg)) {
            $res['logo'] = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_c.png';
        } elseif (empty($res['logo']) && !empty($Logoimg)) {
            $res['logo'] = $Logoimg;
        }
        
        if (empty($res)) {
            return $this->sendError(1, 'Not Found Data', 200);
        } else {
            return $this->sendSuccess($res, 'success', 200);
        }
    }

    /**
     * @title  获取用户商户列表
     * @author wensen 2018-04-17
     * @return int    error            错误代码：1失败 0成功
     * @return string message          消息提醒
     * @return array  data             商户数组
     * @return array  logo_imgs        logo图片数组（其实先用不到）
     * @return array  environment_imgs 商户环境图片数组
     * @return array  goods_imgs       商户商品图片数组
     * @return int    type             图片类型：0未定义；1封面；2商品；3环境
     * @return int    default          默认的商户（排第一）：0否|1是
     * @desc 请求方式: POST <br/> 请求示例: v1/Business/getUserBusiness
     */
    public function getUserBusiness()
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        $page     = input('post.page') ? intval(input('post.page')) : 1;              // 当前分页
        $pageSize = input('post.pagesize') ? intval(input('post.pagesize')) : 10;     // 每页显示数量
// dump($Userid);
        if (empty($Userid)) {
            return $this->sendError(1, '用戶id必填', 200);
        }

        $totalCount = Db::name('business')
            ->field('id')
            ->where('userid', $Userid)
            ->where('delete_id', 0)
            ->where('type', 0)
            ->order('id desc')
            ->count('id');

// dump($Userid);
// dump($totalCount);
// exit();
        if (empty($totalCount)) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        $res = Db::name('business')
            // ->field(true)
            ->field('
                id as businessid,userid,logo,name,tel,addra,address,
                longitude,latitude,total_money,create_time,
                do_day,s_do_time,e_do_time,default
            ')
            ->where('userid', $Userid)
            ->where('delete_id', 0)
            ->where('type', 0)
            ->order('default', 'desc')
            // ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select();

        // 追加照片数据
        foreach ($res as $key => $value) {
            if ($value['do_day']) {
                $week  = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
                $cache = explode(',', $value['do_day']);
                $cache = array_filter($cache);

                $res[$key]['do_day'] = '';
                if (count($cache) > 0) {
                    foreach ($cache as $i => $j) {
                        $res[$key]['do_day'] .= $week[$j - 1] . ',';
                    }
                    unset($i, $j);

                    $res[$key]['do_day'] = substr($res[$key]['do_day'], 0, -1);
                }
            }
            
            // if ($value['s_do_time']) {
            //     $res[$key]['s_do_time'] = date('H:i', strtotime($value['s_do_time']));
            // }
            // if ($value['e_do_time']) {
            //     $res[$key]['e_do_time'] = date('H:i', strtotime($value['e_do_time']));
            // }

            // 所有照片
            $img_WHERE['userid']      = $Userid;
            $img_WHERE['business_id'] = $value['businessid'];
            $img_WHERE['delete_id']   = 0;
            $img_WHERE['status']      = ['<>', 10];    // 图片状态：0刚提交；1通过审核；10未通过审核；
            $img_WHERE['auto_scan']      = 1;    // 图片状态：0刚提交；1通过审核；10未通过审核；

            $Allbusinessimg = Db::name('business_img')
                // ->field(true)
                ->field('img_id,type,url,status')
                ->where($img_WHERE)
                ->select();

            $res[$key]['logo_imgs']        = [];
            $res[$key]['goods_imgs']       = [];
            $res[$key]['environment_imgs'] = [];
            foreach ($Allbusinessimg as $k => $v) {
                // 图片类型：0未定义；1封面；2商品；3环境
                if ($v['type'] == 1) {
                    $res[$key]['logo_imgs'][]  = $v;
                } elseif ($v['type'] == 2) {
                    $res[$key]['goods_imgs'][] = $v;
                } elseif ($v['type'] == 3) {
                    $res[$key]['environment_imgs'][] = $v;
                }
            }
            unset($k, $v, $Allbusinessimg);

            if (empty($res[$key]['logo']) && empty($res[$key]['logo_imgs'])) {
                $res[$key]['logo'] = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_c.png';
            } elseif (empty($res[$key]['logo']) && !empty($res[$key]['logo_imgs'])) {
                $res[$key]['logo'] = $res[$key]['logo_imgs'][0]['url'];
            }
        }
        unset($key, $value);

        $retData = returnData($page, $pageSize, $totalCount, $res);
        
        if (empty($retData)) {
            return $this->sendError(1, 'Not Found Data', 200);
        } else {
            return $this->sendSuccess($retData, 'success', 200);
        }
    }

    /**
     * @title  创建商户
     * @author wensen 2018-04-19
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @desc 请求方式: POST <br/> 请求示例: v1/Business/addBusiness
     */
    public function addBusiness()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        {   //数据验证
            $data = input('post.');

            $rule = [
                // 'logo'      => 'require',
                'name'      => 'require',
                // 'tel'       => 'require',
                // 'addra'     => 'require',
                // 'address'   => 'require',
                // 'longitude' => 'require|between:-180,180',
                // 'latitude'  => 'require|between:-90,90',
                'longitude' => 'between:-180,180',
                'latitude'  => 'between:-90,90',
            ];

            $msg = [
                // 'logo.require'      => '用户LOGO必填',
                'name.require'      => '商户名称必填',
                // 'tel.require'       => '固定电话必填',
                // 'addra.require'     => '主要地址必填',
                // 'address.require'   => '详细地址必填',
                // 'longitude.require' => '经度必填',
                'longitude.between' => '经度必须在-180~180之间',
                // 'latitude.require'  => '纬度必填',
                'latitude.between'  => '纬度必须在-90~90之间',
            ];

            // 验证字段
            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(-1, $validate->getError(), 200);
            }
        }
// dump($data);
// exit();

        // 禁止直接写入总金额
        if (isset($data['total_money']) && $data['total_money']) {
            unset($data['total_money']);
        }

        Db::startTrans();

        try {
            // 添加商户数据，获取商户id（商户表）
            $business_INSERT['userid']       = $Userid;
            $business_INSERT['name']         = $data['name'];
            $business_INSERT['create_time']  = time();

            if (!empty($data['logo'])) {
                if (Config::get('scan_content.image')){
                    $Scan = \aliyuncs\Green\Check::imageSyncScan($data['logo']);
                    $business_INSERT['logo'] = $Scan['auto_scan'] ? $Scan['url'] : "https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_c.png";
                }else{
                    $business_INSERT['logo']   = $data['logo'];
                }
            } else {
                $business_INSERT['logo']   = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_c.png';
            }

            if (!empty($data['tel'])) {
                $business_INSERT['tel']    = $data['tel'];
            }
            if (!empty($data['addra'])) {
                $business_INSERT['addra']  = $data['addra'];
            }
            if (!empty($data['address'])) {
                $business_INSERT['address']    = $data['address'];
            }
            if (!empty($data['longitude'])) {
                $business_INSERT['longitude']  = round($data['longitude'], 6);
            }
            if (!empty($data['latitude'])) {
                $business_INSERT['latitude']   = round($data['latitude'], 6);
            }

            if (!empty($data['default']) && (intval($data['default']) > 0)) {
                $business_INSERT['default'] = 1;
            }

            {   // 判断是否为
                $OldBusdataSum = Db::name('business')
                    ->field('id')
                    ->where('userid', $Userid)
                    ->where('delete_id', 0)
                    ->where('type', 0)
                    ->count('id');

                if (empty($OldBusdataSum)) {
                    $business_INSERT['default'] = 1;
                }
            }

            // 营业时间格式处理
            if (!empty($data['do_day'])) {
                $cache = explode(',', $data['do_day']);
                $cache = array_filter($cache);
                sort($cache);

                $business_INSERT['do_day'] = ',' . implode(',', $cache) . ',';
                unset($cache);
            } else {
                $business_INSERT['do_day'] = '';
            }

            if (!empty($data['s_do_time']) && (strlen($data['s_do_time']) <= 5)) {
                $business_INSERT['s_do_time'] = $data['s_do_time'];
            }

            if (!empty($data['e_do_time']) && (strlen($data['e_do_time']) <= 5)) {
                $business_INSERT['e_do_time'] = $data['e_do_time'];
            }

            if (isset($business_INSERT['default']) && ($business_INSERT['default'] == 1)) {     // 将之前的默认清除
                @$res_defalt = @Db::name('business')->where(['userid' => $Userid])->update(['default' => 0]);            
            }
            
            $Businessid = Db::name('business')->insertGetId($business_INSERT);

// dump($business_INSERT);
// exit();

            {   // 追加添加商户图片信息（商户图片表）
                // 整合店铺logo数据
                $img_INSERT = [];
                if (isset($data['logo']) && $data['logo']) {
                    $img_INSERT[] = [
                        'userid'      => $Userid,
                        'business_id' => $Businessid,
                        'type'        => 1,
                        'url'         => empty($data['logo']) ? '' : trim($data['logo']),
                        // 'size'        => empty($data['logo']['size'])   ? 0 : trim($data['logo']['size']),
                        // 'width'       => empty($data['logo']['width'])  ? 0 : trim($data['logo']['width']),
                        // 'height'      => empty($data['logo']['height']) ? 0 : trim($data['logo']['height']),
                        'create_time' => time(),

                    ];
                }

                // 整合店铺商品图片
                if (isset($data['goods_images']) && $data['goods_images']) {
                    $goods_images = explode(',', $data['goods_images']);
                    // $data['goods_images'] = serialize($goods_images);

                    foreach ($goods_images as $key => $value) {
                        $img_INSERT[] = [
                            'userid'      => $Userid,
                            'business_id' => $Businessid,
                            'type'        => 2,
                            'url'         => empty($value) ? '' : trim($value),
                            'create_time' => time(),
                        ];
                    }
                    unset($key, $value);
                }

                // 整合店铺环境图片
                if (isset($data['environment_images']) && $data['environment_images']) {
                    $environment_images = explode(',', $data['environment_images']);
                    // $data['environment_images'] = serialize($environment_images);

                    foreach ($environment_images as $key => $value) {
                        $img_INSERT[] = [
                            'userid'      => $Userid,
                            'business_id' => $Businessid,
                            'type'        => 3,
                            'url'         => empty($value) ? '' : trim($value),
                            'create_time' => time(),
                        ];
                    }
                    unset($key, $value);
                }
                if (count($img_INSERT) > 0) {
                    if (Config::get('scan_content.image')){
                        $img_INSERT = \aliyuncs\Green\Check::imageSyncScan($img_INSERT);
                    }
                    Db::name('business_img')->insertAll($img_INSERT);
                }
            } 
// dump($Businessid);
// dump($img_INSERT);
// exit();  
            $res['businessid'] = $Businessid;
            $res['name']       = $business_INSERT['name'];
            Db::commit();
            return $this->sendSuccess($res, 'success', 200);
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(-1, 'error', 400);
        }
    }

    /**
     * @title  修改商户信息
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @desc 请求方式:PUT <br/> 请求示例: v1/Business/1
     */
    public function update(Request $request, $id)
    {
        // $data       = $request->put();
        $data       = input('put.');
        $Userid     = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Businessid = intval($id);

// dump($data);
// dump($Userid);
// dump($Businessid);
// exit();

        // if (empty($Userid)) {
        //     return $this->sendError(-1, '用户ID必填', 400);
        // }

        if (empty($Businessid)) {
            return $this->sendError(-1, '商户ID必填', 400);
        }

        $Old_busdata = Db::name('business')->where('id', $Businessid)->find();
        if (empty($Old_busdata)) {
            return $this->sendError(-1, '商户不存在！', 400);
        }

        // 禁止直接更新总金额
        if (isset($data['total_money']) && $data['total_money']) {
            unset($data['total_money']);
        }

        $business_UPDATE = [];
        $img_INSERT      = [];

        {   // 追加添加商户图片信息（商户图片表）
            // 整合店铺logo数据
            if (isset($data['logo']) && $data['logo']) {
                $img_INSERT[] = [
                    'userid'      => $Userid,
                    'business_id' => $Businessid,
                    'type'        => 1,
                    'url'         => trim($data['logo']),//20180523 lixinhe
                    'create_time' => time(),//20180523  lixinhe
                ];

                $delete_WHERE['business_id'] = $Businessid;
                $delete_WHERE['userid']      = $Userid;
                $delete_WHERE['type']        = 1;
            }

            // 整合店铺商品图片
            if (isset($data['goods_images']) && $data['goods_images']) {
                $goods_images = explode(',', $data['goods_images']);
                foreach ($goods_images as $key => $value) {
                    $img_INSERT[] = [
                        'userid'      => $Userid,
                        'business_id' => $Businessid,
                        'type'        => 2,
                        'url'         => empty($value) ? '' : trim($value),
                        'create_time' => time(),
                    ];
                }
                unset($key, $value, $goods_images);
            }

            // 整合店铺环境图片
            if (isset($data['environment_images']) && $data['environment_images']) {
                $environment_images = explode(',', $data['environment_images']);
                foreach ($environment_images as $key => $value) {
                    $img_INSERT[] = [
                        'userid'      => $Userid,
                        'business_id' => $Businessid,
                        'type'        => 3,
                        'url'         => empty($value) ? '' : trim($value),
                        'create_time' => time(),
                    ];
                }
                unset($key, $value, $environment_images);
            }
            // $Imgres = Db::name('business_img')->insertAll($img_INSERT);
        }

        {   // 数据验证
            if (isset($data['logo']) && ($data['logo'] != $Old_busdata['logo'])) {
                if (Config::get('scan_content.image')){
                    $Scan = \aliyuncs\Green\Check::imageSyncScan($data['logo']);
                    $business_UPDATE['logo'] =$Scan['auto_scan'] ? $Scan['url'] : "https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_c.png";
                }else{
                    $business_UPDATE['logo'] = $data['logo'];
                }

            }

            if (isset($data['name']) && ($data['name'] != $Old_busdata['name'])) {
                $business_UPDATE['name'] = $data['name'];
            }

            if (isset($data['tel']) && ($data['tel'] != $Old_busdata['tel'])) {
                $business_UPDATE['tel'] = $data['tel'];
            }

            if (isset($data['addra']) && ($data['addra'] != $Old_busdata['addra'])) {
                $business_UPDATE['addra'] = $data['addra'];
            }

            if (isset($data['address']) && ($data['address'] != $Old_busdata['address'])) {
                $business_UPDATE['address'] = $data['address'];
            }

            if (isset($data['longitude']) && ($data['longitude'] != $Old_busdata['longitude'])) {
                $business_UPDATE['longitude'] = $data['longitude'];
            }

            if (isset($data['latitude']) && ($data['latitude'] != $Old_busdata['latitude'])) {
                $business_UPDATE['latitude'] = $data['latitude'];
            }

            if (isset($data['default']) && ($data['default'] != $Old_busdata['default'])) {
                $business_UPDATE['default'] = $data['default'];
            }

            // 营业时间格式处理
            if (!empty($data['do_day'])) {
                $cache = explode(',', $data['do_day']);
                $cache = array_filter($cache);
                sort($cache);

                $cache = ',' . implode(',', $cache) . ',';

                if ($data['do_day'] != $Old_busdata['do_day']) {
                    $business_UPDATE['do_day'] = $data['do_day'];
                }
            }

            if (!empty($data['s_do_time']) && (strlen($data['s_do_time']) <= 5)) {
                $business_UPDATE['s_do_time'] = $data['s_do_time'];
            }

            if (!empty($data['e_do_time']) && (strlen($data['e_do_time']) <= 5)) {
                $business_UPDATE['e_do_time'] = $data['e_do_time'];
            }
        }

        if ((count($img_INSERT) <= 0) && (count($business_UPDATE) <= 0)) {
            return $this->sendSuccess(0, 'success', 200);
        }

        Db::startTrans();

// dump($data);
// dump($Old_busdata);

        try {
            if (isset($data['default']) && ($Old_busdata['default'] != $data['default']) && ($data['default'] == 1)) {    // 将之前的默认清除
                @$res_defalt = @Db::name('business')->where(['userid' => $Userid])->update(['default' => 0]);            
            }

            // 更新数据
            if (count($business_UPDATE) > 0) {
                $Update_res = Db::name('business')->where('id', $Businessid)->update($business_UPDATE);
            }

            // 删除图片
            if (isset($delete_WHERE)) {
                $Imgres_res = Db::name('business_img')->where($delete_WHERE)->update(['delete_id' => $Userid, 'delete_time' => time()]);
            }

            // 添加图片
            if (count($img_INSERT) > 0) {
                if (Config::get('scan_content.image')){
                    $img_INSERT = \aliyuncs\Green\Check::imageSyncScan($img_INSERT);
                }

                $Imgres_res = Db::name('business_img')->insertAll($img_INSERT);
            }

            Db::commit();
            return $this->sendSuccess(0, 'success', 200);
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(-1, 'error', 400);
        }
    }

    /**
     * @title  修改商户信息（自动判断图片增删）
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @desc 请求方式:POST <br/> 请求示例: v1/Business/updateBusiness
     */
    public function updateBusiness()
    {
        $data       = input('post.');
        $Businessid = input('post.businessid');
        $Userid     = input('userid') ? intval(input('userid')) : intval($this->userId);

// dump($data);
// dump($Userid);
// dump($Businessid);
// exit();

        if (empty($Businessid))
        {
            return $this->sendError(-1, '商户ID必填', 200);
        }

        $Oldbusdata = Db::name('business')->where('id', $Businessid)->find();
        if (empty($Oldbusdata))
        {
            return $this->sendError(-1, '商户不存在！', 200);
        }

        // 禁止直接更新总金额
        if (isset($data['total_money']) && $data['total_money'])
        {
            unset($data['total_money']);
        }

        $delete_WHERE    = [];
        $img_INSERT      = [];
        $business_UPDATE = [];

        {   // 图片处理
            // 获取商户的所有片
            $img_WHERE['business_id'] = $Businessid;
            $img_WHERE['delete_id']   = 0;
            $img_WHERE['status']      = ['<>', 10];    // 图片状态：0刚提交；1通过审核；10未通过审核；

            $Allbusinessimg = Db::name('business_img')// ->field(true)
            ->field('img_id,type,url,status')->where($img_WHERE)->select();

            // 整理数据
            $logo_imgs        = [];
            $goods_imgs       = [];
            $environment_imgs = [];
            foreach ($Allbusinessimg as $k => $v)
            {
                // 图片类型：0未定义；1封面；2商品；3环境
                if ($v['type'] == 1)
                {
                    $logo_imgs = $v;
                } elseif ($v['type'] == 2)
                {
                    $goods_imgs[] = $v;
                } elseif ($v['type'] == 3)
                {
                    $environment_imgs[] = $v;
                }
            }
            unset($k, $v, $Allbusinessimg);

// dump($img_WHERE);
// dump($logo_imgs);
// dump($goods_imgs);
// dump($environment_imgs);
// exit();     

            // 整合店铺logo数据（logo只换不能删）
            if (isset($data['logo']))
            {
                if (isset($logo_imgs['url']) && ($data['logo'] != $logo_imgs['url']))
                {
                    if (!empty($logo_imgs['img_id']))
                    {
                        $delete_WHERE[] = $logo_imgs['img_id'];
                    }

                    $img_INSERT[] = ['userid' => $Userid, 'business_id' => $Businessid, 'type' => 1, 'url' => trim($data['logo']), 'create_time' => time(),];
                    // dump($delete_WHERE);
                    // dump($logo_INSERT);
                } else
                {
                    $img_INSERT[] = ['userid' => $Userid, 'business_id' => $Businessid, 'type' => 1, 'url' => trim($data['logo']), 'create_time' => time(),];
                }
            }

// dump($logo_imgs);
// dump($img_INSERT);
// exit();

            // 整合店铺商品图片
            if (isset($data['goods_images']) && $data['goods_images'])
            {
                if (!empty($goods_imgs))
                {
                    $old_goods_images = array_column($goods_imgs, 'url');
                }

                if (!empty($data['goods_images']))
                {
                    $new_goods_images = explode(',', $data['goods_images']);
                    $new_goods_images = array_filter($new_goods_images);
                    $new_goods_images = array_merge($new_goods_images);
                }


                if (!isset($old_goods_images))
                {
                    // 需要添加的图片
                    foreach ($new_goods_images as $key => $value)
                    {
                        // if (empty($goods_imgs)) {
                        $img_INSERT[] = ['userid' => $Userid, 'business_id' => $Businessid, 'type' => 2, 'url' => $value, 'create_time' => time(),];
                        // } 
                    }
                    unset($key, $value);
                } else
                {
                    // 需要添加的图片
                    if (!empty($goods_imgs))
                    {
                        foreach ($new_goods_images as $key => $value)
                        {
                            if (!in_array($value, $old_goods_images))
                            {
                                $img_INSERT[] = ['userid' => $Userid, 'business_id' => $Businessid, 'type' => 2, 'url' => $value, 'create_time' => time(),];
                            }
                        }
                    }
                    unset($key, $value);

                    // 获取需要删除的图片
                    foreach ($goods_imgs as $key => $value)
                    {
                        if (!in_array($value['url'], $new_goods_images))
                        {
                            $delete_WHERE[] = $value['img_id'];
                        }
                    }
                    unset($key, $value);
                }
            }

            // dump($img_INSERT);
            // dump($delete_WHERE);
            // exit();


            // 整合店铺环境图片
            if (isset($data['environment_images']) && $data['environment_images'])
            {
                if (!empty($environment_imgs))
                {
                    $old_environment_imgs = array_column($environment_imgs, 'url');
                }

                if (!empty($data['environment_images']))
                {
                    $new_environment_images = explode(',', $data['environment_images']);
                    $new_environment_images = array_filter($new_environment_images);
                    $new_environment_images = array_merge($new_environment_images);
                }

                if (!isset($old_environment_imgs))
                {
                    foreach ($new_environment_images as $key => $value)
                    {
                        // if (empty($environment_imgs)) {
                        $img_INSERT[] = ['userid' => $Userid, 'business_id' => $Businessid, 'type' => 3, 'url' => $value, 'create_time' => time(),];
                        // } 
                    }
                    unset($key, $value);
                } else
                {
                    if (!empty($environment_imgs))
                    {
                        foreach ($new_environment_images as $key => $value)
                        {
                            if (!in_array($value, $old_environment_imgs))
                            {
                                $img_INSERT[] = ['userid' => $Userid, 'business_id' => $Businessid, 'type' => 3, 'url' => $value, 'create_time' => time(),];
                            }
                        }
                    }
                    unset($key, $value);

                    // 获取需要删除的图片
                    foreach ($environment_imgs as $key => $value)
                    {
                        if (!in_array($value['url'], $new_environment_images))
                        {
                            $delete_WHERE[] = $value['img_id'];
                        }
                    }
                    unset($key, $value);
                }
            }   
        }

// dump($environment_imgs);
// dump($new_environment_images);
// dump($old_environment_imgs);
// dump($img_INSERT);
// dump($delete_WHERE);
// exit();

        {   // 数据验证
            if (isset($data['logo']) && ($data['logo'] != $Oldbusdata['logo'])) {
                if (Config::get('scan_content.image')){
                    $Scan = \aliyuncs\Green\Check::imageSyncScan($data['logo']);
                    $business_UPDATE['logo'] =$Scan['auto_scan'] ? $Scan['url'] : "https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_c.png";
                }else{
                     $business_UPDATE['logo'] = $data['logo'];
                }
            }

            if (isset($data['name']) && ($data['name'] != $Oldbusdata['name'])) {
                $business_UPDATE['name'] = $data['name'];
            }

            if (isset($data['tel']) && ($data['tel'] != $Oldbusdata['tel'])) {
                $business_UPDATE['tel'] = $data['tel'];
            }

            if (isset($data['addra']) && ($data['addra'] != $Oldbusdata['addra'])) {
                $business_UPDATE['addra'] = $data['addra'];
            }

            if (isset($data['address']) && ($data['address'] != $Oldbusdata['address'])) {
                $business_UPDATE['address'] = $data['address'];
            }

            if (isset($data['longitude']) && ($data['longitude'] != $Oldbusdata['longitude'])) {
                $business_UPDATE['longitude'] = $data['longitude'];
            }

            if (isset($data['latitude']) && ($data['latitude'] != $Oldbusdata['latitude'])) {
                $business_UPDATE['latitude'] = $data['latitude'];
            }

            if (isset($data['default']) && ($data['default'] != $Oldbusdata['default'])) {
                $business_UPDATE['default'] = $data['default'];
            }

            // 营业时间格式处理
            if (!empty($data['do_day'])) {
                $cache = explode(',', $data['do_day']);
                $cache = array_filter($cache);
                sort($cache);

                $cache = ',' . implode(',', $cache) . ',';

                if ($data['do_day'] != $Oldbusdata['do_day']) {
                    $business_UPDATE['do_day'] = $data['do_day'];
                }
            }

            if (!empty($data['s_do_time']) && (strlen($data['s_do_time']) <= 5)) {
                $business_UPDATE['s_do_time'] = $data['s_do_time'];
            }

            if (!empty($data['e_do_time']) && (strlen($data['e_do_time']) <= 5)) {
                $business_UPDATE['e_do_time'] = $data['e_do_time'];
            }
        }

        if ((count($img_INSERT) <= 0) && (count($business_UPDATE) <= 0) && empty($delete_WHERE)) {
            return $this->sendSuccess(0, 'success', 200);
        }

        Db::startTrans();

        $delte_img = array('business_id' => $Businessid, 'userid' => $Userid,);
        $type = array();
        if (isset($data['logo']) && $data['logo'] == "")
        {
            array_push($type, 1);

        }

        if (isset($data['environment_images']) && $data['environment_images'] == "")
        {
            array_push($type, 3);
        }
        if (isset($data['goods_images']) && $data['goods_images'] == "")
        {
            array_push($type, 2);
        }

        if (!empty($type)){
            $delte_img['type'] = array('in',$type);
            Db::name('business_img')->where($delte_img)->update(array('delete_id'=>1,'delete_time'=>time()));
            if (in_array(1,$type)){
                Db::name('business')->where(array('id'=>$Businessid,'userid'=>$Userid))->update(array('logo'=>""));
            }
        }

        // dump($business_UPDATE);
        // dump($img_INSERT);
        // dump($delete_WHERE);
        // exit();

        try
        {
            if (isset($data['default']) && ($Oldbusdata['default'] != $data['default']) && ($data['default'] == 1))
            {    // 将之前的默认清除
                @$res_defalt = @Db::name('business')->where(['userid' => $Userid])->update(['default' => 0]);
            }

            // 更新数据
            if (count($business_UPDATE) > 0) {
                $Update_res = Db::name('business')->where('id', $Businessid)->update($business_UPDATE);
            }
            
            // 添加图片
            if (count($img_INSERT) > 0) {
                if (Config::get('scan_content.image')){
                    $img_INSERT = \aliyuncs\Green\Check::imageSyncScan($img_INSERT);
                }
                $Imgres_res = Db::name('business_img')->insertAll($img_INSERT);
            }

            // 删除图片
            if (count($delete_WHERE) > 0) {
                $delete_UPDATE['delete_id']   = $Userid;
                $delete_UPDATE['delete_time'] = time();

                $img_delete_WHERE['img_id'] = ['in', array_merge($delete_WHERE)];

                $Imgres_res = Db::name('business_img')->where($img_delete_WHERE)->update($delete_UPDATE);
            }

            Db::commit();
            return $this->sendSuccess(0, 'success', 200);
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(-1, 'error', 400);
        }
    }

    /**
     * @title  删除商户（伪删除）
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @desc 请求方式: DELETE <br/> 请求示例: v1/Business/1
     */
    public function delete($id)
    {
        $Userid     = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Businessid = intval($id);

        if (empty($Businessid)) {
            return $this->sendError(-1, '商户ID必填', 400);
        }

        $here_DELETE['delete_id']   = $Userid;
        $here_DELETE['delete_time'] = time();

        $result = Db::name('business')->where('id', $Businessid)->update($here_DELETE);

        if (empty($result)) {
            return $this->sendError(-1, 'error', 400);
        } else{
            return $this->sendSuccess('', 'success', 200);
        }
    }

    /**
     * @title  删除商户图片（伪删除）
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @desc 请求方式: POST <br/> 请求示例: v1/Business/deleteBusImg
     */
    public function deleteBusImg()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Imgids = input('imgids');

// dump($Userid);
// dump($Imgids);
// exit();

        if (empty($Imgids)) {
            return $this->sendError(-1, '商户图片ID必填', 400);
        }

        $Imgarray = explode(',', $Imgids);
        $Imgarray = array_filter($Imgarray);
        $Imgarray = array_merge($Imgarray);

        if (empty($Imgarray)) {
            return $this->sendError(-1, '商户图片ID必填', 400);
        }

        $here_DELETE['delete_id']   = $Userid;
        $here_DELETE['delete_time'] = time();

        $result = Db::name('business_img')->where('img_id', 'in', $Imgarray)->update($here_DELETE);

        if (empty($result)) {
            return $this->sendError(-1, 'error', 400);
        } else{
            return $this->sendSuccess('', 'success', 200);
        }
    }

    /**
     * @title  设置默认商户
     * @return int    error   错误代码：0成功 1失败
     * @return string message 消息提醒
     * @desc 请求方式: POST <br/> 请求示例: v1/Business/setDefaultBusiness
     */
    public function setDefaultBusiness()
    {
        $Userid     = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Businessid = input('businessid');

        // 获取用户商户数据
        $old_WHERE['id']     = $Businessid;
        $old_WHERE['userid'] = $Userid;
        $Old = Db::name('business')->where($old_WHERE)->find();

        if (empty($Old)) {
            return $this->sendError(1, '商户ID必填', 200);
        }

        if ($Old['default'] == 1) {
            return $this->sendSuccess(0, 'success', 200);
        }

        try {
            // 将之前的默认清除
            $Old = Db::name('business')->where(['userid' => $Userid])->update(['default' => 0]);

            // 将当前的设置为默认
            $Old = Db::name('business')->where($old_WHERE)->update(['default' => 1]);

            Db::commit();
            return $this->sendSuccess(0, 'success', 200);
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(1, 'error', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            // 'index' => [
            //     'userid' => [
            //         'name'    => 'userid',
            //         'type'    => 'int',
            //         'require' => 'true',
            //         'default' => '',
            //         'desc'    => '用户id',
            //         'range'   => ''
            //     ],
            // ],
            'addBusiness' => [
                'name' => [
                    'name'    => 'name',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '商户名称',
                    'range'   => ''
                ],
                'logo' => [
                    'name'    => 'logo',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户logo',
                    'range'   => ''
                ],
                'tel' => [
                    'name'    => 'tel',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '固定电话',
                    'range'   => ''
                ],
                'addra' => [
                    'name'    => 'addra',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户地址（例：省-市-区）',
                    'range'   => ''
                ],
                'address' => [
                    'name'    => 'address',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户地址（详细地址）',
                    'range'   => ''
                ],
                'longitude' => [
                    'name'    => 'longitude',
                    'type'    => 'float',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '经度',
                    'range'   => ''
                ],
                'latitude' => [
                    'name'    => 'latitude',
                    'type'    => 'float',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '纬度',
                    'range'   => ''
                ],
                'environment_images' => [
                    'name'    => 'environment_images',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '店铺环境图片 多张图片逗号隔开',
                    'range'   => ''
                ],
                'goods_images' => [
                    'name'    => 'goods_images',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '店铺商品图片 多张图片逗号隔开',
                    'range'   => ''
                ],
                'do_day' => [
                    'name'    => 'do_day',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '营业时间周一到日(例：1,2,3,4)',
                    'range'   => ''
                ],
                's_do_time' => [
                    'name'    => 's_do_time',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '每天开始营业时间（例：08:20）',
                    'range'   => ''
                ],
                'e_do_time' => [
                    'name'    => 'e_do_time',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '每天结束营业时间（例：23:30）',
                    'range'   => ''
                ],
                'default' => [
                    'name'    => 'default',
                    'type'    => 'string',
                    'require' => 'int',
                    'default' => '',
                    'desc'    => '是否设置为默认商户：0否|1是',
                    'range'   => ''
                ]
            ],
            'read' => [
                'id' => [
                    'name'    => 'id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '商户ID',
                    'range'   => ''
                ],
            ],
            'update' => [
                'logo' => [
                    'name'    => 'logo',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户logo',
                    'range'   => ''
                ],
                'name' => [
                    'name'    => 'name',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户名称',
                    'range'   => ''
                ],
                'tel' => [
                    'name'    => 'tel',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '固定电话',
                    'range'   => ''
                ],
                'addra' => [
                    'name'    => 'addra',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户地址（例：省-市-区）',
                    'range'   => ''
                ],
                'address' => [
                    'name'    => 'address',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户地址（详细地址）',
                    'range'   => ''
                ],
                'longitude' => [
                    'name'    => 'longitude',
                    'type'    => 'float',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '经度',
                    'range'   => ''
                ],
                'latitude' => [
                    'name'    => 'latitude',
                    'type'    => 'float',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '纬度',
                    'range'   => ''
                ],
                'environment_images' => [
                    'name'    => 'environment_images',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '店铺环境图片 多张图片逗号隔开',
                    'range'   => ''
                ],
                'goods_images' => [
                    'name'    => 'goods_images',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '店铺商品图片 多张图片逗号隔开',
                    'range'   => ''
                ],
                'do_day' => [
                    'name'    => 'do_day',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '营业时间周一到日(例：1,2,3,4)',
                    'range'   => ''
                ],
                's_do_time' => [
                    'name'    => 's_do_time',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '每天开始营业时间（例：08:20）',
                    'range'   => ''
                ],
                'e_do_time' => [
                    'name'    => 'e_do_time',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '每天结束营业时间（例：23:30）',
                    'range'   => ''
                ],
                'default' => [
                    'name'    => 'default',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '是否设置为默认商户：0否|1是',
                    'range'   => ''
                ]
            ],
            'updateBusiness' => [
                'businessid' => [
                    'name'    => 'businessid',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户id',
                    'range'   => ''
                ],
                'logo' => [
                    'name'    => 'logo',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户logo',
                    'range'   => ''
                ],
                'name' => [
                    'name'    => 'name',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户名称',
                    'range'   => ''
                ],
                'tel' => [
                    'name'    => 'tel',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '固定电话',
                    'range'   => ''
                ],
                'addra' => [
                    'name'    => 'addra',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户地址（例：省-市-区）',
                    'range'   => ''
                ],
                'address' => [
                    'name'    => 'address',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户地址（详细地址）',
                    'range'   => ''
                ],
                'longitude' => [
                    'name'    => 'longitude',
                    'type'    => 'float',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '经度',
                    'range'   => ''
                ],
                'latitude' => [
                    'name'    => 'latitude',
                    'type'    => 'float',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '纬度',
                    'range'   => ''
                ],
                'environment_images' => [
                    'name'    => 'environment_images',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '店铺环境图片 多张图片逗号隔开',
                    'range'   => ''
                ],
                'goods_images' => [
                    'name'    => 'goods_images',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '店铺商品图片 多张图片逗号隔开',
                    'range'   => ''
                ],
                'do_day' => [
                    'name'    => 'do_day',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '营业时间周一到日(例：1,2,3,4)',
                    'range'   => ''
                ],
                's_do_time' => [
                    'name'    => 's_do_time',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '每天开始营业时间（例：08:20）',
                    'range'   => ''
                ],
                'e_do_time' => [
                    'name'    => 'e_do_time',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '每天结束营业时间（例：23:30）',
                    'range'   => ''
                ],
                'default' => [
                    'name'    => 'default',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '是否设置为默认商户：0否|1是',
                    'range'   => ''
                ]
            ],
            'delete' => [
                'id' => [
                    'name'    => 'id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '商户ID',
                    'range'   => ''
                ],
            ],
            'getUserBusiness' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'deleteBusImg' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'imgids' => [
                    'name'    => 'imgids',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '以逗号隔开的图片id（例：1,55）',
                    'desc'    => '',
                    'range'   => ''
                ],
            ],
            'setDefaultBusiness' => [
                'businessid' => [
                    'name'    => 'businessid',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '商户id必填',
                    'desc'    => '',
                    'range'   => ''
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
