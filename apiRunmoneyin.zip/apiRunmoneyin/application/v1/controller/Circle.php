<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 圈子接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;

/**
 * Class  Index
 * @title 圈子接口
 * @url   v1/Circle
 * @desc  圈子接口：创建圈子、编辑圈子、我的圈子、精选圈子、圈子步数排行接口、获取圈子详情
 * @version 1.0
 * @readme
 */
class Circle extends Base
{
    // 附加方法
    protected $extraActionList = ['getRank', 'sendRedBag', 'getUserCircleRank', 'UserCircleWeekRank', 'UserCircleWeekNum', 'getCircleBase'];

    // 跳过验证方法
    protected $skipAuthActionList = ['getCircleBase'];

    protected $rule = [
        'userid'      => 'require',
        'name'        => 'require',
        'targetid'    => 'require',
        'mobile'      => 'require',
        'is_recharge' => 'require',
        'logo'        => 'require',
        'is_pwd'      => 'require',
        'description' => 'require',
        // 'city'        => 'require',
        // 'longitude'   => 'require',
        // 'latitude'    => 'require',
    ];

    protected $msg = [
        'userid.require'      => '用户ID必填',
        'name.require'        => '圈子名称必填',
        'targetid.require'    => '圈子目标必填',
        'mobile.require'      => '手机号必填',
        'is_recharge.require' => '是否充值必填',
        'logo.require'        => 'LOGO必填',
        'is_pwd.require'      => '是否启用密码必填',
        'description.require' => '请输入400字以内的圈子描述',
        // 'city.require'        => '城市必填',
        // 'longitude.require'   => '经度必填',
        // 'latitude.require'    => '纬度必填',
    ];

    /**
     * @title 获取我的圈子/精选圈子/我加入的圈子/我创建的圈子
     * @return int    error         错误代码：0成功 -1错误
     * @return string message       消息提醒
     * @return object data          圈子对象
     * @return int    id            圈子ID
     * @return string name          圈子名称
     * @return string logo          圈子LOGO
     * @return string city          圈子所在市
     * @return int    target        圈子目标步数
     * @return int    member_number 圈子成员数
     * @return int    is_red_packet 是否有红包：0没有红包 1有红包
     * @desc 请求方式：GET<br/> 请求示例：v1/Circle?action=my&userid=1&page=1&pagesize=10
     */
    public function index()
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = input('get.userid');
        $action   = input('get.action');
        $keyword  = input('get.keyword') ? input('get.keyword') : '';
        $page     = input('get.page') ? intval(input('get.page')) : 1;               // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;      // 每页显示数量

        if (!$Userid || empty($action)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        // 开发领取圈子红包时间
        if (time() >= strtotime(date('Y-m-d') . ' 21:18:00')) {
            $is_red_time = 1;
        } else {
            $is_red_time = 0;
        }

        // 获取我的圈子
        if ($action == 'my' || $action == "") {
            $sameDay = strtotime('today');  // 当日时间戳
            $nextDay = $sameDay + 86400;    // 次日时间戳

            // $totalCount = Db::name('circle')
            //     ->field('id as circleid,name,logo,city')
            //     ->where('id','IN',function($query) use ($Userid){
            //         $query->name('circle_member')->where(['userid'=>$Userid])->field('circleid')->group('circleid');
            //     })
            //     ->whereLike('id|name','%'.$keyword.'%')
            //     ->order('create_time desc')
            //     ->count();
            
            // $circle = Db::name('circle')
            //     ->alias('circle')
            //     ->join('circle_target','circle.targetid = circle_target.id')
            //     ->field('circle.id,circle.name,circle.logo,circle.city,circle.is_recharge,circle.total_amount,circle.red_packet_amount,circle_target.target')
            //     ->where('circle.id','IN',function($query) use ($Userid){
            //         $query->name('circle_member')->where(['userid'=>$Userid])->field('circleid')->group('circleid');
            //     })
            //     ->whereLike('circle.id|circle.name','%'.$keyword.'%')
            //     ->order('circle.id desc')
            //     ->page($page,$pageSize)
            //     ->select();

            $totalCount = Db::name('circle')
                ->alias('circle')
                ->field('id as circleid,name,logo,city')
                ->where('circle.delete_id', 0)
                ->where('id','IN',function($query) use ($Userid){
                    $query->name('circle_member')->where(['userid'=>$Userid])->field('circleid')->group('circleid');
                })
                ->whereLike('id|name','%'.$keyword.'%')
                ->order('create_time desc')
                ->count();

            if (empty($totalCount)) {
                return $this->sendError(1, 'Not Found Data', 200);
            }

            $circle = Db::name('circle')
                ->alias('circle')
                ->join('circle_target','circle.targetid = circle_target.id')
                ->field('circle.id,circle.name,circle.logo,circle.city,circle.is_recharge,circle.total_amount,circle.red_packet_amount,circle_target.target')
                ->where('circle.delete_id', 0)
                ->where('circle.id','IN',function($query) use ($Userid){
                    $query->table('rm_circle_member')->where(['userid'=>$Userid,'delete_id'=>0])->field('rm_circle_member.circleid')->group('rm_circle_member.circleid');
                })
                ->whereLike('circle.id|circle.name','%'.$keyword.'%')
                ->order('circle.id desc')
//                ->page($page,$pageSize)
                ->select();

            foreach ($circle as $key => $value) {
                $map = array();
                $map['userid'] = $Userid;
                $map['create_time'] = ['between', [$sameDay,$nextDay]];

                $user_step = Db::name('user_step')->where($map)->find();   // 获取用户步数

                // 查询成员数
                $member_number = Db::name('circle_member')
                    ->alias('circle_member')
                    ->where('circleid', $value['id'])
                    ->count();

                $circle[$key]['member_number'] = $member_number;

                if ($circle[$key]['is_recharge'] == 1) {
                    // 圈子总金额大于红包金额
                    if ($circle[$key]['total_amount'] >= $circle[$key]['red_packet_amount']) {
                        // 如果存在步数
                        if ($user_step) {
                            // 用户步数 大于 圈子目标 有红包
                            if ($user_step['step_number'] > $value['target']) {
                                $map = array();
                                $map['circleid']    = $value['id'];
                                $map['userid']      = $Userid;
                                // $map['create_time'] = ['>=', strtotime('today')];

                                // 判断是否领过红包
                                $circle_record = db('circle_record')
                                    ->where($map)
                                    ->find();

                                if ($circle_record) {
                                    $circle[$key]['is_red_packet'] = 0;
                                } else {
                                    $circle[$key]['is_red_packet'] = 1;
                                }
                            } else {
                                $circle[$key]['is_red_packet'] = 0;
                            }
                        } else {
                            $circle[$key]['is_red_packet'] = 0;
                        }
                    } else {
                        $circle[$key]['is_red_packet'] = 0;
                    }
                }

                $circle[$key]['is_red_time'] = $is_red_time;
            }

            $retData = returnData($page, $pageSize, $totalCount, $circle);

        } else if ($action == 'choice') {    // 获取精选圈子（后期加上用户的定位）
            // 获取圈子人员数据（子查询）
            $subQuery = Db::name('circle_member')
                ->field(true)
                ->where('delete_id', 0)
                ->group('circleid,userid')
                ->buildSql(); 

            $totalCount = Db::table($subQuery.' a')
                ->group('circleid')
                ->count();

            // 精选圈子（后期加上用户的定位）
            $Selectedcircle = Db::table($subQuery.' cm')
                ->field('circleid,cm.userid,count(cm.id) as member_number,name,logo,city,circle.is_pwd')
                ->join('circle','circle.id=cm.circleid')
                ->whereLike('circle.id|circle.name','%'.$keyword.'%')
                ->where('cm.delete_id', 0)
                ->where('circle.delete_id', 0)
                ->group('circleid')
                ->order('count(cm.id) desc')
                // ->buildSql();
                ->page($page, $pageSize)
                ->select();

// dump($subQuery);
// dump($totalCount);
// dump($Selectedcircle);
// exit();

            //在精选圈子数据中添加“is_join”字段；--bug:404圈子缺少字段
            if (!empty($Selectedcircle)) {
                foreach ($Selectedcircle as $key => $value) {
                    $userincircle = Db::name('circle_member')
                        ->where('userid', $Userid)
                        ->where('circleid', $value['circleid'])
                        ->where('delete_id', 0)
                        ->find();

                    if (!empty($userincircle)) {
                        $Selectedcircle[$key]['is_join'] = 1;
                    } else {
                        $Selectedcircle[$key]['is_join'] = 0;
                    }
                }
            }

            $retData = returnData($page, $pageSize, $totalCount, $Selectedcircle);

        } else if ($action == 'join') {    // 我加入的圈子
            $sameDay = strtotime('today'); // 当日时间戳
            $nextDay = $sameDay + 86400;   // 次日时间戳

            $totalCount = Db::name('circle')
                ->alias('circle')
                ->field('id as circleid,name,logo,city')
                ->where('circle.delete_id', 0)
                ->where('id','IN',function($query) use ($Userid){
                    $query->table('rm_circle_member')
                        // ->where(['userid'=>$Userid, 'is_admin'=>0, 'delete_id'=>0])
                        ->where('userid', $Userid)
                        ->where('is_admin', '<>', 2)
                        ->where('delete_id', 0)
                        ->field('rm_circle_member.circleid')
                        ->group('rm_circle_member.circleid');
                })
                ->whereLike('id|name','%'.$keyword.'%')
                ->order('create_time desc')
                ->count();

            if (empty($totalCount))  {
                return $this->sendError(1, 'No Found data', 200);
            }

            $circle = Db::name('circle')
                ->alias('circle')
                ->join('circle_target','circle.targetid = circle_target.id')
                ->where('circle.delete_id', 0)
                ->field('circle.id,circle.name,circle.logo,circle.city,circle.is_recharge,circle.total_amount,circle.red_packet_amount,circle_target.target')
                ->where('circle.id','IN',function($query) use ($Userid){
                    $query->table('rm_circle_member')
                        // ->where(['userid'=>$Userid, 'is_admin'=>0, 'delete_id'=>0])
                        ->where('userid', $Userid)
                        ->where('is_admin', '<>', 2)
                        ->where('delete_id', 0)
                        ->field('rm_circle_member.circleid')
                        ->group('rm_circle_member.circleid');
                })
                ->whereLike('circle.id|circle.name','%'.$keyword.'%')
                ->order('circle.id desc')
                ->page($page,$pageSize)
                ->select();

            if($circle){
                foreach ($circle as $key => $value) {

                    $map = array();
                    $map['userid'] = $Userid;
                    $map['create_time'] = ['between', [$sameDay,$nextDay]];

                    $user_step = Db::name('user_step')
                    ->where($map)
                    ->find();

                    if($circle[$key]['is_recharge'] == 1){
                        // 圈子总金额大于红包金额
                        if($circle[$key]['total_amount'] >= $circle[$key]['red_packet_amount']){
                            // 如果存在步数
                            if($user_step){
                                // 用户步数 大于 圈子目标 有红包
                                if($user_step['step_number'] > $value['target']){
                                    $map = array();
                                    $map['circleid'] = $value['id'];
                                    $map['userid']   = $Userid;
                                    // $map['create_time'] = ['>=',strtotime('today')];

                                    // 判断是否领过红包
                                    $circle_record = db('circle_record')
                                    ->where($map)
                                    ->find();

                                    if($circle_record){
                                        $circle[$key]['is_red_packet'] = 0;
                                    }else{
                                        $circle[$key]['is_red_packet'] = 1;
                                    }
                                }else{
                                    $circle[$key]['is_red_packet'] = 0;
                                }
                            }else{
                                $circle[$key]['is_red_packet'] = 0;
                            }
                        }else{
                            $circle[$key]['is_red_packet'] = 0;
                        }
                    }

                    $circle[$key]['is_red_time'] = $is_red_time;

                    // 查询成员数
                    $member_number = Db::name('circle_member')
                    ->alias('circle_member')
                    ->where('circleid',$value['id'])
                    ->count();
                    $circle[$key]['member_number'] = $member_number;
                }
            }

            $retData = returnData($page,$pageSize,$totalCount,$circle);

        } else if ($action == 'create') {    // 获取我创建的圈子
            $sameDay = strtotime('today');   // 当日时间戳
            $nextDay = $sameDay + 86400;     // 次日时间戳
            
            $totalCount = Db::name('circle')
                ->alias('circle')
                ->field('id as circleid,name,logo,city')
                ->where('circle.delete_id', 0)
                ->where('id','IN',function($query) use ($Userid){
                    $query->table('rm_circle_member')
                        ->where(['userid'=>$Userid,'is_admin'=>2])
                        ->field('rm_circle_member.circleid')
                        ->group('rm_circle_member.circleid');
                })
                ->whereLike('id|name','%'.$keyword.'%')
                ->order('create_time desc')
                ->count();

            if (empty($totalCount))  {
                return $this->sendError(1, 'No Found data', 200);
            }

            $circle = Db::name('circle')
                ->alias('circle')
                ->join('circle_target','circle.targetid = circle_target.id')
                ->field('circle.id,
                    circle.name,
                    circle.logo,
                    circle.city,
                    circle.is_recharge,
                    circle.total_amount,
                    circle.red_packet_amount,
                    circle_target.target,
                    circle.create_time'
                )
                ->where('circle.delete_id', 0)
                ->where('circle.id','IN',function($query) use ($Userid){
                    $query->table('rm_circle_member')
                        ->where(['userid'=>$Userid,'is_admin'=>2])
                        ->field('rm_circle_member.circleid')
                        ->group('rm_circle_member.circleid');
                })
                ->whereLike('circle.id|circle.name','%'.$keyword.'%')
                ->order('circle.id desc')
                ->page($page,$pageSize)
                ->select();


            // 获取我的步数
            $map = array();
            $map['userid']      = $Userid;
            $map['create_time'] = ['between', [$sameDay,$nextDay]];

            $user_step = array();
            $user_step = Db::name('user_step')
                ->where($map)
                ->order('id desc')
                ->find();

            foreach ($circle as $key => $value) {
                $circle[$key]['is_red_packet'] = 0;
                $circle[$key]['is_red_time']   = $is_red_time;

                if ($circle[$key]['is_recharge'] == 1) {
                    $yue  = round($value['total_amount'], 2);        // 圈子余额
                    $redm = round($value['red_packet_amount'], 2);   // 圈子每日红包金额

                    if (($yue >= $redm) && ($redm > 0)) {    // 圈子总金额大于红包金额
                        // 如果存在步数
                        if ($user_step) {
                            // 用户步数 大于 圈子目标 有红包
                            if ($user_step['step_number'] > $value['target']) {
                                $map = array();
                                $map['circleid']    = $value['id'];
                                $map['userid']      = $Userid;
                                // $map['create_time'] = ['>=', strtotime('today')];

                                // 判断是否领过红包
                                $circle_record = db('circle_record')
                                    ->where($map)
                                    ->find();

                                if (empty($circle_record)) {
                                    $circle[$key]['is_red_packet'] = 1;
                                }
                            }
                        }
                    } 
                }

                // 查询成员数
                $member_number = Db::name('circle_member')
                    ->alias('circle_member')
                    ->where('circleid', $value['id'])
                    ->where('delete_id', 0)
                    ->count();

                if ($member_number > 0) {
                    $circle[$key]['member_number'] = $member_number;
                } else {
                    $circle[$key]['member_number'] = 0;
                }
                
                // // 查询充值订单
                // $order = Db::name('order')
                //     ->alias('order')
                //     ->join('order_recharge_record', 'order_recharge_record.order_no = order.order_no')
                //     ->join('circle_member','order.userid = circle_member.userid')
                //     ->where(['order.userid'=>$Userid,'order_recharge_record.circleid'=>$value['id'],'circle_member.is_admin'=>1])
                //     ->find();

                // // 判断是否充值
                // if ($order && $order['status']) {
                //     $circle[$key]['order_no'] = $order['order_no'];
                //     $circle[$key]['is_recharge'] = 1;
                // } else {
                //     $circle[$key]['is_recharge'] = 0;
                // }
            }
            
            $retData = returnData($page,$pageSize,$totalCount,$circle);
        } else {
            return $this->sendError(1, 'Not Found Action', 200);
        }

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }

    /**
     * @title 创建圈子
     * @return int    error   错误代码：0成功 -1错误
     * @return string message 消息提醒
     * @return object data    圈子对象
     * @return int    id      圈子ID
     * @return string name    圈子名称
     * @return string logo    圈子LOGO
     * @desc 请求方式：POST<br/>请求示例：v1/Circle
     */
    public function save(Request $request)
    {
        $data                = $request->post();
        $data['create_time'] = time();
        $data['coverid']     = rand(1, 5);

        if (isset($data['total_amount'])) {
            unset($data['total_amount']);
        }

        $validate = new Validate($this->rule, $this->msg);
        $validate_result = $validate->check($data);

        if (empty($validate_result)) {
            return $this->sendError(1, $validate->getError(), 200);
        }


        // 如果充值开启（验证充值数据）
        if ($data['is_recharge'] == 1) {
            $recharge_rule['red_packet_amount']        = 'require';
            $recharge_rule['red_packet']               = 'require';

            $recharge_msg['red_packet_amount.require'] = '每日红包金额必填';
            $recharge_msg['red_packet.require']        = '每日红包个数必填';

            // 验证字段
            $recharge_validate = new Validate($recharge_rule, $recharge_msg);
            $recharge_result   = $recharge_validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(1, $recharge_validate->getError(), 200);
            }

            // 圈子名
            $Circleneme = strFilter($data['name']);

            // 圈子名字
            if ((strlen($Circleneme) == mb_strlen($Circleneme,"utf-8")) && (strlen($Circleneme) > 32)) {
                return $this->sendError(1, '英文字符串不能大于32位', 200);
            } elseif ((strlen($Circleneme) == mb_strlen($Circleneme, "utf-8") * 3) && (mb_strlen($Circleneme) > 16)) {
                return $this->sendError(1, '中文字符串不能大于16位', 200);
            } else {
                preg_match_all('/[\x{4e00}-\x{9fff}]+/u', $Circleneme, $Chinese);
                $Chinese = implode('', $Chinese[0]);
                $Mixlen = ((strlen($Circleneme) - strlen($Chinese)) / 2) + mb_strlen($Chinese, "utf-8");

                if ($Mixlen > 20) {
                    return $this->sendError(1, '混合符串不能大于20位', 200);
                }
            }

            // 平均每个红包最小限制
            if (($data['red_packet'] * 0.01) > $data['red_packet_amount']) {
                return $this->sendError(1, '每个红包最小金额为0.01元', 200);
            }

            // 平均每个红包最大限制
            if ($data['red_packet_amount'] / $data['red_packet'] > 200) {
                return $this->sendError(1, '平均每个红包最大金额为200元', 200);
            }

            if (!preg_match("/^1[34578]{1}\d{9}$/", $data['mobile'])) {
                return $this->sendError(1, '请输入正确的手机号码', 200);
            }
        }

// dump($data);
// die;
        // 如果密码开启
        if ($data['is_pwd'] == 1) {
            $this->rule['password']        = 'require|min:6|max:32';

            $this->msg['password.require'] = '密码必填';
            $this->msg['password.min']     = '密码只能在6-32位之间';
            $this->msg['password.max']     = '密码只能在6-32位之间';

            // 验证字段
            $validate = new Validate($this->rule, $this->msg);
            $validate_result   = $validate->check($data);
        }

        $where = [
            'name'=>$data['name'],
            'delete_time'=>0,
            'delete_id'=>0,
        ];

        $circle = Db::name('circle')->where($where)->find();

        if ($circle) {
            return $this->sendError(1, '圈子名称已经存在', 200);
        }

        Db::startTrans();

        try {
            if (isset($data['password']) && !empty($data['password'])) {
                $data['password'] = $data['password'];
            }

            // 创建圈子并获取主键ID
            $circleid = Db::name('circle')->insertGetId($data);

            // 加入圈子成员
            $circle_member = array(
                'userid'   => $data['userid'],
                'circleid' => $circleid,
                'is_admin' => 2,
            );

            Db::name('circle_member')->insert($circle_member);

            Db::commit();
            return $this->sendSuccess(array('id' => $circleid, 'name' => $data['name'], 'logo' => $data['logo']), '创建成功', 200);
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(-1, $e->getMessage(), 400);
        }
    }

    /**
     * @title 获取圈子详情
     * @return int    error               错误代码：0成功 -1错误
     * @return string message             消息提醒
     * @return object data                圈子详情对象
     * @return int    id                  圈子ID
     * @return int    userid              用户ID
     * @return string name                圈子名称
     * @return string cover               封面图片
     * @return int    targetid            圈子目标步数id
     * @return int    target              圈子目标步数
     * @return string mobile              管理员手机号
     * @return string logo                圈子LOGO
     * @return int    is_pwd              是否设置密码 0无需密码 1密码验证
     * @return string description         圈子描述
     * @return string city                圈子城市
     * @return float  longitude           经度
     * @return float  latitude            纬度
     * @return float  total_amount        总金额
     * @return int    is_recharge         是否充值：0不充值 1充值
     * @return float  red_packet_amount   每日红包总金额
     * @return int    red_packet          每日红包个数
     * @return int    create_time         圈子创建时间
     * @return int    is_join             是否加入
     * @return int    is_admin            是否管理员
     * @return int    is_red_packet       是否有红包：0否 1是
     * @return int    is_red_time         是否到可领红包时间：0否 1是
     * @return int    red_packet_status   个人红包状态：0步数未达标|1有红包|2红包已领完|3用户已经领过红包|4圈子余额不足
     * @return float  red_packet_money    已领红包金额
     * @desc 请求方式：GET <br/> 请求示例：v1/Circle/圈子id?userid=1
     */
    public function read($id)
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = intval(input('userid'));
        $circleid = intval(input('id'));

        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填', 200);
        }

        if (empty($circleid)) {
            return $this->sendError(-1, '圈子ID必填', 200);
        }

        $sameDay = strtotime('today');   // 当日时间戳
        $nextDay = $sameDay + 86400 -1;  // 次日时间戳

        // 领红包的时间点判断
        if (time() >= strtotime(date('Y-m-d') . ' 21:18:00')) {
            $is_red_time = 1;
        } else {
            $is_red_time = 0;
        }

        {   // 获取圈子详情  上线后密码需隐藏
            $circle = Db::name('circle')
                ->alias('circle')
                ->join('circle_target', 'circle_target.id = circle.targetid', 'LEFT')
                ->join('circle_cover', 'circle_cover.id = circle.coverid', 'LEFT')
                ->field('
                    circle.id,
                    circle.userid,
                    circle.name,
                    circle_cover.conver as cover,
                    circle.targetid,
                    circle_target.target,
                    circle.mobile,
                    circle.logo,
                    circle.is_pwd,
                    circle.description,
                    circle.city,
                    circle.longitude,
                    circle.latitude,
                    circle.total_amount,
                    circle.is_recharge,
                    circle.red_packet_amount,
                    circle.red_packet,
                    circle.create_time
                ')
                ->where('circle.id', $circleid)
                ->find();

            if (empty($circle)) {
                return $this->sendError(-1, 'Not Found Circle', 200);
            }
        }

        $circle['is_red_time']       = $is_red_time;  // 是否到可领红包时间：0否 1是
        $circle['red_packet_status'] = 0;             // 红包状态：0步数未达标|1有红包|2红包已领完|3用户已经领过红包|4圈子余额不足
        $circle['red_packet_money']  = 0.0;           // 已领红包金额
        $circle['is_red_packet']     = 0;             // 是否有红包：0无 1有

        {   // 获取用户当前的步数
            $map['userid']     = $Userid;
            $map['create_day'] = date('Y-m-d');

            $user_step = Db::name('user_step')->where($map)->order('id desc')->value('step_number');

            if (empty($user_step)) {
                $user_step = 0;
            }
            unset($map);
        }

// dump($circle);
// dump($Userid);
// dump($user_step);
// die;

        {   // 获取成员加入圈子数据
            $circle_member = Db::name('circle_member')
                ->where(['userid' => $Userid, 'circleid' => $circleid, 'delete_id' => 0])
                ->find();

            // 判断成员是否在圈子
            if ($circle_member) {
                $circle['is_join'] = 1;
            } else {
                $circle['is_join']  = 0;
                $circle['is_admin'] = 0;
                return $this->sendSuccess($circle, 'success1', 200);
            }

            // 判断成员是否是圈子创建者
            if ($circle['userid'] == $Userid) {
                $circle['is_admin'] = 1;
            } else {
                $circle['is_admin'] = 0;
            }
        }

        {   // 获取当天红包数据
            $circle_record = db('circle_record')
                ->field(true)
                ->where([
                    'circleid'    => $circleid,
                    // 'userid'      => $Userid,
                    // 'status'      => 1,
                    'create_time' => ['>=', strtotime('today')]
                ])
                ->select();

            if (count($circle_record) > 0) {
                // 判断成员是否领过红包
                foreach ($circle_record as $key => $value) {
                    if (($value['userid'] == $Userid) && ($value['status'] == 1)) {
                        $circle['red_packet_status'] = 3;   // 红包状态：0步数未达标|1有红包|2红包已领完|3用户已经领过红包|4圈子余额不足
                        $circle['red_packet_money']  = $value['amount'];   // 已领红包金额

                        return $this->sendSuccess($circle, 'success2', 200);
                    }
                }
                unset($key, $value);
            }
        }

// dump($circle_record);
// exit();

        // 生成当天的红包
        if (empty($circle_record)) {
            // $redsum = intval($circle['red_packet']);
            $yue  = round($circle['total_amount'], 2);        // 圈子余额
            $redm = round($circle['red_packet_amount'], 2);   // 圈子每日红包金额

            if (($yue <= 0) || ($redm > $yue)) {
                $circle['red_packet_status'] = 4;   // 红包状态：0步数未达标|1有红包|2红包已领完|3用户已经领过红包|4圈子余额不足
                return $this->sendSuccess($circle, 'success3', 200);
            }

// dump($circle_record);
// dump($circle);
// dump($yue);
// dump($redm);
// dump($yue <= 0);
// dump(($redm > $yue));
// die;

            if ($circle['red_packet_amount'] <= 0) {
                return $this->sendSuccess($circle, '每日红包金额为空', 200);
            }

            // 生成红包
            $redBag = redPacketGenerate($circle['red_packet_amount'], $circle['red_packet']);

            $here_INSERT = [];
            foreach ($redBag as $key => $value) {
                $here_INSERT[] = array(
                    'amount'      => $value,
                    'create_time' => time(),
                    'circleid'    => $circleid,
                );
            }

            // 生成圈子红包
            $record = db('circle_record')->lock(true)->insertAll($here_INSERT);

            $canLetBag = $here_INSERT;
        } else {   
            // 查询当前圈子可领红包数
            // 可领领个数
            $canLetBag = db('circle_record')
                ->where([
                    'circleid'    => $circleid,
                    'status'      => 0,
                    'create_time' => ['>=', strtotime('today')]
                ])
                ->count();

            if ($canLetBag <= 0) {
                $circle['red_packet_status'] = 2;   // 红包状态：0步数未达标|1有红包|2红包已领完|3用户已经领过红包|4圈子余额不足
                return $this->sendSuccess($circle, 'success4', 200);
            }
        }

// dump($circle);
// die;
        // 判断圈子是否有充值
        if ($circle['is_recharge'] == 1) {
            if (isset($canLetBag) && intval($canLetBag) > 0) { // 圈子总金额大于红包金额（并且不能小于零），用户要有步数
                if ($user_step >= $circle['target']) {         // 用户步数大于圈子目标有红包
                    $circle['is_red_packet']     = 1;
                    $circle['red_packet_status'] = 1;   // 红包状态：0步数未达标|1有红包|2红包已领完|3用户已经领过红包|4圈子余额不足
                }
            } else {
                $circle['red_packet_status'] = 4;       // 红包状态：0步数未达标|1有红包|2红包已领完|3用户已经领过红包|4圈子余额不足
            }
        } else {
            $circle['red_packet_status'] = 4;           // 红包状态：0步数未达标|1有红包|2红包已领完|3用户已经领过红包|4圈子余额不足
        }
 
        return $this->sendSuccess($circle, 'success5', 200);
    }

    /**
     * @title 获取圈子基本信息（跳过验证）
     * @return int    error               错误代码：0成功 -1错误
     * @return string message             消息提醒
     * @return object data                圈子详情对象
     * @return int    id                  圈子ID
     * @return int    userid              用户ID
     * @return string name                圈子名称
     * @return string cover               封面图片
     * @return int    targetid            圈子目标步数id
     * @return int    target              圈子目标步数
     * @return string mobile              管理员手机号
     * @return string logo                圈子LOGO
     * @return int    is_pwd              是否设置密码 0无需密码 1密码验证
     * @return string description         圈子描述
     * @return string city                圈子城市
     * @return float  longitude           经度
     * @return float  latitude            纬度
     * @return float  total_amount        总金额
     * @return int    is_recharge         是否充值：0不充值 1充值
     * @return float  red_packet_amount   每日红包总金额
     * @return int    red_packet          每日红包个数
     * @return int    create_time         圈子创建时间
     * @return int    is_join             是否加入
     * @return int    is_admin            是否管理员
     * @return int    is_red_packet       是否有红包：0否 1是
     * @return int    is_red_time         是否到可领红包时间：0否 1是
     * @return int    red_packet_status   个人红包状态：0步数未达标|1有红包|2红包已领完|3用户已经领过红包|4圈子余额不足
     * @return float  red_packet_money    已领红包金额
     * @desc 请求方式：GET <br/> 请求示例：v1/Circle/getCircleBase
     */
    public function getCircleBase()
    {
        // 指定允许其他域名访问  
        header('Access-Control-Allow-Origin:*');  
        // 响应类型  
        header('Access-Control-Allow-Methods:POST');  
        // 响应头设置  
        header('Access-Control-Allow-Headers:x-requested-with,content-type');  

        $circleid = intval(input('circleid'));

        if (empty($circleid)) {
            return $this->sendError(-1, '圈子ID必填', 200);
        }

        {   // 获取圈子详情  上线后密码需隐藏
            $circle = Db::name('circle')
                ->alias('circle')
                ->join('circle_target', 'circle_target.id = circle.targetid', 'LEFT')
                ->join('circle_cover', 'circle_cover.id = circle.coverid', 'LEFT')
                ->field('
                    circle.id,
                    circle.userid,
                    circle.name,
                    circle_cover.conver as cover,
                    circle.targetid,
                    circle_target.target,
                    circle.mobile,
                    circle.logo,
                    circle.is_pwd,
                    circle.description,
                    circle.city,
                    circle.longitude,
                    circle.latitude,
                    circle.total_amount,
                    circle.is_recharge,
                    circle.red_packet_amount,
                    circle.red_packet,
                    circle.create_time
                ')
                ->where('circle.id', $circleid)
                ->find();

            if (empty($circle)) {
                return $this->sendError(1, 'Not Found Data', 200);
            }
        }

        return $this->sendSuccess($circle, 'success', 200);
    }

    /**
     * @title  编辑圈子
     * @return int error      错误代码：0成功 1错误
     * @return string message 消息提醒
     * @desc 请求方式：PUT <br/>请求示例：v1/Circle/100000
     */
    public function update(Request $request, $id)
    {
        $data = $request->put();

        // is_recharge,red_packet_amount
        $Oldcircle = Db::name('circle')
            ->field('
                logo,name,description,mobile,coverid,targetid,
                city,longitude,latitude,is_recharge,red_packet_amount,red_packet,
                is_pwd,password
            ')
            ->where('id', $id)
            ->find();

        if (empty($Oldcircle)) {
            return $this->sendError(1, '圈子不存在！', 200);
        }

        $here_INSERT = [];

        if (!empty($data['logo']) && ($data['logo'] != $Oldcircle['logo'])) {
            $here_INSERT['logo'] = $data['logo'];
        }
        if (!empty($data['name']) && ($data['name'] != $Oldcircle['name'])) {
            // $here_INSERT['name'] = $data['name'];

            // 圈子名
            $Circleneme = strFilter($data['name']);

            // 圈子名字
            if ((strlen($Circleneme) == mb_strlen($Circleneme, "utf-8")) && (strlen($Circleneme) > 32)) {
                return $this->sendError(1, '英文字符串不能大于32位', 200);
            } elseif ((strlen($Circleneme) == mb_strlen($Circleneme, "utf-8") * 3) && (mb_strlen($Circleneme) > 16)) {
                return $this->sendError(1, '中文字符串不能大于16位', 200);
            } else {
                preg_match_all('/[\x{4e00}-\x{9fff}]+/u', $Circleneme, $Chinese);
                $Chinese = implode('', $Chinese[0]);
                $Mixlen = ((strlen($Circleneme) - strlen($Chinese)) / 2) + mb_strlen($Chinese, "utf-8");

                if ($Mixlen > 20) {
                    return $this->sendError(1, '混合符串不能大于20位', 200);
                }
            }

            if (($Circleneme != $Oldcircle['name'])) {
                $here_INSERT['name'] = $Circleneme;
            }
        }
        if (!empty($data['description']) && ($data['description'] != $Oldcircle['description'])) {
            $here_INSERT['description'] = $data['description'];
        }
        if (!empty($data['coverid']) && ($data['coverid'] != $Oldcircle['coverid'])) {
            $here_INSERT['coverid'] = intval($data['coverid']);
        }
        if (!empty($data['targetid']) && ($data['targetid'] != $Oldcircle['targetid'])) {
            $here_INSERT['targetid'] = intval($data['targetid']);
        }
        if (!empty($data['city']) && ($data['city'] != $Oldcircle['city'])) {
            $here_INSERT['city'] = $data['city'];
        }
        if (!empty($data['longitude']) && ($data['longitude'] != $Oldcircle['longitude'])) {
            $here_INSERT['longitude'] = $data['longitude'];
        }
        if (!empty($data['latitude']) && ($data['latitude'] != $Oldcircle['latitude'])) {
            $here_INSERT['latitude'] = $data['latitude'];
        }
        if (!empty($data['is_recharge']) && ($data['is_recharge'] != $Oldcircle['is_recharge'])) {
            if ($data['is_recharge'] == 0 || $data['is_recharge'] == 1) {
                $here_INSERT['is_recharge'] = $data['is_recharge'];
            }
        }
        if (!empty($data['red_packet_amount']) && ($data['red_packet_amount'] != $Oldcircle['red_packet_amount'])) {
            $here_INSERT['red_packet_amount'] = $data['red_packet_amount'];
        }
        if (!empty($data['red_packet']) && ($data['red_packet'] != $Oldcircle['red_packet'])) {
            $here_INSERT['red_packet'] = $data['red_packet'];
        }
        if (!empty($data['password']) && ($data['password'] != $Oldcircle['password'])) {
            $here_INSERT['password'] = $data['password'];
        }
        if (isset($data['is_pwd']) && ($data['is_pwd'] != $Oldcircle['is_pwd'])) {
            if ($data['is_pwd'] == 0 || $data['is_pwd'] == 1) {
                $here_INSERT['is_pwd'] = $data['is_pwd'];

                if (($here_INSERT['is_pwd'] == 0) && ($Oldcircle['password'] != '')) {
                    $here_INSERT['password'] = '';
                }

                if (($here_INSERT['is_pwd'] == 1) && empty($data['password'])) {
                    return $this->sendSuccess(1, '设置圈子需要密码时，圈子密码必填', 200);
                }
            }
        }


// // 平均每个红包最小限制
// if (($data['red_packet'] * 0.01) > $data['red_packet_amount']) {
//     return $this->sendError(1, '每个红包最小金额为0.01元', 200);
// }

// // 平均每个红包最大限制
// if ($data['red_packet_amount'] / $data['red_packet'] > 200) {
//     return $this->sendError(1, '平均每个红包最大金额为200元', 200);
// }

// if (!preg_match("/^1[34578]{1}\d{9}$/", $data['mobile'])) {
//     return $this->sendError(1, '请输入正确的手机号码', 200);
// }

        if (count($here_INSERT) <= 0) {
            return $this->sendSuccess('', 'success', 200);
        }

        $result = Db::name('circle')->where('id', $id)->update($here_INSERT);

        if ($result) {
            return $this->sendSuccess('', 'success', 200);
        } else {
            return $this->sendError(1, 'error', 200);
        }
    }

    /**
     * @title 删除圈子
     * @return int    error   错误代码：0成功 -1错误
     * @return string message 消息提醒
     * @desc请求方式：DELETE <br/>请求示例：v1/Circle/100000?userid=1
     */
    public function delete($id)
    {   
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = intval(input('get.userid'));
        $Circleid = intval($id);

        if (empty($Userid)) {
            return $this->sendError(-1, '删除者id必须', 400);
        }

        if (empty($Circleid)) {
            return $this->sendError(-1, '圈子id必须', 400);
        }

        $delete_WHERE['id']        = $Circleid;
        $delete_WHERE['delete_id'] = ['>', 0];

        $circle_data = Db::name('circle')
            ->field(true)
            ->where('id', $Circleid)
            ->where('delete_id', 0)
            ->find();

        if (empty($circle_data)) {
            return $this->sendError(-1, '圈子不存在', 400);
        }

        if ($circle_data['total_amount'] > 0) {
            return $this->sendError(-1, '圈子余额大于0，不能解散', 400);
        }

        Db::startTrans();    // 开启事务

        try {
            $delete_UPDATE['delete_id']   = $Userid;
            $delete_UPDATE['delete_time'] = time();

            // 删除圈子
            $delete_c_res = Db::name('circle')->where('id', $Circleid)->update($delete_UPDATE);

            // 删除圈子成员
            $delete_cm_res = Db::name('circle_member')->where('circleid', $Circleid)->update($delete_UPDATE);

            // 提交事务
            Db::commit();
            return $this->sendSuccess('', 'success', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(-1, $e->getMessage(), 400);
        }
    }

    /**
     * @title 获取圈子充值排行 和 圈子成员步数排行
     * @return int    error       错误代码：0成功 -1错误
     * @return string message     消息提醒
     * @return object data        圈子对象
     * @return int    userid      用户ID
     * @return string nickname    用户昵称
     * @return string avatar      用户头像
     * @return string total_fee   充值金额
     * @return int    step_number 用户今日步数
     * @desc 请求方式：GET <br/>请求示例：v1/Circle/getRank?action=recharge&circleid=100000
     */
    public function getRank()
    {
        $action   = input('get.action');
        $circleid = input('get.circleid');
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        $today    = date('Y-m-d');

        if (!$circleid) {
            return $this->sendError(-1, '圈子ID必填', 400);
        }

        // 查询充值排行榜
        if ($action == 'recharge') {
            $totalCount = Db::name('order')
                ->alias('order')
                ->join('order_recharge_record', 'order_recharge_record.order_no = order.order_no', 'left')
                ->join('user', 'user.id = order.userid', 'left')
                ->field('order.userid,user.nickname,user.vip,user.cusvip,sum(order.total_fee) as total_fee')
                ->where(['order_recharge_record.circleid' => $circleid, 'order.status' => 1])
                ->group('order.userid')
                ->count();

            $order = Db::name('order')
                ->alias('order')
                ->join('order_recharge_record','order_recharge_record.order_no = order.order_no')
                ->join('user','user.id = order.userid')
                ->field('
                    order.userid,
                    user.nickname,
                    user.vip,
                    user.cusvip,
                    user.avatar,
                    sum(order.total_fee) as total_fee,
                    order_recharge_record.circleid
                ')
                ->where(['order_recharge_record.circleid' => $circleid, 'order.status' => 1])
                ->group('order.userid')
                ->order('sum(order.total_fee) desc')
                ->page($page, $pageSize)
                ->select();

            foreach ($order as $key => $value) {
                $cnickname_WHERE['circleid'] = $value['circleid'];
                $cnickname_WHERE['userid']   = $value['userid'];

                $cnickname = Db::name('circle_member')
                    ->where($cnickname_WHERE)
                    ->value('nickname');

                if (empty($cnickname)) {
                    $order[$key]['circlenickname'] = '';
                } else {
                    $order[$key]['circlenickname'] = $cnickname;
                }
            }
            unset($key, $value);

            $retData = returnData($page, $pageSize, $totalCount, $order);

        } else if ($action == 'step') {    // 查询步数排行榜
            // // 圈子人数
            // $totalCount = Db::name('user')
            //     ->alias('user')
            //     ->join('circle_member','circle_member.userid = user.id')
            //     ->field('user.id as userid,user.nickname,user.avatar')
            //     ->where('circleid', $circleid)
            //     ->group('user.id')
            //     ->count();

            // 圈子人员数据
            $all_user = Db::name('user')
                ->alias('user')
                // ->field(true)
                ->join('circle_member','circle_member.userid = user.id')
                ->field('user.id as userid,user.nickname,user.avatar,user.vip,user.cusvip')
                ->where('circleid', $circleid)
                ->group('user.id')
                ->order('user.id asc')
                ->select();

// dump($all_user);
// die;
            $Userida = array_column($all_user, 'userid');
            // array_push($Userida, $userid);
            $Userida = array_filter($Userida);
            sort($Userida);
            $Userids = implode(',', $Userida);

            $subQuery = Db::table('rm_user_step')
                ->alias('user_step')
                ->field('id,userid,step_number')
                ->where('create_day', $today)
                ->where('userid', 'in', $Userids)
                ->buildSql();

            $totalCount = Db::name('user')
                ->alias('user')
                ->field('
                    user.id as userid,
                    user.nickname,
                    user.avatar,
                    IFNULL(user_step.step_number, 0) as step_number
                ')
                ->join($subQuery . ' as user_step', 'user.id=user_step.userid', 'left')
                ->where('user.id', 'in', $Userids)
                ->order('step_number desc, user.id asc')
                ->count();

            $UserStepRank = Db::name('user')
                ->alias('user')
                ->field('
                    user.id as userid,
                    user.nickname,
                    user.avatar,
                    user.vip,
                    user.cusvip,
                    IFNULL(user_step.step_number, 0) as step_number
                ')
                ->join($subQuery . ' as user_step', 'user.id=user_step.userid', 'left')
                ->where('user.id', 'in', $Userids)
                ->order('step_number desc, user.id asc')
                ->page($page, $pageSize)
                ->select();

            foreach ($UserStepRank as $key => $value) {
                $cnickname_WHERE['circleid'] = $circleid;
                $cnickname_WHERE['userid']   = $value['userid'];

                $cnickname = Db::name('circle_member')
                    ->where($cnickname_WHERE)
                    ->value('nickname');

                if (empty($cnickname)) {
                    $UserStepRank[$key]['circlenickname'] = '';
                } else {
                    $UserStepRank[$key]['circlenickname'] = $cnickname;
                }
            }
            unset($key, $value);

            $retData = returnData($page, $pageSize, $totalCount, $UserStepRank);

        } else {    // action不存在
            return $this->sendError(-1, 'Not found action', 400);
        }

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 获取用户在圈子当中的步数名次
     * @return int    error       错误代码：0成功 -1错误
     * @return string message     消息提醒
     * @return array  pagenation  分页数组
     * @return array  data        圈子步数名次数组
     * @return int    userid      用户ID
     * @return string nickname    用户昵称
     * @return string avatar      用户头像
     * @return int    step_number 用户今日步数
     * @return int    rank        用户圈子中排名
     * @desc请求方式：GET <br/>地址：v1/Circle/getUserCircleRank?userid=66&circleid=100302
     */
    public function getUserCircleRank() 
    {
        $Userid    = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = intval(input('get.userid'));
        $circleid  = intval(input('get.circleid'));
        $page      = input('get.page') ? input('get.page') : 1;
        $pagesize  = input('get.pagesize') ? input('get.pagesize') : 10;

        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        if (empty($circleid)) {
            return $this->sendError(-1, '圈子ID必填', 400);
        }

        $sameDay = strtotime('today');    // 当日时间戳
        $nextDay = $sameDay + 86400 - 1;  // 次日时间戳
        $today = date('Y-m-d');  // 次日时间戳

        // 获取用户资料
        $user_data = Db::name('user')
            ->alias('user')
            ->field('password', true)
            ->where('id', $Userid)
            ->find();

        $user_data['circleid'] = $circleid;

        // // 获取我的步数
        // $map['userid']      = $Userid;
        // $map['create_time'] = ['between', [$sameDay, $nextDay]];

        // $user_step = Db::name('user_step')->where($map)->order('id desc')->find();

        // if (count($user_step) <= 0) {
        //     return $this->sendError(1, '用户当天步数不纯在！', 200);
        // }

        // 判断用户是否加入圈子
        $in_circle = Db::name('circle_member')
            ->where('circleid', $circleid)
            ->where('userid', $Userid)
            ->where('delete_id', 0)
            ->find();

        if (count($in_circle) <= 0) {
            return $this->sendError(1, '用户不在圈子内！', 200);
        }
            
        // 获取圈子人员数据
        $circle_user = Db::name('circle_member')
            ->field(true)
            ->where('circleid', $circleid)
            ->where('delete_id', 0)
            ->group('userid')
            ->select();
            // ->count();

        if (count($circle_user) <= 0) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        // 取出好友的id，再做升序排序
        $Userids = array_column($circle_user, 'userid');
        // Array_push($Userids, $Userid);
        sort($Userids);
        $Userids = implode(',', $Userids);

        $subQuery = Db::table('rm_user_step')
            ->alias('user_step')
            ->field('id,userid,step_number')
            ->where('create_day', $today)
            ->where('userid', 'in', $Userids)
            ->group('userid')
            ->buildSql(); 

        $All_user_step_data = Db::name('user')
            ->alias('user')
            ->field('
                user.id as userid,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                IFNULL(user_step.step_number, 0) as step_number
            ')
            ->join($subQuery . ' as user_step', 'user.id=user_step.userid', 'left')
            ->where('user.id', 'in', $Userids)
            ->order('step_number desc, user.id asc')
            ->select();

// dump(count($All_user_step_data));
// exit();

        $user_step_data = Db::name('user')
            ->alias('user')
            ->field('
                user.id as userid,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                IFNULL(user_step.step_number, 0) as step_number
            ')
            ->join($subQuery . ' as user_step', 'user.id=user_step.userid', 'left')
            ->where('user.id', 'in', $Userids)
            ->order('step_number desc, user.id asc')
            ->page($page, $pagesize)
            ->select();



        $user_data['circle'] = $user_step_data;
        // $user_data['mydata'] = [];
        // // 获取我的名次
        // foreach ($All_user_step_data as $key => $value) {
        //     if ($value['userid'] == $Userid) {
        //         $res['mydata'] = $value;
        //         $res['mydata']['rank'] = $key + 1;
        //         break;
        //     }
        // }

        // 获取我的名次
        $ranking = 0;
        foreach ($All_user_step_data as $key => $value) {
            if ($value['userid'] == $Userid) {
                $ranking = $key;
                $user_data['step_number'] = $value['step_number'];
                break;
            }
        }

        $user_data['rank'] = $ranking + 1;

        $retData = returnData($page, $pagesize, count($All_user_step_data), $user_data);

        if (count($All_user_step_data) > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }

    /**
     * @title 获取圈子成员周榜单
     * @return int    error       错误代码：0成功 -1错误
     * @return string message     消息提醒
     * @return array  pagenation  分页数组
     * @return array  data        数据
     * @return array  member      成员分页数据
     * @return array  mydata      我的数据
     * @desc请求方式：GET <br/>地址：v1/Circle/UserCircleWeekRank?circleid=100000
     */
    public function UserCircleWeekRank()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        $circleid  = input('get.circleid');
        $page      = input('get.page') ? input('get.page') : 1;
        $pagesize  = input('get.pagesize') ? input('get.pagesize') : 10;
        
        $timestamp = time();
        $monday    = strtotime(date('Y-m-d', strtotime("this week Monday", $timestamp)));
        
        // 圈子人员数据
        $all_user = Db::name('user')
            ->alias('user')
            ->join('circle_member','circle_member.userid = user.id')
            ->field('user.id as userid,user.nickname,user.avatar')
            ->where('circleid', $circleid)
            ->group('user.id')
            ->order('user.id asc')
            ->select();

        $Userida = array_column($all_user, 'userid');
        // array_push($Userida, $userid);
        $Userida = array_filter($Userida);
        sort($Userida);
        $Userids = implode(',', $Userida);

        $subQuery = Db::table('rm_user_step')
            ->alias('user_step')
            ->field('id,userid,step_number')
            ->where('create_day', '>=', $monday)
            ->where('userid', 'in', $Userids)
            ->group('userid,create_day')
            ->buildSql(); 

        $subQueryData = Db::table($subQuery . 'as sq')
            ->field('
                id,
                userid,
                IFNULL(sum(step_number), 0) as step_number
            ')
            ->group('userid')
            ->buildSql();

        // $step_total = Db::name('user')
        //     ->alias('user')
        //     // ->field(true)
        //     ->field('
        //         user.id as userid,
        //         user.nickname,
        //         user.avatar,
        //         IFNULL(step_number, 0) as step_number
        //     ')
        //     ->join($subQueryData . ' as user_step', 'user.id=user_step.userid', 'left')
        //     ->where('user.id', 'in', $Userids)
        //     ->count();

        $AllUserStepRank = Db::name('user')
            ->alias('user')
            // ->field(true)
            ->field('
                user.id as userid,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                IFNULL(step_number, 0) as step_number
            ')
            ->join($subQueryData . ' as user_step', 'user.id=user_step.userid', 'left')
            ->where('user.id', 'in', $Userids)
            ->order('step_number desc, user.id asc')
            ->select();

        $UserStepRank = Db::name('user')
            ->alias('user')
            // ->field(true)
            ->field('
                user.id as userid,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                IFNULL(step_number, 0) as step_number
            ')
            ->join($subQueryData . ' as user_step', 'user.id=user_step.userid', 'left')
            ->where('user.id', 'in', $Userids)
            ->order('step_number desc, user.id asc')
            ->page($page, $pagesize)
            ->select();

        $res['member'] = $UserStepRank;
        $res['mydata'] = [];

        // 获取我的名次
        foreach ($AllUserStepRank as $key => $value) {
            if ($value['userid'] == $Userid) {
                $res['mydata'] = $value;
                $res['mydata']['rank'] = $key + 1;
                break;
            }
        }
        unset($key, $value);

        $retData = returnData($page, $pagesize, count($AllUserStepRank), $res);

        if (count($AllUserStepRank) > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }

    /**
     * @title 获取用户在圈子当中的周名次
     * @return array data 用户排名及基本信息
     * @desc请求方式：GET <br/>地址：v1/Circle/UserCircleWeekNum?circleid=100000&userid=1
     */
    public function UserCircleWeekNum()
    {
        $Userid    = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid    = intval(input('get.userid'));
        $circleid  = intval(input('get.circleid'));
        $timestamp = time();
        $monday    = strtotime(date('Y-m-d', strtotime("this week Monday", $timestamp)));

        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        if (empty($circleid)) {
            return $this->sendError(-1, '圈子ID必填', 400);
        }
        
        // 圈子人员数据
        $all_user = Db::name('user')
            ->alias('user')
            ->join('circle_member','circle_member.userid = user.id')
            ->field('user.id as userid,user.nickname,user.avatar')
            ->where('circleid', $circleid)
            ->group('user.id')
            ->order('user.id asc')
            ->select();

        $Userida = array_column($all_user, 'userid');
        // array_push($Userida, $Userid);
        $Userida = array_filter($Userida);
        sort($Userida);
        $Userids = implode(',', $Userida);

        $subQuery = Db::table('rm_user_step')
            ->alias('user_step')
            ->field('id,userid,step_number')
            ->where('create_day', '>=', $monday)
            ->where('userid', 'in', $Userids)
            ->group('userid,create_day')
            ->buildSql(); 

        $subQueryData = Db::table($subQuery . 'as sq')
            ->field('
                id,
                userid,
                IFNULL(sum(step_number), 0) as step_number
            ')
            ->group('userid')
            ->buildSql();

        $step_total = Db::name('user')
            ->alias('user')
            ->field('
                user.id as userid,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                IFNULL(step_number, 0) as step_number
            ')
            ->join($subQueryData . ' as user_step', 'user.id=user_step.userid', 'left')
            ->where('user.id', 'in', $Userids)
            ->count();

        $AllUserStepRank = Db::name('user')
            ->alias('user')
            ->field('
                user.id as userid,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                IFNULL(step_number, 0) as step_number
            ')
            ->join($subQueryData . ' as user_step', 'user.id=user_step.userid', 'left')
            ->where('user.id', 'in', $Userids)
            ->order('step_number desc, user.id asc')
            ->select();

        $rank          = 0;
        $user_step_sum = 0;
        foreach ($AllUserStepRank as $key => $value) {
            if ($value['userid'] == $Userid) {
                $rank = $key + 1;

                $user = $value;
            }
        }
        unset($key, $value);


        $user['rank']     = $rank;
        // $user['sum_step'] = $user_step_sum;
        // $user['avg_step'] = $avg_step;

        if ($rank > 0) {
            return $this->sendSuccess($user, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title  领取圈子红包
     * @return int   userid 用户ID
     * @return float amount 领取的红包金额
     * @desc请求方式：POST 请求示例：v1/Circle/sendRedBag
     */
    public function sendRedBag()
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = input('post.userid');
        $circleid = input('post.circleid');

        if (!$Userid) {
            return $this->sendError(1, '用户ID必填', 200);
        }

        if (!$circleid) {
            return $this->sendError(1, '圈子ID必填', 200);
        }

        // 获取圈子信息
        $circle = db('circle')
            ->alias('circle')
            ->join('circle_target', 'circle_target.id = circle.targetid')
            ->field('circle.red_packet_amount,circle.red_packet,circle.total_amount,circle_target.target')
            ->where('circle.id', $circleid)
            ->lock(true)
            ->find();

        if (!$circle) {
            return $this->sendError(1, '圈子不存在', 200);
        }

        $UserStepData = Db::name('user_step')
            ->field(true)
            ->where([
                'userid'      => $Userid,
                'create_time' => ['>=', strtotime('today')]
            ])
            ->lock(true)
            ->find();

        if (empty($UserStepData)) {
            $UserStep = 0;
        } else {
            $UserStep = $UserStepData['step_number'];
        }

        if ($UserStepData < $circle['target']) {
            return $this->sendError(1, '步数不足，无法领取红包!', 200);
        }

        // 查询当前圈子红包数
        $Allcirclerecord = db('circle_record')
            ->field(true)
            ->where([
                'circleid'    => $circleid,
                // 'status'      => 1,
                'create_time' => ['>=', strtotime('today')]
            ])
            ->lock(true)
            ->select();

        if (count($Allcirclerecord) <= 0) {
            return $this->sendError(1, '圈子红包已经领完了!', 200);
        }

        $Crecordids = []; // 可领红包记录id
        $sign       = 0;  // 有无可领红包标志（0无，1有）
        foreach ($Allcirclerecord as $key => $value) {
            if ($value['status'] == 0) {
                $Crecordids[] = $value['id'];
                $sign = 1;
            }
        }
        unset($key, $value);

        if (!$sign){
            return $this->sendError(1, '圈子红包已经领完了!', 200);
        }

        // 查询当前用户是否已经领取了当前圈子的红包、若已经领取，则不允许再次领取
        $circle_record = db('circle_record')
            ->where([
                'userid'      => $Userid,
                'circleid'    => $circleid,
                'status'      => 1,
                'create_time' => ['>=', strtotime('today')]
            ])
            ->lock(true)
            ->find();

        if ($circle_record) {
            return $this->sendError(1, '已经领取红包!', 200);
        }

        shuffle($Crecordids);   // 打乱数组

// dump($Allcirclerecord);
// dump($Crecordids);
// die;

        Db::startTrans();    // 开启事务

        try {
            // 找到数据被领取的数据
            $Crf = db('circle_record')
                ->field('amount,id')
                ->where([
                 'id'          => $Crecordids[0],
                 'create_time' => ['>=', strtotime('today')],
                 'status'      => 0
                ])
                ->lock(true)
                ->find();

            if (empty($Crf)) {
                return $this->sendError(1, '手慢了红包被领了!', 200);
            }

            // 更新用户总金额数据
            $user = db('user')->where('id', $Userid)->setInc('balance', $Crf['amount']);

            // 更新已经被领取的红包状态
            $status = db('circle_record')
                ->where('id', $Crf['id'])
                ->update([
                    'userid'      => $Userid,
                    'status'      => 1,
                    'receivetime' => time(),
                ]);

            // 更新收益表收益记录
            $income = db('income')
                ->insert([
                    'userid'      => $Userid,
                    'typeid'      => 1,
                    'amount'      => $Crf['amount'],
                    'source_id'   => $circleid,
                    'create_time' => time()
                ]);

            // 更新圈子总金额
            $circle_total_amount = db('circle')
                ->where('id', $circleid)
                ->setDec('total_amount', $Crf['amount']);

            // 提交事务
            Db::commit();
            return $this->sendSuccess(array('userid' => $Userid, 'amount' => $Crf['amount']), 'success', 200);
        } catch (Exception $e) {

            // 回滚事务
            Db::rollback();
            return $this->sendError(1, $e->getMessage(), 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'action'   => [
                    'name'    => 'action',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => 'my',
                    'desc'    => 'my我的圈子｜choice精选圈子 | join我加入的圈子 | create我创建的圈子',
                    'range'   => ''
                ],
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'keyword'   => [
                    'name'    => 'keyword',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '关键词',
                    'range'   => ''
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'save' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'name'   => [
                    'name'    => 'name',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子名称',
                    'range'   => ''
                ],
                'targetid'   => [
                    'name'    => 'targetid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子目标ID 1-5000步 2-8000步 3-10000步 4-20000步 5-40000步 6-60000步',
                    'range'   => ''
                ],
                'mobile'   => [
                    'name'    => 'mobile',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '管理员手机号',
                    'range'   => ''
                ],
                'is_recharge'   => [
                    'name'    => 'is_recharge',
                    'type'    => 'boolean',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '是否充值 0不充值 1充值',
                    'range'   => ''
                ],
                'red_packet_amount'   => [
                    'name'    => 'red_packet_amount',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包金额',
                    'range'   => ''
                ],
                'red_packet'   => [
                    'name'    => 'red_packet',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包个数',
                    'range'   => ''
                ],
                'logo'   => [
                    'name'    => 'logo',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子LOGO',
                    'range'   => ''
                ],
                'coverid'   => [
                    'name'    => 'coverid',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '封面ID 具体查看-圈子封面接口',
                    'range'   => ''
                ],
                'is_pwd'   => [
                    'name'    => 'is_pwd',
                    'type'    => 'boolean',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '是否设置密码 0无需密码 1密码验证',
                    'range'   => ''
                ],
                'password'   => [
                    'name'    => 'password',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '密码',
                    'range'   => '32'
                ],
                'description'   => [
                    'name'    => 'description',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子描述',
                    'range'   => ''
                ],
                'city'   => [
                    'name'    => 'city',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '城市',
                    'range'   => ''
                ],
                'longitude'   => [
                    'name'    => 'longitude',
                    'type'    => 'float',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '经度',
                    'range'   => ''
                ],
                'latitude'   => [
                    'name'    => 'latitude',
                    'type'    => 'float',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '纬度',
                    'range'   => ''
                ]
            ],
            'read' => [
                'id'   => [
                    'name'    => 'id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '圈子ID',
                    'range'   => ''
                ],
            ],
            'getCircleBase' => [
                'circleid'   => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '圈子ID',
                    'range'   => ''
                ],
            ],
            'update' => [
                'name'   => [
                    'name'    => 'name',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子名称',
                    'range'   => ''
                ],
                'targetid'   => [
                    'name'    => 'targetid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '目标ID',
                    'range'   => ''
                ],
                'mobile'   => [
                    'name'    => 'mobile',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '管理员手机号',
                    'range'   => ''
                ],
                'is_recharge'   => [
                    'name'    => 'is_recharge',
                    'type'    => 'boolean',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '是否充值 0不充值 1充值',
                    'range'   => ''
                ],
                'red_packet_amount'   => [
                    'name'    => 'red_packet_amount',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包金额',
                    'range'   => ''
                ],
                'red_packet'   => [
                    'name'    => 'red_packet',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包个数',
                    'range'   => ''
                ],
                'logo'   => [
                    'name'    => 'logo',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子LOGO',
                    'range'   => ''
                ],
                'is_pwd'   => [
                    'name'    => 'is_pwd',
                    'type'    => 'boolean',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '是否设置密码 0无需密码 1密码验证',
                    'range'   => ''
                ],
                'password'   => [
                    'name'    => 'password',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '密码',
                    'range'   => ''
                ],
                'description'   => [
                    'name'    => 'description',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子描述',
                    'range'   => ''
                ],
                'city'   => [
                    'name'    => 'city',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子描述',
                    'range'   => ''
                ],
                'longitude'   => [
                    'name'    => 'longitude',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '经度',
                    'range'   => ''
                ],
                'latitude'   => [
                    'name'    => 'latitude',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '纬度',
                    'range'   => ''
                ]
            ],
            'delete' => [
                'id'   => [
                    'name'    => 'id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '圈子ID',
                    'range'   => ''
                ],
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
            ],
            'getRank' => [
                'action'   => [
                    'name'    => 'action',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => 'my',
                    'desc'    => 'recharge圈子充值排行榜 | step圈子成员步数排行榜',
                    'range'   => ''
                ],
                'circleid'   => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '1',
                    'desc'    => '圈子ID',
                    'range'   => ''
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'sendRedBag' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
                'circleid'   => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '1',
                    'desc'    => '圈子id',
                    'range'   => ''
                ],
            ],
            'sendRedBag' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
                'circleid'   => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '1',
                    'desc'    => '圈子id',
                    'range'   => ''
                ],
            ],
            'UserCircleWeekRank' => [
                'circleid'   => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子id',
                    'range'   => ''
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'UserCircleWeekNum' => [
                'circleid'   => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子id',
                    'range'   => ''
                ],
                'id'   => [
                    'name'    => '用户id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
            ],
            'getUserCircleRank' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'circleid'   => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子id',
                    'range'   => ''
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ]
        ];
        
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
