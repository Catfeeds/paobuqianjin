<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 圈子成员接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;

/**
 * Class  Index
 * @title 圈子成员接口
 * @url   v1/CircleMember
 * @desc  圈子成员接口包含：加入圈子、备注名搜索圈子成员、获取所有圈子成员、修改备注名称、设为管理员、退出圈子、批量删除成员
 * @version 1.0
 * @readme
 */
class CircleMember extends Base
{
    // 附加方法
    protected $extraActionList = ['signOutCirscle', 'signOutCirscleGet'];

    protected $rule = [
        'userid'   => 'require',
        'circleid' => 'require',
    ];

    protected $msg = [
        'userid.require'   => '用户ID必填',
        'circleid.require' => '圈子ID必填',
    ];

    /**
     * @title 搜索圈子成员
     * @return int    error       错误代码：0成功 -1错误
     * @return string message     消息提醒
     * @return object data        圈子成员对象
     * @return int    id          圈子成员ID
     * @return string avatar      用户头像
     * @return string nickname    用户昵称
     * @return string is_admin    管理员：0普通用户 1管理员 2群主
     * @return sring  remark_name 圈子备注昵称
     * @desc请求方式：GET <br/>请求示例：v1/CircleMember?circleid=100000
     */
    public function index()
    {
        $circleid = input('get.circleid');
        $keyword  = input('get.keyword');
        $page     = input('get.page') ? input('get.page') : 1;
        $pagesize = input('get.pagesize') ? input('get.pagesize') : 10;
        $map      = array();

        //如果圈子或者关键字不为空则开始搜索，否则返回错误
        if(!empty($circleid) || !empty($keyword)){
            $map['circle_member.circleid'] = $circleid;
            $map['user.nickname|circle_member.nickname'] = ['like','%'.$keyword.'%'];
        }else{
            return $this->sendError(-1, '缺少关键词或者圈子id', 400);
        }

        // 搜索符合条件圈子成员
        $circle_member = Db::name('circle_member')
            ->alias('circle_member')
            ->field('
                circle_member.id,user.avatar,user.nickname,circle_member.is_admin,
                circle_member.nickname as circlenickname,
                user.vip,
                user.cusvip
            ')
            ->join('user','user.id = circle_member.userid')
            ->where($map)
            ->page($page,$pagesize)
            ->select();

        // 获取符合条件圈子成员总数
        $totalCount = Db::name('circle_member')
            ->alias('circle_member')
            ->field('
                circle_member.id,user.avatar,user.nickname,circle_member.is_admin,
                circle_member.nickname as circlenickname,
                user.vip,
                user.cusvip
            ')
            ->join('user','user.id = circle_member.userid')
            ->where($map)
            ->count();

        $retData = returnData($page,$pagesize,$totalCount,$circle_member);

        if ($circle_member) {
            return $this->sendSuccess($retData,'success',200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 加入圈子
     * @return int    error   错误代码：0成功 -1错误
     * @return string message 消息提醒
     * @desc请求方式：POST <br/>请求示例：v1/CircleMember
     */
    public function save(Request $request)
    {
        // 指定允许其他域名访问  
        header('Access-Control-Allow-Origin:*');  
        // 响应类型  
        header('Access-Control-Allow-Methods:POST');  
        // 响应头设置  
        header('Access-Control-Allow-Headers:x-requested-with,content-type');  

        $data = input('post.');
        $password = input('post.password') ? input('post.password') : '';
        // 验证字段
        $validate = new Validate($this->rule, $this->msg);
        $validate_result   = $validate->check($data);
        if($validate_result){
            // 判断圈子是否存在
            $circle = Db::name('circle')
            ->where('id',$data['circleid'])
            ->find();

            if(!$circle){
                return $this->sendError(-1, '加入失败，圈子不存在', 400);
            }

            // 判断圈子是否已经加入
            $circle_member = Db::name('circle_member')
            ->where([
                'userid'   => $data['userid'],
                'circleid' => $data['circleid']
            ])
            ->find();
            if ($circle_member) {
                return $this->sendError(-1, '圈子已经加入，请勿重复操作', 400);
            }

            // 判断圈子是否需要输入密码
            if ($circle['is_pwd'] == 1) {
                if (!$password) {
                    return $this->sendError(-1,'请输入密码');
                }
                
                // 判断圈子是否需要密码
                if ($password != $circle['password']) {
                    return $this->sendError(-1,'加入失败,密码错误');
                }
            }

            $data['is_admin'] = 0;
            $data['nickname'] = '';
            $data['add_time'] = time();
            $result = Db::name('circle_member')->insert($data);

            if ($result) {
                return $this->sendSuccess('', 'success', 200);
            } else {
                return $this->sendError(-1, 'error', 400);
            }
        } else {
            return $this->sendError(-1, $validate->getError(), 400);
        }
    }

    /**
     * @title 获取所有圈子成员
     * @return int error 错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @return object data 圈子成员对象
     * @return int id 圈子成员ID
     * @return int user_id 用户ID
     * @return int avatar 用户头像
     * @return int nickname 用户名
     * @return int circlenickname 圈子备注昵称
     * @return int is_admin 是否管理员 0普通用户 1管理员 2圈主
     * @desc请求方式：GET <br/>请求示例：v1/CircleMember/100000
     */
    public function read($id)
    {
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        $totalCount = Db::name('circle_member')
            ->alias('circle_member')
            ->field('circle_member.id,user.id,user.avatar,circle_member.nickname')
            ->join('user', 'user.id = circle_member.userid')
            ->where('circleid', $id)
            ->count();

        $circle_member = Db::name('circle_member')
            ->alias('circle_member')
            ->field('
                circle_member.id,
                user.id as user_id,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                circle_member.nickname as circlenickname,
                circle_member.is_admin
            ')
            ->join('user', 'user.id = circle_member.userid')
            ->where('circleid', $id)
            ->page($page, $pageSize)
            ->select();

        $retData = returnData($page, $pageSize, $totalCount, $circle_member);

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 修改备注名称和设为管理员
     * @return int    error   错误代码：0成功 -1错误
     * @return string message 消息提醒
     * @desc请求方式：PUT <br/> 请求示例：v1/CircleMember/29(圈子成员id)
     */
    public function update(Request $request, $id)
    {
        $cuserid  = intval($id);
        $data     = input('put.');    // $data    = $request->put();
        $action   = $data['action'];
        $nickname = isset($data['nickname']) ? $data['nickname'] : '';

        if (empty($action)) {
            return $this->sendError(-1, 'Not found action', 400);
        }

        // 修改备注名
        if ($action == 'remark') {
            if (!$nickname) {
                return $this->sendError(-1, '备注名必填', 400);
            }

            $user = Db::name('circle_member')->where('id', $cuserid)->find();
            if (empty($user)) {
                return $this->sendError(1, 'Not found Data', 400);
            } else if ($user['nickname'] == $nickname) {
                return $this->sendSuccess('', '备注名修改成功', 200);
            }

            $result = Db::name('circle_member')->where('id', $cuserid)->update(['nickname' => $nickname]);
            $msg = '备注名修改成功';

        } else if ($action == 'admin') {    // 设为管理员
            $circle_member = Db::name('circle_member')->field('is_admin')->where('id', $cuserid)->find();

            if ($circle_member['is_admin'] == 0) {
                $is_admin = 1;
                $msg = '设为管理员成功';
            } else {
                $is_admin = 0;
                $msg = '取消管理员成功';
            }

            $result = Db::name('circle_member')->where('id', $cuserid)->update(['is_admin' => $is_admin]);

        } else {    // 其它
            return $this->sendError(-1, 'Not found action', 400);
        }

        if ($result) {
            return $this->sendSuccess('', $msg, 200);
        } else {
            return $this->sendError(-1, 'error', 400);
        }
    }

    /**
     * @title 批量删除成员
     * @return int error 错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @desc请求方式：DELETE <br/>请求示例：v1/CircleMember/1,2,3(圈子成员id)
     */
    public function delete($id)
    {
        $ids  = explode(",", $id);
        $ids = array_filter($ids);
        sort($ids);
        $ids = implode(',', $ids);

        if (!empty($ids)) {
            $delete_WHERE['id']       = ['in', $ids];
            $delete_WHERE['is_admin'] = ['<>', 2];

            $result = Db::name('circle_member')->where($delete_WHERE)->delete();
        }

        if ($result) {
            return $this->sendSuccess('', 'success', 200);
        } else {
            return $this->sendError(-1, 'error', 400);
        }
    }
    
    /**
     * @title 退出圈子
     * @author chenjie 2018-02-07
     * @return int error 错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @desc请求方式：POST <br/>请求示例：v1/CircleMember/signOutCirscle
     */
    public function signOutCirscle()
    {

        $data     = input('post.');
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = isset($data['userid']) ? intval($data['userid']) : 0;
        $circleid = isset($data['circleid']) ? intval($data['circleid']) : 0;

        if (!$Userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        if (!$circleid) {
            return $this->sendError(-1, '圈子ID必填', 400);
        }

        // 判断是否加入圈子
        $ucdata = Db::name('circle_member')
            ->where([
                'userid'   => $Userid,
                'circleid' => $circleid
            ])
            ->find();

        if (empty($ucdata)) {
            return $this->sendSuccess(0, 'success', 200);
        }

        // 执行退出圈子（删除数据）
        $result = Db::name('circle_member')
            ->where([
                'userid'   => $Userid,
                'circleid' => $circleid
            ])
            ->delete();

        if ($result) {
            return $this->sendSuccess(0, 'success', 200);
        } else {
            return $this->sendError(-1, 'error', 400);
        }
    }

    /**
     * @title 退出圈子（get方法）
     * @author wensen 2018-03-20
     * @return int error 错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @desc请求方式：GET <br/>请求示例：v1/CircleMember/signOutCirscleGet?userid=1&circleid=100000
     */
    public function signOutCirscleGet()
    {
        $data     = input('get.');
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = isset($data['userid']) ? intval($data['userid']) : 0;
        $circleid = isset($data['circleid']) ? intval($data['circleid']) : 0;

        if (!$Userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        if (!$circleid) {
            return $this->sendError(-1, '圈子ID必填', 400);
        }

        // 判断是否加入圈子
        $ucdata = Db::name('circle_member')
            ->where([
                'userid'   => $Userid,
                'circleid' => $circleid
            ])
            ->find();

        if (empty($ucdata)) {
            return $this->sendSuccess(0, 'success', 200);
        }

        // 执行退出圈子（删除数据）
        $result = Db::name('circle_member')
            ->where([
                'userid'   => $Userid,
                'circleid' => $circleid
            ])
            ->delete();

        if ($result) {
            return $this->sendSuccess(0, 'success', 200);
        } else {
            return $this->sendError(-1, 'error', 400);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'circleid' => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子ID',
                    'range'   => ''
                ],
                'keyword' => [
                    'name'    => 'keyword',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '关键词',
                    'range'   => ''
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'page',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'save' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'circleid' => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子ID',
                    'range'   => ''
                ],
                'password' => [
                    'name'    => 'password',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '加入圈子密码',
                    'range'   => ''
                ]
            ],
            'read' => [
                'id' => [
                    'name'    => 'id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子ID',
                    'range'   => ''
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ]
            ],
            'update' => [
                'id' => [
                    'name'    => 'id',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子成员id',
                    'range'   => ''
                ],
                'action' => [
                    'name'    => 'action',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => 'remark修改备注名｜admin设为/取消管理员',
                    'range'   => ''
                ],
                'nickname'   => [
                    'name'    => 'nickname',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '备注名',
                    'range'   => ''
                ]
            ],
            'delete' => [
                'id' => [
                    'name'    => 'id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子成员ID 可逗号分隔传递多个',
                    'range'   => ''
                ]
            ],
            'signOutCirscle' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'circleid' => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子ID',
                    'range'   => ''
                ],
            ],
            'signOutCirscleGet' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'circleid' => [
                    'name'    => 'circleid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子ID',
                    'range'   => ''
                ],
            ]
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
