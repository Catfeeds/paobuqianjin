<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 圈子订单接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
/**
 * Class  CircleCover
 * @title 圈子订单接口
 * @url   v1/CircleOrder
 * @desc  圈子订单数据相关接口
 * @version 1.0
 * @readme
 */
class CircleOrder extends Base
{
    //附加方法
    protected $extraActionList = [];

    /**
     * @title 获取圈子订单列表
     * @return int    error   错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @return object data    圈子订单对象
     * @return int    id      圈子订单ID
     * @return string conver  圈子封面图片
     * @desc请求方式:GET 请求示例：v1/CircleOrder
     */
    public function index()
    {
        $CircleCover = Db::name('circle_cover')->select();

        if($CircleCover){
            return $this->sendSuccess($CircleCover, 'success', 200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 获取单条圈子封面
     * @return int    error   错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @return object data    圈子封面对象
     * @return int    id      圈子封面ID
     * @return string conver  圈子封面图片
     * @desc 请求方式：GET<br/>请求示例：v1/CircleOrder/1
     */
    public function read($id)
    {
        $CircleCover = Db::name('circle_cover')->where('id', $id)->find();

        if($CircleCover){
            return $this->sendSuccess($CircleCover,'success',200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'read' => [
                'id' => [
                    'name'    => 'id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '圈子封面ID',
                    'range'   => ''
                ]
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
