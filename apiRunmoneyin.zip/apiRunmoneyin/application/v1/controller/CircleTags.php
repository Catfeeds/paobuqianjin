<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 圈子标签接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;

/**
 * Class  CircleTags
 * @title 圈子标签接口
 * @url   http://119.29.10.64/v1/CircleTags
 * @desc  圈子标签相关接口
 * @version 1.0
 * @readme
 */
class CircleTags extends Base
{
    //附加方法
    protected $extraActionList = [];

    /**
     * @title 获取圈子标签列表和热门标签
     * @return int error 错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @return object data 圈子类型对象
     * @return int id 标签ID
     * @return string name 标签名称
     * @desc请求方式：GET <br/>地址：http://119.29.10.64/v1/CircleTags
     */
    public function index()
    {
        $CircleTagsRecord = Db::name('circle_tags_record')
        ->alias('circle_tags_record')
        ->field('tagid as id,count(*) as count')
        ->join('circle_tags','circle_tags.id = circle_tags_record.tagid')
        ->group('tagid')
        ->order('count desc')
        ->select();

        $ids = '';
        foreach ($CircleTagsRecord as $value) {
            $ids .= $value['id'].',';
        }

        $HotCircleTags = Db::name('circle_tags')
        ->where('id','in',$ids)
        ->select();

        $AllCircleTags = Db::name('circle_tags')
        ->select();

        $data = ['HotCircleTags' =>$HotCircleTags,'AllCircleTags'=>$AllCircleTags];

        if($HotCircleTags && $AllCircleTags){
            return $this->sendSuccess($data,'success',200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 获取单个或者多个标签
     * @return int error 错误代码 0失败 1成功
     * @return string message 消息提醒
     * @return object data 标签对象
     * @return int id 标签ID
     * @return string name 标签名称
     * @desc请求方式：GET <br/>地址：http://119.29.10.64/v1/CircleTags/1
     */
    public function read($id)
    {
        $ids = explode(',', $id);

        if(count($ids) > 1){
            $CircleTags = Db::name('circle_tags')
            ->where('id','in',$ids)
            ->select();

        }else{
            $CircleTags = Db::name('circle_tags')
            ->where('id',$id)
            ->select();
        }

        if($CircleTags){
            return $this->sendSuccess($CircleTags,'success',200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'read' => [
                'id'   => [
                    'name' => 'id',
                    'type' => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc' => '标签ID,可逗号分隔传递多个',
                    'range' => ''
                ]
            ],
        ];
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
    
}
