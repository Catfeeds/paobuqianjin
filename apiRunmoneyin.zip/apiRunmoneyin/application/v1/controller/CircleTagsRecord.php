<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 圈子标签使用记录
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;

/**
 * Class  Index
 * @title 圈子标签使用记录
 * @url   v1/CircleTagsRecord
 * @desc  圈子标签使用记录接口
 * @version 1.0
 * @readme
 */
class CircleTagsRecord extends Base
{
    //附加方法
    protected $extraActionList = [];

    /**
     * @title 标签使用记录
     * @return int error 错误代码 0失败 1成功
     * @return string message 消息提醒
     * @desc请求方式：POST <br/>请求示例：v1/CircleTagsRecord
     */
    public function save(Request $request)
    {
        $data     = $request->post();
        $circleid = isset($data['circleid']) ? $data['circleid'] : 0;
        $tagid    = isset($data['tagid']) ? $data['tagid'] : 0;

        $tags = explode(',', $tagid);

        if(count($tags) <= 1){

            $insertData = array(
                'circleid' => $circleid,
                'tagid' => $tagid,
                'create_time' => time()
            );
            $result = Db::name('circle_tags_record')->insert($insertData);
        }else{
            foreach ($tags as $key => $value) {
                $insertData[] = array(
                    'circleid' => $circleid,
                    'tagid' => $value,
                    'create_time' => time()
                );
            }

            $result = Db::name('circle_tags_record')->insertAll($insertData);
        }

        if($result){
            return $this->sendSuccess('','success',200);
        }else{
            return $this->sendError(-1, 'error', 400);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'save' => [
                'circleid'   => [
                    'name' => 'circleid',
                    'type' => 'string',
                    'require' => 'true',
                    'default' => '0',
                    'desc' => '圈子ID',
                    'range' => ''
                ],
                'tagid'   => [
                    'name' => 'circleid',
                    'type' => 'string',
                    'require' => 'true',
                    'default' => '0',
                    'desc' => '标签ID,多个标签ID逗号隔开',
                    'range' => ''
                ]
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
