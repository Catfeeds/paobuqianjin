<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 圈子目标接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;

/**
 * Class  CircleTarget
 * @title 圈子目标接口
 * @url   v1/CircleTarget
 * @desc  圈子目标相关接口
 * @version 1.0
 * @readme
 */
class CircleTarget extends Base
{
    //附加方法
    protected $extraActionList = [];

    /**
     * @title 获取圈子目标列表
     * @return int error 错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @return object data 圈子目标对象
     * @return int id 目标ID
     * @return int target 目标步数
     * @desc请求方式：GET <br/>地址：v1/CircleTarget
     */
    public function index()
    {
        $CircleTarget = Db::name('circle_target')->select();

        if ($CircleTarget) {
            return $this->sendSuccess($CircleTarget, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }


    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [];
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
