<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 圈子类型接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;

/**
 * Class  Dynamic
 * @title 动态接口
 * @url   v1/Dynamic
 * @desc  动态相关接口
 * @version 1.0
 * @readme
 */
class Dynamic extends Base
{
    // 附加方法
    protected $extraActionList = ['getUserDynamic'];

    /**
     * @title 获取已关注人动态列表
     * @return int    error       错误代码：0失败 1成功
     * @return string message     消息提醒
     * @return object data        动态对象
     * @return int    id          动态ID
     * @return int    userid      用户ID
     * @return string nickname    用户昵称
     * @return string avatar      用户头像
     * @return string dynamic     动态内容
     * @return string images      动态图片
     * @return string city        城市
     * @return string country     国
     * @return string province    省
     * @return string county      县/区
     * @return string village     乡
     * @return string position    详细地址
     * @return int    vote        点赞数
     * @return int    comment     评论数
     * @return int    create_time 动态发表时间
     * @return int    is_vote     是否点赞：0未点赞 1已点赞
     * @desc请求方式：GET <br/>请求示例：v1/Dynamic?userid=1
     */
    public function index()
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = input('get.userid');
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量


        // 我关注的
        $myFollow = db('user_follow')->field(true)->where('userid', $Userid)->group('followid')->select();

        $Userida = array_column($myFollow, 'followid');
        array_push($Userida, $Userid);
        $Userida = array_filter(array_unique($Userida));
        sort($Userida);
        $Userids = implode(',', $Userida);

// dump($Userida);
// dump($Userids);
// die;
        $here_WHERE['dy.userid'] = ['in', $Userids];

        // 总条数
        $totalCount = db('dynamic')
            ->alias('dy')
            ->field('
                dy.id,
                dy.userid,
                user.avatar,
                user.nickname,
                dy.dynamic,
                dy.images,
                dy.city,
                dy.country,
                dy.province,
                dy.county,
                dy.village,
                dy.position,
                dy.vote,
                dy.comment,
                dy.create_time
            ')
            ->join('user', 'user.id = dy.userid')
            ->where($here_WHERE)
            ->order('dy.create_time desc')
            ->count();

// dump($totalCount);
// die;    

        $dynamic = db('dynamic')
            ->alias('dy')
            ->field('
                dy.id,
                dy.userid,
                user.avatar,
                user.nickname,
                dy.dynamic,
                dy.images,
                dy.city,
                dy.country,
                dy.province,
                dy.county,
                dy.village,
                dy.position,
                dy.vote,
                dy.comment,
                dy.create_time
            ')
            ->join('user', 'user.id = dy.userid')
            ->where($here_WHERE)
            ->order('dy.create_time desc')
            ->page($page, $pageSize)
            ->select();

// dump($totalCount);
// die;

        if ($dynamic) {
            foreach ($dynamic as $key => $value) {
                $dynamic_comment = Db::name('dynamic_comment')
                    ->alias('dynamic_comment')
                    ->field('
                        dynamic_comment.id,
                        dynamic_comment.parent_id,
                        dynamic_comment.reply_userid,
                        dynamic_comment.userid,
                        dynamic_comment.dynamicid,
                        dynamic_comment.content,
                        dynamic_comment.create_time,
                        user.nickname
                    ')
                    ->join('user','user.id = dynamic_comment.userid')
                    ->where('dynamicid', $value['id'])
                    ->where('parent_id', 0)
                    ->order('dynamic_comment.create_time desc')
                    ->limit(1)
                    ->find();

                $newDynamic[] = $value;

                if ($value['images']) {
                    $newDynamic[$key]['images'] = unserialize($value['images']);   // 反序列化
                } else {
                    $newDynamic[$key]['images'] = array();
                }

                if ($dynamic_comment) {
                    $newDynamic[$key]['one_comment'] = $dynamic_comment;
                } else {
                    $newDynamic[$key]['one_comment'] = (object)array();
                }

                // 追加是否点赞
                $dynamic_vote = Db::name('dynamic_vote')
                    ->where([
                        'userid'    => $Userid,
                        'dynamicid' => $value['id']
                    ])
                    ->find();

                if ($dynamic_vote) {
                    $newDynamic[$key]['is_vote'] = 1;
                } else {
                    $newDynamic[$key]['is_vote'] = 0;
                }
            }
        } else {
            $newDynamic = array();
        }

        $retData = returnData($page, $pageSize, $totalCount, $newDynamic);

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 发表动态
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @desc请求方式：POST <br/>请求示例：v1/Dynamic
     */
    public function save(Request $request)
    {
        $data = $request->post();
        $data['create_time'] = time();

        $here_rule = [
            'userid' => 'require',
            // 'city'   => 'require',
        ];

        $here_msg = [
            'userid.require' => '用户ID必填',
            // 'city.require'   => '城市必填',
        ];

        // 验证字段
        $validate = new Validate($here_rule, $here_msg);
        $validate_result = $validate->check($data);

        if (empty($validate_result)) {
            return $this->sendError(-1, $validate->getError(), 400);
        }

        if (isset($data['dynamic']) || isset($data['images'])) {
            if (isset($data['images'])) {
                $data['images'] = explode(',', $data['images']);
                $data['images'] = serialize($data['images']);
            }

            $result = Db::name('dynamic')->insert($data);

            if ($result) {
                return $this->sendSuccess('','success',200);
            } else {
                return $this->sendError(-1, 'error', 400);
            }

        } else {
            return $this->sendError(-1, '动态内容和图片必填一项!', 400);
        }
    }

    /**
     * @title 获取动态详情
     * @return int    error       错误代码：0失败 1成功
     * @return string message     消息提醒
     * @return object data        动态对象
     * @return int    id          动态ID
     * @return int    userid      用户ID
     * @return string nickname    用户昵称
     * @return string avatar      用户头像
     * @return string dynamic     动态内容
     * @return string images      动态图片
     * @return string city        城市
     * @return string country     国
     * @return string province    省
     * @return string county      县/区
     * @return string village     乡
     * @return string position    详细地址
     * @return int    vote        点赞数
     * @return int    comment     评论数
     * @return int    create_time 动态发表时间
     * @return int    is_vote     是否点赞：0未点赞 1已点赞
     * @return creat_time 动态发表时间
     * @desc请求方式：GET <br/>地址：v1/Dynamic/1
     */
    public function read($id)
    {
        $dynamic = Db::name('dynamic')
            ->alias('dynamic')
            ->join('user','user.id = dynamic.userid')
            ->field('dynamic.id,
                dynamic.userid,
                user.avatar,
                user.nickname,
                dynamic.dynamic,
                dynamic.images,
                dynamic.city,
                dynamic.country,
                dynamic.province,
                dynamic.county,
                dynamic.village,
                dynamic.position,
                dynamic.vote,
                dynamic.comment,
                dynamic.create_time')
            ->where('dynamic.id',$id)
            ->find();

        if ($dynamic['images']) {
            $dynamic['images'] = unserialize($dynamic['images']);
        } else {
            $dynamic['images'] = array();
        }

        if ($dynamic) {
            return $this->sendSuccess($dynamic, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }


    /**
     * @title 获取个人动态列表
     * @return array data         个人动态数组
     * @return int    id          动态ID
     * @return int    userid      用户ID
     * @return string nickname    用户昵称
     * @return string avatar      用户头像
     * @return string dynamic     动态内容
     * @return string images      动态图片
     * @return string city        城市
     * @return string country     国
     * @return string province    省
     * @return string county      县/区
     * @return string village     乡
     * @return string position    详细地址
     * @return int    vote        点赞数
     * @return int    comment     评论数
     * @return int    creat_time  动态发表时间
     * @return int    is_vote     是否点赞：0未点赞 1已点赞
     * @desc请求方式：GET <br/>地址：v1/Dynamic/getUserDynamic?userid=1
     */
    public function getUserDynamic()
    {
        $userid   = input('get.userid');
        $page     = input('get.page') ? input('get.page') : 1;
        $pagesize = input('get.pagesize') ? input('get.pagesize') : 10;

        //获取动态总数
        $totalCount = db('dynamic')
            ->where('userid',$userid)
            ->count();

        if ($totalCount <= 0) {
            return $this->sendError(1, 'Not found Data', 200);
        }

        //获取个人动态
        $user_dynamic = db('dynamic')
            ->alias('dynamic')
            ->join('user','user.id = dynamic.userid')
            ->field('
                dynamic.id,
                dynamic.userid,
                user.avatar,
                user.nickname,
                dynamic.dynamic,
                dynamic.images,
                dynamic.city,
                dynamic.country,
                dynamic.province,
                dynamic.county,
                dynamic.village,
                dynamic.position,
                dynamic.vote,
                dynamic.comment,
                dynamic.create_time
            ')
            ->where('userid',$userid)
            ->order('create_time','desc')
            ->page($page, $pagesize)
            ->select();

        // 追加评论
        if ($user_dynamic) {
            foreach ($user_dynamic as $key => $value) {
                $dynamic_comment = Db::name('dynamic_comment')
                    ->alias('dynamic_comment')
                    ->field('dynamic_comment.*,user.nickname')
                    ->join('user','user.id = dynamic_comment.userid')
                    ->where('dynamicid',$value['id'])
                    ->limit(1)
                    ->find();

                $newDynamic[] = $value;
                if ($value['images']) {
                    $newDynamic[$key]['images'] = unserialize($value['images']);
                } else {
                    $newDynamic[$key]['images'] = array();
                }

                if ($dynamic_comment) {
                    $newDynamic[$key]['one_comment'] = $dynamic_comment;
                } else {
                    $newDynamic[$key]['one_comment'] = (object)array();
                }

                //追加是否点赞
                $dynamic_vote = Db::name('dynamic_vote')
                ->where([
                    'userid'    => $this->userId,
                    'dynamicid' => $value['id']
                ])
                ->find();

                if ($dynamic_vote) {
                    $newDynamic[$key]['is_vote'] = 1;
                } else {
                    $newDynamic[$key]['is_vote'] = 0;
                }
            }
        }

        $retData = returnData($page, $pagesize, $totalCount, $newDynamic);

        if ($user_dynamic) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title  删除动态
     * @return int    error   错误代码：0成功|-1错误
     * @return string message 消息提醒
     * @desc请求方式：DELETE <br/>地址：v1/Dynamic/29(动态ID)
     */
    public function delete($id)
    {   
        $Dynamicid = intval($id);

        if (empty($Dynamicid)) {
            return $this->sendError(-1, 'error', 400);
        }


        Db::startTrans();    // 开启事务

        try {
            // 直接删除动态
            $d_result = Db::name('dynamic')->where('id', $Dynamicid)->delete();

            // 删除点赞
            $dc_result = Db::name('dynamic_comment')->where('dynamicid', $Dynamicid)->delete();

            // 删除评论
            $dv_result = Db::name('dynamic_vote')->where('dynamicid', $Dynamicid)->delete();

            // 删除评论和点赞发送到动态用户的消息
            $m_result = Db::name('user_messages')->where('dynamicid', $Dynamicid)->delete();

            // 提交事务
            Db::commit();

            return $this->sendSuccess('', 'success', 200);

        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(-1, 'error', 400);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'save' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'dynamic' => [
                    'name'    => 'dynamic',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '动态内容',
                    'range'   => ''
                ],
                'images' => [
                    'name'    => 'images',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '动态图片',
                    'range'   => ''
                ],
                'vote' => [
                    'name'    => 'vote',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '点赞数',
                    'range'   => ''
                ],
                'country' => [
                    'name'    => 'country',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '国',
                    'range'   => ''
                ],
                'province' => [
                    'name'    => 'province',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '省',
                    'range'   => ''
                ],
                'city' => [
                    'name'    => 'city',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '城市',
                    'range'   => ''
                ],
                'county' => [
                    'name'    => 'county',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '县',
                    'range'   => ''
                ],
                'village' => [
                    'name'    => 'village',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '村',
                    'range'   => ''
                ],
                'position' => [
                    'name'    => 'position',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '详细位置',
                    'range'   => ''
                ],
            ],
            'read' => [
                'id' => [
                    'name'    => 'id',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '动态ID',
                    'range'   => ''
                ],
            ],
            'getUserDynamic' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ]

        ];
        
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
