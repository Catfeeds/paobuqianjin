<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:25
// +----------------------------------------------------------------------
// | TITLE: 圈子类型接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;

/**
 * Class  DynamicComment
 * @title 动态评论
 * @url   v1/DynamicComment
 * @desc  动态评论相关接口
 * @version 1.0
 * @readme
 */
class DynamicComment extends Base
{
    // 附加方法
    protected $extraActionList = ['getComment'];

    protected $rule = [
        'parent_id'    => 'require',
        'userid'       => 'require',
        'reply_userid' => 'require',
        'dynamicid'    => 'require',
        'content'      => 'require',
    ];

    protected $msg = [
        'parent_id.require'    => '评论ID必填',
        'userid.require'       => '评论用户ID必填',
        'reply_userid.require' => '被评论用户ID必填',
        'dynamicid.require'    => '动态ID必填',
        'content.require'      => '评论内容必填',
    ];

    /**
     * @title  获取评论列表（无法获取三级以上的评论）
     * @return int    error          错误代码 0失败 1成功
     * @return string message        消息提醒
     * @return object data           评论对象
     * @return int    id             评论ID
     * @return int    parent_id      评论父ID
     * @return int    reply_userid   被评论者用户ID
     * @return int    userid         评论者用户ID 
     * @return int    dynamicid      动态ID
     * @return string content        动态内容
     * @return string create_time    评论时间
     * @return string nickname       评论者昵称
     * @return string reply_nickname 被评论者昵称
     * @desc请求方式：GET <br/>请求示例：v1/DynamicComment?dynamicid=1
     */
    public function index()
    {
        $dynamicid = input('dynamicid');
        $page      = input('page') ? intval(input('page')) : 1;           // 当前分页
        $pageSize  = input('pagesize') ? intval(input('pagesize')) : 10;  // 每页显示数量

        if (empty($dynamicid)) {
            return $this->sendError(1, '动态ID必填', 200);
        }

        $totalCount = Db::name('dynamic_comment')
            ->where(['dynamicid'=>$dynamicid,'parent_id'=>0])
            ->count();  //总条数

        // 一级评论
        $dynamic_comment = Db::name('dynamic_comment')
            ->alias('dynamic_comment')
            ->field('dynamic_comment.*,user.nickname,user.avatar')
            ->join('user','user.id = dynamic_comment.userid')
            ->where(['dynamicid'=>$dynamicid,'parent_id'=>0])
            ->order('create_time desc')
            ->page($page,$pageSize)
            ->select();

        foreach ($dynamic_comment as $key => $value) {
            // 二级评论
            $sub_dynamic_comment = Db::name('dynamic_comment')
                ->alias('dynamic_comment')
                ->field('dynamic_comment.*,user.nickname')
                ->join('user','user.id = dynamic_comment.userid')
                ->where('parent_id',$value['id'])
                ->select();

            // 追加昵称
            foreach ($sub_dynamic_comment as $key2 => $value2) {
                $user = Db::name('user')->where('id',$value2['reply_userid'])->find();
                $sub_dynamic_comment[$key2]['reply_nickname'] = $user['nickname'];
            }

            if ($sub_dynamic_comment) {
                $dynamic_comment[$key]['child'] = $sub_dynamic_comment;
            } else {
                $dynamic_comment[$key]['child'] = array();
            }

            // dump($dynamic_comment[$key]['content']);
            // $dynamic_comment[$key]['content'] = stripslashes($dynamic_comment[$key]['content']);
        }

        //$new_dynamic_comment = getSubTree($dynamic_comment,'parent_id','id');
        $retData = returnData($page, $pageSize, $totalCount, $dynamic_comment);

        if ($totalCount > 0) {
            return $this->sendSuccess($retData,'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title  获取评论列表（修改成无限评论获取）
     * @return int    error          错误代码 0失败 1成功
     * @return string message        消息提醒
     * @return array  data           评论数据
     * @return int    id             评论ID
     * @return int    parent_id      评论父ID
     * @return int    userid         评论者用户ID 
     * @return int    dynamicid      动态ID
     * @return string content        动态内容
     * @return string create_time    评论时间
     * @return int    userid         评论者用户ID 
     * @return string nickname       评论者昵称
     * @return string avatar         评论者头像路径
     * @return int    reply_userid   被评论者用户ID
     * @return string reply_nickname 被评论者昵称
     * @return string reply_avatar   被评论者头像路径
     * @return array  child          二级评论（键名和一级评论相同）
     * @return array  parentarray    拥有评论的id数组（暂时没什么用）
     * @desc请求方式：GET <br/>请求示例：v1/DynamicComment/getComment?dynamicid=1
     */
    public function getComment()
    {
        $dynamicid = input('get.dynamicid');
        $page      = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize  = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        if (empty($dynamicid)) {
            return $this->sendError(1, '动态ID必填', 200);
        }

        $totalCount = Db::name('dynamic_comment')
            ->alias('dc')
            ->where(['dc.dynamicid' => $dynamicid, 'dc.delete_id' => 0])
            ->count();  //总条数

        if ($totalCount <= 0) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        // 所有评论
        $Dynamicdata = Db::name('dynamic_comment')
            ->alias('dc')
            ->field('
                dc.id,
                dc.dynamicid,
                dc.parent_id,
                dc.userid,
                dc.content,
                dc.create_time,
                low.nickname,
                low.avatar,
                dc.reply_userid,
                up.nickname as reply_nickname,
                up.avatar as reply_avatar
            ')
            ->join('user up',  'up.id = dc.reply_userid', 'left')
            ->join('user low', 'low.id = dc.userid', 'left')
            ->where(['dc.dynamicid' => $dynamicid, 'dc.delete_id' => 0])
            ->order('create_time asc')
            ->page($page, $pageSize)
            ->select();

        // 挑出二级评论
        $Twodata = []; // 二级评论
        foreach ($Dynamicdata as $key => $value) {
            if ($value['parent_id'] != 0) {
                $Twodata[] = $value;
                unset($Dynamicdata[$key]);
            }
        }
        unset($key, $value);

        $Dynamicdata = array_merge($Dynamicdata);

        foreach ($Twodata as $k => $v) {
            foreach ($Dynamicdata as $key => $value) {
                if (!isset($Dynamicdata[$key]['child'])) {
                    $Dynamicdata[$key]['child'] = [];
                }

                if (!isset($Dynamicdata[$key]['parentarray'])) {
                    $Dynamicdata[$key]['parentarray'][] = $value['id'];
                } elseif (!in_array($value['id'], $Dynamicdata[$key]['parentarray'])) {
                    $Dynamicdata[$key]['parentarray'][] = $value['id'];
                }

                if (in_array($v['parent_id'], $Dynamicdata[$key]['parentarray'])) {
                    $Dynamicdata[$key]['child'][] = $v;
                    
                    $Dynamicdata[$key]['parentarray'][] = $v['id'];
                }
            }
            unset($key, $value);
        }
        unset($k, $v);

        array_merge($Dynamicdata);

// dump($Dynamicdata);
// // dump($Twodata);
// die;


        $retData = returnData($page, $pageSize, $totalCount, $Dynamicdata);

        return $this->sendSuccess($retData,'success', 200);
    }

    /**
     * @title  发表评论
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @desc请求方式：POST <br/>请求示例：v1/DynamicComment
     */
    public function save(Request $request)
    {
        $data = $request->post();

        $validate = new Validate($this->rule, $this->msg);
        $validate_result = $validate->check($data);

        if (!$validate_result) {
            return $this->sendError(-1, $validate->getError(), 400);
        }

        $data['create_time'] = time();
        // $data['content']     = string($data['content']);
// dump($data);
// exit();

        if ($data['userid'] == $data['reply_userid']) {
            return $this->sendError(-1, '禁止自己评论自己!');
        }

        Db::startTrans();    // 开启事务

        try {
            // 生成评论
            $dynamic_id = Db::name('dynamic_comment')->insertGetId($data);

            // 增加动态评论数量
            Db::name('dynamic')->where('id', $data['dynamicid'])->setInc('comment');

            // 添加个人消息
            $message_INSERT['dynamicid']   = $data['dynamicid'];
            $message_INSERT['from_userid'] = $data['userid'];
            $message_INSERT['to_userid']   = $data['reply_userid'];
            $message_INSERT['typeid']      = 2;
            $message_INSERT['title']       = '收到一条评论';
            $message_INSERT['content']     = $data['content'];
            $message_INSERT['create_time'] = time();

            $messages_id = Db::name('user_messages')->insertGetId($message_INSERT);

            Db::commit();    // 提交事务

            $data['id'] = $dynamic_id;
            $user = Db::name('user')->where('id', $data['userid'])->find();

            if ($data['parent_id'] == 0) {
                $data['avatar']   = $user['avatar'];
                $data['nickname'] = $user['nickname'];
            } else {
                $user2 = Db::name('user')->where('id', $data['reply_userid'])->find();

                $data['nickname']       = $user['nickname'];
                $data['reply_nickname'] = $user2['nickname'];
            }

            return $this->sendSuccess($data, 'success', 200);

        } catch (\Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(-1, 'error', 200);
        }

    }

    /**
     * @title 获取单条评论
     * @return int error 错误代码 0失败 1成功
     * @return string message 消息提醒
     * @return object data 评论对象
     * @return int id 评论ID
     * @return int reply_userid 被评论者用户ID
     * @return int userid 评论者用户ID
     * @return int dynamicid 动态ID
     * @return int content 评论内容
     * @return int nickname 评论者昵称
     * @return int reply_nickname 被评论者昵称
     * @desc请求方式：GET <br/>请求示例：v1/DynamicComment/1
     */
    public function read($id)
    {
        $dynamic_comment = Db::name('dynamic_comment')
        ->alias('dynamic_comment')
        ->field('dynamic_comment.*,user.nickname')
        ->join('user','user.id = dynamic_comment.userid')
        ->where('dynamic_comment.id',$id)
        ->find();

        if($dynamic_comment['reply_userid']){
            $user = Db::name('user')
            ->where('id',$dynamic_comment['reply_userid'])
            ->find();
            $dynamic_comment['reply_nickname'] = $user['nickname'];
        }

        if($dynamic_comment){
            return $this->sendSuccess($dynamic_comment,'success',200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'dynamicid'   => [
                    'name'    => 'dynamicid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '动态ID',
                    'range'   => ''
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'getComment' => [
                'dynamicid'   => [
                    'name'    => 'dynamicid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '动态ID',
                    'range'   => ''
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'save' => [
                'parent_id'   => [
                    'name'    => 'parent_id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '评论ID',
                    'range'   => ''
                ],
                'reply_userid'   => [
                    'name'    => 'reply_userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '被评论者用户ID',
                    'range'   => ''
                ],
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '评论者用户ID',
                    'range'   => ''
                ],
                'dynamicid'   => [
                    'name'    => 'dynamicid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '动态ID',
                    'range'   => ''
                ],
                'content'   => [
                    'name'    => 'content',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '评论内容',
                    'range'   => ''
                ]
            ],
            'read' => [
                'id'   => [
                    'name'    => 'id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '评论ID',
                    'range'   => ''
                ]
            ]
        ];

        //可以合并公共参数
        return $rules;
    }
    
    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
