<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:25
// +----------------------------------------------------------------------
// | TITLE: 圈子类型接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;

/**
 * Class  Index
 * @title 动态点赞接口
 * @url   v1/DynamicVote
 * @desc  动态点赞相关接口
 * @version 1.0
 * @readme
 */
class DynamicVote extends Base
{
    //附加方法
    protected $extraActionList = [];

    /**
     * @title 获取点赞用户列表
     * @return int error 错误代码 0失败 1成功
     * @return string message 消息提醒
     * @return object data 点赞用户对象
     * @return int id 主键ID
     * @return int userid 用户ID
     * @return int nickname 用户昵称
     * @return int avatar 用户头像
     * @return int dynamicid 动态ID
     * @return int create_time 点赞时间
     * @return int is_follow 是否关注 0未关注 1已关注
     * @desc请求方式：GET <br/>请求示例：v1/DynamicVote?dynamicid=1&userid=1
     */
    public function index()
    {
        $dynamicid = intval(input('get.dynamicid'));
        $userid    = intval(input('get.userid'));

        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        if (empty($dynamicid)) {
            return $this->sendError(-1, '动态ID必填', 400);
        }

        if (empty($userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }
        
        $totalCount = Db::name('dynamic_vote')
            ->alias('dynamic_vote')
            ->join('user', 'user.id = dynamic_vote.userid', 'left')
            ->field('
                dynamic_vote.id,
                dynamic_vote.userid,
                user.avatar,
                user.nickname,
                dynamic_vote.dynamicid,
                dynamic_vote.create_time
            ')
            ->where('dynamicid', $dynamicid)
            ->count();

        $dynamic_vote = Db::name('dynamic_vote')
            ->alias('dynamic_vote')
            ->join('user', 'user.id = dynamic_vote.userid')
            ->field('
                dynamic_vote.id,
                dynamic_vote.userid,
                user.avatar,
                user.nickname,
                dynamic_vote.dynamicid,
                dynamic_vote.create_time
            ')
            ->where('dynamicid', $dynamicid)
            ->page($page, $pageSize)
            ->select();

// dump($totalCount);
// dump($dynamic_vote);
// exit();

        foreach ($dynamic_vote as $key => $value) {
            $followid = $value['userid'];

            $follow = Db::name('user_follow')
                ->where(['userid' => $userid, 'followid' => $followid])
                ->find();

            if ($follow) {
                $dynamic_vote[$key]['is_follow'] = 1;
            } else {
                $dynamic_vote[$key]['is_follow'] = 0;
            }
        }

        $retData = returnData($page, $pageSize, $totalCount, $dynamic_vote);

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }


    /**
     * @title 点赞、取消赞接口
     * @param  int id        用户id
     * @param  int dynamicid 动态id
     * @desc 请求方式：PUT 请求示例：v1/DynamicVote/8(动态ID)
     */
    public function update($id)
    {
        $userid = input('userid') ? input('userid') : intval($this->userId);
        // $userid    = intval(input('put.userid'));
        $dynamicid = intval($id);

        $cacheVote = cache('vote_' . $dynamicid . '_' . $userid);
        if (!empty($cacheVote)) {
            return $this->sendError(1, '连点无效！', 200);
        }

        if (empty($userid)) {
            return $this->sendError(1, '用户ID必填！', 200);
        }

        if (empty($dynamicid)) {
            return $this->sendError(1, '动态ID必填！', 200);
        }

        $dynamic = db('dynamic')->where('id', $dynamicid)->find();

        if (empty($dynamic)) {
            return $this->sendError(1, '动态不存在！', 200);
        }

        $vote_data = db('dynamic_vote')->where(['dynamicid'=>$dynamicid, 'userid'=>$userid])->find();
        $mass_data = db('user_messages')->where(['dynamicid'=>$dynamicid, 'from_userid'=>$userid])->find();

        Db::startTrans();

        // 取消点赞
        if (!empty($vote_data)) {
            try {
                $del_vote = db('dynamic_vote')->where('dynamicid', $dynamicid)->where('userid', $userid)->delete();

                $del_dynamic_vote = db('dynamic')->where('id', $dynamicid)->setDec('vote');

                if ($mass_data) {
                    $del_mass = db('user_messages')->where('dynamicid', $dynamicid)->where('from_userid', $userid)->delete();
                }

                cache('vote_' . $dynamicid . '_' . $userid, true, 2);

                Db::commit();
                return $this->sendSuccess('', '取消赞成功', 200);

            } catch (\Exception $e) {
                Db::rollback();
                // print_r($e);
                return $this->sendError(-1, '取消赞失败', 400);
            }

        } else {   // 动态点赞
            try {
                // 添加点赞记录
                $vote_INSERT = [
                    'userid'      => $userid,
                    'dynamicid'   => $dynamicid,
                    'create_time' => time()
                ];

                $res_vote = db('dynamic_vote')->insert($vote_INSERT);

                // 添加个人消息
                $message_INSERT['dynamicid']   = $dynamicid;
                $message_INSERT['from_userid'] = $userid;
                $message_INSERT['to_userid']   = $dynamic['userid'];
                $message_INSERT['typeid']      = 3;
                $message_INSERT['title']       = '收到点赞';
                $message_INSERT['content']     = $dynamic['dynamic'];
                $message_INSERT['create_time'] = time();

                $dynamic = db('dynamic')->where('id', $dynamicid)->setInc('vote');

                $give_mass = db('user_messages')->insert($message_INSERT);

                cache('vote_' . $dynamicid . '_' . $userid, true, 5);
                
                Db::commit();
                return $this->sendSuccess('', '点赞成功', 200);
            } catch (\Exception $e) {
                Db::rollback();
                // print_r($e);
                return $this->sendError(-1, '点赞失败', 400);
            }
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'dynamicid'   => [
                    'name' => 'dynamicid',
                    'type' => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc' => '动态ID',
                    'range' => ''
                ],
                'userid' => [
                    'name' => 'userid',
                    'type' => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc' => '用户ID',
                    'range' => ''
                ],
                'page'   => [
                    'name' => 'page',
                    'type' => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc' => '当前页码',
                    'range' => ''
                ],
                'pagesize'   => [
                    'name' => 'pagesize',
                    'type' => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc' => '每页显示数量',
                    'range' => ''
                ],
            ],
            'update' => [
                'dynamicid'   => [
                    'name' => 'dynamicid',
                    'type' => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc' => '动态ID',
                    'range' => ''
                ],
                'id'   => [
                    'name' => 'id',
                    'type' => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc' => '点赞用户id',
                    'range' => ''
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }
    
    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
