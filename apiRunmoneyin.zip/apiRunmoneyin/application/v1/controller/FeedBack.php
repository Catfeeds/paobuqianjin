<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:25
// +----------------------------------------------------------------------
// | TITLE: 用户反馈接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Validate;

/**
 * Class  FeedBack
 * @title 用户反馈接口
 * @url   v1/feedback
 * @desc  用户反馈相关接口：获取反馈列表、添加用户反馈
 * @version 1.0
 */
class FeedBack extends Base
{
    protected $rule = [
        'content' => 'require',
        'mobile'  => 'require|length:11',
    ];

    protected $msg = [
        'mobile.require'  => '手机号必须',
        'mobile.length'   => '手机号为11位数字',
        'content.require' => '反馈内容必须',
    ];

    /**
     * @title 获取反馈信息列表
     * @return string name 反馈类型名称
     * @return string content 反馈内容
     * @return string mobile 反馈用户手机号
     * @return int create_time 反馈时间
     * @desc 请求方式：GET <br/>请求示例：v1/feedback
     */
    public function index()
    {
        $page = input('get.page') ? input('get.page') : 1;
        $pagesize = input('get.pagesize') ? input('get.pagesize') : 10;

        $feedback = db('feedback')
            ->alias('f')
            ->field('t.name,f.content,f.mobile,f.creat_time')
            ->join('feedback_type t','f.typeid=t.id')
            ->page($page,$pagesize)
            ->select();

        $totalCount = db('feedback')
            ->alias('f')
            ->field('t.name,f.content,f.mobile,f.creat_time')
            ->join('feedback_type t','f.typeid=t.id')
            ->count();

        $retData = returnData($page, $pagesize, $totalCount, $feedback);

        if ($feedback) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 添加用户反馈
     * @return int    error   错误码
     * @return string massage 错误信息
     * @desc 请求方式：POST <br/>请求示例：v1/feedback
     */
    public function save()
    {
        $data = input('post.');
        $data['create_time'] = time();
        
        if (empty($data['content'])) {
            return $this->sendError(-1, '反馈内容必须', 400);
        }

        if (!empty($data['mobile']) && (strlen($data['mobile']) != 11)) {
            return $this->sendError(-1, '手机号码不正确', 400);
        }

        $feedback = db('feedback')->insert($data);

        if ($feedback) {
            return $this->sendSuccess(0, 'success', 200);
        } else {
            return $this->sendError(-1, '添加反馈失败', 400);
        }
        
        // $validate = new Validate($this->rule,$this->msg);
        // $result   = $validate->TextScan($data);

        // if ($result) {
        //     $feedback = db('feedback')->insert($data);

        //     if ($feedback) {
        //         return $this->sendSuccess(0, 'success', 200);
        //     } else {
        //         return $this->sendError(-1, '插入数据库失败', 400);
        //     }
        // } else {
        //     return $this->sendError(-1, $validate->getError(), 400);
        // }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'save' => [
                'content' => [
                    'name'    => 'content', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '反馈内容', 
                    'range'   => '',
                ],
                'mobile' => [
                    'name'    => 'mobile', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户手机号', 
                    'range'   => '',
                ],
            ],

        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
