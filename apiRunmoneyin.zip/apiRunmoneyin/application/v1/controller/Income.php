<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:28
// +----------------------------------------------------------------------
// | TITLE: 用户收益接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Db;
use think\Request;
use think\Validate;
use wxpay\wechatAppPay;

/**
 * Class  Income
 * @title 用户收益接口
 * @url   v1/Income
 * @desc  用户收益相关接口：添加收益、获取今日收益、获取当月收益、获取总收益
 * @version 1.0
 */
class Income extends Base
{
    protected $rule = [
        'userid' => 'require',
        'typeid' => 'require',
        'amount' => 'require',
    ];

    protected $msg = [
        'userid.require' => '用户ID必填',
        'typeid.require' => '收益类型ID必填',
        'amount.require' => '收益金额必填',
    ];

    /**
     * @title 添加收益
     * @return int error 错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @desc 请求方式：POST <br/>请求示例：v1/Income
     */
    public function save()
    {
        $data = input('post.');

        $validate = new Validate($this->rule, $this->msg);
        $validate_result = $validate->check($data);

        if ($validate_result) {
            $data['create_time'] = time();
            $result = db('income')->insert($data);

            if ($result) {
                return $this->sendSuccess(0, 'success', 200);
            } else {
                return $this->sendError(1, 'Not found Data', 200);
            }
        } else {
          return $this->sendError(-1, $validate->getError(), 400);
        }
    }

    /**
     * @title 获取收益
     * @return int    error        错误代码 0成功 -1错误
     * @return string message      消息提醒
     * @return float  total_amount 收益总金额
     * @return array  pagenation   分页数组
     * @return array  data         收益数组
     * @return int    typeid       类型：1圈子红包|2邀请红包|3商户广告|4任务收益|5活动收益|6任务退款
     * @return int    id           主键ID
     * @return string amount       收益金额
     * @return string name         收益类型
     * @return int    create_time  收益时间
     * @return int    taskid       任务id（非必）
     * @return string taskname     任务名（非必）
     * @return string taskuser     任务创建者名（非必）
     * @return int    circleid     圈子id（非必）
     * @return string circlename   圈子名（非必）
     * @desc 请求方式：GET <br/>请求示例：v1/Income?userid=1&action=yesterday
     */
    public function index()
    {
        $userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid   = input('get.userid');
        $action   = input('get.action');
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        if (!$userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        $actionarray = ['all', 'month', 'yesterday', 'today'];

        if (!in_array($action, $actionarray)) {
            return $this->sendError(-1, 'Not found action', 200);
        }
        $here_WHERE = [];
        $here_WHERE['typeid'] = ['neq', 6];
        if ($action == 'all') {               // 所有收益记录
            $here_WHERE['userid'] = $userid;
        } elseif ($action == 'month') {        // 当月收益
            $here_WHERE['userid']      = $userid;
            $here_WHERE['create_time'] = ['>', mktime(0, 0, 0, date('m'), 1, date('Y'))];
        } elseif ($action == 'yesterday') {    // 昨日收益
            $here_WHERE['userid']      = $userid;
            $here_WHERE['create_time'] = ['between', strtotime('yesterday') .',' . strtotime('today')];
        } elseif ($action == 'today') {        // 今日总收益
            $here_WHERE['userid']      = $userid;
            $here_WHERE['create_time'] = ['>', strtotime('today')];
        }

        // 获取收益数据条数,和收益总金额
        $Allincome = db('income')
            // ->alias('i')
            ->field('count(id) as totalcount, sum(amount) as sum_amount')
            // ->join('income_type t', 'i.typeid=t.id')
            ->where($here_WHERE)
            // ->fetchSql(true)
            ->find();

        if (!empty($Allincome)) {
            $totalCount = $Allincome['totalcount'];
            $sum_amount = $Allincome['sum_amount'];
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }

        $income = db('income')
            ->alias('i')
            ->field('i.id,i.amount,t.name,i.create_time,i.typeid,source_id')
            ->join('income_type t','i.typeid=t.id')
            ->where($here_WHERE)
            ->order('i.create_time desc')
            ->page($page, $pageSize)
            // ->fetchSql(true)
            ->select();

        // // 总金额
        // $sum_amount = 0.00;
        // foreach ($income as $key => $value) {
        //     $sum_amount += round($value['amount'], 2);
        // }
        // unset($key, $value);

        // 循环获取对应的收益数据（圈子名，）
        foreach ($income as $key => $value) {
            if ($value['source_id'] <= 0) continue;

            if ($value['typeid'] == 1) {          // 圈子红包
                $income[$key]['circleid']   = $value['source_id'];
                $income[$key]['circlename'] = db('circle')
                    ->where('id', $value['source_id'])
                    ->value('name');
                if ($income[$key]['circlename']){
                    $income[$key]['name'] = $income[$key]['circlename'].'-'.$income[$key]['name'];
                }

            } else if ($value['typeid'] == 2) {   // 邀请红包
                
                $nickname= db('user_inviter')
                    ->alias('ui')
                    ->field('ui.userid,ui.id,u.nickname')
                    ->join('user u','ui.userid=u.id')
                    ->where('ui.id',$value['source_id'])
                    ->value('u.nickname');
                $income[$key]['name'] = $nickname ? $nickname.'-'.$income[$key]['name'] : $income[$key]['name'];
            } else if ($value['typeid'] == 3) {   // 商户广告
                $business_name = db('business')
                    ->where('id',$value['source_id'])
                    ->value('name');
                $income[$key]['name'] = $business_name ? $business_name.'-'.$income[$key]['name'] : $income[$key]['name'];
            } else if ($value['typeid'] == 4) {   // 任务收益
                $task_data = db('task')
                    ->alias('task')
                    ->field('task.userid,us.nickname,task.id,task.task_name')
                    ->join('user us', 'us.id=task.userid')
                    ->where('task.id', $value['source_id'])
                    ->find();

                if ($task_data) {
                    $income[$key]['taskid']   = $task_data['id'];
                    $income[$key]['taskname'] = $task_data['task_name'];
                    $income[$key]['taskuser'] = $task_data['nickname'];
                    $income[$key]['name'] = $income[$key]['taskname'] ? $income[$key]['taskname'].'-'.$income[$key]['name'] : $income[$key]['name'];
                }
            } else if ($value['typeid'] == 5) {   // 活动收益
                # code...
                $title = db('activity')->where('id',$value['source_id'])->value('title');
                $income[$key]['name'] = $title ? $title.'-'.$income[$key]['name'] : $income[$key]['name'];

            }
//            else if ($value['typeid'] == 6) {   // 任务退款
//                $task_data = db('task')
//                    ->alias('task')
//                    ->field('task.userid,us.nickname,task.id,task.task_name')
//                    ->join('user us', 'us.id=task.userid')
//                    ->where('task.id', $value['source_id'])
//                    ->find();
//
//                if ($task_data) {
//                    $income[$key]['taskid']   = $task_data['id'];
//                    $income[$key]['taskname'] = $task_data['task_name'];
//                    $income[$key]['taskuser'] = $task_data['nickname'];
//                }
//            }
        }

// dump($income);
// exit();

        $retData = returnData($page, $pageSize, $totalCount, $income);
        $retData['total_amount'] = $sum_amount;

        // 处理作日收益
        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'save' => [
                'userid' => [
                  'name'    => 'userid', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '用户id', 
                  'range'   => '',
                ],
                'typeid' => [
                  'name'    => 'typeid', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '收益类型ID 1圈子红包 2邀请红包 3商户广告', 
                  'range'   => '',
                ],
                'amount' => [
                  'name'    => 'amount', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '收益金额', 
                  'range'   => '',
                ],
            ],
            'index' => [
                'userid' => [
                  'name'    => 'userid', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '用户id', 
                  'range'   => '',
                ],
                'action' => [
                  'name'    => 'action', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '当月：action=month, 昨日：action=yesterday, 总收益：action=all, 今日总收益：action=today', 
                  'range'   => '',
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
