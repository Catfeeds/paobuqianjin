<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:30
// +----------------------------------------------------------------------
// | TITLE: 收益类型接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;

/**
 * Class  IncomeType
 * @title 收益类型接口
 * @url   v1/incometype
 * @desc  用户收益类型相关接口：获取收益类型接口
 * @version 1.0
 */
class IncomeType extends Base
{
    /**
     * @title 获取收益类型接口
     * @return int id 收益类型ID
     * @return string name 收益名称
     * @desc 请求方式：GET <br/>请求示例：v1/incometype
     */
    public function index()
    {
        $income_type = db('income_type')->select();

        if ($income_type) {
            return $this->sendSuccess($income_type, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
    
}
