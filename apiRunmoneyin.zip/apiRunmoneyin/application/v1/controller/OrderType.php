<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:30
// +----------------------------------------------------------------------
// | TITLE: 圈子订单类型接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;

/**
 * Class  Index
 * @title 圈子订单类型接口
 * @url   v1/CircleOrderType
 * @desc  圈子订单类型相关接口
 * @version 1.0
 * @readme
 */
class OrderType extends Base
{
    //附加方法
    protected $extraActionList = [];

    /**
     * @title 获取圈子订单类型列表
     * @return int error 错误代码 0成功 -1错误
     * @return string message 消息提醒
     * @return object data 圈子订单类型对象
     * @return int id 订单类型id
     * @return int name 订单类型名称
     * @desc请求方式：GET <br/>请求示例：v1/OrderType
     */
    public function index()
    {
        $OrderType = Db::name('order_type')->select();

        if($OrderType){
            return $this->sendSuccess($OrderType,'success',200);
        }else{
            return $this->sendError(1, 'Not found Data', 404);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [];
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
