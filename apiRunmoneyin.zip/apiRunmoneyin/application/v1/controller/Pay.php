<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:30
// +----------------------------------------------------------------------
// | TITLE: 通用支付接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;
use think\log;
use Payment\Common\PayException;
use Payment\Client\Charge;
use Payment\Client\Notify;
use Payment\Config;
use Payment\Client\Query;
use app\v1\extend\Payment;
use app\v1\extend\PayNotify;
use app\v1\extend\WeixinPay;

use app\v1\extend\HelibaoInt;
use sevenpay\payApplyInt;

/**
 * Class  Index
 * @title 通用支付接口
 * @url   v1/Pay
 * @desc  通用支付接口，目前已集成微信、支付宝
 * @version 1.0
 * @readme
 */
class Pay extends Base
{
    // 跳过验证方法
    protected $skipAuthActionList = ['WxNotify', 'AliNotify', 'notifyUrlApi','quickPayNotify','wxWapPayNotify','sevenpay'];

    // 附加方法
    protected $extraActionList = ['orderQuery', 'createOrder', 'createRechargeOrder','quickPayNotify','quickPayQuery','wxWapPayNotify'];

    protected $rule = [
        'payment_type' => 'require',
        'order_type'   => 'require',
        'userid'       => 'require',
        'total_fee'    => 'require',
    ];

    protected $msg = [
        'payment_type'       => '支付类型必填',
        'order_type.require' => '订单类型必填',
        'userid.require'     => '用户ID必填',
        'total_fee.require'  => '充值金额必填',
    ];

    /**
     * @title 获取我的订单
     * @return int    error          错误代码：0成功 -1错误
     * @return string message        消息提醒
     * @return object data           首页对象
     * @return int    userid         用户ID
     * @return int    order_type     订单类型：0圈子 1用户 2任务
     * @return int    payment_type   支付方式：1钱包 2微信 3支付宝 4银行卡
     * @return string order_no       订单编号
     * @return string transaction_no 微信支付订单号
     * @return string body           商品描述
     * @return string total_fee      充值金额
     * @return string status         订单状态：0未支付 1支付成功 2取消订单
     * @return string create_time    创建时间
     * @desc请求方式：GET <br/> 请求示例：v1/Pay?userid=1
     */
    public function index()
    {
        $userid   = input('get.userid');
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        if(!$userid) {
            return $this->sendError('用户ID必填');
        }

        $totalCount = Db::name('order')
            ->where('userid', $userid)
            ->count();

        $orderList = Db::name('order')
            ->where('userid', $userid)
            ->page($page, $pageSize)
            ->select();

        $retData = returnData($page, $pageSize, $totalCount, $orderList);

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /***测试七分钱支付***/
    public function sevenpay() {

        $sevenpay_obj = new payApplyInt();
        $res = $sevenpay_obj->payUnifiedOrder();

        var_dump($res);
        die;
    }
    /***测试七分钱支付***/

    /**
     * @title 创建充值订单
     * @author fuchao 2018-05-25
     * @title 通用支付(微信/云闪付)
     * @return int    error   错误代码  0成功 (1,-1)失败
     * @return string message 消息提醒
     * @return array  data    返回数据
     * @desc 请求方式：POST 请求示例: v1/Pay/createOrder
     */
    public function createOrder()
    {
        $moneyMax = 10000;      // 用户每日充值上限

        {   // 数据过滤
            $data = input('post.');
            $data['userid'] = input('userid') ? intval(input('userid')) : intval($this->userId);

            $validate = new Validate($this->rule, $this->msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(1, $validate->getError(), 200);
            }

            // 用户每日充值上限
            // $userMoneyCount = cache('moneyCount'.$data['userid']);
            $todayTime = (int)strtotime("today");
            $nextday = strtotime("today") + 24 * 60 * 60;   // 明日凌晨

            $map['status'] = 1;
            $map['userid'] = $data['userid'];
            $map['create_time'] = array([">=", $todayTime],["<", $nextday],'and');            

            $todayMoneyCount = Db::name('order')
                ->where($map)
                ->sum('total_fee');       

            if($todayMoneyCount > $moneyMax) {
                return $this->sendError(1, '用户今日已达到充值上限', 200);
            }            
        }

        $Ordertype   = $data['order_type'];             // 订单类型：circle圈子订单|user用户订单|task任务订单|redpacket红包订单|vip会员订单
        $Userid      = $data['userid'];                 // 用户id
        $Orderno     = date("Ymdhis").rand(1000, 9999); // 订单编号，18位
        $Alltotal    = $data['total_fee'];              // 充值金额
        $Paymenttype = $data['payment_type'];           // 充值方式：wallet系统钱包|wx微信|ali支付宝|wxxcx微信小程序|yspay云闪付
        $Paymentcode = 0;                               // 充值方式代码：1系统钱包|2微信|3支付宝|4微信小程序|6云闪付

        /**云闪付*/
        $deviceType = input('deviceType') ? input('deviceType') : '';              // 设备类型: 1.安卓 2.苹果(必填)
        $terminalId = input('terminalId') ? input('terminalId') : '';              // 终端标识：MAC或IMEI地址(必填)
        $yspayGoods = "";                                                          // 云闪付充值产品
        $yspayDes = "";                                                            // 云闪付充值产品描述

        // 判断充值充值方式
        if ($Paymenttype == 'wx') {  
            return $this->sendError(-1, '微信支付正在调试……', 200);  
            $Paymentcode = 2;
        } elseif ($Paymenttype == 'ali') {
            $Paymentcode = 3;
        } elseif ($Paymenttype == 'wxxcx') {
            $Paymentcode = 4;
            $Xcxopenid = db('user')->where('id', $Userid)->value('xcx_openid');

            if (empty($Xcxopenid))  return $this->sendError(-1, '小程序openid为空', 200);
        } elseif ($Paymenttype == 'wallet') {
            $Paymentcode = 1;
            if ($Ordertype == 'user') return $this->sendError(-1, '不能用余额充值钱包', 200);
        } elseif($Paymenttype == 'yspay') {                   // 云闪付

            if(empty($deviceType)) {
                return $this->sendError(-1, '设备类型必填', 200);  
            }elseif(empty($terminalId)) {
                return $this->sendError(-1, '终端标识必填', 200);
            }

            if($Alltotal<1) {
                return $this->sendError(-1, '最低充值金额为1元', 200);
            }

            $Paymentcode = 6;           // 云闪付类型编号
        } else {
            return $this->sendError(-1, '充值方式有误', 200);
        } 

        // 添加订单的数据
        $order_INSERT = array(
            'userid'       => $Userid,
            'payment_type' => $Paymentcode,
            'order_no'     => $Orderno,
            'total_fee'    => $Alltotal,
            'status'       => 0,
            'create_time'  => time(),
        );

        // 添加订单记录的数据
        $order_record_INSERT = array(
            'order_no'    => $Orderno,
            'userid'      => $Userid,
            'create_time' => time(),
        );

        // 根据充值类型，添加数据
        if ($Ordertype == 'circle') {        // 圈子充值订单
            if (!isset($data['circleid'])) return $this->sendError(-1, '圈子ID必填!', 200);

            $order_record_INSERT['circleid'] = $data['circleid'];

            $order_INSERT['order_type'] = 0;
            $order_INSERT['body'] = '圈子充值_' . $Orderno;
        } elseif ($Ordertype == 'user') {    // 用户充值订单
            $order_INSERT['order_type'] = 1;
            $order_INSERT['body']       = '用户充值_' . $Orderno;
        } elseif ($Ordertype == 'task') {    // 任务充值订单
            if (!isset($data['taskno'])) return $this->sendError(-1, '任务编号必填!', 200);

            $order_record_INSERT['taskno'] = $data['taskno'];

            $order_INSERT['order_type'] = 2;
            $order_INSERT['body']       = '任务充值_' . $Orderno;
        } elseif ($Ordertype == 'vip') {    // 会员充值订单
            if (!isset($data['vip_no'])) return $this->sendError(-1, '会员充值编号必填!', 200);

            $order_record_INSERT['vip_no'] = $data['vip_no'];

            $order_INSERT['order_type'] = 3;
            $order_INSERT['body']       = '会员充值_' . $Orderno;
        } elseif ($Ordertype == 'cvip') {    // 会员充值订单
            if (!isset($data['cvip_no'])) return $this->sendError(-1, '会员充值编号必填!', 200);

            $order_record_INSERT['cvip_no'] = $data['cvip_no'];

            $order_INSERT['order_type'] = 6;
            $order_INSERT['body']       = '商户会员充值_' . $Orderno;
        } elseif ($Ordertype == 'redpacket') {    // 红包充值订单
            if (!isset($data['red_id'])) return $this->sendError(-1, '红包id必填!', 200);

            $order_record_INSERT['red_id'] = $data['red_id'];

            $order_INSERT['order_type'] = 4;
            $order_INSERT['body']       = '红包充值_' . $Orderno;
        } else {
            return $this->sendError(-1, '充值类型不存在', 200);
        }

        // 添加充值订单
        $Neworderid = Db::name('order')->insertGetId($order_INSERT);  

        // 添加充值订单记录
        $Neworderrecordid = Db::name('order_recharge_record')->insertGetId($order_record_INSERT);

        if (empty($Neworderid) || empty($Neworderrecordid)) {
            return $this->sendError(-1, '订单创建失败', 200);
        }                
        
        // 区别钱包充值和其他充值
        if ($Paymenttype == 'wallet') {         // 钱包充值
            return self::walletRecharge($Userid, $Orderno, $Alltotal, $Ordertype, $order_INSERT, $order_record_INSERT);
        }elseif($Paymenttype == 'yspay') {      // 云闪付充值

            $yspayGoods = explode('_',$order_INSERT['body'])[0];
            $yspayDes = $order_INSERT['body'];
            
            /***/
                ## 这里根据$Userid,去认证表查询对应身份证号和实名，如果没有不传
            /**/

            $quickArr['userid'] = $Userid;                                      // 用户id 
            $quickArr['deviceType'] = $data['deviceType'];                      // 设备类型: 1.安卓 2.IOS
            $quickArr['amount'] = $Alltotal;                                    // 充值金额(单位:元)
            $quickArr['goodsName'] = $yspayGoods;                                // 商品名称
            $quickArr['goodsDesc'] = $yspayDes;                                 // 商品描述
            $quickArr['orderNo'] = $Orderno;                                    // 订单编号        
            $quickArr['terminalId'] = $data['terminalId'];                      // 终端标识             

            $helibao_obj = new HelibaoInt();                                    // 合利宝集成类
            $payRes = $helibao_obj->quickSdkMerchant($quickArr);                // 云闪付

            if($payRes['code'] != 'SUCCESS') {
                return $this->sendError(1, $payRes['message'], 200);
            }

            $returnData = json_decode(base64_decode($payRes['data']),true);      // 解码取出预支付id等参数

            if($returnData['retCode'] != 'SUCCESS') {
                return $this->sendError(1, $returnData['retMsg'], 200);
            }

            $payPack['merchantNo'] = $returnData['merchantNo'];      // 商户号
            $payPack['prePayId'] = $returnData['prePayId'];          // 预支付id
            $payPack['userId'] = $returnData['userId'];              // 用户id
            $payPack['appId'] = $returnData['appId'];                // 应用id

            $payPack['orderNum'] = $quickArr['orderNo'];             // 订单编号

            return $this->sendSuccess($payPack, 'success', 200);

        } else {                           // 创建微信或支付宝订单 
            $params = [
                'body'            => $order_INSERT['body'],
                'subject'         => $order_INSERT['body'],
                'order_no'        => $Orderno, 
                'amount'          => $Alltotal,
                'timeout_express' => time() + 600
            ];

            $payment = new Payment();
            $order = $payment->createOrder($data['payment_type'], $params);

            if (($data['payment_type'] == 'wx') || ($data['payment_type'] == 'wxxcx')) {
                $order['order_no'] = $Orderno;
            }
            
            return $this->sendSuccess($order, 'success', 200);
        }
    }

    /**
     * @title  创建充值订单（微信小程序/钱包）
     * @author wensen 2018-04-30
     * @return int error        错误代码：1失败 0成功
     * @return string message   消息提醒
     * @return object data      APP端调起支付的参数列表
     * @return string appid     小程序ID
     * @return string timestamp 时间戳
     * @return string noncestr  随机字符串
     * @return string package   数据包(包含预支付id)
     * @return string signType  签名加密方式
     * @return string paySign   支付签名
     * @desc 请求方式：POST 请求示例: v1/Pay/createRechargeOrder
     */
    public function createRechargeOrder()
    {
        {   // 数据过滤
            $data = input('post.');
            $data['userid'] = input('userid') ? intval(input('userid')) : intval($this->userId);

            $validate = new Validate($this->rule, $this->msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(1, $validate->getError(), 200);
            }
        }

        $Ordertype   = $data['order_type'];             // 订单类型：circle圈子订单|user用户订单|task任务订单|redpacket红包订单|vip会员订单
        $Userid      = $data['userid'];                 // 用户id
        $Orderno     = date("Ymdhis").rand(1000, 9999); // 订单编号，18位
        $Alltotal    = $data['total_fee'];              // 充值金额
        $Paymenttype = $data['payment_type'];           // 充值方式：wallet系统钱包|wx微信|ali支付宝|wxxcx微信小程序
        $Paymentcode = 0;                               // 充值方式代码：1系统钱包|2微信|3支付宝|4微信小程序

        // 判断充值充值方式
        if ($Paymenttype == 'wx') {
            $Paymentcode = 2;
        } elseif ($Paymenttype == 'ali') {
            $Paymentcode = 3;
        } elseif ($Paymenttype == 'wxxcx') {
            $Paymentcode = 4;
            //$Xcxopenid = 'oVJrD5M0BYE5c8T3Z0QRUcXMepxU';    // 李梦漩相对小程序的openid
            $Xcxopenid = db('user')->where('id', $Userid)->value('xcx_openid');

            if (empty($Xcxopenid))  return $this->sendError(-1, '小程序openid为空', 200);
        } elseif ($Paymenttype == 'wallet') {
            $Paymentcode = 1;
            if ($Ordertype == 'user') return $this->sendError(-1, '不能用余额充值钱包', 200);
        } else {
            return $this->sendError(-1, '充值方式有误', 200);
        }

// dump($Paymentcode);
// dump($Xcxopenid);
// exit();

        // 添加订单的数据
        $order_INSERT = array(
            'userid'       => $Userid,
            'payment_type' => $Paymentcode,
            'order_no'     => $Orderno,
            'total_fee'    => $Alltotal,
            'status'       => 0,
            'create_time'  => time(),
        );

        // 添加订单记录的数据
        $order_record_INSERT = array(
            'order_no'    => $Orderno,
            'userid'      => $Userid,
            'create_time' => time(),
        );

        // 根据充值类型，添加数据
        if ($Ordertype == 'circle') {        // 圈子充值订单
            if (!isset($data['circleid'])) return $this->sendError(-1, '圈子ID必填!', 200);

            $order_record_INSERT['circleid'] = $data['circleid'];

            $order_INSERT['order_type'] = 0;
            $order_INSERT['body'] = '圈子充值_' . $Orderno;
        } elseif ($Ordertype == 'user') {    // 用户充值订单
            $order_INSERT['order_type'] = 1;
            $order_INSERT['body']       = '用户充值_' . $Orderno;
        } elseif ($Ordertype == 'task') {    // 任务充值订单
            if (!isset($data['taskno'])) return $this->sendError(-1, '任务编号必填!', 200);

            $order_record_INSERT['taskno'] = $data['taskno'];

            $order_INSERT['order_type'] = 2;
            $order_INSERT['body']       = '任务充值_' . $Orderno;
        } elseif ($Ordertype == 'vip') {    // 会员充值订单
            if (!isset($data['vip_no'])) return $this->sendError(-1, '会员充值编号必填!', 200);

            $order_record_INSERT['vip_no'] = $data['vip_no'];

            $order_INSERT['order_type'] = 3;
            $order_INSERT['body']       = '会员充值_' . $Orderno;
        } elseif ($Ordertype == 'cvip') {    // 会员充值订单
            if (!isset($data['cvip_no'])) return $this->sendError(-1, '会员充值编号必填!', 200);

            $order_record_INSERT['cvip_no'] = $data['cvip_no'];

            $order_INSERT['order_type'] = 6;
            $order_INSERT['body']       = '商户会员充值_' . $Orderno;
        } elseif ($Ordertype == 'redpacket') {    // 红包充值订单
            if (!isset($data['red_id'])) return $this->sendError(-1, '红包id必填!', 200);

            $order_record_INSERT['red_id'] = $data['red_id'];

            $order_INSERT['order_type'] = 4;
            $order_INSERT['body']       = '红包充值_' . $Orderno;
        } else {
            return $this->sendError(-1, '充值类型不存在', 200);
        }

// dump($insert_data );
// dump($payment_type );
// halt($data );

        // 添加充值订单
        $Neworderid = Db::name('order')->insertGetId($order_INSERT);  

        // 添加充值订单记录
        $Neworderrecordid = Db::name('order_recharge_record')->insertGetId($order_record_INSERT);

        if (empty($Neworderid) || empty($Neworderrecordid)) {
            return $this->sendError(-1, '订单创建失败', 200);
        }                
        
        // 区别钱包充值和其他充值
        if ($Paymenttype == 'wallet') {    // 钱包充值
            return self::walletRecharge($Userid, $Orderno, $Alltotal, $Ordertype, $order_INSERT, $order_record_INSERT);
        } else {    // 创建微信小程序支付

            $params = [
                'body'            => $order_INSERT['body'],
                'subject'         => $order_INSERT['body'],
                'order_no'        => $Orderno,
                'amount'          => $Alltotal,
                'openid'          => $Xcxopenid,
                'timeout_express' => time() + 600
            ];

            /**
             * **
             * author: fuchao
             * date: 2018-04-30
             * desc: 这里开始统一下单支付 
             */

            $wxxcx_config = config('pay.wxxcx');            // 微信小程序设置

            $appid = $wxxcx_config['app_id'];               // 小程序id
            $mch_id = $wxxcx_config['mch_id'];              // 支付商户id
            $key = $wxxcx_config['md5_key'];                // 商户的支付密钥
            $notify_url = $wxxcx_config['notify_url'];      // 微信服务器异步通知
            $spbill_create_ip = $_SERVER['REMOTE_ADDR'];    // 客户端ip

            $openid = $Xcxopenid;                           // 用户openid
            $out_trade_no = $Orderno;                       // 订单编号

            $body = $params['body'];                        // 订单描述
            $total_fee = $Alltotal;                         // 支付金额

// var_dump($total_fee);
// die;
            
            // 实例微信支付基类
            $weixinPay = new WeixinPay($appid, $openid, $mch_id, $key,$out_trade_no,$body,$total_fee,$notify_url,$spbill_create_ip);
            // 发起微信支付
            $result = $weixinPay->pay();

            if($result['code'] == 0) {      // 统一下单出错
                return $this->sendError(1, $result['msg'], 200);
            }

            // 获取预支付返回参成功
            return $this->sendSuccess($result, 'success', 200);
            die;

            // $payment = new Payment();
            // $order = $payment->createOrder($Paymenttype, $params);

            // if (($Paymenttype == 'wx') || ($Paymenttype == 'wxxcx')) {
            //     $order['order_no'] = $Orderno;
            // }
            
            // return $this->sendSuccess($order, 'success', 200);
        }
    }


/**********************************支付新增部分********************************************************/

    /**
     * @合利宝微信Wap支付异步回调，请求方式: POST <br/> 地址: v1/Pay/wxWapPayNotify
    */
    public function wxWapPayNotify() { 

        $notifyStr = file_get_contents('php://input', 'r');
// Log::write($notifyArr.'&fc&'.date('Y-m-d H:i:s'),'notice');
// die;
        //parse_str($notifyStr,$notifyArr); 
        
        $insert_data['content'] = $notifyStr;
        $result = Db::name('ztest')->insert($insert_data);
    }

    /**
     * @合利宝闪付宝异步回调，请求方式：POST <br/> 地址：v1/Pay/quickPayNotify
    */
    public function quickPayNotify() {
        $signKey = 'D5waKUkqliHQgDQn8sKIQwyEQkrHl7pw';      // 云闪付签名密钥
        $notifyStr = file_get_contents('php://input', 'r');
// Log::write($notifyArr.'&fc&'.date('Y-m-d H:i:s'),'notice');
// die;
        parse_str($notifyStr,$notifyArr);     
    
        $notifyData = json_decode(base64_decode($notifyArr['data']),true);   // data详细信息
        $verifySign = strtoupper(md5($notifyArr['data'].'&'.$signKey));      // 验签[md5(data&key)]

        // 返回成功且签名相符
        if($notifyArr['code'] == 'SUCCESS' && $notifyArr['sign'] == $verifySign) {

            $notifyData = json_decode(base64_decode($notifyArr['data']),true);   // data详细信息

            // 更新数据库
            if($notifyData['retCode'] == 'SUCCESS' && $notifyData['status'] == 'SUCCESS') {

                // 获取服务器返回的数据  
                $notify['orderSn'] = $notifyData['orderNum'];             // 订单单号  
                $notify['userId'] = $notifyData['userId'];                // 付款人userid 
                $notify['totalFee'] = $notifyData['amount'];              // 付款金额  
                $notify['transactionId'] = $notifyData['serialNumber'];   // 合利宝支付流水号

                $order = Db::name('order')
                ->field('userid,status,order_type')
                ->where('status', 0)         // 订单状态 0未支付 1支付成功 2取消订单
                ->where('order_no', $notify['orderSn'])
                ->find();

                if($order) {    
                    $this->updateDb($notify,$order);   // 更新对应的数据表
                }
            }
        }

        // $insert_data['content'] = $notifyStr;
        // $result = Db::name('ztest')->insert($insert_data);
        die;
    }


    /*微信支付的 异步通知 *回调地址*/   
    /**回调修改2018-05-04**/
    public function notifyUrlApi() {

        $xml = file_get_contents('php://input', 'r');  
          
        //将服务器返回的XML数据转化为数组  
        $data = $this->toArray($xml);  
          
        // 判断签名是否正确  判断支付状态  
        if (($data['return_code'] == 'SUCCESS') && ($data['result_code'] == 'SUCCESS')) {  

            $result = $data;  

            //获取服务器返回的数据  
            // $order_sn = $data['out_trade_no'];          // 订单单号  
            // $openid = $data['openid'];                  // 付款人openID  
            // $total_fee = ($data['total_fee'])/100;      // 付款金额  
            // $transaction_id = $data['transaction_id'];  // 微信支付流水号 

            $notify['orderSn'] = $data['out_trade_no'];          // 订单单号  
            $notify['userId'] = $data['openid'];                  // 付款人openID  
            $notify['totalFee'] = ($data['total_fee'])/100;      // 付款金额  
            $notify['transactionId'] = $data['transaction_id'];  // 微信支付流水号  
              
            //更新数据库  
            $order = Db::name('order')
            ->field('userid,status,order_type')
            ->where('status', 0)         // 订单状态 0未支付 1支付成功 2取消订单
            ->where('order_no', $order_sn)
            ->find();

            if($order) {   // 订单是否存在

                $this->updateDb($notify,$order);   // 更新对应的数据表
            } else {      // 订单不存在 
                $result = false;  
            }
        }else {
            $result = false;  
        }  

        // 返回状态给微信服务器  
        if ($result) {  
            $str='<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';  
        }else{  
            $str='<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[签名失败]]></return_msg></xml>';  
        }

        echo $str;
        return $result;  
    }
    
    // 根据回调更新数据库
    protected function updateDb($notifyData,$order) {

        Db::startTrans();

        try {
            Db::name('order')   // 更新订单状态(order)
                ->where('order_no', $notifyData['orderSn'])
                ->update(['transaction_no' => $notifyData['transactionId'], 'status' => 1]);

            if ($order['order_type'] == 0) {        // 更新圈子总金额
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $notifyData['orderSn'])
                    ->find();

                Db::name('circle')
                    ->where('id', $order_recharge_record['circleid'])
                    ->setInc('total_amount', $notifyData['totalFee']);

            }elseif ($order['order_type'] == 1) {    // 更新用户金额

                Db::name('user')
                    ->where('id', $order['userid'])
                    ->setInc('balance', $notifyData['totalFee']);

            }elseif ($order['order_type'] == 2) {    // 更新任务状态
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $notifyData['orderSn'])
                    ->find();

                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新任务表
                Db::name('task')
                    ->where('task_no', $order_recharge_record['taskno'])
                    ->update($task_ok_UPDATE);

                // 更新任务详细记录表
                Db::name('task_record')
                    ->where('task_no', $order_recharge_record['taskno'])
                    ->update($task_ok_UPDATE);

            }elseif ($order['order_type'] == 3) {    // 更新vip状态
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $notifyData['orderSn'])
                    ->find();

                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新任务表
                Db::name('user_vip')
                    ->where('vip_no', $order_recharge_record['vip_no'])
                    ->update($task_ok_UPDATE);

                // 更新任务详细记录表
                Db::name('user_vip_record')
                    ->where('vip_no', $order_recharge_record['vip_no'])
                    ->update($task_ok_UPDATE);

                $Vipuserid = Db::name('user_vip_record')->field(true)->where('vip_no', $order_recharge_record['vip_no'])->select();

                $user_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                Db::name('user')->where($user_WHERE)->update(['vip' => 1]);

            }elseif ($order['order_type'] == 6) {    // 更新商户vip状态
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $notifyData['orderSn'])
                    ->find();

                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新商户会员表
                Db::name('user_vipcus')
                    ->where('cvip_no', $order_recharge_record['cvip_no'])
                    ->update($task_ok_UPDATE);

                // 更新商户会员表详细记录表
                Db::name('user_vipcus_record')
                    ->where('cvip_no', $order_recharge_record['cvip_no'])
                    ->update($task_ok_UPDATE);

                $Vipuserid = Db::name('user_vipcus_record')->field(true)->where('cvip_no', $order_recharge_record['cvip_no'])->select();

                $user_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                Db::name('user')->where($user_WHERE)->update(['cusvip' => 1]);

            }elseif ($order['order_type'] == 4) {    // 更新红包状态
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $notifyData['orderSn'])
                    ->find();

                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新红包表
                Db::name('redpacket')
                    ->where('red_id', $order_recharge_record['red_id'])
                    ->update($task_ok_UPDATE);

                // 更新红包表
                Db::name('business_record')
                    ->where('red_id', $order_recharge_record['red_id'])
                    ->update($task_ok_UPDATE);
            }

            /**记录用户的今日充值总额**/
            // $nextday = strtotime("today") + 24 * 60 * 60;      
            // $expires = $nextday - time();
            // Cache::set($mobile.'_daytimes', 1, $expires);

            Db::commit();
        }catch (Exception $e) {
            $result = false;  
            Db::rollback();

            Log::write($e->getMessage(),'notice');
        }
    }


   /**
   * 将xml转为array
   * @param  string $xml xml字符串
   * @return array       转换得到的数组
   */
    public function toArray($xml) {   
        libxml_disable_entity_loader(true);     // 禁止引用外部xml实体
        $result = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);        
        return $result;
    }
    
/******************************************************************************************/
    
    // 钱包支付
    private function walletRecharge($Userid, $Orderno, $Alltotal, $Ordertype, $order_INSERT, $order_record_INSERT)
    {
        $Userdata = Db::name('user')->where('id', $Userid)->find();    // 获取用户系统余额

        if ($Userdata['balance'] < $Alltotal) {
            return $this->sendError(-1, '余额不足充值失败', 200);
        }

        Db::startTrans();    // 开启事务

        try {
            Db::name('user')->where('id', $Userid)->setDec('balance', $Alltotal);

            Db::name('order')->where('order_no', $Orderno)->setField('status', 1);

            if ($Ordertype == 'circle') {    // 充值
                // 获取圈子金额
                $circle_total_amount = Db::name('circle')
                    ->where('id', $order_record_INSERT['circleid'])
                    ->value('total_amount');

                // 增加圈子总金额
                Db::name('circle')
                    ->where('id', $order_record_INSERT['circleid'])
                    ->update([
                        'total_amount' => round($Alltotal, 2) + round($circle_total_amount, 2),
                        'is_recharge'  => 1,
                    ]);

            } elseif ($Ordertype == 'task') {
                // 更新任务表
                Db::name('task')
                    ->where('task_no', $order_record_INSERT['taskno'])
                    ->update(['ok' => 1, 'ok_time' => time()]);

                // 更新任务详细记录表
                Db::name('task_record')
                    ->where('task_no', $order_record_INSERT['taskno'])
                    ->update(['ok' => 1, 'ok_time' => time()]);

            } elseif ($Ordertype == 'vip') {
                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新任务表
                Db::name('user_vip')
                    ->where('vip_no', $order_record_INSERT['vip_no'])
                    ->update($task_ok_UPDATE);

                // 更新任务详细记录表
                Db::name('user_vip_record')
                    ->where('vip_no', $order_record_INSERT['vip_no'])
                    ->update($task_ok_UPDATE);

                $Vipuserid = Db::name('user_vip_record')->field(true)->where('vip_no', $order_record_INSERT['vip_no'])->select();

                $user_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                Db::name('user')->where($user_WHERE)->update(['vip' => 1]);

                // 生成系统消息给用户
                $SelfCheck = Db::name('user_vip')->field(true)->where('vip_no', $order_record_INSERT['vip_no'])->find();

                if ($SelfCheck['type'] == 0) {   // 给别人充
                    $admin_WHERE['id'] = $SelfCheck['addid'];
                    $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

                    // $needToUserids  = [];
                    $message_INSERT = [];
                    foreach ($Vipuserid as $key => $value) {
                        $message_INSERT[$key]['create_time'] = time();
                        $message_INSERT[$key]['to_userid']   = $value['userid'];
                        $message_INSERT[$key]['typeid']      = 4;
                        $message_INSERT[$key]['title']       = '恭喜你成为跑步钱进APP会员';
                        $message_INSERT[$key]['content']     = '你的好友' . $admindata['nickname'] . '为你充值了会员，恭喜你成为跑步钱进APP会员';
                    }

                    $need_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                    $needtoname = Db::name('user')->field('id,nickname')->where($need_WHERE)->select();

                    $needtonamearray = array_column($needtoname, 'nickname');
                    $needtonames = implode(',', $needtonamearray);

                    $message_INSERT[$key + 1]['create_time'] = time();
                    $message_INSERT[$key + 1]['to_userid']   = $admindata['id'];
                    $message_INSERT[$key + 1]['typeid']      = 4;
                    $message_INSERT[$key + 1]['title']       = '你成功为你的好友充值会员';
                    $message_INSERT[$key + 1]['content']     = '你已成功为你的好友' . $needtonames . '充值会员';

                    Db::name('user_messages')->insertAll($message_INSERT);

                } else {                         // 给自己充
                    $admin_WHERE['id'] = $SelfCheck['addid'];
                    $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

                    $message_INSERT['create_time'] = time();
                    $message_INSERT['to_userid']   = $admindata['id'];
                    $message_INSERT['typeid']      = 4;
                    $message_INSERT['title']       = '恭喜你成功充值跑步钱进APP会员';
                    $message_INSERT['content']     = '恭喜你成功充值跑步钱进APP会员';

                    Db::name('user_messages')->insert($message_INSERT);
                }

            }  elseif ($Ordertype == 'cvip') {
                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新任务表
                Db::name('user_vipcus')
                    ->where('cvip_no', $order_record_INSERT['cvip_no'])
                    ->update($task_ok_UPDATE);

                // 更新任务详细记录表
                Db::name('user_vipcus_record')
                    ->where('cvip_no', $order_record_INSERT['cvip_no'])
                    ->update($task_ok_UPDATE);

                $Vipuserid = Db::name('user_vipcus_record')->field(true)->where('cvip_no', $order_record_INSERT['cvip_no'])->select();

                $user_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                Db::name('user')->where($user_WHERE)->update(['cusvip' => 1]);

                // 生成系统消息给用户
                $SelfCheck = Db::name('user_vipcus')->field(true)->where('cvip_no', $order_record_INSERT['cvip_no'])->find();

                if ($SelfCheck['type'] == 0) {   // 给别人充
                    $admin_WHERE['id'] = $SelfCheck['addid'];
                    $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

                    // $needToUserids  = [];
                    $message_INSERT = [];
                    foreach ($Vipuserid as $key => $value) {
                        $message_INSERT[$key]['create_time'] = time();
                        $message_INSERT[$key]['to_userid']   = $value['userid'];
                        $message_INSERT[$key]['typeid']      = 4;
                        $message_INSERT[$key]['title']       = '恭喜你成为跑步钱进APP商户会员';
                        $message_INSERT[$key]['content']     = '你的好友' . $admindata['nickname'] . '为你充值了会员，恭喜你成为跑步钱进APP商户会员';
                    }

                    $need_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                    $needtoname = Db::name('user')->field('id,nickname')->where($need_WHERE)->select();

                    $needtonamearray = array_column($needtoname, 'nickname');
                    $needtonames = implode(',', $needtonamearray);

                    $message_INSERT[$key + 1]['create_time'] = time();
                    $message_INSERT[$key + 1]['to_userid']   = $admindata['id'];
                    $message_INSERT[$key + 1]['typeid']      = 4;
                    $message_INSERT[$key + 1]['title']       = '你成功为你的好友充值商户会员';
                    $message_INSERT[$key + 1]['content']     = '你已成功为你的好友' . $needtonames . '充值商户会员';

                    Db::name('user_messages')->insertAll($message_INSERT);

                } else {                         // 给自己充
                    $admin_WHERE['id'] = $SelfCheck['addid'];
                    $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

                    $message_INSERT['create_time'] = time();
                    $message_INSERT['to_userid']   = $admindata['id'];
                    $message_INSERT['typeid']      = 4;
                    $message_INSERT['title']       = '恭喜你成功充值跑步钱进APP商户会员';
                    $message_INSERT['content']     = '恭喜你成功充值跑步钱进APP商户会员';

                    Db::name('user_messages')->insert($message_INSERT);
                }

            } elseif ($Ordertype == 'redpacket') {
                // 更新任务表
                Db::name('redpacket')
                    ->where('red_id', $order_record_INSERT['red_id'])
                    ->update(['ok' => 1, 'ok_time' => time()]);

                // 更新任务表
                Db::name('business_record')
                    ->where('red_id', $order_record_INSERT['red_id'])
                    ->update(['ok' => 1, 'ok_time' => time()]);
            }

            Db::commit();      // 提交事务

            $order_INSERT['status'] = 1;
            return $this->sendSuccess($order_INSERT, 'success', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(-1, $e->getMessage(), 200);
        }
    }

    /**
     * @title 微信回调
     * @author chenjie 2018-02-02
     */
    public function WxNotify()
    {
        $type     = 'wx_charge';
        $config   = config('pay.wx');
        $callback = new PayNotify();

        try {
            $ret = Notify::run($type, $config, $callback); // 处理回调，内部进行了签名检查
            echo $ret;
        } catch (PayException $e) {
            Log::write("错误信息：".$e->errorMessage().time(),'debug');
            exit;
        }
    }

    /**
     * @title 支付宝回调
     * @author chenjie 2018-02-02
     */
    public function AliNotify()
    {
        $type     = 'ali_charge';
        $config   = config('pay.alipay');
        $callback = new PayNotify();

        try {
            $ret = Notify::run($type, $config, $callback);// 处理回调，内部进行了签名检查
            echo $ret;
        } catch (PayException $e) {
            Log::write("错误信息：".$e->errorMessage(),time(),'error');
            exit;
        }
    }

    /**
     * @title 订单查询
     * @author chenjie 2018-02-02
     * @return int    userid         用户ID
     * @return int    order_type     订单类型 0圈子 1用户 2任务
     * @return int    payment_type   支付类型 1钱包 2微信 3支付宝 4银行卡
     * @return string order_no       订单编号
     * @return string transaction_no 微信支付订单号
     * @return string body           商品描述
     * @return float  total_fee      充值金额
     * @return int    status         订单状态 0未支付 1支付成功
     * @return int    create_time    创建时间
     * @return int    circleid       圈子ID
     * @return int    taskid         任务ID
     * @desc 请求方式：GET 请求示例: v1/Pay/orderQuery
     * 
     */
    public function orderQuery()
    {
        $order_no     = input('get.order_no');
        $payment_type = input('get.payment_type');

        if (!$order_no) {
            return $this->sendError(-1, '订单编号必填', 400);
        }

        if (!$payment_type) {
            return $this->sendError(-1, '支付类型必填', 400);
        }

        // 查询订单信息
        $order = Db::name('order')
            ->alias('order')
            ->field('
                order.userid,
                order.order_type,
                order.payment_type,
                order.order_no,
                order.transaction_no,
                order.body,
                order.total_fee,
                order.status,
                order.create_time,
                order_recharge_record.circleid,
                order_recharge_record.taskid')
            ->join('order_recharge_record','order_recharge_record.order_no = order.order_no')
            ->where('order.order_no', $order_no)
            ->find();

        if($order['status'] == 1){
            return $this->sendSuccess($order, 'success', 200);
        }else{
            if($payment_type == 'wx'){
                $config = config('pay.wx');
                $type = 'wx_charge';
            }else{
                $config = config('pay.alipay');
                $type = 'ali_charge';
            }
            $data = ['out_trade_no' => $order_no];

            try {
                $ret = Query::run($type, $config, $data);
            } catch (PayException $e) {
                return $this->sendError(-1, $e->errorMessage(), 400);
            }

            // 支付成功
            if($ret['is_success'] == 'T'){
                Db::startTrans();
                try{
                    //更新订单状态
                    Db::name('order')
                    ->where('order_no', $order_no)
                    ->update(['transaction_no' => $ret['response']['transaction_id'], 'status' => 1]);

                    // 更新圈子总金额
                    if($order['order_type'] == 0){
                        Db::name('circle')
                        ->where('id',$order['circleid'])
                        ->setInc('total_amount', $ret['response']['amount']);

                    }
                    // 更新用户金额
                    elseif($order['order_type'] == 1){
                        Db::name('user')
                        ->where('id',$order['userid'])
                        ->setInc('balance', $ret['response']['amount']);
                    }
                    Db::commit();
                } catch (\Exception $e) {
                    Db::rollback();
                    return $this->sendSuccess($e->getMessage(), 'success', 200);
                }

                return $this->sendSuccess($order, 'success', 200);
            }
            // 支付失败
            else{
                return $this->sendError(-1, $ret['error'], 200);
            }
        }
    }

    /**
     * @title  闪付宝支付订单查询
     * @return int    error   错误代码  0成功 1失败
     * @return string message 消息提醒
     * @return array  data    返回数据
     * @desc 合利宝闪付宝支付，请求方式：POST <br/> 地址：v1/Pay/quickPayQuery
    */
    public function quickPayQuery() {
        $data = input("post.");
        $data['userid'] = input('userid') ? intval(input('userid')) : intval($this->userId);

        $rule = [
                'userid'        => 'require|gt:0',
                'order_no'       => 'require',
        ];

        $msg = [
            'userid.require'        => '用户ID必填',
            'userid.gt'             => '用户ID必须大于0',
            'order_no.require'       => '订单编号必填',
        ];

        // 验证字段
        $validate = new Validate($rule, $msg);
        $validate_result = $validate->check($data);    

        if (empty($validate_result)) {
            return $this->sendError(1, $validate->getError(), 200);
        }

        // 查询订单信息
        $order = Db::name('order')
            ->alias('order')
            ->field('
                order.userid,
                order.order_type,
                order.payment_type,
                order.order_no,
                order.transaction_no,
                order.body,
                order.total_fee,
                order.status,
                order.create_time,
                order_recharge_record.circleid,
                order_recharge_record.taskid')
            ->join('order_recharge_record','order_recharge_record.order_no = order.order_no')
            ->where('order.order_no', $data['order_no'])
            ->find();

        // if(!$order) {
        //     return $this->sendError(1, '订单不存在', 200);
        // }

        // 本地查询订单正常则返回
        if($order && $order['status'] == 1) {
            return $this->sendSuccess($order, 'success', 200);
        }else{

            $helibao_obj = new HelibaoInt();                                     // 合利宝集成类
            $queryRes = $helibao_obj->quickPayQuery($data['order_no']);          // 云闪付支付订单查询

            if($queryRes['code'] != 'SUCCESS') {
                return $this->sendError(1, $queryRes['message'], 200);
            }

            $returnData = json_decode(base64_decode($queryRes['data']),true);     // 解码data信息 

            if($returnData['retCode'] != 'SUCCESS') {
                return $this->sendError(1, $returnData['retMsg'], 200);
            }

            $queryArr['orderSn'] = $returnData['orderNum'];             // 订单单号  
            $queryArr['userId'] = $returnData['userId'];                // 付款人userid 
            $queryArr['totalFee'] = $returnData['amount'];              // 付款金额  
            $queryArr['transactionId'] = $returnData['serialNumber'];   // 合利宝支付流水号

            $currOrder = Db::name('order')
            ->field('userid,status,order_type')
            ->where('status', 0)         // 订单状态 0未支付 1支付成功 2取消订单
            ->where('order_no', $queryArr['orderSn'])
            ->find();

            if($currOrder) {    
                $this->updateDb($queryArr,$currOrder);   // 更新对应的数据表

                return $this->sendSuccess($returnData, 'success', 200);     // 合利宝订单查询源数据
            }
        }
    }


    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
            ],
            'orderQuery' => [
                'order_no' => [
                    'name'    => 'order_no', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '订单编号', 
                    'range'   => '',
                ],
                'payment_type' => [
                    'name'    => 'payment_type', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '支付类型 wx微信支付 | ali支付宝支付', 
                    'range'   => '',
                ]
            ],
            'quickPayQuery' => [
                'order_no' => [
                    'name'    => 'order_no', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '订单编号', 
                    'range'   => '',
                ],
            ],
            'createOrder' => [
                'payment_type' => [
                    'name'    => 'payment_type', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '支付类型：wx微信支付 | ali支付宝支付 | wallet钱包 | wxxcx微信小程序 | yspay云闪付', 
                    'range'   => '',
                ],
                'order_type' => [
                    'name'    => 'order_type', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => 'circle圈子订单 | user用户订单 | task任务订单 | redpacket红包订单 | vip会员订单 | cvip商户会员订单', 
                    'range'   => '',
                ],
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'total_fee' => [
                    'name'    => 'total_fee', 
                    'type'    => 'float', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '充值金额', 
                    'range'   => '',
                ],
                'circleid' => [
                    'name'    => 'circleid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '圈子ID', 
                    'range'   => '',
                ],
                // 'taskid' => [
                //     'name'    => 'taskid', 
                //     'type'    => 'int', 
                //     'require' => 'false', 
                //     'default' => '', 
                //     'desc'    => '任务ID', 
                //     'range'   => '',
                // ],
                'taskno' => [
                    'name'    => 'taskno', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '任务编号', 
                    'range'   => '',
                ],
                'red_id' => [
                    'name'    => 'red_id', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '红包id', 
                    'range'   => '',
                ],
                'vip_no' => [
                    'name'    => 'vip_no', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '会员充值编号', 
                    'range'   => '',
                ],
                'cvip_no' => [
                    'name'    => 'cvip_no', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '商户会员充值编号', 
                    'range'   => '',
                ],

                'deviceType' => [
                    'name'    => 'deviceType', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '设备类型:1.安卓 2.苹果(使用云闪付必填)', 
                    'range'   => '',
                ],
                'terminalId' => [
                    'name'    => 'terminalId', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '终端标识:MAC或IMEI地址(使用云闪付必填)', 
                    'range'   => '',
                ],
            ],
            'createRechargeOrder' => [
                'payment_type' => [
                    'name'    => 'payment_type', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '支付类型：wx微信支付 | ali支付宝支付 | wallet钱包 | wxxcx微信小程序', 
                    'range'   => '',
                ],
                'order_type' => [
                    'name'    => 'order_type', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => 'circle圈子订单 | user用户订单 | task任务订单 | redpacket红包订单 | vip会员订单 | cvip商户会员订单', 
                    'range'   => '',
                ],
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'total_fee' => [
                    'name'    => 'total_fee', 
                    'type'    => 'float', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '充值金额', 
                    'range'   => '',
                ],
                'circleid' => [
                    'name'    => 'circleid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '圈子ID', 
                    'range'   => '',
                ],
                'taskno' => [
                    'name'    => 'taskno', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '任务编号', 
                    'range'   => '',
                ],
                'red_id' => [
                    'name'    => 'red_id', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '红包id', 
                    'range'   => '',
                ],
                'vip_no' => [
                    'name'    => 'vip_no', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '会员充值编号', 
                    'range'   => '',
                ],
                'cvip_no' => [
                    'name'    => 'cvip_no', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '商户会员充值编号', 
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
