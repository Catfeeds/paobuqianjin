<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/06/05 10:00
// +----------------------------------------------------------------------
// | TITLE: 支付密码接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Validate;
use think\Request;
use think\Db;
use app\v1\extend\HelibaoInt;
use app\v1\extend\BankCarData;

/**
 * Class  PayPassword
 * @title 支付密码接口
 * @url   v1/PayPassword
 * @desc  涉及到用户支付密码的都在这
 * @version 1.0
 */
class PayPassword extends Base
{
    // 附加方法
    protected $extraActionList = ['chcekPw', 'validatePw', 'modifyPw', 'powerModifyPw', 'addPw', 'realAddPw', 'validateUserBank', 'addUserBank'];

    // 跳过验证方法
    protected $skipAuthActionList = [];

    /**
     * @title  检测是否设置支付密码
     * @return int    error      错误代码：0成功 1错误
     * @return string message    消息提醒
     * @return array  data       返回数据
     * @return int    setpw      是否设置支付密码：1是 0否
     * @desc 请求方式：GET <br/>请求示例：v1/PayPassword/chcekPw
     */
    public function chcekPw()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        $here_WHERE['id']        = $Userid;
        $here_WHERE['delete_id'] = 0;

        $chcek = db('user')->field('id,paypw,pwsalt')->where($here_WHERE)->find();

        if (empty($chcek)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        if (empty($chcek['paypw'])) {
            return $this->sendSuccess(['setpw' => 0], 'success', 200);
        }

        return $this->sendSuccess(['setpw' => 1], 'success', 200);
    }

    /**
     * @title  验证支付密码
     * @return int    error      错误代码：0成功 1错误
     * @return string message    消息提醒
     * @return array  data       返回数据
     * @desc 请求方式：POST <br/>请求示例：v1/PayPassword/validatePw
     */
    public function validatePw()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Paypw  = input('paypw');

        if (empty($Paypw) || empty($Userid)) {
            return $this->sendError(1, '支付密码必填', 200);
        } else {
            $Paypw = base64_decode($Paypw);
        }

        if ($Paypw < 100000) {
            return $this->sendError(1, '支付密码必须为6位数字', 200);
        }

        $Chcekpwtimes = cache('ChcekPwTimes_' . $Userid);
        if ($Chcekpwtimes > 4) {
            return $this->sendError(1, '连续失败5次，10分钟后再试', 200);
        }
        

        $here_WHERE['id']        = $Userid;
        $here_WHERE['delete_id'] = 0;

        $chcek = db('user')->field('id,paypw,pwsalt')->where($here_WHERE)->find();

        if (empty($chcek)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        if (empty($chcek['paypw'])) {
            return $this->sendError(1, '密码不存在，请设置', 200);
        }

        $Paypw = md5($Paypw . $chcek['pwsalt']);

        if ($chcek['paypw'] != $Paypw) {
            cache('ChcekPwTimes_' . $Userid, $Chcekpwtimes + 1, 600);

            return $this->sendError(1, '密码错误', 200);
        } else {
            self::addPwLog($Userid, 3);   // 支付密码日志

            cache('ChcekPwTimes_' . $Userid, 0, 1);

            return $this->sendSuccess('', '密码正确', 200);
        }
    }

    /**
     * @title  修改支付密码
     * @return int    error      错误代码：0成功 1错误
     * @return string message    消息提醒
     * @return array  data       返回数据
     * @desc 请求方式：POST <br/>请求示例：v1/PayPassword/modifyPw
     */
    public function modifyPw()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Oldpw  = input('oldpw');
        $Paypw  = input('paypw');
        $Pwsalt = rand(1000, 9999);

        if (empty($Oldpw)) {
            return $this->sendError(1, '支付密码必填', 200);
        } else {
            $Oldpw = base64_decode($Oldpw);
        }

        if (empty($Paypw)) {
            return $this->sendError(1, '支付密码必填', 200);
        } else {
            $Paypw = base64_decode($Paypw);
        }

        if (($Oldpw < 100000) || ($Paypw < 100000)) {
            return $this->sendError(1, '支付密码必须为6位数字', 200);
        }

        if (empty($Paypw) || empty($Userid)) {
            return $this->sendError(1, '新支付密码必填', 200);
        }

        $Chcekpwtimes = cache('ChcekPwTimes_' . $Userid);
        if ($Chcekpwtimes > 4) {
            return $this->sendError(1, '连续失败5次，10分钟后再试', 200);
        }

        $here_WHERE['id']        = $Userid;
        $here_WHERE['delete_id'] = 0;

        $chcek = db('user')->field('id,paypw,pwsalt')->where($here_WHERE)->find();

        if (empty($chcek)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        if (empty($chcek['paypw'])) {
            return $this->sendError(1, '密码不存在，请设置', 200);
        }

        $Oldpw = md5($Oldpw . $chcek['pwsalt']);

        if ($chcek['paypw'] != $Oldpw) {
            return $this->sendError(1, '旧密码错误', 200);
        }

        $here_UPDATE['paypw']  = md5($Paypw . $Pwsalt);
        $here_UPDATE['pwsalt'] = $Pwsalt;
        $here_UPDATE['pwtime'] = time();

        $res = db('user')->where($here_WHERE)->update($here_UPDATE);

        if ($res) {
            self::addPwLog($Userid, 2);   // 支付密码日志

            cache('ChcekPwTimes_' . $Userid, 0, 1);

            return $this->sendSuccess('', '修改支付密码成功', 200);
        } else {
            cache('ChcekPwTimes_' . $Userid, $Chcekpwtimes + 1, 600);

            return $this->sendError(1, '修改支付密码失败', 200);
        }
    }

    /**
     * @title  强制修改支付密码（验证成功后调）
     * @return int    error      错误代码：0成功 1错误
     * @return string message    消息提醒
     * @return array  data       返回数据
     * @desc 请求方式：POST <br/>请求示例：v1/PayPassword/powerModifyPw
     */
    public function powerModifyPw()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Paypw  = input('paypw');
        $Pwsalt = rand(1000, 9999);

        // 通过验证缓存，用于修改支付密码
        if (cache('validateUserBank_' . $Userid) != 1) {
            return $this->sendError(1, '要进行相关验证才能改密', 200);
        } else {
            cache('validateUserBank_' . $Userid, 0, 0);
        }

        if (empty($Paypw)) {
            return $this->sendError(1, '支付密码必填', 200);
        } else {
            $Paypw = base64_decode($Paypw);
        }

        if ($Paypw < 100000) {
            return $this->sendError(1, '支付密码必须为6位数字', 200);
        }

        if (empty($Paypw) || empty($Userid)) {
            return $this->sendError(1, '支付密码必填', 200);
        }

        $here_WHERE['id']        = $Userid;
        $here_WHERE['delete_id'] = 0;

        $chcek = db('user')->field('id,paypw,pwsalt')->where($here_WHERE)->find();

        if (empty($chcek)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        $here_UPDATE['paypw']  = md5($Paypw . $Pwsalt);
        $here_UPDATE['pwsalt'] = $Pwsalt;
        $here_UPDATE['pwtime'] = time();

        $res = db('user')->where($here_WHERE)->update($here_UPDATE);

        if ($res) {
            self::addPwLog($Userid, 2);   // 支付密码日志
            return $this->sendSuccess('', '强制修改支付密码成功', 200);
        } else {
            return $this->sendError(1, '强制修改支付密码失败', 200);
        }
    }

    /**
     * @title  添加支付密码
     * @return int    error      错误代码：0成功 1错误
     * @return string message    消息提醒
     * @return array  data       返回数据
     * @desc 请求方式：POST <br/>请求示例：v1/PayPassword/addPw
     */
    public function addPw()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Paypw  = input('paypw');
        $Pwsalt = rand(1000, 9999);

        if (empty($Paypw)) {
            return $this->sendError(1, '支付密码必填', 200);
        } else {
            $Paypw = base64_decode($Paypw);
        }

        if ($Paypw < 100000) {
            return $this->sendError(1, '支付密码必须为6位数字', 200);
        }

        if (empty($Paypw) || empty($Userid)) {
            return $this->sendError(1, '支付密码必填', 200);
        }

        $here_WHERE['id']        = $Userid;
        $here_WHERE['delete_id'] = 0;

        $chcek = db('user')->field('id,paypw,pwsalt')->where($here_WHERE)->find();

        if (empty($chcek)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        if (!empty($chcek['paypw'])) {
            return $this->sendError(1, '支付密码存在，请到修改密码', 200);
        }

        $here_UPDATE['paypw']  = md5($Paypw . $Pwsalt);
        $here_UPDATE['pwsalt'] = $Pwsalt;
        $here_UPDATE['pwtime'] = time();

        $res = db('user')->where($here_WHERE)->update($here_UPDATE);

        if ($res) {
            self::addPwLog($Userid, 1);   // 支付密码日志
            return $this->sendSuccess('', '设置支付密码成功', 200);
        } else {
            return $this->sendError(1, '设置支付密码失败', 200);
        }
    }

    /**
     * @title  添加支付密码（验证实名）
     * @return int    error      错误代码：0成功 1错误
     * @return string message    消息提醒
     * @return array  data       返回数据
     * @desc 请求方式：POST <br/>请求示例：v1/PayPassword/realAddPw
     */
    public function realAddPw()
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Paypw    = input('post.paypw');
        $Realname = input('post.realname');
        $Idcard   = input('post.idcard');
        $Pwsalt   = rand(1000, 9999);

        if (empty($Paypw) || empty($Realname) || empty($Idcard) || empty($Userid)) {
            return $this->sendError(1, '参数不足', 200);
        } else {
            $Paypw = base64_decode($Paypw);
        }

        if ($Paypw < 100000) {
            return $this->sendError(1, '支付密码必须为6位数字', 200);
        }

        $here_WHERE['id']        = $Userid;
        $here_WHERE['delete_id'] = 0;

        $chcek = db('user')->field('id,paypw,pwsalt')->where($here_WHERE)->find();

        if (empty($chcek)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        if (!empty($chcek['paypw'])) {
            return $this->sendError(1, '支付密码存在，请到修改密码', 200);
        }

        // 获取用户的实名数据
        $shiming_WHERE['userid']    = $Userid;
        $shiming_WHERE['delete_id'] = 0;
        $shiming = db('user_authentication')->field(true)->where($shiming_WHERE)->find();

        if (empty($shiming)) {
            return $this->sendError(1, '用户没有实名认证', 200);
        }

        // 姓名
        if ($shiming['realname'] != $Realname) {
            return $this->sendError(1, '验证失败', 200);
            // return $this->sendError(1, '姓名验证失败', 200);
        }

        // 身份证
        if ($shiming['idcard'] != $Idcard) {
            return $this->sendError(1, '验证失败', 200);
            // return $this->sendError(1, '身份证验证失败', 200);
        }

        $here_UPDATE['paypw']  = md5($Paypw . $Pwsalt);
        $here_UPDATE['pwsalt'] = $Pwsalt;
        $here_UPDATE['pwtime'] = time();

        $res = db('user')->where($here_WHERE)->update($here_UPDATE);

        if ($res) {
            self::addPwLog($Userid, 1);   // 支付密码日志
            return $this->sendSuccess('', '设置支付密码成功', 200);
        } else {
            return $this->sendError('', '设置支付密码失败', 200);
        }
    }

    // 写入支付密码日志
    private function addPwLog($Userid, $Type, $Remark = '')
    {
        $here_INSERT['userid'] = $Userid;
        $here_INSERT['type']   = $Type;
        $here_INSERT['ip']     = Request::instance()->ip();

        if (!empty($Remark)) {
            $here_INSERT['remark'] = $Remark;
        }

        Db::name('log_paypw')->insert($here_INSERT);
    }

    /**
     * @title  验证银行卡信息
     * @return int    error      错误代码：0成功 1错误
     * @return string message    消息提醒
     * @return array  data       返回数据
     * @desc 请求方式：POST <br/>请求示例：v1/PayPassword/validateUserBank
     */
    public function validateUserBank()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $data   = input('post.');

        {   // 数据过滤
            $rule = [
                'cardno'        => 'require',
                'account'       => 'require',
                'phone'         => 'require',
                'code'          => 'require',
                'idcard'        => 'require',
            ];

            $msg = [
                'cardno.require'        => '银行卡账号必填',
                'account.require'       => '银行卡户名必填',
                'phone.require'         => '手机号必填',
                'code.require'          => '手机验证码必填',
                'idcard.require'        => '身份证号必填',
            ];

            // 验证字段
            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(1, $validate->getError(), 200);
            }

            if (!preg_match("/^1[34578]{1}\d{9}$/", $data['phone'])) {
                return $this->sendError(1, '手机号码不正确', 200);
            }

            if (!preg_match("/([\d]{4})([\d]{4})([\d]{4})([\d]{4})([\d]{0,})?/", $data['cardno'])) {
                return $this->sendError(1, '银行卡号不合法', 200);
            }

            if (!isCreditNo($data['idcard'])) {
                return $this->sendError(1, '身份证号不合法', 200);
            }
        }

        // 获取用户的实名数据
        $shiming_WHERE['userid']    = $Userid;
        $shiming_WHERE['delete_id'] = 0;
        $shiming = db('user_authentication')->field(true)->where($shiming_WHERE)->find();

        // 获取银行卡数据
        $bankcard = db('user_bank')->field(true)->where('id', $data['cardid'])->find();

// dump($shiming);
// dump($bankcard);
    
        // 姓名
        if ($shiming['realname'] != $data['account']) {
            return $this->sendError(1, '验证失败', 200);
            // return $this->sendError(1, '姓名验证失败', 200);
        }

        // 身份证
        if ($shiming['idcard'] != $data['idcard']) {
            return $this->sendError(1, '验证失败', 200);
            // return $this->sendError(1, '身份证验证失败', 200);
        }

        // 卡号
        if ($bankcard['bank_card'] != $data['cardno']) {
            return $this->sendError(1, '验证失败', 200);
            // return $this->sendError(1, '卡号验证失败', 200);
        }

        // 手机号
        if ($bankcard['bank_card'] != $data['cardno']) {
            return $this->sendError(1, '验证失败', 200);
            // return $this->sendError(1, '手机号验证失败', 200);
        }

        // 通过验证缓存，用于修改支付密码
        cache('validateUserBank_' . $Userid, 1, 600);
        return $this->sendSuccess('', '验证成功', 200);
    }

    /**
     * @title  添加并验证银行卡（能绑定超过2张）
     * @return int    error      错误代码：0成功 1错误
     * @return string message    消息提醒
     * @return array  data       返回数据
     * @desc 请求方式：POST <br/>请求示例：v1/PayPassword/addUserBank
     */
    public function addUserBank()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $data   = input('post.');

        {   // 数据过滤
            $rule = [
                'cardno'        => 'require',
                'account'       => 'require',
                'phone'         => 'require',
                'code'          => 'require',
                'idcard'        => 'require',
            ];

            $msg = [
                'cardno.require'        => '银行卡账号必填',
                'account.require'       => '银行卡户名必填',
                'phone.require'         => '手机号必填',
                'code.require'          => '手机验证码必填',
                'idcard.require'        => '身份证号必填',
            ];

            // 验证字段
            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(1, $validate->getError(), 200);
            }

            if (!preg_match("/^1[34578]{1}\d{9}$/", $data['phone'])) {
                return $this->sendError(1, '手机号码不正确', 200);
            }

            if (!preg_match("/([\d]{4})([\d]{4})([\d]{4})([\d]{4})([\d]{0,})?/", $data['cardno'])) {
                return $this->sendError(1, '银行卡号不合法', 200);
            }

            if (!isCreditNo($data['idcard'])) {
                return $this->sendError(1, '身份证号不合法', 200);
            }

            $carddata = BankCarData::getBankCardData($data['cardno']);
            if ($carddata['iscreditcard'] == 2) {
                return $this->sendError(1, '不能绑信用卡', 200);
            } else {
                $iscreditcard = 1;
            }

            // $carddata = BankCarData::getBankCardData($data['cardno']);
            // if ($carddata['iscreditcard'] == 2) {
            //     $iscreditcard = 2;
            // } else {
            //     $iscreditcard = 1;
            // }
        }

        {   // 判断是否已经绑定的银行卡
            $CheckBindCard = Db::name('user_bank')
                ->field(true)
                ->where('userid', $Userid)
                ->where('is_bind', 1)
                ->where('bank_card', $data['cardno'])
                ->find();

            if (!empty($CheckBindCard)) {
                return $this->sendError(1, '该银行卡已绑定', 200);
            }
        }

        {   // 验证实名制
            // 获取用户的实名数据
            $shiming_WHERE['userid']    = $Userid;
            $shiming_WHERE['delete_id'] = 0;
            $shiming = db('user_authentication')->field(true)->where($shiming_WHERE)->find();

            // 姓名
            if ($shiming['realname'] != $data['account']) {
                return $this->sendError(1, '验证失败', 200);
                // return $this->sendError(1, '姓名验证失败', 200);
            }

            // 身份证
            if ($shiming['idcard'] != $data['idcard']) {
                return $this->sendError(1, '验证失败', 200);
                // return $this->sendError(1, '身份证验证失败', 200);
            }

        }

// dump($shiming);
// die;

        $authParam['orderNum']  = date('YmdHis') . rand(100000, 999999);    // 订单编号 
        $authParam['payerName'] = $data['account'];                         // 真实名字
        $authParam['idCardNo']  = $data['idcard'];                          // 证件号（身份证号）
        $authParam['cardNo']    = $data['cardno'];                          // 银行卡号
        $authParam['phoneNo']   = $data['phone'];                           // 手机号

        $here = new HelibaoInt();                   // 合利宝集成类
        $authRes = $here->verifyAuth($authParam);   // 鉴权结果

// dump($authParam);
// dump($authRes);
// die;

        if (!$authRes) {                            // 参数为空
            // return $this->sendError(1, '非法操作', 200);
            return $this->sendError(1, '验证失败', 200);
        }

        if ($authRes['rt2_retCode'] != '0000') {    // 鉴权不成功
            // return $this->sendError(1, $authRes['rt3_retMsg'], 200);
            return $this->sendError(1, '验证失败', 200);
        }

        Db::startTrans();    // 开启事务

        try {

            // 银行卡编号
            $tempCardNo = BankCarData::getBankCode($data['cardno']);
            switch ($tempCardNo) {
                case 'CMB':                     // 招商
                    $cardNo = 'CMBCHINA';   
                    break;
                case 'SPABANK':                 // 平安  
                    $cardNo = 'PINGAN';   
                    break; 
                case 'PSBC':                    // 邮政储蓄  
                    $cardNo = 'POST';   
                    break; 
                case 'COMM':                    // 交通  
                    $cardNo = 'BOCO';   
                    break;   
                default:
                    $cardNo = $tempCardNo;
                    break;
            }

            // 添加银行卡
            $bankData['userid']       = $Userid;
            $bankData['account_name'] = $data['account'];
            $bankData['bank_card']    = $data['cardno'];
            $bankData['bank_phone']   = $data['phone'];
            $bankData['bank_code']    = $cardNo;
            $bankData['bank_name']    = BankCarData::getBankname();
            $bankData['iscreditcard'] = $iscreditcard;
            if (isset($data['couplet']) && ($data['couplet']> 0)) {
                $bankData['couplet'] = $data['couplet'];
            }
            $bankData['is_bind']      = 1;
            $bankData['bind_time']    = time();

            $insertBankRes = Db::name('user_bank')->insert($bankData);

            if (empty($insertBankRes)) {
                Db::rollback();
                return $this->sendError(1, '验证失败', 200);
            }

            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            // return $this->sendError(1, '系统出错', 200);
            return $this->sendError(1, $e->getMessage(), 200);
        }

        // 通过验证缓存，用于修改支付密码
        cache('validateUserBank_' . $Userid, 1, 600);

        return $this->sendSuccess('', '验证成功', 200);
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'validatePw' => [
                'paypw' => [
                    'name'    => 'paypw', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '支付密码（6位数字，base64编码）', 
                    'range'   => '指定长度: 6',
                ]
            ],
            'modifyPw' => [
                'oldpw' => [
                    'name'    => 'oldpw', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '旧支付密码（6位数字，base64编码）', 
                    'range'   => '指定长度: 6',
                ],
                'paypw' => [
                    'name'    => 'paypw', 
                    'type'    => 'string', 
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '新支付密码（6位数字，base64编码）', 
                    'range'   => '指定长度: 6',
                ]
            ],
            'powerModifyPw' => [
                'paypw' => [
                    'name'    => 'paypw', 
                    'type'    => 'string', 
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '新支付密码（6位数字，base64编码）', 
                    'range'   => '指定长度: 6',
                ]
            ],
            'addPw' => [
                'paypw' => [
                    'name'    => 'paypw', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '新支付密码（6位数字，base64编码）', 
                    'range'   => '指定长度: 6',
                ]
            ],
            'realAddPw' => [
                'paypw' => [
                    'name'    => 'paypw', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '新支付密码（6位数字，base64编码）', 
                    'range'   => '指定长度: 6',
                ],
                'realname' => [
                    'name'    => 'realname', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '真实姓名', 
                    'range'   => '',
                ],
                'idcard' => [
                    'name'    => 'idcard', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '身份证号', 
                    'range'   => '指定长度: 18',
                ]
            ],
            'validateUserBank' => [
                'cardid' => [
                    'name'    => 'cardid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '银行卡id', 
                    'range'   => '',
                ],
                'phone' => [
                  'name'    => 'phone', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '手机号', 
                  'range'   => '指定长度: 11',
                ],
                'code' => [
                  'name'    => 'code', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '验证码', 
                  'range'   => '指定长度: 6',
                ],
                'cardno' => [
                  'name'    => 'cardno', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '银行卡号', 
                  'range'   => '',
                ],
                'account' => [
                  'name'    => 'account', 
                  'type'    => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc'    => '户名（未进行实名制的必填）', 
                  'range'   => '',
                ],
                'idcard' => [
                  'name'    => 'idcard', 
                  'type'    => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc'    => '身份证号（未进行实名制的必填）', 
                  'range'   => '指定长度: 18',
                ],
                'couplet' => [
                  'name'    => 'couplet', 
                  'type'    => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc'    => '联行号（对公账户必填）', 
                  'range'   => '',
                ],
            ],
            'addUserBank' => [
                'phone' => [
                  'name'    => 'phone', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '手机号', 
                  'range'   => '指定长度: 11',
                ],
                'code' => [
                  'name'    => 'code', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '验证码', 
                  'range'   => '指定长度: 6',
                ],
                'cardno' => [
                  'name'    => 'cardno', 
                  'type'    => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc'    => '银行卡号', 
                  'range'   => '',
                ],
                'account' => [
                  'name'    => 'account', 
                  'type'    => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc'    => '户名（未进行实名制的必填）', 
                  'range'   => '',
                ],
                'idcard' => [
                  'name'    => 'idcard', 
                  'type'    => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc'    => '身份证号（未进行实名制的必填）', 
                  'range'   => '指定长度: 18',
                ],
                'couplet' => [
                  'name'    => 'couplet', 
                  'type'    => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc'    => '联行号（对公账户必填）', 
                  'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
    
}
