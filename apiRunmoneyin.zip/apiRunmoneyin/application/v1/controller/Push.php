<?php
/**
 * Created by PhpStorm.
 * User: administered
 * Date: 2018/5/9
 * Time: 9:44
 */

namespace app\v1\controller;

use think\Cache;
use think\Request;
use umeng\UPush;
use think\Config;
use think\Db;

class Push
{
    public $device_tokens;

    public function __construct($uid = null)
    {
        $this->Upush = new UPush(Config::get('UPUSH.APPKEY'), Config::get('UPUSH.AMS'));
        if ($uid) {
            $this->device_tokens = Cache::get('device_tokens' . $uid);
            Request::instance()->header('device_tokens') && Cache::set('device_tokens' . $uid,Request::instance()->header('device_tokens'),0);
        }
    }

    /**
     * 推送单体
     */
    public function sendUnicast($uid = null, $title)
    {
        $uid && $this->device_tokens = Db::name('user')->where(['id' => $uid])->value('device_tokens');

        if (strlen($this->device_tokens) == 64) {
            $re = $this->Upush->sendIOSUnicast($this->device_tokens, $title);
        } else {
            $re = $this->Upush->sendAndroidUnicast($this->device_tokens, $title);
        }
        return $re;
    }


}