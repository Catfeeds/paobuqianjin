<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/04/13 18:50
// +----------------------------------------------------------------------
// | TITLE: 红包接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;
use app\v1\extend\Lredpacket;

/**
 * Class  Index
 * @title 商户接口
 * @url   v1/Redpacket
 * @desc  红包相关接口
 * @version 1.0
 */
class Redpacket extends Base
{
    // 附加方法
    protected $extraActionList = ['receiveRed'];

    /**
     * @title  获取附近红包
     * @return int    error              错误代码：-1失败 0成功 1没有数据
     * @return string message            消息提醒
     * @return array  data               商户对象
     * @return int    userstatus         用户状态数据：0正常|1个数上限|2金额上限
     * @return float  ledredmoney        已领红包的总金额
     * @return array  ledredpacket       已领红包数据
     * @return array  canredpacket       可领红包数据
     * @return int    id                 商户ID
     * @return string logo               商户LOGO
     * @return string name               商户名称
     * @return string hours              营业时间
     * @return string tel                固定电话
     * @return string address            地址
     * @return int    longitude          经度
     * @return float  latitude           纬度
     * @return float  total_money        总金额
     * @return string environment_images 环境图片
     * @return string goods_images       商品图片
     * @return int    distance           距离（单位：米）
     * @return int    red_packet         红包金额
     * @desc 请求方式:GET <br/> 请求示例: v1/Redpacket
     */
    public function index()
    {   
        $data = input('get.');
        $data = array_filter($data);
        $data['userid'] = intval(isset($data['userid'])) ? intval($data['userid']) : intval($this->userId);

        $res = [];  // 返回的数据
        $res['userstatus']   = 0;    // 用户状态数据：0正常|1个数上限|2金额上限
        $res['ledredmoney']  = 0.00; // 已领红包的总金额
        $res['ledredpacket'] = [];   // 已领红包的数据
        $res['canredpacket'] = [];   // 可领红包数据

        {   // 数据过滤
            $rule = [
                'userid'    => 'require|gt:0',
                'longitude' => 'require|between:-180,180',
                'latitude'  => 'require|between:-90,90',
            ];

            $msg = [
                'userid.require'    => '用户ID必填',
                'userid.gt'         => '用户ID必须大于0',
                'longitude.require' => '经度必填',
                'longitude.between' => '经度必须在-180~180之间',
                'latitude.require'  => '纬度必填',
                'latitude.between'  => '纬度必须在-90~90之间',
            ];

            // 验证字段
            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(-1, $validate->getError(), 400);
            }

            $Userid    = intval($data['userid']);       // 用户id
            $Longitude = round($data['longitude'], 6);  // 经度
            $Latitude  = round($data['latitude'], 6);   // 纬度
        }

        {   // 获取用户数据
            $Userdata = Db::name('user')
                ->field('
                    id as userid,nickname,levelid,sex,education,
                    concat_ws("-",birthyear,birthmonth,birthday) as birthday,
                    height,weight,province,city,n_long,n_lat,n_updatetime
                ')
                ->where('id', $data['userid'])
                ->where('delete_id', 0)
                ->find();

            if (empty($Userdata)) {
                return $this->sendError(-1, '用户不存在必填', 400);
            }

            // 获取用户当天步数
            $userstep = Db::name('user_step')
                ->where('create_day', date('Y-m-d'))
                ->where('userid', $data['userid'])
                ->value('step_number');

            if (empty($userstep)) {
                $Userdata['step'] = 0;
            } else {
                $Userdata['step'] = intval($userstep);
            }

            // 计算年龄
            $Userdata['age'] = calcAge($Userdata['birthday']);
        }

        {   // 判断用户领取红包上限
            // 用户今天所有的红包数据 
            $Ledredpacket = Db::name('business_record')
                ->alias('br')
                ->field('red_id,business_id as businessid,issuerid,name,br.money,br.actually,br.longitude,br.latitude,is_receive,create_day')
                ->join('business', 'br.business_id=business.id', 'left')
                ->where('br.userid', $Userdata['userid'])
                ->where('create_day', date('Y-m-d'))
                // ->fetchSql(true)
                ->select();

            // 判断个人是否达到每日个数上限（12个）
            if (count($Ledredpacket) > 12) {
                $res['userstatus'] = 1;   // 用户状态数据：0正常|1个数上限|2金额上限
                // return $this->sendError(1, '已经达到每天个数上限', 200);
            }
  
            // 判断个人是否达到每日金额上限（50元）
            $sum = 0.00;
            foreach ($Ledredpacket as $value) {
                $sum += round($value['actually'], 2);
            }
            unset($value);

            if ($sum > 50.00) {
                $res['userstatus'] = 2;   // 用户状态数据：0正常|1个数上限|2金额上限
                // return $this->sendError(1, '已经达到每天金额上限', 200);
            }

            $res['ledredmoney'] = round($sum, 2) . '';

            if (!empty($Ledredpacket)) {
                $res['ledredpacket'] = $Ledredpacket;
            }

            if ($res['userstatus'] != 0) {
                return $this->sendSuccess($res, 'success', 200);
            }
        }

// dump($Userdata);
// dump($Ledredpacket);
// exit();

        {   // 20公里的直径获取商家
            $scope = calcScope($Latitude, $Longitude, 50000);

            // 查询附近商户
            $map['business.latitude']   = ['between', [$scope['minLat'], $scope['maxLat']]];
            $map['business.longitude']  = ['between', [$scope['minLng'], $scope['maxLng']]];
            // $map['business.delete_id']  = 0;
            $map['redpacket.ok']        = 1;
            $map['redpacket.delete_id'] = 0;
            $map['redpacket.s_time']    = ['<', time()];   // 时间条件
            $map['redpacket.e_time']    = ['>', time()];   // 时间条件

            // 无范围用户
            $mapOr['business.latitude']   = 0;
            $mapOr['business.longitude']  = 0;
            // $mapOr['business.delete_id']  = 0;
            $mapOr['redpacket.delete_id'] = 0;
            $mapOr['redpacket.ok']        = 1;
            $mapOr['redpacket.s_time']    = ['<', time()];   // 时间条件
            $mapOr['redpacket.e_time']    = ['>', time()];   // 时间条件

            // ,tel,addra,address,do_day,s_do_time,e_do_time
            $business = Db::name('redpacket')
                ->alias('redpacket')
                ->field('
                    red_id,businessid,red_name,red_content,step,number,money,sex,
                    age_min,age_max,education,distance,trading_area,s_time,e_time,
                    business.longitude,business.latitude,
                    logo,name
                ')
                ->join('business', 'redpacket.businessid=business.id', 'left')
                ->where(function ($query) use ($map, $mapOr) {
                    $query->where($map);
                    })->whereOr(function ($query) use ($map, $mapOr) {
                        $query->where($mapOr);
                })
                // ->fetchSql(true)
                // ->where('red_id', 1075)
                ->limit(200)
                ->select();

// dump($Userdata);
// dump($business);
// exit();
            // 附近没有红包
            if (empty($business)) {
                return $this->sendError(1, 'Not Found Data', 200);
            } else {
                shuffle($business);
            }
        }

// dump($Userdata);
// dump($Ledredpacket);
// dump($business);
// exit();

        $Canredpacket = [];    // 可领红包数据
        foreach ($business as $key => $value) {
            // 计算商户和客户之间的距离
            $realdistance = intval(calcDistance($Latitude, $Longitude, $value['latitude'], $value['longitude']) * 1000);
            $business[$key]['realdistance'] = $realdistance;

// dump();

            // 判断距离是否符合
            if (($value['distance'] > 0) && ($realdistance > $value['distance'])) {
                unset($business[$key]);
                // echo "<br/>";
                // echo "判断距离是否符合";
                continue;
            }

            // 判断性别是否符合
            if (($value['sex'] > 0) && ($Userdata['sex'] != $value['sex'])) {
                unset($business[$key]);
                // echo "<br/>";
                // echo "判断性别是否符合";
                continue;
            }

            // 判断年龄是否符合
            // if (($value['age_max'] > 0) && ($Userdata['age']!=0) && (($Userdata['age'] < $value['age_min']) || ($Userdata['age'] > $value['age_max']))) {
            if (($value['age_max'] > 0) && (($Userdata['age'] < $value['age_min']) || ($Userdata['age'] > $value['age_max']))) {
                unset($business[$key]);
                // echo "<br/>";
                // echo "判断年龄是否符合";
                continue;
            }

            // // 判断学历是否符合
            // if (($value['education'] > 0) && ($Userdata['education'] != $value['education'])) {
            //     unset($business[$key]);
            //     continue;
            // }
            
            // 判断步数是否符合
            if (($value['step'] > 0) && ($Userdata['step'] < $value['step'])) {
                unset($business[$key]);
                // echo "<br/>";
                // echo "判断步数是否符合";
                continue;
            }

            // 商家今天所有的红包数据 
            $Allbusredpacket = Db::name('business_record')
                ->alias('br')
                ->field(true)
                ->where('business_id', $value['businessid'])
                ->where('red_id', $value['red_id'])
                ->where('create_day', date('Y-m-d'))
                // ->whereTime('create_day', 'today')
                // ->fetchSql(true)
                ->select();

// exit();

            // 判断今天商家是否有红包余量 
            if ((count($Allbusredpacket) > 0)) {
                $Isreceive = array_column($Allbusredpacket, 'is_receive');
                // array_push($Userida, $userid);
                $Isreceive = array_filter($Isreceive);

                if (count($Isreceive) >= count($Allbusredpacket)) {
                    // echo "<br/>";
                    // echo "红包余量没了";
                    unset($business[$key]);
                    continue;
                }
            }

            // 判断今天是否领过该商家红包 
            if ((count($Allbusredpacket) > 0)) {
                $Myreceive = array_column($Allbusredpacket, 'userid');
                // array_push($Userida, $userid);
                $Myreceive = array_filter($Myreceive);

                if ((count($Myreceive) > 0) && (in_array($Userdata['userid'], $Myreceive))) {
                    // echo "<br/>";
                    // echo "领过该商家红包";
                    unset($business[$key]);
                    continue;
                }
            }

            // 只取出4个红包商户
            if (count($Canredpacket) < 4) {
                $Canredpacket[] = $value;
            } else {
                break;
            }

            unset($Allbusredpacket);
        }
        unset($key, $value);

// dump($Userdata);
// dump($Canredpacket);
// $Canredpacket = arraySort($Canredpacket, 'red_id', 'asc');
// dump($Canredpacket);
// exit();

        if (!empty($Canredpacket)) {
            $Canredpacket = arraySort($Canredpacket, 'red_id', 'asc');
            $res['canredpacket'] = $Canredpacket;  // 可领红包数据
        }

        if (empty($res)) {
            return $this->sendError(1, '附近没有可领取的红包', 200);
        } else {
            return $this->sendSuccess($res, 'success', 200);
        }
    }

    /**
     * @title  生成红包（添加红包信息）
     * @return int    error   错误代码：1失败 0成功
     * @return string message 消息提醒
     * @return array  data    返回数组
     * @return int    red_id  红包id
     * @desc 请求方式:POST <br/> 请求示例地址: v1/Redpacket
     */
    public function save()
    {
        $data = input('post.');
        $data['type'] = 2; // 先锁定为商户，后期可能开个人红包（类型：1个人红包|2商户红包）

// dump($data);
// exit();

        $data['userid'] = intval(input('userid')) ? intval(input('userid')) : intval($this->userId);

        {   // 数据过滤
            $rule = [
                'type'           => 'between:1,2',
                'userid'         => 'require|gt:0',
                // 'businessid'  => 'require|gt:0',
                'red_name'       => 'require',
                // 'red_content'    => 'require',
                'step'           => 'require|gt:0',
                // 'number'         => 'require|gt:0.1',
                // 'money'          => 'require|gt:0.1',
                'number'         => 'require|gt:4',
                'money'          => 'require|gt:0.01',
                'day'            => 'require|gt:0',
                // 'sex'            => 'between:0,2',
                // 'age_min'            => 'max:3',
                // 'age_max'            => 'max:3',
                // 'education'          => 'max:3',
                // 's_time'             => 'max:3',
                // 'e_time'             => 'max:3',
                // 'country'            => 'max:3',
                // 'province'           => 'max:3',
                // 'trading_area'       => 'max:3',
                // 'distance'           => 'max:3',
                // 'city'           => 'require',
                // 'city_code'      => 'require',
                // 'county'             => 'max:3',
                // 'village'            => 'max:3',
                // 'remark'             => 'max:3',
            ];

            $msg = [
                'type.between'        => '红包类型必须为1或2',
                'userid.require'      => '用户ID必填',
                'userid.gt'           => '用户ID必大于0',
                'red_name.require'    => '红包名必填',
                // 'red_content.require' => '红包内容必填',
                'step.require'        => '目标步数必填',
                'step.gt'             => '目标步数必大于0',
                'number.require'      => '红包个数必填',
                'number.gt'           => '红包个数不能少于5',
                'money.require'       => '红包总金额必填',
                'money.gt'            => '红包总金额不能少于5',
                'day.require'         => '天数必填',
                'day.gt'              => '天数必需大于0',
                // 'sex.between'         => '性别必须为0、1、2',
            ];

            // $rule = [
            //     'userid'    => 'require|gt:0',
            //     'longitude' => 'require|between:-180,180',
            //     'latitude'  => 'require|between:-90,90',
            // ];

            // $msg = [
            //     'userid.require'    => '用户ID必填',
            //     'userid.gt'         => '用户ID必须大于0',
            //     'longitude.require' => '经度必填',
            //     'longitude.between' => '经度必须在-180~180之间',
            //     'latitude.require'  => '纬度必填',
            //     'latitude.between'  => '纬度必须在-90~90之间',
            // ];

// dump($data);
// exit();
            // 验证字段
            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(1, $validate->getError(), 200);
            }

            if ($data['day'] > 0) {
                $data['s_time'] = strtotime('today');
                $data['e_time'] = strtotime(date("Y-m-d") . " + " . $data['day'] . " day");
            };

            if ($data['money'] < 50) {
                return $this->sendError(1, '每次红包金额不能少于50元', 200);
            }

            $OneRedLimit = $data['money'] / $data['day'] / $data['number'];

            if ($OneRedLimit < 1) {
                return $this->sendError(1, '平均每个红包金额不能小于1元，最少要发' . ($data['number'] * $data['day']) . '元', 200);
            }
            
            $Type = intval($data['type']);
        }

// dump($data);
// exit();

        // 添加创建时间
        $data['create_time'] = time();

        // 判断类型：1个人红包|2商户红包
        if ($Type == 1) {
            return self::addUserRed($data);
        } elseif ($Type == 2) {
            return self::addBusinessRed($data);
        } else {
            return $this->sendError(-1, '红包类型不存在', 400);
        }
    }

    /**
     * @title  生成个人红包（生成红包）（后期可能开个人红包）
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @return array  data    返回数组
     * @return int    red_id  红包id
     */
    private function addUserRed($data)
    {

        dump('生成个人红包（生成红包）（后期可能开个人红包）');

    }

    /**
     * @title  生成商户红包（生成红包）
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @return array  data    返回数组
     * @return int    red_id  红包id
     */
    private function addBusinessRed($data)
    {
        Db::startTrans();    // 开启事务

        try {
            // 如果为空商户为空则自动按红包名生成商户
            if (empty($data['businessid'])) {
                $business_INSERT['type']        = 1;
                $business_INSERT['userid']      = $data['userid'];
                $business_INSERT['name']        = $data['red_name'];
                $business_INSERT['logo']        = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_c.png';
                $business_INSERT['create_time'] = time();
                $Businessid = Db::name('business')->insertGetId($business_INSERT);

                $data['businessid'] = $Businessid;
            } else {
                $check_WHERE['id']        = $data['businessid'];
                $check_WHERE['delete_id'] = 0;
                $check_WHERE['userid']    = $data['userid'];
                $checkBusiness = db('business')->where($check_WHERE)->find();

                if (empty($checkBusiness)) {
                    return $this->sendError(1, '该商户不存在', 200);
                }
            }

            // 添加红包（红包表）
            $Redpacketid = db('redpacket')->insertGetId($data);

            $OneDayMomey = round($data['money'] / $data['day'], 2);
            for ($i=0; $i < $data['day']; $i++) { 
                $OneDayMomeyArray[] = $OneDayMomey;
            }

            $AllDayMomey = array_sum($OneDayMomeyArray);

            if ($AllDayMomey < $data['money']) {
                $OneDayMomeyArray[0] += $data['money'] - $AllDayMomey;
            }

// dump($Redpacketid);
// dump($OneDayMomeyArray);
// dump($AllDayMomey);

            $sign = 0;
            $record_INSERT = [];
            foreach ($OneDayMomeyArray as $k => $v) {
                $Baseredpacket = randRedPacket($v, $data['number']);
// dump($Baseredpacket);
// dump(array_sum($Baseredpacket));
                foreach ($Baseredpacket as $key => $value) {
                    $record_INSERT[$sign]['money']       = $value;
                    $record_INSERT[$sign]['red_id']      = $Redpacketid;
                    $record_INSERT[$sign]['issuerid']    = $data['userid'];
                    $record_INSERT[$sign]['business_id'] = $data['businessid'];
                    $record_INSERT[$sign]['create_time'] = time();
                    $record_INSERT[$sign]['create_day']  = date("Y-m-d", strtotime(date("Y-m-d") . " + " . $k . " day"));

                    ++$sign;
                }
                unset($key, $value, $Baseredpacket);
            }
            unset($k, $v);

// dump($sign);
// dump($Redpacketid);
// dump($Baseredpacket);
// dump($record_INSERT);
// die;
            $record_res = db('business_record')->insertAll($record_INSERT);

            $res['red_id'] = $Redpacketid;

            // 提交事务
            Db::commit();
            return $this->sendSuccess($res, 'success', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(1, $e->getMessage(), 200);
        }
    }

    /**
     * @title  删除红包
     * @return int    error   错误代码：0成功 1失败
     * @return string message 消息提醒
     * @desc 请求方式: delete <br/> 请求示例: v1/Redpacket/121
     */
    public function delete($id)
    {
        $Userid = intval(input('userid')) ? intval(input('userid')) : intval($this->userId);
    }

    /**
     * @title  领取红包
     * @return int    error        错误代码：0失败 1成功
     * @return string message      消息提醒
     * @return array  data         红包数据
     * @return int    allmoney     领取成功金额
     * @return array  result       红包领取后的数据
     * @return int    is_redpacket 红包领取状态：0领取成功|1已被领完|2已领过|3条件不符
     * @return string ms_redpacket 红包状态信息
     * @return int    is_statue    红包状态：0领取成功|1领取失败
     * @desc 请求方式: POST <br/>  请求示例: v1/Redpacket/receiveRed
     */
    public function receiveRed()
    {
        $data = input('post.');
        $data['userid'] = isset($data['userid']) ? intval($data['userid']) : intval($this->userId);

        // 红包辅助类
        $Lredpacket = new Lredpacket();

        {   // 数据过滤
            $rule = [
                'userid'    => 'require|gt:0',
                'redids'    => 'require',
                'longitude' => 'require|between:-180,180',
                'latitude'  => 'require|between:-90,90',
            ];

            $msg = [
                'userid.require'    => '用户ID必填',
                'userid.gt'         => '用户ID必须大于0',
                'redids.require'    => '红包IDS必填',
                'longitude.require' => '经度必填',
                'longitude.between' => '经度必须在-180~180之间',
                'latitude.require'  => '纬度必填',
                'latitude.between'  => '纬度必须在-90~90之间',
            ];

            // 验证字段
            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(-1, $validate->getError(), 400);
            }

            $Userid    = intval($data['userid']);       // 用户id
            $Longitude = round($data['longitude'], 6);  // 经度
            $Latitude  = round($data['latitude'], 6);   // 纬度

            $Redids  = input('post.redids');
            $Redidarray = explode(',', $Redids);
            $Redidarray = array_filter($Redidarray);
            $Redidarray = array_merge($Redidarray);
            sort($Redidarray);
        }

        // 获取用户数据
        $Userdata = $Lredpacket->getUserData($Userid);
        
        // 判断用户领取红包上限
        $chcekUserRedStatus = $Lredpacket->chcekUserRedStatus($Userid);
        if ($chcekUserRedStatus !== true) {
            return $this->sendError(1, $chcekUserRedStatus, 200);
        }

        // 满足条件的红包以及红包记录
        $Conditions = $Lredpacket->getCanLenRed($Redidarray, $Longitude, $Latitude);
        if ($Conditions['status'] !== true) {
            $res['allmoney'] = 0;
            $res['result']   = $Conditions['resdata'];
            return $this->sendSuccess($res, '所有红包领取失败', 200);
        }

        Db::startTrans();    // 开启事务

        try {
            $Conditions = $Lredpacket->getArrangeData($Userid, $Longitude, $Latitude);

// dump($Lredpacket->allRedMoney);
// dump($Lredpacket->record_UPDATE);
// dump($Lredpacket->income_INSERT);
// dump($Lredpacket->income_i_INSERT);
// dump($Lredpacket->bonus_INSERT);
// dump($Lredpacket->user_UPDATE);
// dump($Userdata);
// die;

            // 将红包设置为领取状态,并更新
            foreach ($Lredpacket->record_UPDATE as $key => $value) {
                $record_WHERE = [];
                $record_WHERE['id'] = $value['id'];
                unset($value['id']);
                $red_res[] = Db::name('business_record')->where($record_WHERE)->update($value);
                // $red_res[] = Db::name('business_record')->where($record_WHERE)->lock(true)->update($value);
            }
            unset($key, $value);
// die;
            // 写入用户收益记录，并增加用户收益
            if ($Lredpacket->income_INSERT['allmoney'] > 0) {
                Db::name('income')->insertAll($Lredpacket->income_INSERT['alldata']);
                Db::name('user')->where('id', $Lredpacket->income_INSERT['userid'])->setInc('balance', $Lredpacket->income_INSERT['allmoney']);

                if (count($Lredpacket->user_UPDATE) > 0) {
                    Db::name('user')->where('id', $Lredpacket->income_INSERT['userid'])->update($Lredpacket->user_UPDATE);
                }
            }
// dump(1);
// exit();
            // 写入邀请人收益记录，并增加邀请人收益
            if ($Lredpacket->income_i_INSERT['allmoney'] > 0) {
                Db::name('income')->insertAll($Lredpacket->income_i_INSERT['alldata']);
                Db::name('user')->where('id', $Lredpacket->income_i_INSERT['userid'])->setInc('balance', $Lredpacket->income_i_INSERT['allmoney']);
            }

            // 写入提成记录
            Db::name('inviter_bonus')->insertAll($Lredpacket->bonus_INSERT);

            $res['result']   = $Conditions;
            $res['allmoney'] = round($Lredpacket->allRedMoney, 2);

            // 提交事务
            Db::commit();
            return $this->sendSuccess($res, 'success', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(-1, $e->getMessage(), 400);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
                'longitude' => [
                    'name'    => 'longitude',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '经度',
                    'range'   => ''
                ],
                'latitude' => [
                    'name'    => 'latitude',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '纬度',
                    'range'   => ''
                ],
                'citycode' => [
                    'name'    => 'citycode',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '城市代码',
                    'range'   => ''
                ],
            ],
            'save' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'longitude' => [
                    'name'    => 'longitude',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '经度',
                    'range'   => ''
                ],
                'latitude' => [
                    'name'    => 'latitude',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '纬度',
                    'range'   => ''
                ],
                'number' => [
                    'name'    => 'number',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包个数',
                    'range'   => ''
                ],
                'money' => [
                    'name'    => 'money',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包金额（单位：元，例：5.20）',
                    'range'   => ''
                ],
                'day' => [
                    'name'    => 'day',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '持续时间（单位：天）',
                    'range'   => ''
                ],
                'red_name' => [
                    'name'    => 'red_name',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包名',
                    'range'   => ''
                ],
                'red_content' => [
                    'name'    => 'red_content',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '红包内容',
                    'range'   => ''
                ],
                'sex' => [
                    'name'    => 'sex',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '性别：0不做限制|1男|2女',
                    'range'   => ''
                ],
                'businessid' => [
                    'name'    => 'businessid',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商户id',
                    'range'   => ''
                ],
                'distance' => [
                    'name'    => 'distance',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '距离（单位：米）：为0不做限制',
                    'range'   => ''
                ],
                'step' => [
                    'name'    => 'step',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '目标步数',
                    'range'   => ''
                ],
                'age_min' => [
                    'name'    => 'age_min',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '年龄下限',
                    'range'   => ''
                ],
                'age_max' => [
                    'name'    => 'age_max',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '年龄上限：为0不做限制',
                    'range'   => ''
                ],
                'education' => [
                    'name'    => 'education',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '学历：0不限，1小学，2初中，3高中，4中专，5大专，6本科，7硕士，8博士',
                    'range'   => ''
                ],
                's_time' => [
                    'name'    => 's_time',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '开始时间',
                    'range'   => ''
                ],
                'e_time' => [
                    'name'    => 'e_time',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '结束时间',
                    'range'   => ''
                ],
                'city' => [
                    'name'    => 'city',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '城市',
                    'range'   => ''
                ],
                'city_code' => [
                    'name'    => 'city_code',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '城市代码',
                    'range'   => ''
                ],
                'remark' => [
                    'name'    => 'remark',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '备注',
                    'range'   => ''
                ],
                'trading_area' => [
                    'name'    => 'trading_area',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '商圈',
                    'range'   => ''
                ]
            ],
            'delete' => [
                'redids' => [
                    'name'    => 'redids',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包id字符串（例：2,3,110）',
                    'range'   => ''
                ],
            ],
            'receiveRed' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
                'redids' => [
                    'name'    => 'redids',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包id字符串，例：2,3,110',
                    'range'   => ''
                ],
                'longitude' => [
                    'name'    => 'longitude',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '经度',
                    'range'   => ''
                ],
                'latitude' => [
                    'name'    => 'latitude',
                    'type'    => 'float',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '纬度',
                    'range'   => ''
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}

