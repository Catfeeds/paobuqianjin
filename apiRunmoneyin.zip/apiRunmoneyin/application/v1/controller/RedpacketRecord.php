<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/04/13 18:50
// +----------------------------------------------------------------------
// | TITLE: 红包记录接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;
use app\v1\extend\Lredpacket;

/**
 * Class  Index
 * @title 商户接口
 * @url   v1/RedpacketRecord
 * @desc  红包相关接口
 * @version 1.0
 */
class RedpacketRecord extends Base
{
    // 附加方法
    protected $extraActionList = ['letRedList'];

    /**
     * @title  获取用户发布红包记录
     * @return int    error        错误代码：1失败 0成功
     * @return string message      消息提醒
     * @return array  data         商户对象
     * @return int    red_id       红包id
     * @return int    userid       用户id（发红包者id）
     * @return int    businessid   商户id
     * @return string logo         商户图标
     * @return string name         商户名
     * @return string red_name     红包名
     * @return string red_content  红包内容
     * @return int    number       红包个数
     * @return float  money        红包总金额
     * @return int    sex          性别要求（0无要求，1男，2女）
     * @return int    step         步数要求
     * @return int    age_min      年龄下限
     * @return int    age_max      年龄上限
     * @return int    education    学历限制
     * @return int    distance     距离限制
     * @return string trading_area 商圈
     * @return int    s_time       开始时间
     * @return int    e_time       结束时间
     * @return int    create_time  创建时间
     * @return float  longitude    红包经度
     * @return float  latitude     红包纬度
     * @desc 请求方式:GET <br/> 请求示例: v1/RedpacketRecord?keyword=关键字
     */
    public function index()
    {   
        $Userid   = intval(input('userid')) ? intval(input('userid')) : intval($this->userId);
        $keyword  = input('get.keyword') ? input('get.keyword') : '';                // 关键字
        $page     = input('get.page') ? intval(input('get.page')) : 1;               // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;      // 每页显示数量
        
// dump($Userid);
// dump($keyword);
// dump($page);
// dump($pageSize);
        
        // 查询附近商户
        $map['redpacket.userid']    = $Userid;
        $map['redpacket.ok']        = 1;
        $map['redpacket.delete_id'] = 0;

        $totalCount = Db::name('redpacket')
            ->alias('redpacket')
            ->field('red_id')
            ->join('business', 'redpacket.businessid=business.id', 'left')
            ->where($map)
            ->whereLike('red_name', '%' . $keyword . '%')
            ->count('red_id');

        if (empty($totalCount)) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        // ,tel,addra,address,do_day,s_do_time,e_do_time
        $Reds = Db::name('redpacket')
            ->alias('redpacket')
            ->field('
                red_id,redpacket.userid as userid,red_name,red_content,number,money,sex,step,
                age_min,age_max,education,distance,trading_area,s_time,e_time,redpacket.create_time,
                rlongitude,rlatitude,
                businessid,logo,name
            ')
            ->join('business', 'redpacket.businessid=business.id', 'left')
            // ->where(function ($query) use ($map, $mapOr) {
            //     $query->where($map);
            //     })->whereOr(function ($query) use ($map, $mapOr) {
            //         $query->where($mapOr);
            // })
            // ->fetchSql(true)
            ->where($map)
            ->whereLike('red_name','%'.$keyword.'%')
            ->order('redpacket.create_time desc')
            ->page($page, $pageSize)
            ->select();

// dump($map);
// dump($Reds);
// exit();

        $retData = returnData($page, $pageSize, $totalCount, $Reds);

        if (empty($retData)) {
            return $this->sendError(1, '没有发布红包记录', 200);
        } else {
            return $this->sendSuccess($retData, 'success', 200);
        }
    }

    /**
     * @title  获取红包记录详情
     * @return int    error   错误代码：1失败 0成功
     * @return string message 消息提醒
     * @return array  data    返回数组
     * @return int    red_id  红包id
     * @desc 请求方式:GET <br/> 请求示例地址: v1/RedpacketRecord/1(红包id)
     */
    public function read($id)
    {
        $Userid = intval(isset($data['userid'])) ? intval($data['userid']) : intval($this->userId);
        $Redid  = intval($id) ? intval($id) : 0;

        if (empty($Redid)) {
            return $this->sendError(1, '红包id必填', 200);
        }

        $res = Db::name('redpacket')
            ->alias('redpacket')
            ->field('
                red_id,redpacket.userid as userid,red_name,red_content,number,money,sex,step,
                age_min,age_max,education,distance,trading_area,s_time,e_time,redpacket.create_time,
                rlongitude,rlatitude,
                businessid,logo,name
            ')
            ->join('business', 'redpacket.businessid=business.id', 'left')
            ->where('redpacket.red_id', $Redid)
            // ->where('redpacket.userid', $Userid)
            ->find();

        if (empty($res)) {
            return $this->sendError(1, 'error', 200);
        } else {
            return $this->sendSuccess($res, 'success', 200);
        }
    }

    /**
     * @title  获取红包领取记录
     * @return int    error   错误代码：0成功 1失败
     * @return string message 消息提醒
     * @return array  data    返回数组
     * @return int    red_id  红包id
     * @desc 请求方式:GET <br/> 请求示例地址: v1/RedpacketRecord/letRedList
     */
    public function letRedList()
    {
        $Userid   = intval(isset($data['userid'])) ? intval($data['userid']) : intval($this->userId);
        $Redid    = intval(input('redid'));
        $page     = input('get.page') ? intval(input('get.page')) : 1;               // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;      // 每页显示数量
        
        if (empty($Redid)) {
            return $this->sendError(1, '红包id必填', 200);
        }

        $totalCount = Db::name('business_record')
            ->alias('bsr')
            ->field(true)
            ->where('bsr.red_id', $Redid)
            ->count();

        if (empty($totalCount)) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        $res = Db::name('business_record')
            ->alias('bsr')
            ->field('
                bsr.id,bsr.business_id,bsr.issuerid,bsr.red_id,bsr.userid,bsr.money,
                bsr.actually,bsr.ratio,bsr.is_receive,bsr.is_time,
                bsr.create_day,bsr.longitude,bsr.latitude,bsr.ok,bsr.ok_time,
                bsr.update_time,bsr.create_time,bsr.devices_num,
                user.nickname as usname,
                business.name as busname,
                redpacket.red_name as redname
            ')
            ->join('user', 'user.id=bsr.userid', 'left')
            ->join('business', 'business.id=bsr.business_id', 'left')
            ->join('redpacket', 'redpacket.red_id=bsr.red_id', 'left')
            ->where('bsr.red_id', $Redid)
            ->page($page, $pageSize)
            ->order('bsr.is_time desc, bsr.id desc')
            ->select();

        $retData = returnData($page, $pageSize, $totalCount, $res);

        if (empty($retData)) {
            return $this->sendError(1, '没有红包详细记录', 200);
        } else {
            return $this->sendSuccess($retData, 'success', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'keyword'   => [
                    'name'    => 'keyword',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '关键词',
                    'range'   => ''
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'read' => [
                'redid'   => [
                    'name'    => 'redid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包ID',
                    'range'   => ''
                ],
                // 'userid'   => [
                //     'name'    => 'userid',
                //     'type'    => 'int',
                //     'require' => 'false',
                //     'default' => '',
                //     'desc'    => '用户ID（最好别填）',
                //     'range'   => ''
                // ],
            ],
            'letRedList' => [
                'redid'   => [
                    'name'    => 'redid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '红包ID',
                    'range'   => ''
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
                // 'userid'   => [
                //     'name'    => 'userid',
                //     'type'    => 'int',
                //     'require' => 'false',
                //     'default' => '',
                //     'desc'    => '用户ID（最好别填）',
                //     'range'   => ''
                // ],
            ],
        
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
