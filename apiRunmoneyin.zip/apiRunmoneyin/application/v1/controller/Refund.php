<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:30
// +----------------------------------------------------------------------
// | TITLE: 定时退款处理接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;

/**
 * Class  Refund
 * @title 将各种到期没被领取的资金回退到用户余额中
 * @url   v1/Refund
 * @desc  将没领完的钱退到用户钱包
 * @version 1.0
 */
class Refund extends Base
{
    // 跳过验证方法
    protected $skipAuthActionList = ['refundTask', 'refundRedpacket', 'vipOverdue'];

    // 附加方法
    protected $extraActionList = ['refundTask', 'refundRedpacket', 'vipOverdue'];

    public function __construct()
    {
        // self::checkTime();
    }

    /**
     * @title  将未完成任务金额退回用户余额中
     * @author wensen 2018-03-23
     * @return int    是否成功: 1失败|0成功
     * @desc 请求方式: get <br/> 请求示例: v1/Refund/refundTask
     */
    public function refundTask()
    {   
        {   // 查询需要退款数据
            $task_WHERE['tr.ok']                = 1;
            // $task_WHERE['ts.ok']                = 1;
            $task_WHERE['tr.delete_id']         = 0;
            // $task_WHERE['ts.delete_id']         = 0;
            $task_WHERE['tr.is_receive']        = ['<>', 2];
            $task_WHERE['tr.activity_end_time'] = ['<', time()];

            // 获取以前的没退款的任务
            $user_task = Db::name('task_record')
                ->alias('tr')
                // ->field(true)
                ->field('
                    tr.id as tcid,
                    tr.task_no,
                    tr.amount,
                    tr.activity_start_time,
                    tr.activity_end_time,
                    tr.is_receive,
                    tr.userid as tuserid,
                    ts.userid as userid
                ')
                ->join('task ts', 'ts.id=tr.taskid', 'left')
                ->where($task_WHERE)
                ->select();

            if (empty($user_task)) {
                return $this->sendError(1, 'Not Found Data', 200);
            }
        }

// dump($user_task_ids);
// dump($task_WHERE);
// dump($user_task);
// exit();
        
        Db::startTrans();    // 开启事务

        foreach ($user_task as $key => $value) {
            // 将余额加到用户余额中
            $user_WHERE['id'] = $value['userid'];
            $user_res[$key] = Db::name('user')
                ->where($user_WHERE)
                ->setInc('balance', $value['amount']);

// dump($user_WHERE);

            if (empty($user_res[$key])) {
                Db::rollback();    // 回滚事务
                return $this->sendError(1, '修改用户余额失败', 200);
            }

            // 添加收益记录
            $income_INSERT['userid']      = $value['userid'];
            $income_INSERT['typeid']      = 6;
            $income_INSERT['amount']      = $value['amount'];
            $income_INSERT['create_time'] = time();
            $income_INSERT['source_id']   = $value['tcid'];
            $income_res[$key] = Db::name('income')->insertGetId($income_INSERT);

            //写入到订单记录  做明细统计
            $order_INSERT['userid']         = $income_INSERT['userid'];
            $order_INSERT['order_type']     = 5;//退款订单
            $order_INSERT['payment_type']   = 5;//任务退款
            $order_INSERT['status']         = 1;//完成退款
            $order_INSERT['order_no']       = build_accept_no('order','order_no');//生成唯一编号
            $order_INSERT['total_fee']      = $income_INSERT['amount'];
            $order_INSERT['create_time']    = $income_INSERT['create_time'];
            $order_INSERT['body']           = $income_INSERT['source_id'];//记录退款的任务记录id
            $order_res[$key] = Db::name('order')->insertGetId($order_INSERT);
            //必须同时成功才能
            if (empty($income_res[$key])||empty($order_res[$key])) {
                Db::rollback();    // 回滚事务
                return $this->sendError(1, '添加收益记录失败', 200);
            }

            unset($user_WHERE, $income_INSERT);
        }
        unset($key, $value);

        $user_task_ids = array_column($user_task, 'tcid');
        $user_task_ids = array_filter($user_task_ids);
        sort($user_task_ids);
        $user_task_ids = implode(',', $user_task_ids);

        // 将任务设置成退款状态
        $task_record_UPDATE = Db::name('task_record')
            ->where('id', 'in', $user_task_ids)
            // ->fetchSql(true)
            ->update([
                'is_refund'   => 1,
                'refund_time' => time(),
            ]);

        // // 退款记录（退款记录表）
        // $refund_INSERT['type']   = 2;
        // $refund_INSERT['money']  = $Sum;
        // $refund_INSERT['allsum'] = count($Resback);
        // $refund = Db::name('log_refund')->insert($refund_INSERT);

        if (empty($task_record_UPDATE)) {
            Db::rollback();    // 回滚事务
            return $this->sendError(1, '修改用户任务退款记录失败', 200);
        }

        // Db::rollback();    // 回滚事务
        Db::commit();    // 提交事务

        return $this->sendError(0, '任务金额退回成功', 200);
    }

    /**
     * @title  将未领取的商户红包退回用户余额中
     * @author wensen 2018-06-01
     * @return int    是否成功: 1失败|0成功
     * @desc 请求方式: get <br/> 请求示例: v1/Refund/refundRedpacket
     */
    public function refundRedpacket()
    {   
        $here_WHERE['is_receive'] = 0;
        $here_WHERE['ok']         = 1;
        // $here_WHERE['create_day'] = date('Y-m-d');
        $here_WHERE['create_day'] = ['<', date('Y-m-d')];
        
        // 获取今天以前的没被领取的红包
        $reds = Db::name('business_record')
            ->field(true)
            ->where($here_WHERE)
            ->select();

        if (empty($reds)) {
            return $this->sendError(1, '没有需要退款的红包', 200);
        }

        
        $Userrefund = [];  // 计算需要退款的人员（userid => money）
        $incomefund = [];  // 计算需要退款的红包（red_id => money）
        $Sum        = 0.00;
        foreach ($reds as $key => $value) {
            $Userrefund[$value['issuerid']] = (isset($Userrefund[$value['issuerid']]) ? $Userrefund[$value['issuerid']] : 0) + $value['money'];
            $incomefund[$value['red_id']]['m'] = (isset($incomefund[$value['red_id']]['m'] ) ? $incomefund[$value['red_id']]['m'] : 0) + $value['money'];
            $incomefund[$value['red_id']]['u'] = $value['issuerid'];
            $Sum += $value['money'];
        }
        unset($key, $value);

// dump($Userrefund);
// dump($incomefund);
// dump($Sum);
// dump(array_sum($Userrefund));
// // dump(array_sum($incomefund));
// // dump(count($reds));
// // dump(($reds));
// die;

        if ((count($Userrefund) <= 0) && (count($incomefund) <= 0)) {
            return $this->sendError(1, '退款金额为0', 200);
        }

        Db::startTrans();

        try {
            // 退款商家红包标记
            $business_record_UPDATE['is_receive'] = 2;
            $business_record_UPDATE['is_time']    = time();

            $Updatered = Db::name('business_record')
                ->field(true)
                ->where($here_WHERE)
                ->update($business_record_UPDATE);

            // 将金额退回到用户余额（用户表）
            foreach ($Userrefund as $key => $value) {
                $Resback[] = Db::name('user')->where('id', $key)->setInc('balance', $value);
            }
            unset($key, $value);

            // 退款收益记录（收益记录表）
            $sign = 0;
            foreach ($incomefund as $key => $value) {
                $income_INSERT[$sign]['userid']      = $value['u'];
                $income_INSERT[$sign]['typeid']      = 8;
                $income_INSERT[$sign]['amount']      = $value['m'];
                $income_INSERT[$sign]['create_time'] = time();
                $income_INSERT[$sign]['source_id']   = $key;

                ++$sign;
            }

            $resincome = Db::name('income')->insertAll($income_INSERT);

// dump($Sum);
// dump($signs);
// dump($income_INSERT);
// dump($Updatered);
// dump($Resback);
// dump($refund);
// die;
            
            // 退款记录（退款记录表）
            $refund_INSERT['type']   = 2;
            $refund_INSERT['money']  = $Sum;
            $refund_INSERT['allsum'] = count($Resback);
            
            $refund = Db::name('log_refund')->insert($refund_INSERT);

            Db::commit();
            return $this->sendSuccess(0, '红包退回成功', 200);
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(1, '红包退回失败', 200);
        }
    }

    /**
     * @title  将过期的会员处理
     * @author wensen 2018-05-28
     * @return int    是否成功: 1失败|0成功
     * @desc 请求方式: get <br/> 请求示例: v1/Refund/vipOverdue
     */
    public function vipOverdue()
    {   
        // $Etime = strtotime('today + 1day');
        $Etime = strtotime('today');

        $vip_WHERE['uvr.end_time']  = ['<', $Etime];
        $vip_WHERE['uvr.ok']        = 1;
        $vip_WHERE['uvr.delete_id'] = 0;
        $vip_WHERE['uvr.rback']     = 0;

        $vip = Db::name('user_vip_record')
            ->alias('uvr')
            ->field('
                uvr.vip_id,uvr.userid,uvr.create_day,uvr.create_time,uvr.end_time,uvr.delete_id,uvr.ok,uvr.rback,
                user.vip
            ')
            ->join('user', 'user.id=uvr.userid')
            ->where($vip_WHERE)
            // ->group('userid')
            ->select();

        if (empty($vip)) {
            return $this->sendError(1, '没有过期的会员需要处理', 200);
        }

        try {
            foreach ($vip as $key => $value) {
                if ($value['vip'] == 0) {
                    Db::name('user_vip_record')->where('vip_id', $value['vip_id'])->update(['rback' => 1]);
                } elseif ($value['vip'] == 1) {
                    $lastvip = Db::name('user_vip_record')->field(true)->where('userid', $value['userid'])->order('vip_id desc')->find();

                    if ($lastvip['end_time'] > $value['end_time']) {
                        Db::name('user_vip_record')->where('vip_id', $value['vip_id'])->update(['rback' => 1]);
                    } else {
                        Db::name('user_vip_record')->where('vip_id', $value['vip_id'])->update(['rback' => 1]);

                        Db::name('user')->where('id', $value['userid'])->update(['vip' => 0]);
                    }
                }
            }
            unset($key, $value);

            // 退款记录（退款记录表）
            $refund_INSERT['type'] = 3;
            $refund_INSERT['allsum'] = count($vip);
            $refund = Db::name('log_refund')->insert($refund_INSERT);

            Db::commit();
            return $this->sendSuccess(0, 'vip处理成功', 200);
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(1, 'vip处理失败', 200);
        }
    }

    /**
     * @title  将过期的商户会员处理
     * @author wensen 2018-05-28
     * @return int    是否成功: 1失败|0成功
     * @desc 请求方式: get <br/> 请求示例: v1/Refund/vipOverdue
     */
    public function cvipOverdue()
    {   
        // $Etime = strtotime('today + 1day');
        $Etime = strtotime('today');

        $vip_WHERE['uvr.end_time']  = ['<', $Etime];
        $vip_WHERE['uvr.ok']        = 1;
        $vip_WHERE['uvr.delete_id'] = 0;
        $vip_WHERE['uvr.rback']     = 0;

        $cvip = Db::name('user_vipcus_record')
            ->alias('uvr')
            ->field('
                uvr.cvip_id,uvr.userid,uvr.create_day,uvr.create_time,uvr.end_time,uvr.delete_id,uvr.ok,uvr.rback,
                user.cusvip
            ')
            ->join('user', 'user.id=uvr.userid')
            ->where($vip_WHERE)
            // ->group('userid')
            ->select();

        if (empty($cvip)) {
            return $this->sendError(1, '没有过期的商户会员需要处理', 200);
        }

// dump($cvip);
// die;

        try {
            foreach ($cvip as $key => $value) {
                if ($value['cusvip'] == 0) {
                    Db::name('user_vipcus_record')->where('cvip_id', $value['cvip_id'])->update(['rback' => 1]);
                } elseif ($value['cusvip'] == 1) {
                    $lastvip = Db::name('user_vipcus_record')->field(true)->where('userid', $value['userid'])->order('cvip_id desc')->find();

                    if ($lastvip['end_time'] > $value['end_time']) {
                        Db::name('user_vipcus_record')->where('cvip_id', $value['cvip_id'])->update(['rback' => 1]);
                    } else {
                        Db::name('user_vipcus_record')->where('cvip_id', $value['cvip_id'])->update(['rback' => 1]);

                        Db::name('user')->where('id', $value['userid'])->update(['cusvip' => 0]);
                    }
                }
            }
            unset($key, $value);

            // 退款记录（退款记录表）
            $refund_INSERT['type'] = 4;
            $refund_INSERT['allsum'] = count($cvip);
            $refund = Db::name('log_refund')->insert($refund_INSERT);

            Db::commit();
            return $this->sendSuccess(0, '商户会员处理成功', 200);
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(1, '商户会员处理失败', 200);
        }
    }

    // 检测时间
    private function checkTime()
    {
        $now_hour = intval(date('G'));  // 时
        $now_min  = intval(date('i'));  // 分

        if ($now_hour != 0) {
            exit("敢问，您是，何方神经？");
        }

        if (($now_min < 0) || ($now_min > 30)) {
            exit("敢问，您是，何方神经？");
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'refundTask' => [
                'adminid' => [
                    'name'    => 'adminid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '操作者id', 
                    'range'   => '',
                ],
            ],
            'refundRedpacket' => [
                'adminid' => [
                    'name'    => 'adminid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '操作者id', 
                    'range'   => '',
                ],
            ],
            'vipOverdue' => [
                'adminid' => [
                    'name'    => 'adminid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '操作者id', 
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
