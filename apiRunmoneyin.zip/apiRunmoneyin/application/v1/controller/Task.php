<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:30
// +----------------------------------------------------------------------
// | TITLE: 任务接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;
use reward\CreateReward;
use redpacket\OptionDTO;
use redpacket\RedPackageBuilder;

/**
 * Class  Index
 * @title 任务接口
 * @url   v1/Task
 * @desc  任务相关接口
 * @version 1.0
 * @readme
 */
class Task extends Base
{
    // 附加方法
    protected $extraActionList = [];
    
    protected $rule = [
        'userid'        => 'require|number',
        'to_userid'     => 'require',
        'target_step'   => 'require|number',
        'reward_amount' => 'require|number',
        'task_days'     => 'require|number',
    ];

    protected $msg = [
        'userid.require'        => '用户ID必填',
        'userid.number'         => '用户ID只能是数字',
        'to_userid.require'     => '领取人ID必填',
        'target_step.require'   => '目标步数必填',
        'target_step.number'    => '目标步数只能是数字',
        'reward_amount.require' => '奖励金额必填',
        'reward_amount.number'  => '奖励金额只能是数字',
        'task_days.require'     => '任务天数必填',
        'task_days.number'      => '任务天数只能是数字',
    ];
    
    /**
     * @title 获取我发布的任务/任务记录
     * @return int    error       错误代码 0成功 1失败
     * @return string message     消息提醒
     * @return object data        任务对象
     * @return int    id          任务id
     * @return string task_name   任务名称
     * @return int    task_days   任务天数
     * @return int    auserid     发布人id
     * @return string anickname   发布人昵称
     * @return int    to_userid   接收人ID
     * @return string nickname    接收人昵称
     * @return int    create_time 创建时间
     * @return array  unfinished  未完成（与其他相同）
     * @return array  finished    已完成（与其他相同）
     * @return array  waitfor     未来几天的任务（与其他相同）
     * @return int    days        天数（其他数组的字段）
     * @return float  amount      金额（其他数组的字段）
     * @desc 请求方式: GET 请求地址: v1/Task?action=release&userid=1
     */
    public function index()
    {
        $data   = input('get.');
        $action = isset($data['action']) ? $data['action'] : '';
        // $userid = isset($data['userid']) ? $data['userid'] : 0;
        $userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        if (!$userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        $page     = isset($data['page']) ? intval($data['page']) : 1;            // 当前分页
        $pageSize = isset($data['pagesize']) ? intval($data['pagesize']) : 10;   // 当前条数

        // 我发布的的任务
        if ($action == 'release') {
            $map = array();
            $map['userid']   = $userid;
            $map['end_time'] = ['>', time()];
            $map['ok']       = 1;

            $totalCount = Db::name('task')
                ->field('id,task_name,task_days')
                ->where($map)
                ->count();

            $task = Db::name('task')
                ->alias('task')
                ->field('
                    task.id,task.task_name,task.task_days,
                    task.userid as auserid,a.nickname as anickname,
                    task.to_userid,t.nickname,task.create_time
                ')
                ->join('user a','task.userid=a.id')
                ->join('user t','task.to_userid=t.id')
                ->where($map)
                ->order('task.create_time desc')
                ->page($page, $pageSize)
                ->select();

            foreach ($task as $key => $value) {
                if (!empty($value['create_time'])) {
                    $task[$key]['date'] = date('Y-m-d H:i', $value['create_time']);
                }
            }
            unset($key, $value);

            $retData = returnData($page, $pageSize, $totalCount, $task);    
// dump($totalCount);
// dump($task);
// exit();
        } else if ($action == 'record') {    // 我的任务记录
            $map = array();
            $map['userid'] = $userid;
            $map['ok']     = 1;
            $map['end_time'] = ['<',time()];

            $totalCount = Db::name('task')
                ->field('id,task_name,target_step,reward_amount,task_days,create_time')
                ->where($map)
                ->count();

            // 历史任务
            $task = Db::name('task')
                ->alias('task')
                ->join('user','user.id = task.to_userid')
                ->field('
                    task.id,
                    task.task_name,
                    task.to_userid,
                    user.nickname,
                    task.task_days,
                    task.create_time
                ')
                ->where($map)
                ->order('task.create_time desc')
                ->page($page,$pageSize)
                ->select();

            if (empty($task)) {
                return $this->sendError(1, 'Not Found Data', 200);
            }
            
// dump($map);
// dump($totalCount);
// dump($task);
// die;
            // 达标天数
            foreach ($task as $key => $value) {
                $taskid = $value['id'];

                // // 未达标天数和金额 
                // $task[$key]['unfinished']['days'] = Db::name('task_record')
                //     ->alias('task_record')
                //     ->join('task','task.id = task_record.taskid')
                //     ->where([
                //         'task_record.taskid' => $taskid,
                //         'task_record.is_receive' => ['in','0,1']
                //     ])
                //     ->count();

                // $task[$key]['unfinished']['amount'] = Db::name('task_record')
                //     ->alias('task_record')
                //     ->join('task','task.id = task_record.taskid')
                //     ->where([
                //         'task_record.taskid' => $taskid,
                //         'task_record.is_receive' => ['in','0,1']
                //     ])
                //     ->sum('task.reward_amount');

                // // 达标天数和金额
                // $to_userid = $value['to_userid'];
                // $task[$key]['finished']['days'] = Db::name('task_record')
                //     ->alias('task_record')
                //     ->join('task','task.id = task_record.taskid')
                //     ->where([
                //         'task_record.taskid' => $taskid,
                //         'task_record.is_receive'=>2
                //     ])
                //     ->count();
                
                // $task[$key]['finished']['amount'] = Db::name('task_record')
                //     ->alias('task_record')
                //     ->join('task','task.id = task_record.taskid')
                //     ->where([
                //         'task_record.taskid' => $taskid,
                //         'task_record.is_receive'=>2
                //     ])
                //     ->sum('task.reward_amount');

                // if (!empty($value['create_time'])) {
                //     $task[$key]['date'] = date('Y-m-d H:i', $value['create_time']);
                // }
                
                // 未达标天数和金额 
                $Alltaskdata = Db::name('task_record')
                    ->alias('task_record')
                    ->field('
                        task_record.id,task_record.task_no,taskid,
                        task_record.userid,task_record.amount,
                        activity_start_time,activity_end_time,
                        task_record.is_receive,
                        task_record.ok,
                        task_record.is_refund
                    ')
                    ->join('task','task.id = task_record.taskid')
                    ->where('task_record.taskid', $taskid)
                    // ->where('task.end_time', '<=', time())
                    ->where('task_record.delete_id', 0)
                    ->where('task_record.ok', 1)
                    ->select();

// dump(strtotime('today'));
// dump($Alltaskdata);
// die;
            
                $task[$key]['unfinished']['days']   = 0;
                $task[$key]['unfinished']['amount'] = 0.00;

                $task[$key]['finished']['days']     = 0;
                $task[$key]['finished']['amount']   = 0.00;

                $task[$key]['waitfor']['days']      = 0;
                $task[$key]['waitfor']['amount']    = 0.00;

                foreach ($Alltaskdata as $k => $v) {
                    // 未完成的
                    if (($v['activity_start_time'] <= strtotime('today')) && (($v['is_receive'] == 0) || ($v['is_receive'] == 1))) {
                        $task[$key]['unfinished']['days']   += 1;
                        $task[$key]['unfinished']['amount'] += $v['amount'];
                    }

                    // 已经领取奖励的
                    if (($v['activity_start_time'] <= strtotime('today')) && ($v['is_receive'] == 2)) {
                        $task[$key]['finished']['days']   += 1;
                        $task[$key]['finished']['amount'] += $v['amount'];
                    }

                    // 未来几天的任务
                    if (($v['activity_start_time'] > strtotime('today')) && (($v['is_receive'] == 0) || ($v['is_receive'] == 1))) {
                        $task[$key]['waitfor']['days']   += 1;
                        $task[$key]['waitfor']['amount'] += $v['amount'];
                    }

                    if (isset($task[$key]['unfinished']['amount'])) {
                        $task[$key]['unfinished']['amount'] = round($task[$key]['unfinished']['amount'], 2) . '';
                    }

                    if (isset($task[$key]['finished']['amount'])) {
                        $task[$key]['finished']['amount'] = round($task[$key]['finished']['amount'], 2) . '';
                    }

                    if (isset($task[$key]['waitfor']['amount'])) {
                        $task[$key]['waitfor']['amount'] = round($task[$key]['waitfor']['amount'], 2) . '';
                    }
                }

                if (!empty($value['create_time'])) {
                    $task[$key]['date'] = date('Y-m-d H:i', $value['create_time']);
                }
                
                unset($k, $v, $Alltaskdata);
            }
            unset($key, $value);

            $retData = returnData($page, $pageSize, $totalCount, $task);
        } else {
            return $this->sendError(1, 'Not found action', 200);
        }

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }

    /**
     * @title  发布任务
     * @return int     error   错误代码：0成功 1失败
     * @return string  message 消息提醒
     * @return array   data    返回数据
     * @return taskid  array   生成的任务id数组
     * @return task_no string  生成的任务编号
     * @desc 请求方式: POST 请求地址: v1/Task
     */
    public function save()
    {
        {   // 数据处理
            $data = input('post.');
            $data['userid'] = intval(isset($data['userid'])) ? intval($data['userid']) : intval($this->userId);

            $rule = [
                'userid'        => 'require|gt:0',
                'to_userid'     => 'require',
                'target_step'   => 'require|number',
                'reward_amount' => 'require|number',
                'task_days'     => 'require|number|lt:365',
            ];

            $msg = [
                'userid.require'        => '用户ID必填',
                'userid.gt'             => '用户ID必须大于0',
                'to_userid.require'     => '领取人ID必填',
                'target_step.require'   => '目标步数必填',
                'target_step.number'    => '目标步数只能是数字',
                'reward_amount.require' => '奖励金额必填',
                'reward_amount.number'  => '奖励金额只能是数字',
                'task_days.require'     => '任务天数必填',
                'task_days.number'      => '任务天数只能是数字',
                'task_days.lt'          => '任务天数不能大于365天',
            ];

            // 验证字段
            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(1, $validate->getError(), 200);
            }

            $sameDay = strtotime('today');   // 当日时间戳开始
            $nextDay = $sameDay + 86400 - 1; // 当日时间戳结束
        }

        // $data['reward_amount'] / $data['task_days'] / $data['to_userid'];

        $to_userid_array  = explode(',', $data['to_userid']);    // 字符串切割成数组
        $to_userid_array  = array_filter($to_userid_array);      // 过滤空数组
        $to_userid_string = implode(',', $to_userid_array);

        $task_no = date("YmdHis") . rand(1000, 9999);            // 18位的任务编号

        if (in_array($data['userid'], $to_userid_array)) {
            return $this->sendError(1, '不能给自己派发任务', 200);
        }

        $NowBeseMomey = $data['reward_amount'] / $data['task_days'] / count($to_userid_array);

        if (($NowBeseMomey < 1) || ($NowBeseMomey > 200)) {
            return $this->sendError(1, '平均每日没人金额为1元至200元', 200);
        }

        // 判断任务是否完成
        $old_task = Db::name('task')
            ->where([
                'userid'    => $data['userid'], 
                'to_userid' => ['in', $to_userid_string], 
                'end_time'  => ['>', time()],
                'ok'        => 1,
            ])
            // ->fetchSql(true)
            ->select();

// dump($data);
// dump($NowBeseMomey);
// dump($old_task);
// die;

        if (count($old_task) > 0) {
            return $this->sendError(1, '任务未完成, 不能重复派发任务!', 200);
        }

        $task_rule = '达标即可获得红包奖励，未达标者无奖励';
        $task_ios_desc = '
            <p>
                ①运动数据以跑步钱进的APP为准；
            </p>
            <p>
                ②任务每天晚上12点重置，未领取的红包退回到派发人账户；
            </p>
            <p>
                ③若任务领取人未领取任务及奖励，属用户自主行为，与跑步钱进无关；
            </p>
            <p>
                ④此活动由跑步钱进举办，与苹果公司无关；
            </p>
        ';

        $task_desc = '
            <p>
                ①运动数据以跑步钱进的APP为准；
            </p>
            <p>
                ②任务每天晚上12点重置，未领取的红包退回到派发人账户；
            </p>
            <p>
                ③若任务领取人未领取任务及奖励，属用户自主行为，与跑步钱进无关；
            </p>
            <p>
                ④此活动由跑步钱进举办；
            </p>
        ';

        $OneManMomey = round($data['reward_amount'] / count($to_userid_array), 2);
        for ($i=0; $i < count($to_userid_array); $i++) { 
            $OneManMomeyArray[] = $OneManMomey;
        }

        $AllDayMomey = array_sum($OneManMomeyArray);

        if ($AllDayMomey < $data['reward_amount']) {
            $OneManMomeyArray[0] += $data['reward_amount'] - $AllDayMomey;
        } elseif ($AllDayMomey > $data['reward_amount']) {
            $OneManMomeyArray[0] -= $AllDayMomey - $data['reward_amount'];
        }

// dump($OneManMomey);
// dump($AllDayMomey);
// dump($OneManMomeyArray);
// die;

        Db::startTrans();    // 开启事务

        try {
            $task_record_INSERT = [];   // 插入新的任务红包
            foreach ($to_userid_array as $key => $value) {
                // 创建任务
                $task_INSERT = array(
                    'task_no'       => $task_no,
                    'userid'        => $data['userid'],
                    'to_userid'     => $value,
                    'task_name'     => $data['target_step'] . '步达标赛',
                    'target_step'   => $data['target_step'],
                    'reward_amount' => $data['reward_amount'],
                    'avgmoney'      => $OneManMomeyArray[$key],
                    'task_days'     => $data['task_days'],
                    'task_rule'     => $task_rule,
                    'task_ios_desc' => $task_ios_desc,
                    'task_desc'     => $task_desc,
                    'end_time'      => strtotime(date("Y-m-d")." + ".$data['task_days']." day"),
                    'create_time'   => time(),
                );

                $taskarray[$key] = Db::name('task')->insertGetId($task_INSERT);

// dump($task_INSERT);
                
                $CacheOneDayMoney = round($OneManMomeyArray[$key] / $data['task_days'], 2);

                // 创建子任务
                for ($i = 0; $i < $data['task_days']; $i++) {
                    $current_time        = date("Y-m-d");
                    $activity_start_time = strtotime($current_time . " +" . $i . " day");
                    $activity_end_time   = $activity_start_time + 86399;

                    $task_record_INSERT[] = array(
                        'task_no'             => $task_no,
                        'taskid'              => $taskarray[$key],
                        'userid'              => $value,
                        'amount'              => $CacheOneDayMoney,
                        'activity_start_time' => $activity_start_time,
                        'activity_day'        => date("Y-m-d", $activity_start_time),
                        'activity_end_time'   => $activity_end_time,
                        'status'              => 0,
                    );
                }
                unset($k, $v);

                $CacheMoney = array_sum(array_column($task_record_INSERT, 'amount'));

                if ($OneManMomeyArray[$key] < $CacheMoney) {
                    $task_record_INSERT[0]['amount'] -= $CacheMoney - $OneManMomeyArray[$key];
                } elseif ($OneManMomeyArray[$key] > $CacheMoney) {
                    $task_record_INSERT[0]['amount'] += $OneManMomeyArray[$key] - $CacheMoney;
                }

// dump($CacheMoney);
// $CacheMoney = array_sum(array_column($task_record_INSERT, 'amount'));
// dump($CacheMoney);
// dump($task_record_INSERT);

                $taskrecord[$key] = Db::name('task_record')->insertAll($task_record_INSERT);
                unset($task_INSERT, $CacheOneDayMoney, $CacheMoney, $task_record_INSERT);
                
                unset($task_INSERT);
                unset($CacheMoney);
                unset($task_record_INSERT);
            }
            unset($key, $value);

            Db::commit();      // 提交事务

            $res['taskid']  = $taskarray;
            $res['task_no'] = $task_no;

            return $this->sendSuccess($res, 'success', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(1, $e->getMessage(), 200);
        }
    }

    /**
     * @title 获取我发布的任务详情
     * @return int    error               错误代码 0成功 1失败
     * @return string message             消息提醒
     * @return object task                任务对象
     * @return int    id                  任务id
     * @return string task_name           任务名称
     * @return int    target_step         目标步数
     * @return int    reward_amount       奖励总金额
     * @return int    avgmoney            个人获得奖励总金额
     * @return int    task_days           任务天数
     * @return string task_rule           任务规则
     * @return string task_ios_desc       任务说明（ios端）
     * @return string task_desc           任务说明（非ios端）
     * @return object task_record         任务记录对象
     * @return int    userid              任务执行人用户id
     * @return int    userno              任务执行人用户编号
     * @return string nickname            任务执行人名
     * @return int    activity_start_time 活动开始时间
     * @return int    is_receive          是否领取任务 0未领取 1已领取任务（未领钱） 2已领取奖励
     * @desc 请求方式: GET 请求地址: v1/Task/1
     */
    public function read($id)
    {
        if (intval($id) <= 0) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        // 我发布任务数据
        $task = Db::name('task')
            ->field('id,task_no,task_name,target_step,reward_amount,avgmoney,task_days,task_rule,task_ios_desc,task_desc')
            ->where('id', $id)
            ->find();
        
        // 接任务人的完成情况
        $task_record = Db::name('task_record')
            ->alias('task_record')
            ->field('userid,user.no as userno,nickname,activity_start_time,is_receive,amount')
            ->join('user', 'user.id=task_record.userid', 'left')
            // ->where('task_no', $task['task_no'])
            ->where('taskid', $task['id'])
            ->select();

        foreach ($task_record as $key => $value) {
            if (!empty($value['activity_start_time'])) {
                $task_record[$key]['date'] = date('Y-m-d H:i', $value['activity_start_time']);
            }
        }
        unset($key, $value);

        $retData = array('task' => $task, 'task_record' => $task_record);

        if ($task) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'action' => [
                    'name'    => 'action', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => 'release我发布的 | record发布记录', 
                    'range'   => '',
                ],
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true',
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ]
            ],
            'save' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'to_userid' => [
                    'name'    => 'to_userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '领取人ID 多个用户逗', 
                    'range'   => '',
                ],
                'target_step' => [
                    'name'    => 'target_step', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '目标步数', 
                    'range'   => '',
                ],
                'reward_amount' => [
                    'name'    => 'reward_amount', 
                    'type'    => 'float', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '奖励总金额', 
                    'range'   => '',
                ],
                'task_days' => [
                    'name'    => 'task_days', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '任务天数', 
                    'range'   => '',
                ]
            ],
            'read' => [
               'id' => [
                    'name'    => 'id', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '任务ID', 
                    'range'   => '',
                ]
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
