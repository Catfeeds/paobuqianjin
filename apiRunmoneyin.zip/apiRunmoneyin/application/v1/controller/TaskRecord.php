<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:30
// +----------------------------------------------------------------------
// | TITLE: 我的任务接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;

/**
 * Class  Index
 * @title 我的任务接口
 * @url   v1/TaskRecord
 * @desc  我的任务相关接口
 * @version 1.0
 * @readme
 */
class TaskRecord extends Base
{
    // 附加方法
    protected $extraActionList = ['getFriends'];

    /**
     * @title 获取我的任务列表
     * @return int    error         错误代码：0成功 1失败
     * @return string message       消息提醒
     * @return object data          我的任务对象
     * @return int    id            我的任务ID
     * @return string avatar        领取人头像
     * @return string nickname      领取人昵称
     * @return string task_name     任务名称
     * @return int    target_step   目标步数
     * @return float  reward_amount 奖励金额
     * @return int    task_days     任务天数
     * @return int    is_receive    是否领取任务：0未领取 1已领取 2已经领取奖励（不显示）
     * @return int    is_finished   步数是否达标：0未完成 1已完成
     * @desc 请求方式: GET 请求地址: v1/TaskRecord?action=finished&userid=2
     */
    public function index()
    {
        $data     = input('get.');
        $action   = isset($data['action']) ? $data['action'] : '';
        $userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid   = isset($data['userid']) ? intval($data['userid']) : 0;
        $page     = isset($data['page']) ? intval($data['page']) : 1;             // 当前页面
        $pageSize = isset($data['pagesize']) ? intval($data['pagesize']) : 10;    // 当前条数

        $start_time = strtotime("today");
        $end_time   = strtotime("+1 day", $start_time) - 1;

        if (!$userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        // 查询用户当天步数
        $user_step = Db::name('user_step')
            ->field('step_number')
            ->where([
                'userid'      => $userid,
                'create_time' => ['between', [$start_time, $end_time]]
            ])
            ->find();

        if (empty($user_step)) {
            $UserTodayStep = 0;
        } else {
            $UserTodayStep = $user_step['step_number'];
        }
        unset($user_step);

        // 全部任务
        if ($action == 'all') {
            $map = array();
            $map['task_record.userid'] = $userid;
            // $map['task_record.activity_start_time'] = $start_time;
            // $map['task_record.activity_end_time']   = $end_time;
            $map['task_record.activity_start_time'] = ['<=', time()];
            $map['task_record.activity_end_time']   = ['>=', time()];
            $map['task_record.is_receive']          = ['neq', 2];
            $map['task_record.ok']                  = 1;
            $map['task.ok']                         = 1;

            $totalCount = Db::name('task_record')
                ->alias('task_record')
                ->join('task','task.id = task_record.taskid')
                ->where($map)
                ->count();

            $task_record = Db::name('task_record')
                ->alias('task_record')
                ->join('task','task.id = task_record.taskid')
                ->join('user','user.id = task.userid')
                ->field('
                    task_record.userid,
                    task_record.id,
                    task_record.taskid,
                    user.avatar,
                    user.nickname,
                    task.task_name,
                    task.target_step,
                    task.reward_amount,
                    task.ok as tok,
                    task.task_days,
                    task_record.is_receive,
                    task_record.ok as cok
                ')
                ->where($map)
                ->order('task.id', 'desc')
                ->page($page, $pageSize)
                ->select();

            foreach ($task_record as $key => $value) {
                if ($UserTodayStep > $value['target_step']) {
                    $task_record[$key]['is_finished'] = 1;
                } else {
                    $task_record[$key]['is_finished'] = 0;
                }
            }

            $retData = returnData($page, $pageSize, $totalCount, $task_record);

        } else if ($action == 'unfinished') {    // 未完成任务（未接任务，未达标步数）
            $map = array();
            $map['task_record.userid']              = $userid;
            $map['task_record.activity_start_time'] = $start_time;
            $map['task_record.activity_end_time']   = $end_time;
            $map['task_record.is_receive']          = 1;
            // $map['task_record.is_receive']          = ['in', [0, 1]];
            $map['task.target_step']                = ['>', $UserTodayStep];
            $map['task_record.ok']                  = 1;
            $map['task.ok']                         = 1;

            $totalCount = Db::name('task_record')
                ->alias('task_record')
                ->join('task', 'task.id = task_record.taskid')
                ->where($map)
                ->count();

            $task_record = Db::name('task_record')
                ->alias('task_record')
                ->join('task', 'task.id = task_record.taskid')
                ->join('user', 'user.id = task.userid')
                ->field('
                    task_record.id,
                    task_record.taskid,
                    user.avatar,
                    user.nickname,
                    task.task_name,
                    task.target_step,
                    task.reward_amount,
                    task.ok as tok,
                    task.task_days,
                    task_record.is_receive,
                    task_record.ok as tok
                ')
                ->where($map)
                ->order('task.id', 'desc')
                ->page($page,$pageSize)
                ->select();

            $res_data = [];
            foreach ($task_record as $key => $value) {
                // 步数达标
                if ($UserTodayStep > $value['target_step']) {
                    // $task_record[$key]['is_finished'] = 1;
                    unset($task_record[$key]);
                } else {    // 步数未达标
                    $value['is_finished'] = 0;
                    $res_data[] = $value;
                }   
            }
            unset($key, $value);

            if (count($res_data) > 0) {
                foreach ($res_data as $key => $value) {
                    $res_data[$key]['is_finished'] = 0;
                }
                unset($key, $value);
            }

            $retData = returnData($page, $pageSize, $totalCount, $res_data);

// dump($task_record);
// dump($res_data);
// exit();
        } else if ($action == 'finished') {    // 已完成任务（已达标步数）
            // 条件拼接
            $map = array();
            $map['task_record.userid']              = $userid;
            $map['task_record.activity_start_time'] = $start_time;
            $map['task_record.activity_end_time']   = $end_time;
            $map['task_record.is_receive']          = 1;
            $map['task.target_step']                = ['<=', $UserTodayStep];
            $map['task_record.ok']                  = 1;
            $map['task.ok']                         = 1;

            $totalCount = Db::name('task_record')
                ->alias('task_record')
                ->join('task','task.id = task_record.taskid')
                ->where($map)
                ->count();

            $task_record = Db::name('task_record')
                ->alias('task_record')
                ->join('task','task.id = task_record.taskid')
                ->join('user','user.id = task.userid')
                ->field('
                    task_record.id,
                    task_record.taskid,
                    user.avatar,
                    user.nickname,
                    task.task_name,
                    task.target_step,
                    task.reward_amount,
                    task.task_days,
                    task.ok as tok,
                    task_record.is_receive,
                    task_record.ok as tok
                ')
                ->where($map)
                ->order('task.id', 'desc')
                ->page($page, $pageSize)
                ->select();

            foreach ($task_record as $key => $value) {
                $task_record[$key]['is_finished'] = 1;
            }
            unset($key, $value);

            $retData = returnData($page, $pageSize, $totalCount, $task_record);
        } else {
            return $this->sendError(1, 'Not Found Action', 200);
        }

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }

    /**
     * @title 根据每天任务ID获取详情
     * @return int    error               错误代码：0成功 1失败
     * @return string message             消息提醒
     * @return object data                我的任务对象
     * @return string task_name           任务名称
     * @return int    task_days           任务天数
     * @return int    target_step         目标步数
     * @return int    reward_amount       奖励总金额
     * @return int    avgmoney            个人获得奖励总金额
     * @return int    userid              领取人用户ID
     * @return int    userno              领取人用户编号
     * @return string avatar              领取人头像
     * @return string nickname            领取人昵称
     * @return int    activity_start_time 活动开始时间
     * @return int    activity_end_time   活动结束时间
     * @return string task_rule           任务规则
     * @return string task_ios_desc       任务说明（ios端）
     * @return string task_desc           任务说明（非ios端）
     * @return string user_step           用户当前步数
     * @return int    is_finished         是否已完成：0未完成 1已完成
     * @desc 请求方式: GET 请求地址: v1/TaskRecord/1
     */
    public function read($id)
    {
        $start_time = strtotime("today");
        $end_time   = strtotime("+1 day", $start_time) - 1;

        if (empty($id)) {
            return $this->sendError(1, '任务id必填', 200);
        }

        $task = Db::name('task_record')
            ->alias('task_record')
            ->join('task', 'task.id = task_record.taskid')
            ->join('user', 'user.id = task.userid')
            ->field('
                task_record.id,
                task.task_name,
                task.task_days,
                task.target_step,
                task.reward_amount,
                task.avgmoney,
                task.userid,
                user.no as userno,
                user.avatar,
                user.nickname,
                task_record.activity_start_time,
                task_record.activity_end_time,
                task.task_rule,
                task.task_ios_desc,
                task.task_desc,
                task_record.userid as to_userid,
                is_receive
            ')
            ->where('task_record.id', $id)
            ->where('task.delete_id', 0)
            ->where('task_record.delete_id', 0)
            ->find();

        if (empty($task)) {
            return $this->sendError(1, 'Not found Data', 200);
        }
// dump($task);
// exit();

        // 查询用户当天步数
        $user_step = Db::name('user_step')
            ->where([
                'userid'      => $task['to_userid'],
                'create_time' => ['between', [$start_time, $end_time]]
            ])
            ->order('id desc')
            ->value('step_number');

// dump($task);
// dump($user_step);
// exit();

        if ($user_step) {
            $task['user_step'] = $user_step;
        } else {
            $task['user_step'] = 0;
        }

        if ($user_step >= $task['target_step']) {
            $task['is_finished'] = 1;
        } else {
            $task['is_finished'] = 0;
        }

        if ($task) {
            return $this->sendSuccess($task, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 领取任务/领取奖励
     * @return int    error   错误代码：0成功 1失败
     * @return string message 消息提醒
     * @desc 请求方式: PUT 请求地址: v1/TaskRecord/1
     */
    public function update(Request $request, $id)
    {
        $data   = $request->put();
        $action = isset($data['action']) ? $data['action'] : '';

// dump($action);
// exit();

        if ($action == 'receive_task') {
            $is_receive = 1;
        } else if ($action == 'receive_reward') {
            $is_receive = 2;
        } else {
            return $this->sendError(-1, 'Not found action', 400);
        }

        Db::startTrans();    // 开启事务

        try {
            // 获取任务数据
            $Old = Db::name('task_record')->field(true)->where('id', $id)->find();

            if ($is_receive == 1) {     // 领取奖励

                if ($Old['is_receive'] >= 1) {
                    return $this->sendSuccess(0, 'success', 200);
                }

                // 更新已领取的状态
                $record_UPDATE['is_receive']   = 1;
                $record_UPDATE['receive_time'] = time();

                $result = Db::name('task_record')
                    ->where('id', $id)
                    ->update($record_UPDATE);

            } elseif ($is_receive == 2) {     // 领取奖励

                if ($Old['is_receive'] >= 2) {
                    return $this->sendSuccess(0, 'success', 200);
                }

                // 更新已领取的状态
                $record_UPDATE['is_receive']   = 2;
                $record_UPDATE['receive_time'] = time();

                $result = Db::name('task_record')
                    ->where('id', $id)
                    ->update($record_UPDATE);

                // 添加收益记录
                $income_INSERT['userid']      = $Old['userid'];
                $income_INSERT['typeid']      = 4;
                $income_INSERT['amount']      = $Old['amount'];
                $income_INSERT['create_time'] = time();
                $income_INSERT['source_id']   = $Old['id'];
                $income_id = Db::name('income')->insertGetId($income_INSERT);

                // 修改用户余额
                Db::name('user')->where('id', $Old['userid'])->setInc('balance', $Old['amount']);
            }

            // 提交事务
            Db::commit();
            return $this->sendSuccess(0, 'success', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(-1, $e->getMessage(), 400);
        }
    }

    /**
     * @title 获取可选择好友
     * @return int    error         错误代码：0成功 1失败
     * @return string message       消息提醒
     * @return array  data          返回数组
     * @return int    userid        用户ID
     * @return string vip           会员：0否|1是
     * @return string cusvip        商户会员：0否|1是
     * @return string avatar        用户头像
     * @return string nickname      用户昵称
     * @return int    is_distribute 是否已派发任务：0未派发 1已派发
     * @desc 请求方式: GET 请求地址: v1/TaskRecord/getFriends?userid=1
     */
    public function getFriends()
    {
        $data     = input('get.');
        $userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid   = intval($data['userid']);

        $page     = isset($data['page']) ? $data['page'] : 1;
        $pageSize = isset($data['pagesize']) ? $data['pagesize'] : 10;
        $keyword  = isset($data['keyword']) ? $data['keyword'] : '';

        $totalCount = Db::name('user_follow')
            // ->where('userid', $userid)
            ->alias('user_follow')
            ->join('user', 'user.id = user_follow.followid', 'left')
            ->where(['user_follow.userid' => $userid, 'user.nickname' => ['like', '%'.$keyword.'%']])
            ->where('followid', 'IN', function($query) use ($userid) {
                $query->name('user_follow')->where('followid', $userid)->field('userid');
            })
            ->count();

        // 获取好友（互相关注的）
        $user_friends = Db::name('user_follow')
            ->alias('user_follow')
            ->join('user', 'user.id = user_follow.followid', 'left')
            ->field('user.id,user.avatar,user.nickname,user_follow.followid,vip,cusvip')
            ->where(['user_follow.userid' => $userid, 'user.nickname' => ['like', '%'.$keyword.'%']])
            ->where('user_follow.followid', 'IN', function($query) use ($userid) {
                $query->name('user_follow')->where('followid', $userid)->field('userid');
            })
            ->page($page, $pageSize)
            ->select();

// dump($userid);
// dump($user_friends);
// exit();

        // 我派发的任务人列表（未完成的）
        $task = Db::name('task')
            ->alias('task')
            ->field('task.id,task.task_name,task.task_days,user.id as userid,user.nickname')
            ->join('user', 'task.to_userid = user.id')
            ->where('userid', $userid)
            ->where('end_time', '>', time())
            ->where('ok', 1)
            ->select();

        $have_user_task = [];
        foreach ($task as $key => $value) {
            $have_user_task[] = $value['userid'];
        }
        unset($key, $value);
        
        foreach ($user_friends as $key => $value) {
            if (in_array($value['followid'], $have_user_task)) {
                $user_friends[$key]['is_distribute'] = 1;
            } else {
                $user_friends[$key]['is_distribute'] = 0;
            }
        }
        unset($key, $value);

        $retData = returnData($page, $pageSize, $totalCount, $user_friends);

        if ($user_friends) {
            return $this->sendSuccess($retData ,'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'action' => [
                    'name'    => 'action', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => 'all全部 | unfinished未完成 | finished已完成', 
                    'range'   => '',
                ],
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ]
            ],
            'read' => [
                'id' => [
                    'name'    => 'id', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '任务ID', 
                    'range'   => '',
                ],
                'task_name' => [
                    'name'    => 'task_name', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '任务名称', 
                    'range'   => '',
                ],
                'task_days' => [
                    'name'    => 'task_days', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '任务天数', 
                    'range'   => '',
                ],
                'target_step' => [
                    'name'    => 'target_step', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '目标步数', 
                    'range'   => '',
                ],
                'reward_amount' => [
                    'name'    => 'reward_amount', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '奖励金额', 
                    'range'   => '',
                ],
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '领取人用户ID', 
                    'range'   => '',
                ],
                'avatar' => [
                    'name'    => 'avatar', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '领取人头像', 
                    'range'   => '',
                ],
                'nickname' => [
                    'name'    => 'nickname', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '领取人昵称', 
                    'range'   => '',
                ],
                'activity_start_time' => [
                    'name'    => 'activity_start_time', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '活动开始时间', 
                    'range'   => '',
                ],
                'activity_start_time' => [
                    'name'    => 'activity_end_time', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '活动结束时间', 
                    'range'   => '',
                ],
                'task_rule' => [
                    'name'    => 'task_rule', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '任务规则', 
                    'range'   => '',
                ],
                'task_desc' => [
                    'name'    => 'task_desc', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '任务说明（非ios端）', 
                    'range'   => '',
                ],
                'task_ios_desc' => [
                    'name'    => 'task_desc', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '任务说明（ios端）', 
                    'range'   => '',
                ],
            ],
            'update' => [
                'action' => [
                    'name'    => 'action', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => 'receive_task领取任务 | receive_reward领取奖励', 
                    'range'   => '',
                ]
            ],
            'getFriends' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
                'keyword' => [
                    'name'    => 'keyword', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ]
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
