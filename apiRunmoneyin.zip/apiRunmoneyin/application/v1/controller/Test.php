<?php
/**
 * Created by PhpStorm.
 * User: lixinhe
 * Date: 2018/5/22
 * Time: 上午11:58
 */

namespace app\v1\controller;

use app\v1\extend\HelibaoInt;
use think\Validate;
use think\Db;

header("Content-Type:text/html;charset=utf-8");

class Test extends Base
{


    public function check()
    {
//        $text = array('content' => '约炮，姐姐阿姨和少妇满意 ，不影响家庭，做得私聊谈，喜欢被亲吻，被口活的姐姐加我，本人。可长期相处，也可就一次高兴。单身寂寞的，经常空虚的，老公无法满足你的，就想让男人跪下给你舔，泄压满足心理的等等，只要你愿意都可以私聊我。', 'dataId' => uniqid(), 'time' => round(microtime(true) * 1000));



//                $re = \aliyuncs\Green\Check::textScan('约炮，姐姐阿姨和少妇满意 ，不影响家庭，做得私聊谈，喜欢被亲吻，被口活的姐姐加我，本人。可长期相处，也可就一次高兴。单身寂寞的，经常空虚的，老公无法满足你的，就想让男人跪下给你舔，泄压满足心理的等等，只要你愿意都可以私聊我。');
//        $re = \aliyuncs\Green\Check::textScan(array($text));
        return $this->sendError(0, '测试成功', 200);

    }

    public function refundTask()
    {
        {   // 查询需要退款数据
            $task_WHERE['tr.ok'] = 1;
            // $task_WHERE['ts.ok']                = 1;
            $task_WHERE['tr.delete_id'] = 0;
            // $task_WHERE['ts.delete_id']         = 0;
            $task_WHERE['tr.is_receive'] = ['<>', 2];
            $task_WHERE['tr.activity_end_time'] = ['<', time()];

            // 获取以前的没退款的任务
            $user_task = Db::name('task_record')->alias('tr')// ->field(true)
                ->field('
                    tr.id as tcid,
                    tr.task_no,
                    tr.amount,
                    tr.activity_start_time,
                    tr.activity_end_time,
                    tr.is_receive,
                    tr.userid as tuserid,
                    ts.userid as userid
                ')->join('task ts', 'ts.id=tr.taskid', 'left')->where($task_WHERE)->select();
            if (empty($user_task))
            {
                return $this->sendError(1, 'Not Found Data', 200);
            }
        }

        // dump($user_task_ids);
        // dump($task_WHERE);
        // dump($user_task);
        // exit();

        Db::startTrans();    // 开启事务

        foreach ($user_task as $key => $value)
        {
            // 将余额加到用户余额中
            $user_WHERE['id'] = $value['userid'];

            $user_res[$key] = Db::name('user')->where($user_WHERE)->setInc('balance', $value['amount']);
            //            exit(var_dump($value['amount']));

            if (empty($user_res[$key]))
            {
                Db::rollback();    // 回滚事务
                return $this->sendError(1, '修改用户余额失败', 200);
            }

            // 添加收益记录
            $income_INSERT['userid'] = $value['userid'];
            $income_INSERT['typeid'] = 6;
            $income_INSERT['amount'] = $value['amount'];
            $income_INSERT['create_time'] = time();
            $income_INSERT['source_id'] = $value['tcid'];
            $income_res[$key] = Db::name('income')->insertGetId($income_INSERT);


            //写入到订单记录  做明细统计
            $order_INSERT['userid'] = $income_INSERT['userid'];
            $order_INSERT['order_type'] = 5;//退款订单
            $order_INSERT['payment_type'] = 5;//任务退款
            $order_INSERT['status'] = 1;//完成退款
            $order_INSERT['order_no'] = build_accept_no('order', 'order_no');//生成唯一编号
            $order_INSERT['total_fee'] = $income_INSERT['amount'];
            $order_INSERT['create_time'] = $income_INSERT['create_time'];
            $order_INSERT['body'] = $income_INSERT['source_id'];//记录退款的任务记录id
            $order_res[$key] = Db::name('order')->insertGetId($order_INSERT);

            //必须同时成功才能
            if (empty($income_res[$key]) || empty($order_res[$key]))
            {
                Db::rollback();    // 回滚事务
                return $this->sendError(1, '添加收益记录失败', 200);
            }

            unset($user_WHERE, $income_INSERT);
        }
        unset($key, $value);

        $user_task_ids = array_column($user_task, 'tcid');

        $user_task_ids = array_filter($user_task_ids);

        sort($user_task_ids);
        $user_task_ids = implode(',', $user_task_ids);

        // 将任务设置成退款状态
        $task_record_UPDATE = Db::name('task_record')->where('id', 'in', $user_task_ids)// ->fetchSql(true)
            ->update(['is_refund' => 1, 'refund_time' => time(),]);


        // // 退款记录（退款记录表）
        // $refund_INSERT['type']   = 2;
        // $refund_INSERT['money']  = $Sum;
        // $refund_INSERT['allsum'] = count($Resback);
        // $refund = Db::name('log_refund')->insert($refund_INSERT);

        if (empty($task_record_UPDATE))
        {
            Db::rollback();    // 回滚事务
            return $this->sendError(1, '修改用户任务退款记录失败', 200);
        }

        // Db::rollback();    // 回滚事务
        Db::commit();    // 提交事务

        return $this->sendError(0, '任务金额退回成功', 200);
    }


    public function testIni()
    {
        exit(json_decode(input()));
    }

    //测试推送模板

    public function addPushTempLate()
    {
        $device_type = strtolower(trim(input('device_type')));
        $name = input('name');
        $desc = input('desc');
        $code = 90001;
        $template = input('template');
        $template = explode("\n", $template);
        $newArray = array();
        foreach ($template as $v)
        {
            $temp = explode("=>", $v);
            $newArray[$temp[0]] = $temp[1];
        }


        if ($device_type != 'android' && $device_type != 'ios')
        {
            return $this->sendError(1, "device_type必要参数缺失", 200);
        } elseif ($device_type == 'android')
        {
            if (!isset($template['display_type']))
            {
                return $this->sendError(1, "display_type必要参数解析失败", 200);
            }

            if ($template['display_type'] == 'message')
            {
                $rule = ["custom" => 'require',];
                $msg = ['custom.require' => 'custom参数缺失',];
            } elseif ($template['display_type'] == 'notification')
            {
                $rule = ["ticker" => 'require', "title" => 'require', "text" => 'require', "after_open" => 'require',];

                $msg = ['ticker.require' => 'ticker参数缺失', 'title.require' => 'title参数缺失', 'text.require' => 'text参数缺失', 'after_open.require' => 'after_open参数缺失',];
            } else
            {
                return $this->sendError(1, "display_type必要参数解析失败", 200);
            }


            // 验证字段
            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($template);

            if (empty($validate_result))
            {
                return $this->sendError(1, $validate->getError(), 200);
            }
        }


    }


    //测试推送
    public function testPush()
    {

        $re = \umeng\UPush::sendUnicast('05e7d78b0fbbd62c12763bf09333f1dc9e9304b9d3bc4be9e105d0b6c17418f5', 'ceshi');
        //        $re = \umeng\UPush::sendBroadcast();

        //        $re = strlen('AoDrHOhwIUgnLTZVvGV1Z8oCqGfRk2DnanVlbCb2Im_Z');
        //       $re =  \umeng\UPush::sendBroadcast('ceshi','','','','ios');

    }

    //测试微信支付
    public function testPay()
    {


        $re = (new \app\v1\extend\HelibaoInt)->wapPay();

        exit(dump($re));
    }

    //批量修改城市信息
    public function editCity()
    {
        $list = db('business')->field('id,addra')->select();

        foreach ($list as $k => &$v)
        {
            if (!$v['addra'])
            {
                unset($list[$k]);
            } else
            {
                $list[$k]['addra'] = str_replace("///", "/", $v['addra']);
                //                db('business')->where(['id'=>$v['id']])->update(['addra'=>$v['addra']]);
            }

        }
        exit(var_dump($list));

    }


    public function insertToStr($str, $i, $substr)
    {
        //指定插入位置前的字符串
        $startstr = "";
        for ($j = 0; $j < $i; $j++)
        {
            $startstr .= $str[$j];
        }
        //指定插入位置后的字符串
        $laststr = "";
        for ($j = $i; $j < strlen($str); $j++)
        {
            $laststr .= $str[$j];
        }
        //将插入位置前，要插入的，插入位置后三个字符串拼接起来
        $str = $startstr . $substr . $laststr;
        //返回结果
        return $str;
    }

    public static function getScanFields()
    {
        return [
            'check'=>[
            ]
        ];
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
