<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:30
// +----------------------------------------------------------------------
// | TITLE: 第三方接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;
use think\Cache;
use app\v1\extend\AliyunWeather;
use app\v1\extend\AliyunSms;
use anerg\Alidayu\SmsGateWay;

/**
 * Class  Index
 * @title 第三方接口
 * @url   v1/ThirdParty
 * @desc  第三方相关接口
 * @version 1.0
 */
class ThirdParty extends Base
{
    // 跳过验证方法
    protected $skipAuthActionList = ['sendMsg'];

    // 附加方法
    protected $extraActionList = ['getWeather', 'sendMsg'];

    /**
     * @title  天气查询接口
     * @return string weather 天气
     * @return string img     天气图片
     * @return string temp    温度
     * @desc 请求方式: GET 请求示例:v1/ThirdParty/getWeather
     */
    public function getWeather()
    {
        $data = input('get.');
        $longitude = isset($data['longitude']) ? $data['longitude'] : 0;  // 经度
        $latitude  = isset($data['latitude']) ? $data['latitude'] : 0;    // 纬度

        if (empty($longitude)) {
            return $this->sendError(-1, '经度必填', 400);
        }

        if (empty($latitude)) {
            return $this->sendError(-1, '纬度必填', 400);
        }

        $config['AppCode'] = 'ff5736e074164fa39b3d970536cff56e';

        $aliyunWeather = new AliyunWeather($config);
        $result = $aliyunWeather->WeatherQuery($longitude, $latitude);

// dump($aliyunWeather->data['img']);
// dump($result);
// dump($aliyunWeather->data);
// exit();

        if ($result) {
            $data = $aliyunWeather->data;

            $retData = array(
                'weather'  => $data['weather'],
                'img'      => $data['img'],
                'temp'     => $data['temp'],
                'city'     => $data['city'],
                'citycode' => $data['citycode'],
            );

            if (empty($retData['weather'])) {
                return $this->sendError(-1, '数据出错', 400);
            } else {
                return $this->sendSuccess($retData, 'success', 200);
            }
        } else {
            return $this->sendError(-1, $aliyunWeather->error, 400);
        }
    }

    /**
     * @title  发送验证码
     * @return integer num 验证码
     * @desc  请求方式: GET <br/> 请求地址：v1/ThirdParty/sendMsg
     */
    public function sendMsg()
    {
        $mobile = input('get.mobile');            // 手机号码
        $veryify_code = mt_rand(100000, 999999);  // 6位数的验证码

        if (empty($mobile)) {
            return $this->sendError(-1, '手机号必填', 200);
        }

        $Daytimes = intval(cache($mobile.'_daytimes'));

        if ($Daytimes > 10) {
            return $this->sendError(-1, '超出每天发送验证码上限', 200);
        }

        if (!empty(cache($mobile.'_msgtimes'))) {
            return $this->sendError(-1, '60秒后才能继续发', 200);
        }

        if (!preg_match("/^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$/", $mobile)) {
            return $this->sendError(-1, '手机号码不正确', 200);
        }

        if ($Daytimes % 2 == 0) {
            $config = config('aliyun_sms.sms1');
        } else {
            $config = config('aliyun_sms.sms2');
        }

// dump($config);
// die;

        $aliyunSms = new AliyunSms($config);
        $status    = $aliyunSms->send_verify($mobile, $veryify_code);

        // 短信发送失败
        if (!$status) {
            return $this->sendError(-1, $aliyunSms->error, 200);
        } else {    // 短信发送成功
            cache($mobile.'_msgtimes', 1, 60);

            cache($mobile.'_code', $veryify_code, 600);

            if ($Daytimes > 0) {
                $nextday = strtotime("today") + 24 * 60 * 60;
                $expires = $nextday - time();
                 
                // $expires = 1524542250 - time();
                Cache::set($mobile.'_daytimes', $Daytimes + 1, $expires);
            } else {
                $nextday = strtotime("today") + 24 * 60 * 60;
                $expires = $nextday - time();
                // $expires = 1524542250 - time();
                Cache::set($mobile.'_daytimes', 1, $expires);
            }

            return $this->sendSuccess('', 'success', 200);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'getWeather' => [
                'latitude' =>  [
                    'name' => 'latitude', 
                    'type' => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc' => '经度', 
                    'range' => '',
                ],
                'longitude'  =>  [
                    'name' => 'longitude', 
                    'type' => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc' => '纬度', 
                    'range' => '',
                ]
            ],
            'sendMsg' => [
                'mobile'    =>  [
                    'name' => 'mobile', 
                    'type' => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc' => '用户手机号', 
                    'range' => '',
                ]
            ]
        ];
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
