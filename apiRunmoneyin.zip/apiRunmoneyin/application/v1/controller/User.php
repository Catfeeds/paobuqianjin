<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:30
// +----------------------------------------------------------------------
// | TITLE: 用户相关信息接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Db;
use think\Validate;
use think\Action;
use v1\AppHelper;
use think\Request;
use app\v1\location\Location;
use think\Cache;
use \app\v1\auth\AccessToken;
use \app\v1\extend\Loginlog;

// 指定允许其他域名访问  
header('Access-Control-Allow-Origin:*');  
// 响应类型  
header('Access-Control-Allow-Methods:POST');  
// 响应头设置  
header('Access-Control-Allow-Headers:x-requested-with,content-type');  

/**
 * Class  User
 * @title 用户相关信息接口
 * @url   v1/user
 * @desc  用户相关接口包含：发送验证码、获取附近的人、手机注册、手机号登录、手机验证码登录、第三方登录、获取用户详细信息、修改密码、修改用户资料、删除用户、刷新秘钥、退出登录、绑定第三方、检查用户绑定状态
 * @version 1.0
 */
class User extends Base
{
    // 跳过验证方法
    protected $skipAuthActionList = ['login', 'logOut', 'save', 'modifyPasswordByMobile', 'thirdPartyLogin', 'mobileCodeRegister', 'refreshToken'];

    // 附加方法
    protected $extraActionList = [
        'modifyPasswordByMobile',
        'modifyPasswordByOldPassword',
        'getNearbyPeople',
        'chcekMobile',
        'bindMobile',
        'forceBindMobile',
        'bindOpenid',
        'login',
        'thirdPartyLogin',
        'logOut',
        'refreshToken',
        'mobileCodeRegister',
        'checkUserStatus',
        'userUntie',
    ];

    // protected $rule = [
    //     'mobile'   => 'require|number',
    //     'password' => 'require|length:6,32',
    // ];

    // protected $msg = [
    //     'mobile.require'   => '手机号必须',
    //     'mobile.length'    => '手机号为11位数字',
    //     'mobile.number'    => '手机号为11位数字',
    //     'password.require' => '密码必须',
    //     'password.length'  => '密码为6-12位之间',
    // ];

    /**
     * @title  手机注册（手机号）
     * @return int    error      错误代码 0成功 -1错误
     * @return string message    消息提醒
     * @return array  data       数组数据
     * @return int    userid     用户id
     * @return string user_token 秘钥 
     * 
     * @desc  请求方式：POST <br/>请求地址：v1/user
     */
    public function save()
    {
        $data = input('post.');

        unset($data['balance']);
        unset($data['credit']);

        $rule = [
            'mobile'   => 'require|number|length:11',
            'password' => 'require|length:6,32',
        ];

        $msg = [
            'mobile.require'   => '手机号必须',
            'mobile.length'    => '手机号为11位数字',
            'mobile.number'    => '手机号为11位数字',
            'password.require' => '密码必须',
            'password.length'  => '密码为6-12位之间',
        ];

        //验证数据是否合法
        $mobile = isset($data['mobile']) ? $data['mobile'] : '';

        $validate = new Validate($rule, $msg);
        $result   = $validate->check($data);

        if (!$result) {
            return $this->sendError(-1, $validate->getError(), 400);
        }

        // // 获取缓存的短信验证码
        // $code = cache($mobile . '_code');
        // if (!$code) {
        //     return $this->sendError(-1, '验证码已经过期', 400);
        // }

        // // 匹配短信验证码
        // if ($code != $data['code']) {
        //     return $this->sendError(-1, '验证码错误', 400);
        // }

        // 查询手机号码是否已注册
        $user = db('user')->field('mobile')->where('mobile', $mobile)->find();
        if ($user) {
            return $this->sendError(-1, '手机号已注册', 400);    // 用户已存在
        }

// dump($user);
// exit();

        // 用户不存在注册
        // $data['id']          = getNewUserid();
        $data['no']          = getNewUserNo();
        $data['avatar']      = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_h.png';
        $data['password']    = md5($data['password']);
        $data['nickname']    = 'rm_' . $mobile;
        $data['levelid']     = 1;
        $data['create_time'] = time();
        $data['type']        = 1;

        $userid = db('user')->insertGetId($data);
        
        if ($userid) {
            {   // 注册成功发表动态
                $dynamic_data['userid']   = $userid;
                $dynamic_data['dynamic']  = base64_encode('号外！号外！我加入跑步钱进了，大家一起走路领红包吧！');
                $dynamic_data['images'][] = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_d.png';
                $dynamic_data['images']   = serialize($dynamic_data['images']);
                $dynamic_data['create_time'] = time();
                
                $result = Db::name('dynamic')->insert($dynamic_data);
            }

            $res['id'] = $userid;
            $res['no'] = $data['no'];

            // token处理类
            $accessToken = new AccessToken();
            $accessToken = $accessToken->getToken($userid);
            
            if (empty($accessToken)) {
                return $this->sendError(-1, '秘钥生成失败', 400);
            } else {
                $res['user_token'] = $accessToken;
            }

            return $this->sendSuccess($res, '注册成功', 200);
        } else {
            return $this->sendError(-1, '数据库错误', 400);
        }
    }

    /**
     * @title 获取用户详细信息
     * @return int    error        错误代码：0成功 1失败
     * @return string message      消息提醒
     * @return array  data         返回数组
     * @return int    id           用户id
     * @return int    no           用户编号
     * @return string vip          会员：0否|1是
     * @return string cusvip       商户会员：0否|1是
     * @return int    wx_openid    微信openid
     * @return int    qq_openid    腾讯QQopenid
     * @return int    weibo_openid 微博openid
     * @return string mobile       手机号
     * @return int    nickname     昵称
     * @return string avatar       头像地址
     * @return string levelid      段位ID  具体查看获取段位接口 
     * @return string sex          性别
     * @return string birthyear    生年
     * @return string birthmonth   生月
     * @return string birthday     生日
     * @return int    height       身高
     * @return int    weight       体重
     * @return string province     省
     * @return string city         市
     * @return string balance      余额
     * @return string target_step  目标步数
     * @return string credit       步币
     * @return string status       状态 0正常 1禁用
     * @return string creat_time   创建时间
     * @return string level        段位名称
     * @return string followCount  我的关注总数
     * @return string circleCount  我的圈子总数
     * @return string authentication_status  认证状态：0认证中|1认证通过|2认证未通过|4未认证
     * @return string messagesCount          总消息数
     * @desc 请求方式:get &nbsp; 请求地址：v1/user/1（用户id）
     */
    public function read($id)
    {   
        // $id = intval($id);
        $id = intval($id) ? intval($id) : intval($this->userId);

        if (empty($id)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        // 获取用户数据（密码除外）
        $user = db('user')
            ->field('
                id,no,wx_unionid,qq_unionid,
                wx_openid,qq_openid,mobile,avatar,nickname,
                levelid,sex,birthyear,birthmonth,birthday,height,weight,
                type,province,city,balance,credit,status,is_perfect,
                create_time,delete_time,logintimes,vip,cusvip,
                CASE WHEN target_step<5000 THEN 5000 ELSE target_step END as target_step
            ')
            ->where('id', $id)
            ->find();
            // target_step,ifnull(target_step, 5000),

        if (empty($user)) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

// dump($user);
// exit();

        // 获取用户段位信息
        $level = db('user_level')->field('level')->where('id', $user['levelid'])->find();
        $user['level'] = $level['level'];

        // 我关注的
        $myFollow = db('user_follow')->where('userid', $id)->group('followid')->count();

        // 关注我的
        $followMy = db('user_follow')->where('followid', $id)->group('userid')->count();

        // 互相关注的
        $followEach = Db::name('user_follow')
            ->alias('user_follow')
            ->join('user','user.id = user_follow.followid')
            ->field('user.id as userid,user.avatar,user.nickname,user.sex,user_follow.followid')
            ->where('user_follow.userid', $id)
            ->where('user_follow.followid', 'IN', function($query) use ($id) {
                $query->name('user_follow')->where('followid', $id)->field('userid');
            })
            ->count();

// dump();
// exit();

        // 关注总数
        $user['followCount'] = $myFollow + $followMy - $followEach;

        // // 获取关注的总数
        // $followCount = db('user_follow')->where('userid', $id)->count();
        // $user['followCount'] = $followCount;

        // 获取我的圈子总数
        $circleCount = db('circle_member')
            ->where('userid', $id)
            ->where('delete_id', 0)
            ->group('circleid')
            ->count();

        $user['circleCount'] = $circleCount;

        // 认证状态
        $user_authentication = db('user_authentication')->where(['userid'=>$id])->find();

        if ($user_authentication) {
            $user['authentication_status'] = $user_authentication['status'];
        } else {
            $user['authentication_status'] = 4;
        }

        // 获取消息总数
        $messagesCount = db('user_messages')->where('to_userid', $id)->count();
        $user['messagesCount'] = $messagesCount;

        // 用户总收益
        $userAllincome = db('income')->where('userid', $id)->sum('amount');
        $user['userAllincome'] = $userAllincome;

        return $this->sendSuccess($user, 'success', 200);
    }

    /**
     * @title 修改用户资料
     * @param int id  用户id
     * @desc  请求方式:put 请求地址: v1/user/用户id
     */
    public function update($id)
    {   
        $Userid = intval($id) ? intval($id) : intval($this->userId);
        // $Userid = intval($id);
        $data   = input('put.');

        $Old = db('user')->field('password', true)->where('id', $Userid)->find();

        if (empty($Old)) {
            return $this->sendError(-1, '用户不存在', 400);
        }

        $age_sign    = 0;    // 年龄改变状态
        $here_UPDATE = [];   // 更新的数据
    
        // 昵称
        if (isset($data['nickname']) && $data['nickname'] != $Old['nickname']) {
            $here_UPDATE['nickname'] = $data['nickname'];
        }
        // 头像
        if (isset($data['avatar']) && $data['avatar'] != $Old['avatar']) {
            $here_UPDATE['avatar'] = $data['avatar'];
        }
        // 性别 0无|1男|1女
        if (isset($data['sex']) && ($data['sex'] >= 0) && ($data['sex'] <= 2)  && $data['sex'] != $Old['sex']) {
            $here_UPDATE['sex'] = $data['sex'];
        }
        // 身高
        if (isset($data['height']) && $data['height'] != $Old['height']) {
            $here_UPDATE['height'] = $data['height'];
        }
        // 体重
        if (isset($data['weight']) && $data['weight'] != $Old['weight']) {
            $here_UPDATE['weight'] = $data['weight'];
        }
        // 所在省
        if (isset($data['province']) && $data['province'] != $Old['province']) {
            $here_UPDATE['province'] = $data['province'];
        }
        // 所在市
        if (isset($data['city']) && $data['city'] != $Old['city']) {
            $here_UPDATE['city'] = $data['city'];
        }
        // 生年
        if (isset($data['birthyear']) && $data['birthyear'] != $Old['birthyear']) {
            $here_UPDATE['birthyear'] = $data['birthyear'];
            $age_sign = 1;
        }
        // 生月
        if (isset($data['birthmonth']) && $data['birthmonth'] != $Old['birthmonth']) {
            $here_UPDATE['birthmonth'] = $data['birthmonth'];
            $age_sign = 1;
        }
        // 生日
        if (isset($data['birthday']) && $data['birthday'] != $Old['birthday']) {
            $here_UPDATE['birthday'] = $data['birthday'];
            $age_sign = 1;
        }

        if ($age_sign != 0) {
            $Age = birthdayToAge($data['birthyear'] . '-' . $data['birthmonth'] . '-' . $data['birthday']);

            if (($Age > 10) && ($Age < 60)) {
                $here_UPDATE['target_step'] = 10000;
            } else {
                $here_UPDATE['target_step'] = 5000;
            }
        }

        // 判断是否有修改
        if (count($here_UPDATE) <= 0) {
            return $this->sendError(0, 'success', 200);
        }

        $here_UPDATE['is_perfect'] = 1;

// dump($data['sex']);
// dump($Old['sex']);
// dump($here_UPDATE);
// die;
        $res = db('user')->where('id', $Userid)->update($here_UPDATE);

        if ($res) {
            return $this->sendSuccess(0, 'success', 200);
        } else {
            return $this->sendError(1, '修改失败', 200);
        }
    }

    /**
     * @title 删除用户
     * @param  int $id
     * @return int id 返回删除用户的id
     * @desc 请求方式：delete 请求地址：v1/user/用户id
     */
    public function delete($id)
    {
        return false;

        $res = db('user')->delete($id);

        if ($res) {
            return $this->sendSuccess($res, '删除成功', 200);
        } else {
            return $this->sendError(-1, '删除失败', 400);
        }
    }

    /**
     * @title 根据手机号修改密码
     * @desc 请求方式：POST 请求地址：v1/user/modifyPasswordByMobile
     */
    public function modifyPasswordByMobile()
    {
        $data = input('post.');

// dump($data);
// $str = '123456';
// dump(md5($str));
// dump(md5(md5($str)));
// die;

        $rule = array(
            'mobile'   => 'require',
            'password' => 'require',
            'code'     => 'require|length:6'
        );

        $msg = array(
            'mobile.require'   => '手机号必填',
            'password.require' => '密码必填',
            'code.require'     => '验证码必填',
        );

        $validate = new Validate($rule, $msg);
        $validate_result = $validate->check($data);

        if (empty($validate_result)) {
            return $this->sendError(-1, $validate->getError(), 400);
        }

        $mobile   = $data['mobile'];
        $password = md5($data['password']);    // 加密后的密码
        $code     = $data['code'];

        // 查询用户是否存在
        $user = db('user')->field(true)->where('mobile', $mobile)->find();

        if (empty($user)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        $old_code = cache($mobile.'_code');

        if (!$old_code) {
            return $this->sendError(1, '验证码已经过期', 200);
        } else if ($code != $old_code) {
            return $this->sendError(1, '验证码错误', 200);
        }

// dump($password);
// dump($user['password']);
// die;

        // 判断密码是否修改
        if (strlen($password) == 32 && $password == $user['password']) {
            return $this->sendSuccess(0, 'success', 200);
        }

        $inserId = db('user')->where('mobile', $mobile)->update(['password' => $password]);

        //判断是否更新成功
        if ($inserId) {
            return $this->sendSuccess(0, 'success', 200);
        } else {
            return $this->sendError(1, '密码修改失败', 200);
        }
    }

    /**
     * @title 根据原密码修改密码
     * @desc 请求方式：POST 请求地址：v1/user/modifyPasswordByOldPassword
     */
    public function modifyPasswordByOldPassword()
    {
        $data = input('post.');

        $rule = array(
            'userid'       => 'require',
            'old_password' => 'require',
            'new_password' => 'require',
        );

        $msg = array(
            'userid.require'       => '用户ID必填',
            'old_password.require' => '原密码必填',
            'new_password.require' => '新密码必填',
        );

        $validate = new Validate($rule,$msg);
        $validate_result = $validate->check($data);

        // 验证字段
        if (empty($validate_result)) {
            return $this->sendError(1, $validate->getError(), 200);
        }

        $userid = $data['userid'];                       // 用户ID
        $old_password = md5($data['old_password']);      // 原密码
        $new_password = md5($data['new_password']);      // 新密码

        $user = Db::name('user')->where(['id'=>$userid,'password'=>$old_password])->find();

        // 验证原密码
        if ($user) {
            // 更新密码
            $result = Db::name('user')->where('id',$userid)->update(['password' => $new_password]);

            if ($result) {
                return $this->sendSuccess('','修改密码成功', 200);
            } else {
                return $this->sendError(-1, '密码未变更', 200);
            }
        } else {
            return $this->sendError(-1, '原密码错误', 200);
        }
    }

    /**
     * @title  获取附近的人
     * @return int    id          用户id
     * @return string avatar      用户头像地址
     * @return int    nickname    用户昵称
     * @return string step_number 用户当天行走步数
     * @return string distance    两个用户之间的距离
     * @return string is_follow   是否已经关注：0未关注 1关注
     * @return float  longitude   经度
     * @return float  latitude    纬度
     * @desc 请求方式：get 请求地址：v1/user/getNearbyPeople?userid=1&longitude=86.26000&latitude=35.17000
     */
    public function getNearbyPeople()
    {
        $data      = input('get.');
        $userid    = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid    = input('get.userid');
        $latitude  = input('get.latitude');
        $longitude = input('get.longitude');
        $page      = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize  = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量 

        if (empty($latitude) || empty($longitude)) {
            return $this->sendError(-1, '需要经纬度信息', 200);
        }

        // 计算当前用户位置范围内符合条件的用户
        $location = new Location();
             
        // 附近排序原理：先筛选附近1公里，按最近排序前50个的人，若不足够50个，则继续加1公里筛选，一直往后筛选
        $Finduser = $location->searchNearbyStepSort($latitude, $longitude, $page, $pageSize);  // 参数：纬度、经度、当前分页、每页数量

        if (isset($Finduser['data'])) {
            $user = $Finduser['data'];
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }

        // 计算两个用户之间的距离差
        foreach ($user as $key => $value) {
            // 参数：纬度1 经度1 纬度2 经度2
            $destance = $location->calcDistance($latitude, $longitude, $value['latitude'], $value['longitude']);
            // 单位转换  计算出当前位置与附近人的距离（米）
            $user[$key]['distance'] = $destance * 1000;

            unset($destance);
        }
        unset($key, $value);

// dump($user);
// exit();

        // 追加是否关注信息
        foreach ($user as $key => $value) {
            $follow_user = db('user_follow')->where(['userid' => $userid, 'followid' => $value['userid']])->find();

            if ($follow_user) {
                $user[$key]['is_follow'] = 1;
            } else {
                $user[$key]['is_follow'] = 0;
            }

            unset($follow_user);
        }

        // if ($user) {
        //     // 对附近用户进行距离排序
        //     $userInfo = arraySort($user, 'distance', 'asc');

        //     if ($userInfo) {
        //         return $this->sendSuccess($userInfo, 'success', 200);
        //     } else {
        //         return $this->sendError(-1, '排序错误', 200);
        //     }
        // } else {
        //     return $this->sendError(1, 'Not found Data', 200);
        // }

        if ($user) {
            $resData['pagenation'] = $Finduser['pagenation'];
            $resData['data']       = $user;

            return $this->sendSuccess($resData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title  判断手机号码是否已经注册
     * @author wensen 2018-03-27
     * @return int    error    状态码：-1失败|0手机号码不存在可直接绑定|1手机号码存在可强制绑定
     * @return string message  错误信息
     * @desc 请求方式：POST 请求地址：v1/user/chcekMobile
     */
    public function chcekMobile()
    {
        {   // 校验数据
            $rule = array(
                'userid' => 'require',
                'mobile' => 'require|length:11',
            );

            $msg = array(
                'userid.require' => '用户ID必填',
                'mobile.require' => '手机号必填',
                'mobile.length'  => '手机号为11位数字',
            );

            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(-1, $validate->getError(), 400);
            }

            $Userid = $data['userid'];
            $Mobile = $data['mobile'];
        }

        // 根据手机获取用户数据
        $user_data_mobile = Db::name('user')->field(true)->where('mobile', $mobile)->find();

        if (empty($user_data_mobile)) {
            return $this->sendError(0, '手机号码不存在', 200);
        } else {
            return $this->sendError(1, '手机号码存在', 200);
        }
    }

    /**
     * @title  绑定手机号（第三方注册成功）
     * @author wensen 2018-03-24
     * @return int    error    状态码：-1失败|0成功|2验证码匹配失败|3手机号码已被绑定|4用户不存在|5该第三方已经绑定手机号码|6第三方注册失败
     * @return string message  错误信息
     * @desc 请求方式：POST 请求地址：v1/user/bindMobile
     */
    public function bindMobile()
    {   
        $data = input('post.');
        $data['userid'] = input('post.userid') ? intval(input('post.userid')) : intval($this->userId);

        {   // 校验数据
            $rule = array(
                'userid'   => 'require|gt:0',
                'mobile'   => 'require|length:11',
                'code'     => 'require',
                'password' => 'require|length:32',
            );

            $msg = array(
                'userid.require'   => '用户id必填',
                'userid.gt'        => '用户id必须大于0',
                'mobile.require'   => '手机号必填',
                'mobile.length'    => '手机号为11位数字',
                'code.require'     => '验证码必填',
                'password.require' => '密码必填',
                'password.length'  => '密码必须位MD5加密后的32位英文小写字符串',
            );

            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(-1, $validate->getError(), 200);
            }

            $Userid   = $data['userid'];
            $mobile   = $data['mobile'];
            $code     = $data['code'];
            $password = md5($data['password']);
        }

        // 校验验证码
        $cache_code = cache($mobile . '_code');
        if (empty($cache_code) || ($cache_code != $code)) {
            return $this->sendError(2, '验证码匹配失败', 200);
        }

        // 根据手机获取用户数据（手机号存在不能绑定）
        $user_data_mobile = Db::name('user')->field('password', true)->where('mobile', $mobile)->find();
        if (!empty($user_data_mobile)) {
            return $this->sendError(3, '手机号码已被绑定', 200);
        }

        // 根据userid获取用户数据
        $Userthree = Db::name('user')
            ->field('id,wx_unionid,wx_openid,qq_openid,mobile')
            ->where('id', $Userid)
            ->find();

        if (empty($Userthree)) {
            return $this->sendError(4, '用户不存在', 200);
        } elseif (!empty($Userthree['mobile'])) {
            return $this->sendError(5, '该第三方已经绑定手机号码', 200);
        } elseif (empty($Userthree['wx_unionid']) && empty($Userthree['wx_openid']) && empty($Userthree['qq_openid'])) {
            return $this->sendError(6, '第三方注册失败', 200);
        }

        $here_UPDATE['mobile']   = $mobile;
        $here_UPDATE['password'] = $password;
        $result = Db::name('user')->where('id', $Userid)->update($here_UPDATE);

        if ($result) {
            return $this->sendSuccess(0, '绑定成功', 200);
        } else {
            return $this->sendError(-1, '绑定失败', 400);
        }
    }

    /**
     * @title  三方绑手机(删除openid，强制绑定)
     * @author wensen 2018-03-24
     * @return int    error    状态码：-1失败|0成功|1验证匹配失败|2第三方注册失败|3该第三方已经绑定手机号码
     * @return string message  错误信息
     * @desc 请求方式：POST 请求地址：v1/user/forceBindMobile
     */
    public function forceBindMobile()
    {   
        $data = input('post.');
        $data['userid'] = input('post.userid') ? intval(input('post.userid')) : intval($this->userId);

        {   // 校验数据
            $rule = array(
                'action' => 'require',
                'openid' => 'require',
                'mobile' => 'require|length:11',
                'code'   => 'require',
            );

            $msg = array(
                'action.require' => '登录方式必填',
                'openid.require' => 'openid必填',
                'mobile.require' => '手机号必填',
                'mobile.length'  => '手机号为11位数字',
                'code.require'   => '验证码必填',
            );

            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(-1, $validate->getError(), 400);
            }

            $action = $data['action'];
            $openid = $data['openid'];
            $mobile = $data['mobile'];
            $code   = $data['code'];
        }

        // 校验验证码
        $cache_code = cache($mobile . '_code');
        if (empty($cache_code) || ($cache_code != $code)) {
            return $this->sendError(1, '验证匹配失败', 400);
        }

        // 根据手机获取用户数据（手机号存在不能绑定）
        $user_data_mobile = Db::name('user')->field(true)->where('mobile', $mobile)->find();
        if (!empty($user_data_mobile)) {
            $Userid_mobile = $user_data_mobile['id'];    // 手机账号的用户id
        }

        // 根据openid获取用户数据
        if ($action == 'wx') {
            $user_data_third = Db::name('user')->field(true)->where('wx_openid', $openid)->find();
        } elseif ($action == 'qq') {
            $user_data_third = Db::name('user')->field(true)->where('qq_openid', $openid)->find();
        }

        if (empty($user_data_third)) {
            return $this->sendError(2, '第三方注册失败', 400);
        } elseif (!empty($user_data_third['mobile'])) {
            return $this->sendError(3, '该第三方已经绑定手机号码先解绑', 400);
        } else {
            $Userid_third = $user_data_third['id'];    // 第三方账号的用户id
        }

        if (empty($Userid_mobile)) {     // 直接绑定手机到第三方账号下
            $mobile_UPDATE['mobile'] = $mobile;
            $res = Db::name('user')->field(true)->where('id', $Userid_third)->update($mobile_UPDATE);

        } elseif (!empty($Userid_mobile) && !empty($Userid_third)) {    // 将第三方的openid对应的用户数据删除并合并到手机账号下
            Db::startTrans();
            try {
                if ($action == 'wx') {
                    $third_UPDATE['wx_openid'] = $openid;
                } elseif ($action == 'qq') {
                    $third_UPDATE['qq_openid'] = $openid;
                }

                // 将第三方的openid合并到手机账号下
                $res = Db::name('user')->field(true)->where('id', $Userid_mobile)->update($third_UPDATE);

                // 删除三方的用户数据
                $res = Db::name('user')->field(true)->where('id', $Userid_third)->delete();

                // 转移圈子
                // 转移关注
                // 转移交易信息
                // 转移收入数据
                // 转移动态数据
                // 转移评论数据

                Db::commit();
                // return $this->sendSuccess(0, '绑定成功', 200);
            } catch (\Exception $e) {
                Db::rollback();
                return $this->sendError(-1, '绑定失败', 200);
            }
        }

        if (empty($res)) {
            return $this->sendError(-1, '绑定失败', 200);
        } else {
            return $this->sendSuccess(0, '绑定成功', 200);
        }
    }

    /**
     * @title  绑定第三方（用户存在）
     * @return int    error    状态码：-1失败|0成功|1用户数据不存在|2已经绑定其他账号，先解绑
     * @return string message  错误信息
     * @desc 请求方式：POST 请求地址：v1/user/bindOpenid
     */
    public function bindOpenid()
    {
        $data = input('post.');
        $data['userid'] = input('userid') ? intval(input('userid')) : intval($this->userId);

        $rule = array(
            'action'  => 'require',
            'unionid' => 'require',
            'openid'  => 'require',
            'userid'  => 'require'
        );

        $msg = array(
            'action.require'  => '登录方式必填',
            'unionid.require' => 'unionid必填',
            'openid.require'  => 'openid必填',
            'userid.require'  => '用户ID必填',
        );

        $validate = new Validate($rule,$msg);
        $validate_result = $validate->check($data);

        if (empty($validate_result)) {
            return $this->sendError(1, $validate->getError(), 200);
        }
        
        $action  = $data['action'];
        $userid  = $data['userid'];
        $openid  = $data['openid'];
        $unionid = $data['unionid'];

        {   // 检测用户是否存在
            $user = Db::name('user')->field('password', true)->where('id', $userid)->find();

            if (empty($user)) {
                return $this->sendError(1, '用户数据不存在', 200);
            }
        }

        {   // 检测unionid是否存在
            $unionid_WHERE = [];

            if ($action == 'wx') {
                $unionid_WHERE['wx_unionid'] = $unionid;
            } elseif ($action == 'qq') {
                $unionid_WHERE['qq_unionid'] = $unionid;
            } else {
                return $this->sendError(1, 'Not Found Action', 200);
            }

            $open_user = Db::name('user')
                ->where($unionid_WHERE)
                ->where('id', '<>', $user['id'])
                ->find();

            if (!empty($open_user)) {
                return $this->sendError(1, '当前第三方已绑定其他账号', 200);
            }
        }

// dump($user);
// dump($unionid_WHERE);
// dump($open_user);
// die;

        // 判断qq、微信
        if ($action == 'wx') {    // 如果是绑定微信
            if ($user['wx_unionid'] == $unionid) {    // 解绑
                return $this->sendSuccess(0, '绑定成功', 200);
            } elseif ($user['wx_unionid'] != $unionid) {
                $data['wx_unionid'] = $unionid;
                $data['wx_openid']  = $openid;
            }
        } elseif ($action == 'qq') {    // 如果是绑定qq
            if ($user['qq_openid'] == $unionid) {    // 解绑
                return $this->sendSuccess(0, '绑定成功', 200);
            } elseif ($user['qq_openid'] != $unionid) {
                $data['qq_unionid'] = $unionid;
                $data['qq_openid']  = $openid;
            }
        }

        // 执行更新数据
        $result = Db::name('user')->where('id', $userid)->update($data);

        if ($result) {
            return $this->sendSuccess(0, '绑定成功', 200);
        } else {
            return $this->sendError(1, '绑定失败', 200);
        }
    }

    /**
     * @title 手机号登录（编号登录）
     * @return array  用户信息
     * @return string user_token 秘钥
     * @desc 请求方式：POST 请求地址：v1/user/login
     */
    public function login()
    {
        // // 写入用户登录记录
        // $Userlog = new Loginlog();
        // $Userlog->addLog(66, 1, 1, 2, 'ghdjrtdrtdjdjt123');
        // exit();

        $data = input('post.');

        $rule = [
            'mobile'   => 'require|number',
            'password' => 'require|length:6,32',
        ];

        $msg = [
            'mobile.require'   => '账号必须',
            'mobile.length'    => '账号为数字',
            'password.require' => '密码必须',
            'password.length'  => '密码为6-32位之间',
        ];

        //验证数据是否合法
        $validate = new Validate($rule, $msg);
        $result   = $validate->check($data);

        if (empty($result)) {
            return $this->sendError(-1, $validate->getError(), 400);
        }

        $mobile       = $data['mobile'];
        $password     = md5($data['password']);
        $login_number = cache($mobile);
        $Side         = empty($data['side']) ? 0 : intval($data['side']);

        if ($login_number && $login_number >= 5) {
            return $this->sendError(-1, '输入密码错误次数超过5次，请在10分钟后再登录', 400);
        }

        // 查询是否存在此用户
        $user = db('user')
            // ->field('password', true)
            ->field('id,no,wx_unionid,wx_openid,qq_openid,nickname,avatar,target_step,province,city,sex,levelid,create_time,logintimes,is_perfect,vip,cusvip')
            ->where(['mobile|no' => $mobile, 'password' => $password])
            // ->fetchSql(true)
            ->find();

        // 用户名或密码错误
        if (empty($user)) {
            $login_number = $login_number + 1;
            cache($mobile, $login_number, 600);
            
            return $this->sendError(-1, '用户名或密码错误', 400);
        }

        db('user')->where('mobile', $mobile)->setInc('logintimes', 1);

        // token处理类
        $accessToken = new AccessToken();
        $accessToken = $accessToken->getToken($user['id']);
        
        if (empty($accessToken)) {
            return $this->sendError(-1, '秘钥生成失败', 400);
        } else {
            $user['user_token'] = $accessToken;
        }

        // 写入用户登录记录
        @$Userlog = new Loginlog();
        @$Userlog->addLog($user['id'], 1, $Side, 1, $mobile);

        return $this->sendSuccess($user, '登录成功', 200);
    }

    
    /**
     * @title 手机验证码登录（并注册）
     * @return int    error        错误代码：0成功 1失败
     * @return string message      错误信息
     * @return array  data         返回数组
     * @return int    id           用户id
     * @return string nickname     用户昵称
     * @return string mobile       手机号
     * @return string avatar       头像地址
     * @return string vip          会员：0否|1是
     * @return string cusvip       商户会员：0否|1是
     * @return string levelid      段位ID（具体查看获取段位接口）
     * @return string user_token   秘钥
     * @desc 请求方式：POST 请求地址：v1/user/mobileCodeRegister
     */
    public function mobileCodeRegister()
    {
        {   // 数据过滤
            $Mobile = input('post.mobile');
            $Code   = input('post.code');
            $Side   = (intval(input('post.side')) > 0) ? intval(input('post.side')) : 0;

            if (!preg_match("/^1[34578]\d{9}$/", $Mobile)) {
                return $this->sendError(-1, '手机号格式错误', 400);
            }

            if (!preg_match("/^\d{6}$/", $Code)) {
                return $this->sendError(-1, '验证码格式错误', 400);
            }
        }

        // $Old_code = cache($Mobile . '_code', '123456', 60);

        // 匹配验证码 
        $Old_code = cache($Mobile . '_code');

        if ($Old_code != $Code) {
            return $this->sendError(-1, '验证码错误', 400);
        }

        // 判断是否有对应的手机号
        $Olduser = db('user')->field('id,no,mobile,nickname,avatar,vip,cusvip')->where('mobile', $Mobile)->find();

        if (empty($Olduser)) {    // 不存在，添加用户
            // 新数据
            $user_INSERT = [
                // 'id'       => getNewUserid(),
                'no'       => getNewUserNo(),
                'mobile'   => $Mobile,
                'avatar'   => 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_h.png',
                'nickname' => 'rm_' . $Mobile,
                'levelid'  => 1,
            ];

            $Newuserid = db('user')->insertGetId($user_INSERT);
            
            if (empty($Newuserid)) {
                return $this->sendError(-1, '添加用户出错', 400);
            } else {
                $Olduser = $user_INSERT;
                $Olduser['id']     = $Newuserid;
                $Olduser['vip']    = 0;
                $Olduser['cusvip'] = 0;

                {   // 注册成功发表动态
                    $dynamic_data['userid']   = $Newuserid;
                    $dynamic_data['dynamic']  = base64_encode('号外！号外！我加入跑步钱进了，大家一起走路领红包吧！');
                    $dynamic_data['images'][] = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_d.png';
                    $dynamic_data['images']   = serialize($dynamic_data['images']);
                    $dynamic_data['create_time'] = time();
                    
                    $result = Db::name('dynamic')->insert($dynamic_data);
                }
            }
        } else {                  // 存在，登录
            db('user')->where('mobile', $Mobile)->setInc('logintimes', 1);
        }

        // token处理类
        $accessToken = new AccessToken();
        $accessToken = $accessToken->getToken($Olduser['id']);
        
        if (empty($accessToken)) {
            return $this->sendError(-1, '秘钥生成失败', 400);
        } else {
            $Olduser['user_token'] = $accessToken;
        }

        // 写入用户登录记录
        @$Userlog = new Loginlog();
        @$Userlog->addLog($Olduser['id'], 1, $Side, 4, $mobile);

        return $this->sendSuccess($Olduser, '登录成功', 200);
    }


    /**
     * @title 第三方登录
     * @return int    error        错误代码：0成功 1失败
     * @return string message      消息提醒
     * @return array  data         用户信息
     * @return int    id           用户id
     * @return string wx_unionid   微信unionid
     * @return string wx_openid    微信openid
     * @return string qq_unionid    QQunionid
     * @return string qq_ios_openid QQIOSopenid
     * @return string qq_ad_openid  QQ安卓openid
     * @return string mobile       手机号
     * @return int    nickname     昵称
     * @return string avatar       头像地址
     * @return string levelid      段位ID  具体查看获取段位接口 
     * @return string sex          性别
     * @return string vip          会员：0否|1是
     * @return string cusvip       商户会员：0否|1是
     * @return string user_token   秘钥
     * @desc 请求方式：POST 请求地址：v1/user/thirdPartyLogin
     */
    public function thirdPartyLogin()
    {
        $data   = input('post.');
        $action = isset($data['action']) ? $data['action'] : '';
        $Side   = empty($data['side']) ? 0 : intval($data['side']);
        
        // 获取用户数据的条件
        $here_WHERE = [];

        {   // 数据验证
            $rule = array(
                'unionid' => 'require',
                'openid'  => 'require',
            );
            // 'nickname'  => 'require',
            // 'avatar'    => 'require',
            // 'sex'       => 'require|between:0,2',
            // 'province'  => 'require',
            // 'city'      => 'require',

            $msg = array(
                'unionid.require' => 'unionid必填',
                'openid.require'  => 'openid必填',
            );
            // 'nickname.require' => '用户昵称必填',
            // 'avatar.require'   => '头像必填',
            // 'sex.require'      => '性别必填',
            // 'sex.number'       => '性别只能为0,1,2',
            // 'province.require' => '省份必填',
            // 'city.require'     => '城市必填',

            // 字段验证
            $validate = new Validate($rule, $msg);
            $result   = $validate->check($data);

            if (empty($result)) {
                return $this->sendError(-1, $validate->getError(), 200);
            }

            if ($action == 'wx') {
                $here_WHERE['wx_unionid'] = trim($data['unionid']);
                // $here_WHERE['wx_unionid'] = $data['openid'];
                $Wxopenid = trim($data['openid']);
            } elseif ($action == 'qq') {
                $here_WHERE['qq_unionid'] = trim($data['unionid']);

                // $here_WHERE['qq_openid'] = $data['openid'];
                $Qqopenid = trim($data['openid']);
            } else {
                return $this->sendError(-1, 'Not Found Action', 200);
            }
        }

        // 新数据
        $user_INSERT = [
            'nickname'   => isset($data['nickname']) ? $data['nickname'] : 'rm_' . rand(10000, 99999),
            'avatar'     => empty($data['avatar']) ? 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_h.png' : $data['avatar'],
            'province'   => empty($data['province']) ? '' : $data['province'],
            'city'       => empty($data['city']) ? '' : $data['city'],
            'sex'        => isset($data['sex']) ? intval($data['sex']) : 0,
            'levelid'    => 1,
        ];

        // 查询该微信或qq用户是否授权过登录
        $user_info = db('user')
            ->field('
                id,no,wx_unionid,wx_openid,qq_unionid,qq_openid,qq_ad_openid,
                nickname,avatar,target_step,province,city,sex,levelid,create_time,
                logintimes,is_perfect,vip,cusvip
            ')
            ->where($here_WHERE)
            ->find();
            // ->select();

// dump($user_info);
// die;
        // 用户存在更新用户
        if (!empty($user_info)) {
            $user_UPDATE['logintimes'] = $user_info['logintimes'] + 1;

            // if (isset($user_INSERT['nickname']) && ($user_INSERT['nickname'] != $user_info['nickname'])) {
            //     $user_UPDATE['nickname'] = $user_INSERT['nickname'];
            // }
            // if (isset($user_INSERT['avatar']) && ($user_INSERT['avatar'] != $user_info['avatar'])) {
            //     $user_UPDATE['avatar'] = $user_INSERT['avatar'];
            // }
            // if (isset($user_INSERT['province']) && ($user_INSERT['province'] != $user_info['province'])) {
            //     $user_UPDATE['province'] = $user_INSERT['province'];
            // }
            // if (isset($user_INSERT['city']) && ($user_INSERT['city'] != $user_info['city'])) {
            //     $user_UPDATE['city'] = $user_INSERT['city'];
            // }
            // if (isset($user_INSERT['sex']) && ($user_INSERT['sex'] != $user_info['sex'])) {
            //     $user_UPDATE['sex'] = $user_INSERT['sex'];
            // }

            if (isset($Wxopenid) && ($Wxopenid != $user_info['wx_openid'])) {
                $user_UPDATE['wx_openid'] = $Wxopenid;
            }

            if (isset($Qqopenid) && ($Qqopenid != $user_info['qq_openid'])) {
                $user_UPDATE['qq_openid'] = $Qqopenid;
            }
            $res = db('user')->where(['id'=>$user_info['id']])->update($user_UPDATE);

        } else {    // 用户不存在添加用户

            unset($user_info);

            $user_info = $user_INSERT;

            if ($action == 'wx') {
                $user_info['wx_unionid'] = trim($data['unionid']);
                $user_info['wx_openid']  = trim($data['openid']);
                $Pattern = 2;
            } elseif ($action == 'qq') {
                $user_info['qq_unionid'] = trim($data['unionid']);
                $user_info['qq_openid']  = trim($data['openid']);
                $Pattern = 3;

                if ($Side == 1) {
                    $user_info['qq_openid'] = $data['openid'];
                } elseif ($Side == 2) {
                    $user_info['qq_openid'] = $data['openid'];
                }
            }

            $user_info['create_time'] = time();
            $user_info['is_perfect']  = 0;
            $user_info['no']          = getNewUserNo();

            $Newuserid = db('user')->insertGetId($user_info);

            if (empty($Newuserid)) {
                return $this->sendError(-1, '登录错误', 400);
            } else {
                $user_info['id']          = $Newuserid;
                $user_info['vip']         = 0;
                $user_info['cusvip']      = 0;
                $user_info['target_step'] = 10000;

                {   // 注册成功发表动态
                    $dynamic_data['userid']   = $Newuserid;
                    $dynamic_data['dynamic']  = base64_encode('号外！号外！我加入跑步钱进了，大家一起走路领红包吧！');
                    $dynamic_data['images'][] = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_d.png';
                    $dynamic_data['images']   = serialize($dynamic_data['images']);
                    $dynamic_data['create_time'] = time();

                    $result = Db::name('dynamic')->insert($dynamic_data);
                }
            }
        }

        // 生成用户token（token处理类）
        $accessToken = new AccessToken();
        $accessToken = $accessToken->getToken($user_info['id']);
        if (empty($accessToken)) {
            return $this->sendError(-1, '秘钥生成失败', 400);
        } else {
            $user_info['user_token'] = $accessToken;
        }

        // 写入用户登录记录
        @$Userlog = new Loginlog();
        @$Userlog->addLog($user_info['id'], 1, $Side, $Pattern, $data['openid']);

        return $this->sendSuccess($user_info, '登录成功', 200);
    }

    /**
     * @title  退出登录
     * @return int    error   状态码：-1失败 0成功
     * @return string message 相应描述
     * @desc 请求方式：POST   请求地址：v1/user/logOut
     */
    public function logOut()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        
        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        // 删除token
        $accessToken = new AccessToken();
        $res = $accessToken->destroyToken($Userid);
        
        if ($res == true) {
            return $this->sendSuccess(0, '退出成功', 200);
        } else {
            return $this->sendError(-1, '退出失败', 400);
        }
    }

    /**
     * @title  刷新秘钥
     * @return int    error      状态码：-1失败|0成功
     * @return string message    相应描述
     * @return array  data       返回数组
     * @return int    userid     用户id
     * @return string user_token 用户秘钥
     * @desc 请求方式：POST   请求地址：v1/user/refreshToken
     */
    public function refreshToken()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        // 小程序用户ID处理
        if ($Userid == 0) {
            $Userid = intval(input('headtoken'));
        }

        if (empty($Userid)) {
            return $this->sendError(1, '用户ID必填', 200);
        }

        $Userno = Db::name('user')->where('id', $Userid)->where('delete_id', 0)->value('no');

        if (empty($Userno)) {
            return $this->sendError(1, '用户编号获取失败', 200);
        }

        // token处理类
        $accessToken = new AccessToken();
        $Token = $accessToken->getToken($Userid);

        $res['userid']     = $Userid;
        $res['userno']     = $Userno;
        $res['user_token'] = $Token;

        if ($res == true) {
            return $this->sendSuccess($res, 'sccess', 200);
        } else {
            return $this->sendError(1, '刷新秘钥失败', 200);
        }
    }

    /**
     * @title  检查用户绑定状态
     * @return int    error      状态码：1失败|0成功
     * @return string message    相应描述
     * @return array  data       返回数组
     * @return int    mobile     是否绑定手机：   0否|1是
     * @return int    xcx        是否绑定小程序： 0否|1是
     * @return int    wx         是否绑定微信：   0否|1是
     * @return int    qq         是否绑定qq：     0否|1是
     * @desc 请求方式：GET  请求地址：v1/user/checkUserStatus
     */
    public function checkUserStatus()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        if (empty($Userid)) {
            return $this->sendError(1, '用户ID必填', 200);
        }

        $Userdata = db('user')->field('id,mobile,wx_unionid,xcx_openid,qq_unionid')->where('id', $Userid)->find();

        if (empty($Userdata)) {
            return $this->sendError(1, 'error', 200);
        }

        $res['mobile'] = 0;
        $res['xcx']    = 0;
        $res['wx']     = 0;
        $res['qq']     = 0;

        if ($Userdata['mobile'] > 0) {
            $res['mobile'] = 1;
        }

        if (!empty($Userdata['xcx_openid'])) {
            $res['xcx'] = 1;
        }

        if (!empty($Userdata['wx_unionid'])) {
            $res['wx'] = 1;
        }

        if (!empty($Userdata['qq_unionid'])) {
            $res['qq'] = 1;
        }

        if ($res == true) {
            return $this->sendSuccess($res, 'sccess', 200);
        } else {
            return $this->sendError(1, 'error', 200);
        }
    }

    /**
     * @title  解绑账号（手机、微信、qq）
     * @return int    error    状态码：1失败|0成功
     * @return string message  相应描述
     * @return array  data     返回数组
     * @desc 请求方式：POST 请求地址：v1/user/userUntie
     */
    public function userUntie()
    {
        $Action = input('action') ? input('action') : '';
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        $actionArray = ['mobile', 'wx', 'qq'];
        if (!in_array($Action, $actionArray)) {
            return $this->sendError(1, 'Not Found Action', 200);
        }

        $Userdata = db('user')->field('id,mobile,wx_unionid,qq_unionid')->where('id', $Userid)->find();

        if (empty($Userdata)) {
            return $this->sendError(1, 'error', 200);
        }

        $sign = 0;
        if ($Userdata['mobile'] > 0) {
            $here['mobile'] = 1;
            ++$sign;
        }
        if (!empty($Userdata['wx_unionid'])) {
            $here['wx'] = 1;
            ++$sign;
        }
        if (!empty($Userdata['qq_unionid'])) {
            $here['qq'] = 1;
            ++$sign;
        }

        if ($sign <= 1) {
            return $this->sendError(1, 'QQ、微信、手机至少要有一方绑定', 200);
        }

        $here_UPDATE = [];
        if ($Action == 'mobile' && $here['mobile'] == 1) {
            $here_UPDATE['mobile']     = '';
        } elseif ($Action == 'wx' && $here['wx'] == 1) {
            $here_UPDATE['wx_unionid'] = '';
        } elseif ($Action == 'qq' && $here['qq'] == 1) {
            $here_UPDATE['qq_unionid'] = '';
        }

        if (empty($here_UPDATE)) {
            return $this->sendSuccess('', 'success', 200);
        }

        $res = db('user')->where('id', $Userid)->update($here_UPDATE);

        if (empty($res)) {
            return $this->sendError(1, 'error', 200);
        } else {
            return $this->sendSuccess('', 'success', 200);
        }
    }
    

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'save' => [
                'mobile' => [
                    'name'    => 'mobile', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户手机号', 
                    'range'   => '指定长度: 11',
                ],
                'password' => [
                    'name'    => 'password', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '密码', 
                    'range'   => '最小长度:6 &nbsp; 最大长度:32',
                ],
                'code' => [
                    'name'    => 'code', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '验证码', 
                    'range'   => '',
                ],
            ],
            'update' => [
                'nickname' => [
                    'name'    => 'nickname', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '昵称', 
                    'range'   => '',
                ],
                'avatar' => [
                    'name'    => 'avatar', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '头像', 
                    'range'   => '',
                ],
                'sex' => [
                    'name'    => 'sex', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '性别 0男 1女', 
                    'range'   => '',
                ],
                'birthyear' => [
                    'name'    => 'birthyear', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '生年',
                    'range'   => '',
                ],
                'birthmonth' => [
                    'name'    => 'birthmonth', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '生月',
                    'range'   => '',
                ],
                'birthday' => [
                    'name'    => 'birthday', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '生日',
                    'range'   => '',
                ],
                'height' => [
                    'name'    => 'height', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '身高',
                    'range'   => '',
                ],
                'weight' => [
                    'name'    => 'weight', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '体重',
                    'range'   => '',
                ],
                'province' => [
                    'name'    => 'province', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '所在省',
                    'range'   => '',
                ],
                'city' => [
                    'name'    => 'city', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '所在市',
                    'range'   => '',
                ]
            ],
            'read' => [
                'id' => [
                    'name'    => 'id', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
            ],
            'delete' => [
                'id' => [
                    'name'    => 'id', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
            ],
            'modifyPasswordByMobile' => [
                'mobile' => [
                    'name'    => 'mobile', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户手机号', 
                    'range'   => '',
                ],
                'password' => [
                    'name'    => 'password', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '密码',
                    'range'   => '',
                ],
                'code' => [
                    'name'    => 'code', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '验证码', 
                    'range'   => '',
                ],
            ],
            'modifyPasswordByOldPassword'    => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'old_password' => [
                    'name'    => 'old_password', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '原密码',
                    'range'   => '',
                ],
                'new_password' => [
                    'name'    => 'new_password', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '新密码', 
                    'range'   => '',
                ],
            ],
            'getNearbyPeople' => [
                'latitude' => [
                    'name'    => 'latitude', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '位置纬度', 
                    'range'   => '',
                ],
                'longitude' => [
                    'name'    => 'longitude', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '位置经度', 
                    'range'   => '',
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'chcekMobile' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'mobile' => [
                    'name'    => 'mobile', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '11位手机号码', 
                    'range'   => '',
                ],
            ],
            'bindMobile'  => [
                'userid'  =>  [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id必填', 
                    'range'   => '',
                ],
                'mobile' =>  [
                    'name'    => 'mobile', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '绑定的手机号', 
                    'range'   => '',
                ],
                'code' =>  [
                    'name'    => 'code', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '验证码', 
                    'range'   => '',
                ],
                'password' =>  [
                    'name'    => 'password', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '登录密码：32位小写的md5', 
                    'range'   => '',
                ],
            ],
            'forceBindMobile'  => [
                'action'  =>  [
                    'name'    => 'action', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户类型：wx|qq', 
                    'range'   => '',
                ],
                'openid' =>  [
                    'name'    => 'openid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信或者QQ的openid', 
                    'range'   => '',
                ],
                'mobile' =>  [
                    'name'    => 'mobile', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '绑定的手机号', 
                    'range'   => '',
                ],
                'code' =>  [
                    'name'    => 'code', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '验证码', 
                    'range'   => '',
                ],
            ],
            'bindOpenid'  => [
                'action'  =>  [
                    'name'    => 'action', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户类型 wx qq', 
                    'range'   => '',
                ],
                'openid' =>  [
                    'name'    => 'openid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '绑定的OPENID（说明：微信、qq都传openid）', 
                    'range'   => '',
                ],
                'unionid' =>  [
                    'name'    => 'unionid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信或qq的unionid必填', 
                    'range'   => '',
                ],
                'userid' =>  [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
            ],
            'login' => [
                'mboile'    =>  [
                    'name'    => 'mobile', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '手机号', 
                    'range'   => '',
                ],
                'password'    =>  [
                    'name'    => 'password', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '密码', 
                    'range'   => '',
                ],
                'side' =>  [
                    'name'    => 'side', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户端：0未知|1ios|2android|3小程序|4web', 
                    'range'   => '',
                ],
            ],
            'mobileCodeRegister' => [
                'mobile'    =>  [
                    'name'    => 'mobile', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '电话号码', 
                    'range'   => '',
                ],
                'code'    =>  [
                    'name'    => 'code', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '手机验证码', 
                    'range'   => '',
                ],
                'side'    =>  [
                    'name'    => 'side', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户端：0未知|1ios|2android|3小程序|4web', 
                    'range'   => '',
                ],
            ],
            'logOut' => [
                'userid'    =>  [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
            ],
            'thirdPartyLogin' => [
                'action'    =>  [
                    'name'    => 'action', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '登录方式：wx 微信登录 | qq QQ登录', 
                    'range'   => '',
                ],
                'openid'    =>  [
                    'name'    => 'openid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => 'openid', 
                    'range'   => '',
                ],
                'unionid'    =>  [
                    'name'    => 'unionid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => 'qq或者微信登录时候必填', 
                    'range'   => '',
                ],
                'nickname'    =>  [
                    'name'    => 'nickname', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '昵称', 
                    'range'   => '',
                ],
                'avatar'    =>  [
                    'name'    => 'avatar', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '头像', 
                    'range'   => '',
                ],
                'province'    =>  [
                    'name'    => 'province', 
                    'type'    => 'string', 
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '省份', 
                    'range'   => '',
                ],
                'city'    =>  [
                    'name'    => 'city', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '城市', 
                    'range'   => '',
                ],
                'sex'    =>  [
                    'name'    => 'sex', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '性别：0未知|1男|2女', 
                    'range'   => '',
                ],
                'side' =>  [
                    'name'    => 'side', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户端：0未知|1ios|2android|3小程序|4web', 
                    'range'   => '',
                ],
            ],
            'refreshToken' => [
                'userid'    =>  [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
            ],
            'userUntie' => [
                'action'    =>  [
                    'name'    => 'action', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '需要解绑的：mobile手机|wx微信|qq腾讯QQ', 
                    'range'   => '',
                ],
                'userid'    =>  [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    public static function getScanFields()
    {
        return [
            'login'=>[
                'mobile',
            ]
        ];
    }
}

