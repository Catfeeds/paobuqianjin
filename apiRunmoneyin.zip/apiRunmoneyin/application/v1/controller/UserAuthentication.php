<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:40
// +----------------------------------------------------------------------
// | TITLE: 用户身份认证接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Db;
use think\Request;
use think\Validate;
use think\Log;
use app\v1\extend\JuheIdcardQuery;
use app\v1\extend\AliyunVerifyIdcard;
use app\v1\extend\HelibaoInt;
use app\v1\extend\BankCarData;
use helibao\Crypt_RSA;

/**
 * Class  User
 * @title 用户身份认证接口
 * @url   v1/userauthentication
 * @desc  用户身份认证接口、用户认证、获取用户认证状态
 * @version 1.0
 */
class UserAuthentication extends Base
{
    // 附加方法
    protected $extraActionList = [
        'userAuthState', 'realAuth'
    ];

    // 跳过验证方法
    protected $skipAuthActionList = ['wapPay','scanPay','quickPayNotify','splitBillPay'];

    protected $rule = [
        'userid'   => 'require',
        'realname' => 'require',
        'idcard'   => 'require|length:18',
    ];

    protected $msg = [
        'userid.require'   =>  '用户ID必填',
        'realname.require' =>  '真实姓名必填',
        'idcard.require'   =>  '身份证号码必填',
        'idcard.length'    =>  '身份证号码为18位数',
    ];

    // /**
    //  * @title 用户认证
    //  * @return int error 错误代码 0失败 1成功
    //  * @return string message 消息提醒
    //  * @desc 请求方式：POST <br/>地址：v1/userauthentication
    //  */
    // public function save()
    // {
    //     $aliyunVerifyIdcard = new AliyunVerifyIdcard(array('AppCode'=>'ff5736e074164fa39b3d970536cff56e'));
    //     $result = $aliyunVerifyIdcard->IdcardQuery('陈杰','36073119920626821X');
    //     halt($result);

    //     $data = input('post.');
    //     //验证数据是否合法
    //     $validate = new Validate($this->rule,$this->msg);
    //     $result   = $validate->check($data);
    //     if($result){
    //         $JuheIdcardQuery = new JuheIdcardQuery(array('AppKey'=>'5c7efc95092d67cb51df123a2e3ad509'));
    //         $result = $JuheIdcardQuery->idcard_query($data['realname'],$data['idcard']);

    //         if($result) {
               
    //             $data['status'] = 1;
    //             $data['create_time'] = time();
    //             Db::name('user_authentication')->insert($data);

    //             $idcartInfo = getIDCardInfo($data['idcard']);
    //             //$age = calcAge($idcartInfo['tdate']);

    //             // 更新用户信息
    //             Db::name('user')
    //             ->where('id',$data['userid'])
    //             ->update([
    //               'birthyear' => $idcartInfo['tyear'],
    //               'birthmonth' => $idcartInfo['tmonth'],
    //               'birthday' => $idcartInfo['tday'],
    //             ]);
    //             return $this->sendSuccess('', '认证成功', 200);
    //         }else{
    //             return $this->sendError(-1, $JuheIdcardQuery->error, 400);
    //         }
    //     }else{
    //         return $this->sendError(-1, $validate->getError(), 400);
    //     }
    // }

    /**
     * @title 获取用户认证状态
     * @return int error          错误代码：0成功 1失败
     * @return string message     消息提醒
     * @return object data        用户认证对象
     * @return int    userid      用户ID
     * @return int    realname    真实姓名
     * @return string idcard      身份证号码
     * @return int    status      认证状态：0未认证 1认证通过
     * @return string remark      审核备注
     * @return int    create_time 创建时间
     * @desc 获取用户认证状态，请求方式：get <br/> 地址：v1/userauthentication/userAuthState
     */
    public function userAuthState() 
    {
        $userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        $Userdata = db('user')
            ->field('password', true)
            ->where('id', $userid)
            // ->where('isreal', 0)
            ->find();

        $status = db('user_authentication')
            ->field('id', true)
            ->where('userid', $userid)
            ->find();

        if (empty($status)) {
            $status['userid']   = $Userdata['id'];
            $status['realname'] = '';
            $status['idcard']   = '';
            $status['status']   = 0;
        }

        return $this->sendSuccess($status, 'success', 200);
    }

    /**
     * @title  实名制、绑定银行卡（4要素实名制）
     * @return int    error   错误代码  0成功 1失败
     * @return string message 消息提醒
     * @return array  data    返回数据
     * @desc 合利宝鉴权，请求方式：POST <br/> 地址：v1/userauthentication/realAuth
    */
    public function realAuth()
    {
        // $data = input('post.');
        // $bankData['bank_code'] = BankCarData::getBankCode($data['cardno']);
        // $bankData['bank_name'] = BankCarData::getBankname();
        // dump($bankData);
        // die;

        $cardMaxNum = 2;    // 每人绑卡张数
        $data = input('post.');
        $data['userid'] = input('userid') ? intval(input('userid')) : intval($this->userId);

        if (!isset($data['cardno'])) {
            return $this->sendError(1, '银行卡号必填', 200);
        } else {
            $carddata = BankCarData::getBankCardData($data['cardno']);

	        if ($carddata['iscreditcard'] == 2) {       // 信用卡
                return $this->sendError(1, '不能绑信用卡', 200);

                // if(empty($data['cyear'])) {
                //     return $this->sendError(1, '信用卡到期年份必填', 200);
                // } elseif (empty($data['cday'])) {
                //     return $this->sendError(1, '信用卡到期月份必填', 200);
                // } elseif(empty($data['ccode'])) {
                //     return $this->sendError(1, '信用卡交易码必填', 200);
                // } else if(strlen($data['ccode']) <3 || strlen($data['ccode'])>6) {
                //     return $this->sendError(1, '信用卡交易码长度为3-6位', 200);
                // }
            } else {
                $iscreditcard = 1;
            }

            // $carddata = BankCarData::getBankCardData($data['cardno']);
            // if ($carddata['iscreditcard'] == 2) {
            //     $iscreditcard = 2;
            // } else {
            //     $iscreditcard = 1;
            // }
        }

        {   // 实名认证判断
            $isBind = false;

            // 是否实名认证（用户表）
            $Userdata = Db::name('user')
                ->field('password', true)
                ->where('id', $data['userid'])
                ->where('isreal', 1)
                ->find();

            // 是否实名认证（认证表）
            $Realinfo = Db::name('user_authentication')
                ->field(true)
                ->where('userid', $data['userid'])
                ->where('status', 1)
                ->find();

            if (!empty($Userdata) && !empty($Realinfo)) {
                $isBind = 1;
            }

            // 用户绑卡个数
            $Carsum = Db::name('user_bank')
                ->field(true)
                ->where('userid', $data['userid'])
                ->where('is_bind', 1)
                ->select();

            if ($isBind && count($Carsum) >= $cardMaxNum) {
                return $this->sendError(1, '用户最多能绑定'.$cardMaxNum.'张卡', 200);
            }

            if (in_array($data['cardno'], array_column($Carsum, 'bank_card'))) {
                return $this->sendError(1, '该卡已绑定', 200);
            }
           
            if ($isBind && (count($Carsum) < $cardMaxNum)) {   // 已经实名认证
                $idcards = $Realinfo['idcard'];
                $data['account'] = $Realinfo['realname'];
            } else {                                           // 未名认证
                if (empty($data['idcard'])) {
                    return $this->sendError(1, '身份证号必填', 200);
                }
                $idcards = $data['idcard'];
                $data['account'] = isset($data['account']) ? $data['account'] : '';
            }
        }

        {   // 数据过滤
            $rule = [
                'userid'        => 'require|gt:0',
                'cardno'        => 'require',
                'account'       => 'require',
                'phone'         => 'require',
                'code'          => 'require',
                // 'idcard'        => 'require',
                // 'cardName'      => 'require',
            ];

            $msg = [
                'userid.require'        => '用户ID必填',
                'userid.gt'             => '用户ID必须大于0',
                'phone.require'         => '手机号必填',
                'code.require'          => '手机验证码必填',
                'account.require'       => '银行卡户名必填',
                'cardno.require'        => '银行卡账号必填',
                // 'idcard.require'        => '身份证号必填',
                // 'cardName.require'      => '银行卡类型必填',
            ];

            // 验证字段
            $validate = new Validate($rule, $msg);
            $validate_result = $validate->check($data);

            if (empty($validate_result)) {
                return $this->sendError(1, $validate->getError(), 200);
            }

            if (!preg_match("/^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$/", $data['phone'])) {
                return $this->sendError(1, '手机号码不正确', 200);
            }

            if (!preg_match("/([\d]{4})([\d]{4})([\d]{4})([\d]{4})([\d]{0,})?/", $data['cardno'])) {
                return $this->sendError(1, '银行卡号不合法', 200);
            }

            if (!isCreditNo($idcards)) {
                return $this->sendError(1, '身份证号不合法', 200);
            }
        }

        // 验证手机验证码
        $cache_code = cache($data['phone'] . '_code');
        if (empty($cache_code) || ($cache_code != $data['code'])) {
            return $this->sendError(1, '验证码匹配失败', 200);
        }
        
        $authParam['orderNum']  = date('YmdHis') . rand(100000, 999999);    // 订单编号 
        $authParam['payerName'] = $data['account'];                         // 真实名字
        $authParam['idCardNo']  = $idcards ? $idcards : '';                 // 证件号（身份证号）
        $authParam['cardNo']    = $data['cardno'];                          // 银行卡号
        $authParam['phoneNo']   = $data['phone'];                           // 手机号
        
        $authParam['cyear']   = isset($data['cyear']) ? $data['cyear'] : '';    // 信用卡到期年份
        $authParam['cday']   = isset($data['cday']) ? $data['cday'] : '';       // 信用卡到期月份
        $authParam['ccode']   = isset($data['ccode']) ? $data['ccode'] : '';    // 信用卡交易码

        $here = new HelibaoInt();                   // 合利宝集成类
        $authRes = $here->verifyAuth($authParam);   // 鉴权结果

        if (!$authRes) {                            // 参数为空
            return $this->sendError(1, '非法操作', 200);
        }

        if ($authRes['rt2_retCode'] != '0000') {    // 鉴权不成功
            return $this->sendError(1, $authRes['rt3_retMsg'], 200);
            return $this->sendError(1, '实名认证失败', 200);
        }

        {   // 实名制和绑卡处理
            Db::startTrans();    // 开启事务

            // 从未绑定，添加实名认证数据
            if (!$Realinfo && !$isBind) {
                // 添加身份证信息到实名认证表
                $insertData['realname'] = $data['account'];
                $insertData['idcard']   = $data['idcard'];
                $insertData['userid']   = $data['userid'];
                $insertData['status']   = 1;

                $insertRes = Db::name('user_authentication')->insert($insertData);

                if (empty($insertRes)) {
                    Db::rollback();
                    return $this->sendError(1, '系统出错', 200);
                }

                // 修改用户实名认证标志
                $insertRes = Db::name('user')->where('id', $data['userid'])->update(['isreal' => 1]);
            }

            // 银行卡编号
            $tempCardNo = BankCarData::getBankCode($data['cardno']);
            switch ($tempCardNo) {
                case 'CMB':                     // 招商
                    $cardNo = 'CMBCHINA';   
                    break;
                case 'SPABANK':                 // 平安  
                    $cardNo = 'PINGAN';   
                    break; 
                case 'PSBC':                    // 邮政储蓄  
                    $cardNo = 'POST';   
                    break; 
                case 'COMM':                    // 交通  
                    $cardNo = 'BOCO';   
                    break;   
                default:
                    $cardNo = $tempCardNo;
                    break;
            }

            // 添加银行卡
            $bankData['userid']       = $data['userid'];
            $bankData['account_name'] = $data['account'];
            $bankData['bank_card']    = $data['cardno'];
            $bankData['bank_phone']   = $data['phone'];
            $bankData['bank_code']    = $cardNo;
            $bankData['bank_name']    = BankCarData::getBankname();
            $bankData['iscreditcard'] = $iscreditcard;

            if($iscreditcard == 2) {
                $bankData['cyear'] = $authParam['cyear'];       // 信用卡到期年份
                $bankData['cday'] = $authParam['cday'];         // 信用卡到期月份
                $bankData['ccode'] = $authParam['ccode'];       // 信用卡交易码
            }
            
            if (isset($data['couplet']) && ($data['couplet']> 0)) {
                $bankData['couplet'] = $data['couplet'];
            }
            $bankData['is_bind']      = 1;
            $bankData['bind_time']    = time();

            $insertBankRes = Db::name('user_bank')->insert($bankData);

            if (empty($insertBankRes)) {
                Db::rollback();
                return $this->sendError(1, '系统出错', 200);
            }

            Db::commit();
        }

        return $this->sendSuccess('', 'success', 200);
    }

    /**
     * @title  银行卡列表
     * @return int    error   错误代码：0成功 1失败
     * @return string message 消息提醒
     * @return array  data    返回数据
     * @desc 用户绑定的银行卡列表，请求方式：POST <br/> 地址：v1/userAuthentication/BankCardList
     */
    public function BankCardList() {

        $data = input('post.');
        $data['userid'] = input('userid') ? intval(input('userid')) : intval($this->userId);

        $bankList = Db::name('user_bank')
            ->where('userid', $data['userid'])
            ->where('is_bind', 1)
            ->select();

        if(!$bankList) {
            return $this->sendError(1, 'Not found Data', 200);
        }

        return $this->sendSuccess($bankList, 'success', 200);
    }

  
    //title 合利宝WFT支付
    public function wapPay()
    {
        $data = input("post.");

        $helibao_obj = new HelibaoInt();                   // 合利宝集成类
        
        $payRes = $helibao_obj->wapPay();                  // 鉴权结果

var_dump(json_decode($payRes,true));
die;
    }

   
     //  合利宝扫码
    public function scanPay() {

        $data = input("post.");

        $helibao_obj = new HelibaoInt();                   // 合利宝集成类
        
        $payRes = $helibao_obj->scanPay();                  // 鉴权结果

        $testArr = json_decode($payRes,true);

        var_dump($testArr);
        die;
    }


    //  合利宝分账扫码
    public function splitBillPay() {

        $data = input("post.");

        $helibao_obj = new HelibaoInt();                       // 合利宝集成类
        
        $payRes = $helibao_obj->routingPay();                  // 鉴权结果

        $testArr = json_decode($payRes,true);

        var_dump($testArr);
        die;
    }

    /**
     * @title  合利闪付宝支付
     * @return int    error   错误代码  0成功 1失败
     * @return string message 消息提醒
     * @return array  data    返回数据
     * @desc 合利宝闪付宝支付，请求方式：POST <br/> 地址：v1/userauthentication/quickSdkMerchant
    */
    public function quickSdkMerchant() {
        $data = input("post.");
        $data['userid'] = input('userid') ? intval(input('userid')) : intval($this->userId);

        $rule = [
                'userid'        => 'require|gt:0',
                'deviceType'       => 'require|number',
                'amount'        => 'require|number',
                'terminalId'    => 'require',
        ];

        $msg = [
            'userid.require'        => '用户ID必填',
            'userid.gt'             => '用户ID必须大于0',
            'deviceType.require'    => '设备类型必填',
            'deviceType.number'     => '设备类型为数字',
            'amount.require'        => '支付金额必填',
            'amount.number'         => '支付金额必须为数字',
            'terminalId.require'    => '终端标识必填',
        ];

        // 验证字段
        $validate = new Validate($rule, $msg);
        $validate_result = $validate->check($data);    

        if (empty($validate_result)) {
            return $this->sendError(1, $validate->getError(), 200);
        }

        $quickArr['userid'] = $data['userid'];
        $quickArr['deviceType'] = $data['deviceType'];
        $quickArr['amount'] = $data['amount'];
        $quickArr['goodsName'] = '商品名称';                                // 商品名称
        $quickArr['goodsDesc'] = '商品描述';                                // 商品描述
        $quickArr['orderNo'] = date('YmdHis') . rand(100000, 999999);       // 订单编号        
        $quickArr['terminalId'] = $data['terminalId'];                      // 终端标识             

        $helibao_obj = new HelibaoInt();                                    // 合利宝集成类
        $payRes = $helibao_obj->quickSdkMerchant($quickArr);                // 云闪付

        if($payRes['code'] != 'SUCCESS') {
            return $this->sendError(1, $payRes['message'], 200);
        }

        $returnData = json_decode(base64_decode($payRes['data']),true);      // 解码取出预支付id等参数

        if($returnData['retCode'] != 'SUCCESS') {
            return $this->sendError(1, $returnData['retMsg'], 200);
        }

        $payPack['merchantNo'] = $returnData['merchantNo'];      // 商户号
        $payPack['prePayId'] = $returnData['prePayId'];          // 预支付id
        $payPack['userId'] = $returnData['userId'];              // 用户id
        $payPack['appId'] = $returnData['appId'];                // 应用id

        return $this->sendSuccess($payPack, 'success', 200);

        //$testArr = json_decode($payRes,true);
        die;
    }

    /**
     * @title  闪付宝支付订单查询
     * @return int    error   错误代码  0成功 1失败
     * @return string message 消息提醒
     * @return array  data    返回数据
     * @desc 合利宝闪付宝支付，请求方式：POST <br/> 地址：v1/userauthentication/quickPayQuery
    */
    public function quickPayQuery() {
        $data = input("post.");
        $data['userid'] = input('userid') ? intval(input('userid')) : intval($this->userId);

        $rule = [
                'userid'        => 'require|gt:0',
                'orderNo'       => 'require',
        ];

        $msg = [
            'userid.require'        => '用户ID必填',
            'userid.gt'             => '用户ID必须大于0',
            'orderNo.require'       => '订单编号必填',
        ];

        // 验证字段
        $validate = new Validate($rule, $msg);
        $validate_result = $validate->check($data);    

        if (empty($validate_result)) {
            return $this->sendError(1, $validate->getError(), 200);
        }

        $helibao_obj = new HelibaoInt();                                    // 合利宝集成类
        $queryRes = $helibao_obj->quickPayQuery($data['orderNo']);          // 云闪付支付订单查询

        if($queryRes['code'] != 'SUCCESS') {
            return $this->sendError(1, $queryRes['message'], 200);
        }

        $returnData = json_decode(base64_decode($queryRes['data']),true);     // 解码data信息 

        if($returnData['retCode'] != 'SUCCESS') {
            return $this->sendError(1, $returnData['retMsg'], 200);
        }

        var_dump($returnData);     
        die;   
    }


    /**
     * @title 合利宝提现
     * @return int    error   错误代码  0成功 1失败
     * @return string message 消息提醒
     * @return array  data    返回数据
     * @desc 获取用户认证状态，请求方式：POST <br/> 地址：v1/userAuthentication/withDrawToBank
     */
    public function withDrawToBank() {
        $data = input("post.");
        $data['userid'] = input('userid') ? intval(input('userid')) : intval($this->userId);    

        // 先判断当前用户今日是否提现过
        // ##
        // 

        $rule = [
                'userid'        => 'require|gt:0',
                'cardid'        => 'require',
                'amount'        => 'require|number',
            ];

        $msg = [
            'userid.require'        => '用户ID必填',
            'userid.gt'             => '用户ID必须大于0',
            'cardid.require'        => '银行卡未选择',
            'amount.require'        => '提现金额必填',
            'amount.number'         => '提现金额为数字',
        ];

        // 验证字段
        $validate = new Validate($rule, $msg);
        $validate_result = $validate->check($data);

        if (empty($validate_result)) {
            return $this->sendError(1, $validate->getError(), 200);
        }

// if(($data['amount'] < 100) || ($data['amount'] > 200)) {
//     return $this->sendError(1, '提现金额介于100.00~200.00之间', 200);
// }

        /* 是否实名制 */
        // $is_authen = db('user_authentication')
        //         ->where('userid',$data['userid'])
        //         ->find();

        // if(!$is_authen) {
        //     return $this->sendError(1, '当前用户未实名', 200);
        // }

        // /* 该用户的卡是否存在/绑定 */
        // $user_card = db('user_bank')
        //             ->where([
        //                 'id'      => $data['cardid'],
        //                 'userid'  => $data['userid'],
        //                 'is_bind' => 1,     // 是否绑定 1.绑定 2.解绑
        //             ])
        //             ->find();

        // if(!$user_card) {
        //     return $this->sendError(1, '当前银行卡不存在', 200);
        // }

        $withDrawArr['orderNo'] = date('YmdHis') . rand(100000, 999999);        // 订单编号
        $withDrawArr['amount'] = $data['amount'];                               // 提现金额

        // $withDrawArr['bankCode'] = $user_card['bank_code'];                     // 银行编码
        // $withDrawArr['bankCard'] = $user_card['bank_card'];                     // 银行卡号
        // $withDrawArr['account'] = $user_card['account_name'];                   // 银行户主名
        
        $withDrawArr['bankCode'] = 'CBHB';                                       // 银行编码
        $withDrawArr['bankCard'] = '2005209906000111';                           // 银行卡号
        $withDrawArr['account'] = '深圳市跑步钱进网络科技有限公司';              // 银行户主名

        $withDrawArr['bankUnionCode'] = '318584000010';                         // 银行联行号

        $withDrawArr['remark'] = '结算';                                        // 打款备注

        $helibao_obj = new HelibaoInt();                                        // 合利宝集成类
        
        $withDrawRes = $helibao_obj->transfer($withDrawArr,true);           // 单笔代付

        var_dump($withDrawRes);
        die;
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            // 'save' => [
            //     'id' => [
            //       'name' => 'id', 
            //       'type' => 'int', 
            //       'require' => 'true', 
            //       'default' => '', 
            //       'desc' => '用户id', 
            //       'range' => '',
            //     ],
            //     'realname' => [
            //       'name' => 'realname', 
            //       'type' => 'string', 
            //       'require' => 'true', 
            //       'default' => '', 
            //       'desc' => '真实姓名', 
            //       'range' => '',
            //     ],
            //     'idcard' => [
            //       'name' => 'idcard', 
            //       'type' => 'string', 
            //       'require' => 'true', 
            //       'default' => '', 
            //       'desc' => '身份证号码', 
            //       'range' => '',
            //     ]
            // ],
            'userAuthState' => [
                'userid' => [
                  'name' => 'userid', 
                  'type' => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc' => '用户id（不填最好）', 
                  'range' => '',
                ],
            ],
            'realAuth' => [
                'phone' => [
                  'name' => 'phone', 
                  'type' => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '手机号', 
                  'range' => '',
                ],
                'code' => [
                  'name' => 'code', 
                  'type' => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '验证码', 
                  'range' => '',
                ],
                'cardno' => [
                  'name' => 'cardno', 
                  'type' => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '银行卡号', 
                  'range' => '',
                ],
                'account' => [
                  'name' => 'account', 
                  'type' => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc' => '户名（未进行实名制的必填）', 
                  'range' => '',
                ],
                'idcard' => [
                  'name' => 'idcard', 
                  'type' => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc' => '身份证号（未进行实名制的必填）', 
                  'range' => '',
                ],
                'couplet' => [
                  'name' => 'couplet', 
                  'type' => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc' => '联行号（对公账户必填）', 
                  'range' => '',
                ],
                'cyear' => [
                  'name' => 'cyear', 
                  'type' => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc' => '信用卡到期年份（绑信用卡必填）', 
                  'range' => '',
                ],
                'cday' => [
                  'name' => 'cday', 
                  'type' => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc' => '信用卡到期月份（绑信用卡必填）', 
                  'range' => '',
                ],
                'ccode' => [
                  'name' => 'ccode', 
                  'type' => 'string', 
                  'require' => 'false', 
                  'default' => '', 
                  'desc' => '信用卡交易码（绑信用卡必填）', 
                  'range' => '',
                ],
            ],
            'wapPay' => [
                'id' => [
                  'name' => 'id', 
                  'type' => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '用户id', 
                  'range' => '',
                ],
            ],
            'withDrawToBank' => [
                'cardid' => [
                  'name' => 'cardid', 
                  'type' => 'int', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '银行卡id', 
                  'range' => '',
                ],
                'amount' => [
                  'name' => 'amount', 
                  'type' => 'float', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '提现金额', 
                  'range' => '',
                ],
            ],
            'quickSdkMerchant' => [
                'deviceType' => [
                  'name' => 'deviceType', 
                  'type' => 'int', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '设备类型 1.安卓 2.IOS', 
                  'range' => '',
                ],
                'amount' => [
                  'name' => 'amount', 
                  'type' => 'float', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '支付金额', 
                  'range' => '',
                ],
                'terminalId' => [
                  'name' => 'terminalId', 
                  'type' => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '终端标识 MAC或IMEI地址', 
                  'range' => '',
                ],
            ],
            'quickPayQuery' => [
                'deviceType' => [
                  'name' => 'orderNo', 
                  'type' => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '支付订单编号', 
                  'range' => '',
                ]
            ],
        ];
        
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }

}
