<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:40
// +----------------------------------------------------------------------
// | TITLE: 用户银行卡接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;
use app\v1\extend\BankCarData;

/**
 * Class  Index
 * @title 用户银行卡接口
 * @url   v1/UserBankCard
 * @desc  提现账户相关接口
 * @version 1.0
 * @readme
 */
class UserBankCard extends Base
{
    //附加方法
    protected $extraActionList = ['getCardList', 'checkCode', 'getBankCardData'];

    protected $rule = [
        'userid'    => 'require',
        'typeid'    => 'require',
        'realname'  => 'require',
        'bank_card' => 'require',
    ];

    protected $msg = [
        'userid.require'    =>  '用户ID必填',
        'typeid.require'    =>  '提现类型必填',
        'realname.require'  =>  '真实姓名必填',
        'bank_card.require' =>  '提现账号必填',
    ];

    // /**
    //  * @title 获取提现账户列表
    //  * @return int    error        错误代码：0成功 1失败 
    //  * @return string message      消息提醒
    //  * @return object data         提现对象
    //  * @return int    id           提现方式ID
    //  * @return int    userid       用户ID
    //  * @return int    typeid       提现类型ID
    //  * @return string realname     真实姓名
    //  * @return string bank_card    提现账号
    //  * @return string opening_bank 开户行名称
    //  * @return string subbranch    开户支行
    //  * @return string region       开户地区
    //  * @return int    create_time  创建时间
    //  * @desc 请求方式：GET <br/> 请求示例：v1/UserBankCard
    //  */
    // public function index()
    // {
    //     $userid = input('get.userid');
    //     $typeid = input('get.typeid');

    //     $map = array();
    //     $map['userid'] = $userid;
    //     if ($typeid) {
    //         $map['typeid'] = $typeid;
    //     }
        
    //     if(!$userid){
    //         return $this->sendError(-1, '用户ID必填', 400);
    //     }
    //     $user_bank_card = Db::name('withdraw_log')
    //         ->where($map)
    //         ->select();

    //     if($user_bank_card){
    //         return $this->sendSuccess($user_bank_card,'success',200);
    //     }else{
    //         return $this->sendError(1, 'Not found Data', 200);
    //     }
    // }

    /**
     * @title 获取用户的银行卡列表
     * @return int    error        错误代码：0成功 1失败 
     * @return string message      消息提醒
     * @return array  data         返回数据
     * @return int    cardid       用户卡ID
     * @return int    userid       用户ID
     * @return int    account_name 真实姓名
     * @return string bank_name    银行名
     * @return string img_url      银行图标
     * @return string bank_card    提现账号
     * @return string bank_code    英文简写
     * @return string subbranch    开户支行
     * @return string region       开户地区
     * @return int    couplet      联行号
     * @return int    is_bind      绑定状态：0已解绑 1绑定
     * @return int    iscreditcard 银行卡类型：1借记卡 2信用卡
     * @return int    bind_time    绑定时间（linux时间戳）
     * @return int    unbind_time  解绑时间（linux时间戳）
     * @desc 请求方式：GET <br/> 请求示例：v1/UserBankCard/getCardList
     */
    public function getCardList()
    {
        // dump('getCardList');

        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        $Cardlist = Db::name('user_bank')
            ->alias('ub')
            ->field('
                ub.id as cardid,userid,account_name,ub.bank_name,ub.bank_code,img_url,
                bank_card,subbranch,region,couplet,is_bind,bind_time,unbind_time,
                iscreditcard
            ')
            ->join('user_bank_img ubi', 'ubi.bank_code=ub.bank_code', 'left')
            ->where('userid', $Userid)
            ->where('is_bind', 1)
            ->select();

        if (empty($Cardlist)) {
            return $this->sendError(1, 'Not found Data', 200);
        }

        foreach ($Cardlist as $key => $value) {
            if (empty($value['img_url'])) {
                $Cardlist[$key]['img_url'] = 'https://pbqj-cdn.oss-cn-shenzhen.aliyuncs.com/bank/df.png';
            }
        }

        return $this->sendSuccess($Cardlist, 'success', 200);
    }

    /**
     * @title  根据银行卡号获取详细信息
     * @return int   error              错误代码：0成功 1失败
     * @return string message           消息提醒
     * @return array  data              返回数据
     * @return string bankname          发卡银行
     * @return string banknum           起始数
     * @return string cardname          银行卡名称
     * @return string cardtype          银行卡类型
     * @return string cardprefixlength  bin长度
     * @return string isLuhn            是否符合编码规范
     * @return string cardlength        卡号长度
     * @return string iscreditcard      是否是信用卡,1为借记卡,2为信用卡
     * @return string province          省份
     * @return string city              城市
     * @return string bankurl           官网地址
     * @return string enbankname        英文全称
     * @return string abbreviation      银行编码（英文简写）
     * @return string bankimage         银行图标
     * @return string servicephone      客户电话
     * @desc 获取用户认证状态，请求方式：GET <br/> 地址：v1/UserBankCard/getBankCardData
     */
    public function getBankCardData() 
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Cardno = input('cardno');

        if (empty($Cardno)) {
            return $this->sendError(1, '银行卡号必填', 200);
        }

        $res = BankCarData::getBankCardData($Cardno);

        return $this->sendSuccess($res, 'success', 200);
    }

    // /**
    //  * @title 绑定提现账户
    //  * @return int    error   错误代码：0成功 1失败
    //  * @return string message 消息提醒
    //  * @desc 请求方式：POST <br/> 请求示例：v1/UserBankCard
    //  */
    // public function save(Request $request)
    // {
    //     $data = $request->post();
    //     $data['create_time'] = time();

    //     // 验证字段
    //     $validate = new Validate($this->rule, $this->msg);
    //     $validate_result   = $validate->check($data);

    //     if($validate_result){
    //         if ($data['typeid'] == 3) {
    //             if(!isset($data['opening_bank'])){
    //                 return $this->sendError(-1,'开户行必填');
    //             }
    //             if(!isset($data['subbranch'])){
    //                 return $this->sendError(-1,'开户支行必填');
    //             }
    //             if(!isset($data['region'])){
    //                 return $this->sendError(-1,'开户地区必填');
    //             }
    //         }

    //         $user_bank_card = Db::name('withdraw_log')
    //             ->where('bank_card',$data['bank_card'])
    //             ->find();

    //         if(!$user_bank_card){
    //             $result = Db::name('withdraw_log')->insert($data);
    //         }else{
    //             $result = Db::name('withdraw_log')->where('bank_card',$data['bank_card'])->update($data);
    //         }

    //         if($result){
    //             return $this->sendSuccess('','success',200);
    //         }else{
    //             return $this->sendError(-1, 'error', 400);
    //         }
    //     }else{
    //         return $this->sendError(-1, $validate->getError(), 400);
    //     }
    // }

    /**
     * @title 根据ID获取提现信息
     * @return int error 错误代码 0失败 1成功
     * @return string message 消息提醒
     * @return object data 争行卡对象
     * @desc 请求方式：GET <br/> 请求示例：v1/UserBankCard/1
     */
    public function read($id)
    {
        $user_bank_card = Db::name('withdraw_log')
            ->where('id', $id)
            ->find();

        if ($user_bank_card) {
            return $this->sendSuccess($user_bank_card,'success',200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title  银行卡解除绑定
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @return sarray data    返回数据
     * @desc 请求方式：DELETE <br/> 请求示例：v1/UserBankCard/1
     */
    public function delete($id)
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Cardid = intval($id) ? intval($id) : input('cardid');
        $Cardno = input('cardno');

        if (empty($Cardid)) {
            return $this->sendError(1, '卡ID必填', 200);
        }

        if (empty($Cardno)) {
            return $this->sendError(1, '卡号必填', 200);
        }

        $bank_WHERE['id']        = $Cardid;
        $bank_WHERE['bank_card'] = $Cardno;
        $bank_WHERE['is_bind']   = 1;
        $delete = Db::name('user_bank')->where($bank_WHERE)->find();

        if (empty($delete)) {
            return $this->sendSuccess('', 'success', 200);
        }

        $bank_UPDATE['is_bind']     = 2;
        $bank_UPDATE['unbind_time'] = time();

        $result = Db::name('user_bank')->where($bank_WHERE)->update($bank_UPDATE);

        if (!empty($result)) {
            return $this->sendSuccess('', 'success', 200);
        } else {
            return $this->sendError(1, 'error', 200);
        }
    }

    /**
     * @title 校验验证码
     * @author chenjie 2018-02-05
     * @return int error 错误代码 0失败 1成功
     * @return string message 消息提醒
     * @desc 请求方式：POST <br/> 请求示例：v1/UserBankCard/checkCode
     */
    public function checkCode() {
        $data = input('post.');

        if(!isset($data['userid'])){
            return $this->sendError(-1, '用户ID必填', 400);
        }
        if(!isset($data['code'])){
            return $this->sendError(-1, '验证码必填', 400);
        }

        $user = Db::name('user')
            ->where('id', $data['userid'])
            ->find();

        // 短信验证码验证
        $mobile = $user['mobile'];
        $code = cache($mobile.'_code');

        if(!$code){
            return $this->sendError(-1,'验证码已经过期',400);
        }
        if($code != $data['code']){
            return $this->sendError(-1,'验证码错误',400);
        }

        return $this->sendSuccess('', 'success' ,200);
    }
    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            // 'index' => [
            //     'userid'   => [
            //         'name' => 'userid',
            //         'type' => 'int',
            //         'require' => 'true',
            //         'default' => '1',
            //         'desc' => '用户ID',
            //         'range' => ''
            //     ],
            //     'typeid'   => [
            //         'name' => 'typeid',
            //         'type' => 'int',
            //         'require' => 'false',
            //         'default' => '',
            //         'desc' => '提现类型 1微信 2支付宝 3银行卡',
            //         'range' => ''
            //     ],
            // ],
            'getCardList' => [
                'userid'   => [
                    'name' => 'userid',
                    'type' => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc' => '用户ID（最好别传）',
                    'range' => ''
                ],
            ],
            // 'save' => [
            //     'userid'   => [
            //         'name' => 'userid',
            //         'type' => 'int',
            //         'require' => 'true',
            //         'default' => '1',
            //         'desc' => '用户ID',
            //         'range' => ''
            //     ],
            //     'typeid'   => [
            //         'name' => 'typeid',
            //         'type' => 'string',
            //         'require' => 'true',
            //         'default' => '1',
            //         'desc' => '提现类型 1微信 2支付宝 3银行卡',
            //         'range' => ''
            //     ],
            //     'realname'   => [
            //         'name' => 'realname',
            //         'type' => 'int',
            //         'require' => 'true',
            //         'default' => '1',
            //         'desc' => '真实姓名',
            //         'range' => ''
            //     ],
            //     'bank_card'   => [
            //         'name' => 'bank_card',
            //         'type' => 'string',
            //         'require' => 'true',
            //         'default' => '1',
            //         'desc' => '账户 typeid为1填写微信openid｜typeid为2填写支付宝账号｜typeid为3填写银行账号',
            //         'range' => ''
            //     ],
            //     'opening_bank'   => [
            //         'name' => 'opening_bank',
            //         'type' => 'string',
            //         'require' => 'false',
            //         'default' => '1',
            //         'desc' => '开户行',
            //         'range' => ''
            //     ],
            //     'subbranch'   => [
            //         'name' => 'subbranch',
            //         'type' => 'string',
            //         'require' => 'false',
            //         'default' => '1',
            //         'desc' => '开户支行',
            //         'range' => ''
            //     ],
            //     'region'   => [
            //         'name' => 'region',
            //         'type' => 'string',
            //         'require' => 'false',
            //         'default' => '1',
            //         'desc' => '开户地区',
            //         'range' => ''
            //     ],
            // ],
            'read' => [
                'id'   => [
                    'name' => 'id',
                    'type' => 'int',
                    'require' => 'true',
                    'default' => '1',
                    'desc' => 'ID',
                    'range' => ''
                ],
            ],
            'delete' => [
                'id'   => [
                    'name' => 'id',
                    'type' => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc' => '银行卡ID',
                    'range' => ''
                ],
                'cardno'   => [
                    'name' => 'cardno',
                    'type' => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc' => '银行卡号',
                    'range' => ''
                ],
            ],
            'checkCode' => [
                'userid'   => [
                    'name' => 'userid',
                    'type' => 'int',
                    'require' => 'true',
                    'default' => '1',
                    'desc' => '用户ID',
                    'range' => ''
                ],
                'code'   => [
                    'name' => 'code',
                    'type' => 'string',
                    'require' => 'true',
                    'default' => '1',
                    'desc' => '短信验证码',
                    'range' => ''
                ]
            ],
            'getBankCardData' => [
                'cardno' => [
                  'name' => 'cardno', 
                  'type' => 'string', 
                  'require' => 'true', 
                  'default' => '', 
                  'desc' => '银行卡号', 
                  'range' => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
