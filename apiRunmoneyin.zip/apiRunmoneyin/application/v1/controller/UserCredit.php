<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:40
// +----------------------------------------------------------------------
// | TITLE: 用户步币信息接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;

/**
 * Class  UserCredit
 * @title 用户步币信息接口
 * @url   v1/usercredit
 * @desc  获取用户步币详细信息
 * @version 1.0
 */
class UserCredit extends Base
{

    /**
     * @title 获取用户步币记录
     * @return int id          步币ID
     * @return int userid      用户ID
     * @return int source      步币来源
     * @return int credit      步币
     * @return int creat_time  收入时间
     * @return string typename 步币来源
     * @return string sname    被邀请人名（先不用）
     * @return string bname    邀请人名（先不用）
     * @desc 请求方式：GET <br/>请求示例：v1/UserCredit?userid=1
     */
    public function index()
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid = input('get.userid');
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        if (!$Userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        $totalCount = db('user_credit')
            ->where('userid', $Userid)
            ->count();

        $user_credit = db('user_credit')
            ->alias('uc')
            ->field('uc.id,uc.userid,uc.type,uc.source,uc.credit,uc.create_time,iu.nickname as sname,bu.nickname as bname')
            ->where('userid', $Userid)
            ->join('user iu', 'iu.id=uc.source')
            ->join('user bu', 'bu.id=uc.userid')
            ->page($page, $pageSize)
            ->select();

        foreach ($user_credit as $key => $value) {
            if (!empty($value['create_time'])) {
                $user_credit[$key]['create_day'] = date('Y-m-d', $value['create_time']);
            }

            if ($value['type'] == 1) {
                $user_credit[$key]['typename'] = '邀请用户奖励';
            } else {
                $user_credit[$key]['typename'] = '';
            }
        }
        unset($key, $value);

        $retData = returnData($page,$pageSize,$totalCount,$user_credit);

        if($totalCount > 0){
            return $this->sendSuccess($retData, 'success', 200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 获取步币总数
     * @return int credit 步数总数
     * @desc 请求方式：GET <br/>请求示例：v1/UserCredit/1
     */
    public function read($id)
    {
        $Userid = intval($id) ? intval($id) : intval($this->userId);

        $user = Db::name('user')->field('credit')->where('id', $Userid)->find();
        
        if ($user) {
            return $this->sendSuccess(array('credit'=>$user['credit']), 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'read' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }

}
