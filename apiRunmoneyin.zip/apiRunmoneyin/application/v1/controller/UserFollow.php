<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:40
// +----------------------------------------------------------------------
// | TITLE: 用户关注接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;

/**
 * Class  Index
 * @title 用户关注接口
 * @url   v1/UserFollow
 * @desc  用户关注相关接口
 * @version 1.0
 * @readme
 */
class UserFollow extends Base
{
    // 附加方法
    protected $extraActionList = ['followStatus', 'addressBook'];

    /**
     * @title 获取我关注的\关注我的\相互关注的
     * @return int    error    错误代码：0成功 1失败
     * @return string message  消息提醒
     * @return object data     关注对象
     * @return int    id       关注ID
     * @return int    userid   用户ID
     * @return string avatar   用户头像
     * @return string nickname 用户昵称
     * @return int    sex      性别：0男 1女
     * @desc 请求方式：GET <br/> 请求示例: v1/UserFollow?action=my&userid=1
     */
    public function index()
    {
        $action   = input('action');
        $userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid   = input('get.userid');
        $keyword  = input('get.keyword');
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        $mutuals_WHERE = [];    // 条件

        if (!$userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        // 互相关注的人，用于排除，关注我和我关注的人
        if ($action != 'mutual') {
            $mutual_WHERE['user_follow.userid']   = $userid;
            $mutual_WHERE['user_follow.followid'] = ['<>', 0];

            $user_mutual = Db::name('user_follow')
                ->alias('user_follow')
                ->join('user','user.id = user_follow.followid')
                ->field('user.id as userid,user.avatar,user.nickname,user.sex,user_follow.followid,vip')
                ->where($mutual_WHERE)
                ->where('user_follow.followid','IN',function($query) use ($userid){
                    $query->name('user_follow')->where('followid', $userid)->field('userid');
                })
                ->select();

            if (count($user_mutual) > 0) {
                $mutuals = '';
                foreach ($user_mutual as $key => $value) {
                    $mutuals .= $value['userid'] . ',';
                }

                $mutuals_WHERE = ['not in', substr($mutuals, 0, -1)];
            }
        }

        // 获取我关注的
        if ($action == 'my') {
            $here_WHERE['user_follow.userid']   = $userid;
            $here_WHERE['user_follow.followid'] = ['<>', 0];

            if (!empty($mutuals_WHERE)) {
                $here_WHERE['user_follow.followid'] = $mutuals_WHERE;
            }

            if (!empty($keyword)) {
                $here_WHERE['user.nickname'] = ['like', '%'.$keyword.'%'];
            }

            $totalCount = Db::name('user_follow')
                ->alias('user_follow')
                ->field('user_follow.id,user_follow.followid,user.id as userid,user.avatar,user.nickname,user.sex,vip')
                ->join('user','user_follow.followid = user.id')
                ->where($here_WHERE)
                ->count();

            $user_follow = Db::name('user_follow')
                ->alias('user_follow')
                ->field('user_follow.id,user_follow.followid,user.id as userid,user.avatar,user.nickname,user.sex,vip')
                ->join('user','user_follow.followid = user.id')
                ->where($here_WHERE)
                ->page($page, $pageSize)
                ->select();

            foreach ($user_follow as $key => $value) {
                $tmp_user_follow = Db::name('user_follow')
                    ->where([
                        'userid'   => $value['followid'], 
                        'followid' => $userid,
                    ])
                    ->find();

                if ($tmp_user_follow) {
                    unset($user_follow[$key]);
                }
            }

            $user_follow = array_merge($user_follow);

            $retData = returnData($page, $pageSize, $totalCount, $user_follow);

        } else if ($action == 'me') {    // 获取关注我的
            $here_WHERE['user_follow.followid'] = $userid;
            $here_WHERE['user_follow.userid']   = ['<>', 0];

            if (!empty($mutuals_WHERE)) {
                $here_WHERE['user_follow.userid'] = $mutuals_WHERE;
            }

            if ($keyword) {
                $here_WHERE['user.nickname'] = ['like', '%'.$keyword.'%'];
            }

            $totalCount = Db::name('user_follow')
                ->alias('user_follow')
                ->field('user_follow.id,user.id as userid,user.avatar,user.nickname,user.sex,vip')
                ->join('user','user_follow.userid = user.id')
                ->where($here_WHERE)
                ->count();

            $user_follow = Db::name('user_follow')
                ->alias('user_follow')
                ->field('user_follow.id,user.id as userid,user.avatar,user.nickname,user.sex,vip')
                ->join('user','user_follow.userid = user.id')
                ->where($here_WHERE)
                ->page($page, $pageSize)
                ->select();

            foreach ($user_follow as $key => $value) {
                $tmp_user_follow = Db::name('user_follow')
                    ->where([
                        'userid' => $userid,
                        'followid' => $value['userid']
                    ])
                    ->find();

                if ($tmp_user_follow) {
                    unset($user_follow[$key]);
                }
            }

            $user_follow = array_merge($user_follow);

            $retData = returnData($page, $pageSize, $totalCount, $user_follow);

        } else if ($action == 'mutual') {    // 获取相互关注的
            $here_WHERE['user_follow.userid']     = $userid;
            $mutual_WHERE['user_follow.followid'] = ['<>', 0];


            if ($keyword) {
                $here_WHERE['user.nickname'] = ['like', '%'.$keyword.'%'];
            }

            $totalCount = Db::name('user_follow')
                ->alias('user_follow')
                ->join('user','user.id = user_follow.followid')
                ->field('user.id as userid,user.avatar,user.nickname,user.sex,user_follow.followid,vip')
                ->where($here_WHERE)
                ->where('user_follow.followid','IN',function($query) use ($userid){
                    $query->name('user_follow')->where('followid',$userid)->field('userid');
                })
                ->count();

            $user_follow = Db::name('user_follow')
                ->alias('user_follow')
                ->join('user','user.id = user_follow.followid')
                ->field('user.id as userid,user.avatar,user.nickname,user.sex,user_follow.followid,vip')
                ->where($here_WHERE)
                ->where('user_follow.followid','IN',function($query) use ($userid){
                    $query->name('user_follow')->where('followid', $userid)->field('userid');
                })
                ->order('userid asc')
                ->page($page, $pageSize)
                ->select();

            $retData = returnData($page, $pageSize, $totalCount, $user_follow);
        }

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title 添加关注/取消关注
     * @return int error      错误代码：0成功 1失败
     * @return string message 消息提醒
     * @desc 请求方式：POST <br/>请求示例：v1/UserFollow 如果未关注则关注，否则取消关注
     */
    public function save(Request $request)
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Followid = input('followid') ? intval(input('followid')) : 0;

        if (empty($Userid)) {
            return $this->sendError(1, '用户ID必填', 200);
        }

        if (empty($Followid)) {
            return $this->sendError(1, '对方ID必填', 200);
        }


        $UserFollow = Db::name('user_follow')
            ->where(['userid' => $Userid, 'followid' => $Followid])
            ->find();

        // 如果存在，取消关注
        if ($UserFollow) {
            $result = Db::name('user_follow')
                ->where(['userid' => $Userid, 'followid' => $Followid])
                ->delete();

            $msg = '取消关注成功';
        } else {    // 否则，添加关注
            $user_follow_INSERT['userid']      = $Userid;
            $user_follow_INSERT['followid']    = $Followid;
            $user_follow_INSERT['create_time'] = time();

            $result = Db::name('user_follow')->insertGetId($user_follow_INSERT);

            $msg = '添加关注成功';
        }

        if ($result) {
            return $this->sendSuccess(0, $msg, 200);
        } else {
            return $this->sendError(1, 'error', 200);
        }
    }

    /**
     * @title 用户关注状态
     * @author chenjie 2018-02-08
     * @return int is_follow 0未关注 1已关注
     * @desc 请求方式:POST <br/>请求示例: v1/UserFollow/followStatus
     */
    public function followStatus()
    {
        $userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid   = intval(input('post.userid'));
        $followid = intval(input('post.followid'));

        if (empty($userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        if (empty($followid)) {
            return $this->sendError(-1, '我关注的用户ID必填', 400);
        }

        $user_follow = Db::name('user_follow')
            ->where([
                'userid'   => $userid, 
                'followid' => $followid
            ])
            ->find();

        if ($user_follow) {
            $is_follow = 1;
        } else {
            $is_follow = 0;
        }

        return $this->sendSuccess(array('is_follow' => $is_follow), 'success', 200);
    }

    /**
     * @title 通讯录接口
     * @author chenjie 2018-03-02
     * @return array in_system    在系统的数据
     * @return array name         通讯录名
     * @return array phone        通讯录电话
     * @return array userid       用户id
     * @return array nickname     用户名
     * @return array avatar       用户头像
     * @return array follow_type  关注情况：0无关系|1关注我|2我关注|3互相关注
     * @return array out_system   不在系统的数据
     * @desc 请求方式:POST <br/>请求示例: v1/UserFollow/addressBook
     */
    public function addressBook()
    {
        $data    = input('post.');
        $userid  = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid  = intval($data['userid']);
        $mobiles = json_decode($data['mobiles'], true);

        if (empty($userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        if (empty($mobiles)) {
            return $this->sendError(-1, '通讯录必填', 400);
        }

        $in_system  = [];
        $out_system = [];
        foreach ($mobiles as $key => $value) {
            $tmp_user = Db::name('user')
                ->field('id as userid,nickname,avatar,vip')
                ->where('mobile', $value['phone'])
                ->where('id', '<>', $userid)
                ->find();

            if ($tmp_user) {
                // // 追加步数
                // $user_step = Db::name('user_step')
                //     ->where([
                //         'userid' => $tmp_user['userid'],
                //         'create_time' => strtotime('today')
                //     ])
                //     ->find();

                // if ($user_step) {
                //     $tmp_user['step_number'] = $user_step['step_number'];
                // } else {
                //     $tmp_user['step_number'] = 0;
                // }

                // 追加是否关注
                $myfollow = Db::name('user_follow')
                    ->where([
                        'userid'   => $userid,
                        'followid' => $tmp_user['userid']
                    ])
                    ->find();

                $followme = Db::name('user_follow')
                    ->where([
                        'userid'   => $tmp_user['userid'],
                        'followid' => $userid
                    ])
                    ->find();

                if (!empty($myfollow) && !empty($followme)) {         // 互相关注的
                    $follow_type = 3;
                } else if (!empty($myfollow) && empty($followme)) {   // 我关注的
                    $follow_type = 2;
                } else if (empty($myfollow) && !empty($followme)) {   // 关注我的
                    $follow_type = 1;
                } else {                                              // 没关系的
                    $follow_type = 0;
                }

                $one_value['name']        = $value['name'];
                $one_value['phone']       = $value['phone'];

                $one_value['userid']      = $tmp_user['userid'];
                $one_value['nickname']    = $tmp_user['nickname'];
                $one_value['avatar']      = $tmp_user['avatar'];
                $one_value['follow_type'] = $follow_type;

                $in_system[]  = $one_value;
            } else {
                $out_system[] = $value;
            }
        }
        unset($key, $value);

        $book['in_system']  = $in_system;
        $book['out_system'] = $out_system;

        if ($book) {
            return $this->sendSuccess($book, 'success', 200);
        } else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'action' => [
                    'name'    => 'action',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => 'my我关注的｜me关注我的｜mutual相互关注的',
                    'range'   => ''
                ],
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'keyword' => [
                    'name'    => 'keyword',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '0',
                    'desc'    => '关键词',
                    'range'   => ''
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'save' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'followid' => [
                    'name'    => 'followid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '关注ID',
                    'range'   => ''
                ]
            ],
            'followStatus' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'followid' => [
                    'name'    => 'followid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '被关注用户ID',
                    'range'   => ''
                ]
            ],
            'addressBook' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'mobiles' => [
                    'name'    => 'mobiles',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '0',
                    'desc'    => 'JSON格式的数据例：[{"name":"测试跑步钱进","phone":"13828873978"}]',
                    'range'   => ''
                ]
            ]
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
