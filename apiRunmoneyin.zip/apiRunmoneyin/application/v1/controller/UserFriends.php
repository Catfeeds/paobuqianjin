<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:40
// +----------------------------------------------------------------------
// | TITLE: 用户关注接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;

/**
 * Class  UserFriends
 * @title 用户好友接口
 * @url   v1/UserFriends
 * @desc  用户好友相关接口
 * @version 1.0
 * @readme
 */
class UserFriends extends Base
{
    //附加方法
    protected $extraActionList = ['getUserFriendSort', 'getUserSort'];

    protected $rule = [
        'userid'   => 'require',
        'friendid' => 'require',
    ];

    protected $msg = [
        'userid.require'   => '用户ID必填',
        'friendid.require' => '好友ID必填',
    ];
    
    /**
     * @title 获取好友列表 和 好友步数排行
     * @return int error      错误代码：-1失败 1成功
     * @return string message 消息提醒
     * @return object data    首页对象
     * @desc 请求方式：GET <br/> 获取好友步数排行地址&获取好友列表（默认是好友列表） 地址：v1/UserFriends/?userid=1&action=step
     */
    public function index()
    {
        $userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid   = input('get.userid');

        $action   = input('get.action');
        $keyword  = input('get.keyword');
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        $start_time = strtotime("today");
        $end_time   = strtotime("+1 day", $start_time) - 1;
        $today      = date('Y-m-d', $start_time);

        if (!$userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        // 用户步数排行榜
        if ($action == 'step') {
            {   // 查询用户当天步数
                $user_step = Db::name('user')
                    ->alias('user')
                    ->field('id as userid,nickname,avatar,vip,cusvip')
                    ->where('id', $userid)
                    ->find();

                if (empty($user_step)) {
                    return $this->sendError(1, 'Not found Data', 200);
                }

                $step_number = Db::name('user_step')
                    ->where([
                        'userid'     => $userid,
                        'create_day' => $today,
                    ])
                    ->order('id desc')
                    ->value('step_number');

                if (empty($step_number)) {
                    $user_step['step_number'] = 0;
                } else {
                    $user_step['step_number'] = $step_number;
                }
            }

            if (empty($user_step)) {
                return $this->sendError(1, 'Not found Data', 200);
            }

            // 新的 互相关注的就是好友 wensen 20180315
            $totalCount = Db::name('user_follow')
                ->alias('user_follow')
                ->join('user','user.id = user_follow.followid')
                ->field('user.id as userid')
                ->where('user_follow.userid', $userid)
                ->where('user_follow.followid','IN',function($query) use ($userid) {
                    $query->name('user_follow')->where('followid', $userid)->field('userid');
                })
                ->count();

            if (empty($totalCount)) {
                $data['member'][] = $user_step;
                $data['mydata'] = $user_step;
                $data['mydata']['rank'] = 1;

                $retData = returnData(1, 1, 1, $data);

                return $this->sendSuccess($retData, '没有互相关注的好友', 200);
            }

            $Userida = Db::name('user_follow')
                ->alias('user_follow')
                ->join('user','user.id = user_follow.followid')
                ->field('user.id as userid')
                ->where('user_follow.userid', $userid)
                ->where('user_follow.followid','IN',function($query) use ($userid) {
                    $query->name('user_follow')->where('followid', $userid)->field('userid');
                })
                ->order('user_follow.followid asc')
                ->select();

            $Userida = array_column($Userida, 'userid');
            array_push($Userida, $userid);
            $Userida = array_filter($Userida);
            sort($Userida);
            $Userids = implode(',', $Userida);

// dump($user_step);
// dump($Userids);
// exit();
            $subQuery = Db::table('rm_user_step')
                ->alias('user_step')
                ->field('id,userid,step_number')
                ->where('create_day', $today)
                ->where('userid', 'in', $Userids)
                ->buildSql();

            $AllUserStepRank = Db::name('user')
                ->alias('user')
                ->field('
                    user.id as userid,
                    user.nickname,
                    user.avatar,
                    user.vip,
                    user.cusvip,
                    IFNULL(user_step.step_number, 0) as step_number
                ')
                ->join($subQuery . ' as user_step', 'user.id=user_step.userid', 'left')
                ->where('user.id', 'in', $Userids)
                ->order('step_number desc, user.id asc')
                ->select();

            $UserStepRank = Db::name('user')
                ->alias('user')
                ->field('
                    user.id as userid,
                    user.nickname,
                    user.avatar,
                    user.vip,
                    user.cusvip,
                    IFNULL(user_step.step_number, 0) as step_number
                ')
                ->join($subQuery . ' as user_step', 'user.id=user_step.userid', 'left')
                ->where('user.id', 'in', $Userids)
                ->order('step_number desc, user.id asc')
                ->page($page, $pageSize)
                ->select();

            // 获取我的名次
            $ranking = 0;
            foreach ($AllUserStepRank as $key => $value) {
                if ($value['userid'] == $userid) {
                    $ranking = $key;
                    break;
                }
            }
            unset($key, $value);

            $res['member'] = $UserStepRank;
            $res['mydata'] = $AllUserStepRank[$ranking];
            $res['mydata']['rank'] = $ranking + 1;

// dump($totalCount);
// dump($Userids);
// dump($res['member']);
// dump($res);
// exit();

            $retData = returnData($page, $pageSize, count($AllUserStepRank), $res);

        } else {    // 获取好友列表
            $totalCount = Db::name('user_follow')
                ->alias('user_follow')
                ->join('user','user.id = user_follow.followid')
                ->field('user.id,user.nickname,user.avatar,user.vip,user.cusvip')
                ->where('user_follow.userid', $userid)
                ->where('user_follow.followid','IN',function($query) use ($userid) {
                    $query->name('user_follow')->where('followid', $userid)->field('userid');
                })
                ->count();

            $UserFriends = Db::name('user_follow')
                ->alias('user_follow')
                ->join('user','user.id = user_follow.followid')
                ->field('user.id,user.nickname,user.avatar,user.vip,user.cusvip')
                ->where('user_follow.userid', $userid)
                ->where('user_follow.followid','IN',function($query) use ($userid) {
                    $query->name('user_follow')->where('followid', $userid)->field('userid');
                })
                ->page($page, $pageSize)
                ->select();

            $retData = returnData($page, $pageSize, $totalCount, $UserFriends);
        }

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }


    /**
     * @title 添加好友
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @desc 请求方式：POST <br/> 地址：v1/UserFriends
     */
    public function save(Request $request)
    {
        $data = $request->post();
        $data['creat_time'] = time();

        // 验证字段
        $validate = new Validate($this->rule, $this->msg);
        $validate_result = $validate->check($data);

        if($validate_result){

            $result = Db::name('user_friends')->insert($data);

            if($result){
                return $this->sendSuccess('','success',200);
            }else{
                return $this->sendError(-1, 'error', 400);
            }
        }else{
            return $this->sendError(-1, $validate->getError(), 400);
        }
    }

    /**
     * @title 获取我的好友步数排名
     * @return array rank 用户步数排名
     * @desc 请求方式：GET <br/> 地址：v1/UserFriends/1
     */
    public function read($id)
    {
        // $userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Userid = intval($id) ? intval($id) : intval($this->userId);

        $UserStep = Db::name('user_step')
            ->alias('user_step')
            ->field('user.id,user.nickname,user.avatar,user_step.step_number,user.vip,user.cusvip')
            ->join('user', 'user.id = user_step.userid')
            ->where('userid', $Userid)
            ->where('user_step.creat_time','>',strtotime('today'))
            ->find();

        $UserRank = Db::name('user_friends')
            ->alias('user_friends')
            ->field('user.id,user.nickname,user.avatar,user_step.step_number,user.vip,user.cusvip')
            ->join('user','user.id = user_friends.friendid')
            ->join('user_step','user_step.userid = user.id')
            ->where(['user_friends.userid' => $Userid, 'user_step.step_number' => ['>', $UserStep['step_number']]])
            ->where('user_step.creat_time','>',strtotime('today'))
            ->order('user_step.step_number desc')
            ->count();

        $UserStep['rank'] = $UserRank + 1;

        return $this->sendSuccess($UserStep, 'success', 200);
    }

    /**
     * @title  获取我的好友本周步数排行榜（没使用）
     * @return array data 用户好友排行榜
     * @desc 请求方式：GET <br/>地址：v1/UserFriends/getUserFriendSort/?userid=1,参数；用户userid
     */
    public function getUserFriendSort()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid    = input('get.userid');
        $page      = input('get.page') ? input('get.page') : 1;
        $pagesize  = input('get.pagesize') ? input('get.pagesize') : 10;
        $timestamp = time();
        $monday    = strtotime(date('Y-m-d', strtotime("this week Monday", $timestamp)));
        //查询用户好友
        $res = db('user_friends')
             ->field('friendid')
             ->where('userid',$Userid)
             ->select();

        $friends = array_column($res, 'friendid');
        Array_push($friends, $Userid);

        $step_total = db('user_step')
            ->alias('step')
            ->join('user','user.id=step.userid')
            ->field('userid,sum(step_number) as step_number,user.avatar,user.nickname,user.vip,user.cusvip')
            ->where('userid','in',$friends)
            ->where('step.creat_time','>',$monday)
            ->group('userid')
            ->order('sum(step_number) desc')
            ->count();

        $step = db('user_step')
            ->alias('step')
            ->join('user','user.id=step.userid')
            ->field('userid,sum(step_number) as step_number,user.avatar,user.nickname,user.vip,user.cusvip')
            ->where('userid','in',$friends)
            ->where('step.creat_time','>',$monday)
            ->group('userid')
            ->order('sum(step_number) desc')
            ->page($page, $pagesize)
            ->select();

        $step = returnData($page,$pagesize,$step_total,$step);

        if ($step) {
            return $this->sendSuccess($step, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title  获取我的好友本周步数排名
     * @return int    error       错误代码：0成功 -1错误
     * @return string message     消息提醒
     * @return array  pagenation  分页数组
     * @return array  data        用户好友周排名数据
     * @return array  member      好友分页数据
     * @return array  mydata      我的数据
     * @desc 请求方式：GET <br/> 地址：v1/UserFriends/getUserSort?userid=1
     */
    public function getUserSort()
    {
        // dump('getUserSort');

        $userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid    = intval(input('get.userid'));
        $timestamp = time();
        $today     = date('Y-m-d');
        $monday    = strtotime(date('Y-m-d', strtotime("this week Monday", $timestamp)));

        $page      = input('get.page') ? intval(input('get.page')) : 1;             // 分页页数
        $pagesize  = input('get.pagesize') ? intval(input('get.pagesize')) : 10;    // 分页条数
        
        $start_time = strtotime("today");
        $end_time   = strtotime("+1 day", $start_time) - 1;

        // 获取我的周步数
        $user_step_data = Db::name('user_step')
            ->alias('user_step')
            ->field('id,userid,sum(step_number) as step_number')
            ->where('userid', $userid)
            ->whereTime('create_time', '>=', $monday)
            ->whereTime('create_time', '<=', $end_time)
            ->group('userid')
            ->find();
            // ->select();

        if (empty($user_step_data)) {
            // return $this->sendError(1, 'Not found Data', 200);
            $user_step = 0;
        } else {
            $user_step = intval($user_step_data['step_number']);
        }

// dump($user_step_data);
// dump($user_step);
// exit();

        // 获取我的好友(互相关注)
        $friends_WHERE['user_follow.userid'] = $userid;
        $user_friends = Db::name('user_follow')
            ->alias('user_follow')
            ->join('user', 'user.id = user_follow.followid')
            ->field('user.id as userid,user.avatar,user.nickname,user.sex,user_follow.followid,user.vip,user.cusvip')
            ->where($friends_WHERE)
            ->where('user_follow.followid', 'IN',function($query) use ($userid){
                $query->name('user_follow')->where('followid', $userid)->field('userid');
            })
            ->select();

        if (empty($user_friends)) {
            $Useridata = Db::name('user')->field('id as userid,avatar,nickname,vip,cusvip')->where('id', $userid)->find();
            $Useridata['step_number'] = $user_step;
            $res['member'][] = $Useridata;
            $res['mydata'] = $Useridata;
            $res['mydata']['rank'] = 1;

            $step = returnData(1, 1, 1, $res);

            return $this->sendSuccess($step, 'Not Found Data', 200);
        }

        // 取出好友的id，并加入自己的id，再做升序排序
        $Userids = array_column($user_friends, 'userid');
        Array_push($Userids, $userid);
        sort($Userids);
        $Userids = implode(',', $Userids);

        $subQuery = Db::table('rm_user_step')
            ->alias('user_step')
            ->field('id,userid,step_number')
            ->where('create_day', '>=', $monday)
            ->where('userid', 'in', $Userids)
            ->group('userid,create_day')
            ->buildSql(); 

        $subQueryData = Db::table($subQuery . 'as sq')
            ->field('
                id,
                userid,
                IFNULL(sum(step_number), 0) as step_number
            ')
            ->group('userid')
            ->buildSql();

        $step_total = Db::name('user')
            ->alias('user')
            // ->field(true)
            ->field('
                user.id as userid,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                IFNULL(step_number, 0) as step_number
            ')
            ->join($subQueryData . ' as user_step', 'user.id=user_step.userid', 'left')
            ->where('user.id', 'in', $Userids)
            ->count();

        $AllUserStepRank = Db::name('user')
            ->alias('user')
            // ->field(true)
            ->field('
                user.id as userid,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                IFNULL(step_number, 0) as step_number
            ')
            ->join($subQueryData . ' as user_step', 'user.id=user_step.userid', 'left')
            ->where('user.id', 'in', $Userids)
            ->order('step_number desc, user.id asc')
            ->select();

        $UserStepRank = Db::name('user')
            ->alias('user')
            // ->field(true)
            ->field('
                user.id as userid,
                user.nickname,
                user.avatar,
                user.vip,
                user.cusvip,
                IFNULL(step_number, 0) as step_number
            ')
            ->join($subQueryData . ' as user_step', 'user.id=user_step.userid', 'left')
            ->where('user.id', 'in', $Userids)
            ->order('step_number desc, user.id asc')
            ->page($page, $pagesize)
            ->select();

// dump($UserStepRank);
// exit();

        // 获取我的名次
        $ranking = 0;
        foreach ($AllUserStepRank as $key => $value) {
            if ($value['userid'] == $userid) {
                $ranking = $key;
                break;
            }
        }
        unset($key, $value);

        $res['member'] = $UserStepRank;
        $res['mydata'] = $AllUserStepRank[$ranking];
        $res['mydata']['rank'] = $ranking + 1;

        $step = returnData($page, $pagesize, $step_total, $res);

        if ($step_total) {
            return $this->sendSuccess($step, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'action' => [
                    'name'    => 'action',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => 'step好友步数排行榜｜留空 获取好友列表',
                    'range'   => ''
                ],
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'keyword' => [
                    'name'    => 'keyword',
                    'type'    => 'string',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '搜索关键词',
                    'range'   => ''
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ]
            ],
            'save' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'friendid' => [
                    'name'    => 'friendid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '朋友ID（需要添加的好友id）',
                    'range'   => ''
                ],
            ],
            'read' => [
                'id'   => [
                    'name' => 'id',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
            ],
            'getUserFriendSort' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
            ],
            'getUserSort' => [
                'userid' => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户ID',
                    'range'   => ''
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ]
            ]
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
