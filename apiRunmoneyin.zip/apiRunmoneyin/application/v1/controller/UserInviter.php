<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:00
// +----------------------------------------------------------------------
// | TITLE: 我的邀请接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;
use app\v1\extend\AliyunSms;

// 指定允许其他域名访问  
header('Access-Control-Allow-Origin:*');  
// 响应类型  
header('Access-Control-Allow-Methods:POST');  
// 响应头设置  
header('Access-Control-Allow-Headers:x-requested-with,content-type');  

/**
 * Class  UserInviter
 * @title 邀请好友接口
 * @url   v1/userinviter
 * @desc  邀请好友接口相关接口：邀请达人排行榜、获取我的邀请人数、发短信邀请好友（手机通讯录）、网页注册
 * @version 1.0
 */
class UserInviter extends Base
{
    // 跳过验证方法
    protected $skipAuthActionList = ['inviteMsg', 'postRegister'];

    // 附加方法
    protected $extraActionList = ['inviteMsg', 'postRegister', 'getMyCode', 'getMyInviter'];

    /**
     * @title  邀请达人排行榜
     * @return int    error      错误代码：0成功 1失败
     * @return string message    消息提醒
     * @return array  data       返回数据
     * @return int    inviterid  邀请人id
     * @return int    inviternum 邀请人数
     * @return int    nickname   邀请人昵称
     * @return string avatar     邀请人头像地址
     * @return int    sum_credit 邀请获得总步币数量
     * @return float  allmoney   邀请可获得提成金额总数
     * @desc 请求方式：GET <br/> 请求示例：v1/userinviter?page=1&pagesize=2
     */
    public function index()
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);

        $page     = input('get.page') ? input('get.page') : 1;
        $pagesize = input('get.pagesize') ? input('get.pagesize') : 10;

        $totalCount = db('user_inviter')
            ->alias('i')
            ->field('count(i.userid) as inviternum,i.inviterid,u.avatar,u.nickname,i.create_time,u.vip')
            ->join('user u','i.inviterid=u.id')
            ->group('inviterid')
            ->count();

        if (empty($totalCount)) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        $Inviters = db('user_inviter')
            ->alias('i')
            ->field('i.inviterid,count(i.userid) as inviternum,u.avatar,u.nickname,i.create_time,u.vip')
            ->join('user u','i.inviterid=u.id')
            ->group('inviterid')
            ->order('count(i.userid) desc, userid asc')
            ->page($page, $pagesize)
            ->select();

        foreach ($Inviters as $key => $value) {
            $sum_credit = Db::name('user_credit')
                ->where(['userid' => $value['inviterid']])
                ->sum('credit');

            $Inviters[$key]['sum_credit'] = intval($sum_credit);

            $invitermomey = Db::name('inviter_bonus')
                ->where(['userid' => $value['inviterid']])
                ->sum('bonus');

            $Inviters[$key]['allmoney'] = round($invitermomey, 2) . '';
        }
        unset($key, $value);
        
        $retData = returnData($page, $pagesize, $totalCount, $Inviters);

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * @title  获取我的邀请数据和我的邀请人列表
     * @return int    error        错误代码：0成功 1失败
     * @return string message      消息提醒
     * @return array  data         返回数据
     * @return int    Inumber      邀请人数量
     * @return int    Icredit      邀请人获取的步币
     * @return float  Imoney       邀请人获取的金额
     * @return array  Ilist        邀请人数据
     * @desc 请求方式：GET <br/> 请求示例：v1/userinviter/getMyInviter
     */
    public function getMyInviter()
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        $page     = input('get.page') ? input('get.page') : 1;
        $pagesize = input('get.pagesize') ? input('get.pagesize') : 10;

        if (empty($Userid)) {
            return $this->sendError(1, '用户ID必填', 200);
        }

        $res['Inumber'] = 0;
        $res['Icredit'] = 0;
        $res['Imoney']  = 0.0;
        $res['Ilist']   = [];

        $baseImoney = 30;
        $Userdata = Db::name('user')->field('id,vip')->where('id', $Userid)->find();
        if ($Userdata['vip'] == 1) {
            $baseImoney = 50;
        }

        // 获取用户的邀请人数据
        $Inviters = db('user_inviter')->field(true)->where('inviterid', $Userid)->select();

        if (empty($Inviters)) {
            return $this->sendSuccess($res, 'success', 200);
        }

        // 获取用户的邀请人获得的步币
        $Sumcredit = Db::name('user_credit')->where('userid', $Userid)->sum('credit');

        $res['Inumber'] = count($Inviters);
        // $res['Imoney']  = count($Inviters) * $baseImoney;
        $res['Icredit'] = intval($Sumcredit) > 0 ? intval($Sumcredit) : 0;
        $res['Ilist']   = $Inviters;

        $Imoney = Db::name('inviter_bonus')
            ->where(['userid' => $Userid])
            ->sum('bonus');

        if (round($Imoney, 2) > 0) {
            $res['Imoney'] = round($Imoney, 2);
        } else {
            $res['Imoney'] = 0;
        }

        return $this->sendSuccess($res, 'success', 200);
    }

    /**
     * @title  填写邀请码
     * @return int    error    状态码：0成功|1失败
     * @return string message  错误信息
     * @return string data     返回数组
     * @desc 请求方式：POST <br/> 请求示例：v1/userinviter
     */
    public function save(Request $request)
    {

// $xcxcs['ip'] = Request::instance()->ip();
// $xcxcs['time'] = date('Y-m-d H:i:s');
// cache('xcxcs', $xcxcs, 100000);

        $Icode  = input('icode');
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        if (empty($Icode)) {
            return $this->sendError(1, '邀请码必填', 200);
        }

        if (strlen($Icode) > 11) {
            return $this->sendError(1, '邀请码位数不正确', 200);
        }

        // 判断邀请码是否存在
        $Iuser = Db::name('user')->where('no', $Icode)->find();
        if (empty($Iuser)) {
            return $this->sendError(1, '邀请码不存在', 200);
        }

        // 判断是否邀请的是自己
        if ($Iuser['id'] == $Userid) {
            return $this->sendError(1, '不能自己邀请自己', 200);
        }

        // 判断被邀请人是否存在
        $res_user = Db::name('user')->field('id,vip,inviter_id,credit')->where('id', $Userid)->find();
        if (empty($res_user)) {
            return $this->sendError(1, '被邀请人不存在', 200);
        } elseif ($res_user['inviter_id'] > 0) {
            return $this->sendError(1, '被邀请人已经填写过邀请码', 200);
        }

        // 判断是否已经邀请
        $user_inviter = Db::name('user_inviter')
            ->where([
                'inviterid' => $Iuser['id'],
                'userid'    => $Userid,
            ])
            ->find();

        if ($user_inviter) {
            return $this->sendError(1, '被邀请人已经填写过邀请码', 200);
        }

        Db::startTrans();

        try {
            // 添加邀请记录
            Db::name('user_inviter')
                ->insert([
                    'inviterid'   => $Iuser['id'],
                    'userid'      => $Userid,
                    'code'        => $Iuser['id'] . 'T' . $Userid,
                    'create_time' => time()
                ]);

            // 添加获得步币记录
            Db::name('user_credit')
                ->insert([
                    'userid'      => $Iuser['id'],
                    'type'        => 1,
                    'credit'      => 100,
                    'source'      => $Userid,
                    'create_time' => time()
                ]);

            // 更新被邀请人的推荐人（用户表）
            Db::name('user')->where('id', $Userid)->update(['inviter_id' => $Iuser['id']]);

            // 更新邀请人步币（用户表）
            Db::name('user')->where('id', $Iuser['id'])->setInc('credit', 100);

            // 提交事务
            Db::commit();
            return $this->sendSuccess(0, '成功', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(1, '录入邀请码失败', 200);
        }
    }

    /**
     * @title  获取我的邀请码
     * @return int    error    错误码: 0成功 1失败
     * @return string massge   错误信息
     * @return array  data     返回数据
     * @return int    mycode   我的邀请码
     * @desc 请求方式：GET <br/> 请求示例：v1/userinviter/getMyCode
     */
    public function getMyCode()
    { 
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid = input('post.userid');

        if (empty($Userid)) {
            return $this->sendError(1, '用户ID必填', 200);
        }

        // $Usernum = str_pad($Userid, 10, "0", STR_PAD_LEFT); 
        // base64互转
        // $encode = substr(base64_encode($Usernum), 0, -2) ;
        // $encode2 = base64_encode($Usernum) ;
        // $code   = base64_decode($encode);
        // $res['userid'] = $Userid;
        // $res['mycode'] = $encode;
        
        $Old = db('user')->field('password', true)->where('id', $Userid)->find();

        if (empty($Old)) {
            return $this->sendError(1, 'error', 200);
        } else {
            return $this->sendSuccess(['mycode' => $Old['no']], 'success', 200);
        }
    }

    /**
     * @title  发短信邀请好友（手机通讯录）
     * @return error  int     错误码: 0成功 1失败
     * @return massge string  错误信息
     * @desc 请求方式：POST <br/> 请求示例：v1/userinviter/inviteMsg
     */
    public function inviteMsg()
    {   
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid = intval(input('post.userid'));
        $Phones = json_decode(input('post.phones'), true);

        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        if (empty($Phones)) {
            return $this->sendError(-1, '手机号码必填', 400);
        }

        // 过滤手机号码
        $new_mobile = [];
        foreach ($Phones as $key => $value) {
            if (preg_match("/^1[34578]\d{9}$/", $value)) {
                $new_mobile[] = $value;
            }
        }

        if (empty($new_mobile)) {
            return $this->sendError(-1, '邀请好友的手机号码必填', 400);
        }

        $config    = [
            'accessKeyId'     => 'LTAIpSQX9t1xK9ji',
            'accessKeySecret' => 'oakQeBuJLUJV8znUY9Uw631HTMGLmf',
            'signName'        => '跑步钱进',
            'templateCode'    => 'SMS_129761518',
            'templatePara'    => 'ucode',
        ];

        $aliyunSms = new AliyunSms($config);
        $status    = $aliyunSms->sendInviteMsg($new_mobile, $Userid);

        // 短信发送失败
        if (!$status) {
            return $this->sendError(-1, $aliyunSms->error, 400);
        } else {    // 短信发送成功
            // cache($mobile.'_code', $veryify_code, 600);
            return $this->sendSuccess('', 'success', 200);
        }
    }


    /**
     * @title  网页注册
     * @return error   int     错误码
     * @return message string  错误信息
     * @desc 请求方式：POST <br/> 请求示例：v1/userinviter/postRegister
     */
    public function postRegister()
    {
        $data = input('post.');

// return $this->sendSuccess($data, 'success', 200);

        $Inviter  = strFilter($data['r']);
        $Phone    = strFilter($data['p']);
        $Code     = strFilter($data['c']);
        $Password = strFilter($data['w']);

        // 数据过滤
        if (empty($Phone) || empty($Code) || empty($Password)) {
            return $this->sendError(1, '参数不足', 200);
        }

        // 校验验证码
        $cache_code = cache($Phone . '_code');
        if (empty($cache_code) || ($cache_code != $Code)) {
            return $this->sendError(1, '验证码匹配失败', 200);
        }

        // 判断邀请人是否存在
        $Inviterdata = db('user')
            ->field('id,vip,inviter_id,credit')
            ->where('no', $Inviter)
            ->where('delete_id', 0)
            ->find();

        if (empty($Inviterdata)) {
            $Inviterdata['id'] = 0;
        }

        // 判断电话是否存在
        $chcek_phone = db('user')->field('mobile')->where('mobile', $Phone)->find();

        if (!empty($chcek_phone)) {    // 用户已存在
            return $this->sendError(1, '用户已存在', 200);    
        } 

// die;

        Db::startTrans();

        try {

            {    // 注册新用户
                $here_INSERT['no']          = getNewUserNo();
                $here_INSERT['mobile']      = $Phone;
                $here_INSERT['password']    = md5($Password);
                $here_INSERT['nickname']    = 'rm_' . $Phone;
                $here_INSERT['avatar']      = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_h.png';
                $here_INSERT['levelid']     = 1;
                $here_INSERT['create_time'] = time();
                $here_INSERT['type']        = 1;
                $here_INSERT['inviter_id']  = $Inviterdata['id'];

                $Userid = db('user')->insertGetId($here_INSERT);

                if (empty($Userid)) {
                    Db::rollback();    // 回滚事务
                    return $this->sendError(1, '注册失败', 200);
                }
            }

            if ($Inviterdata['id'] > 0) {
                // 添加邀请记录
                Db::name('user_inviter')
                    ->insert([
                        'inviterid'   => $Inviterdata['id'],
                        'userid'      => $Userid,
                        'code'        => $Inviterdata['id'] . 'T' . $Userid,
                        'create_time' => time()
                    ]);

                // 添加获得步币记录
                Db::name('user_credit')
                    ->insert([
                        'userid'      => $Inviterdata['id'],
                        'type'        => 1,
                        'credit'      => 100,
                        'source'      => $Userid,
                        'create_time' => time()
                    ]);

                // 更新邀请人步币（用户表）
                Db::name('user')->where('id', $Inviterdata['id'])->setInc('credit', 100);
            }

            {   // 注册成功发表动态
                $dynamic_data['userid']   = $Userid;
                $dynamic_data['dynamic']  = base64_encode('号外！号外！我加入跑步钱进了，大家一起走路领红包吧！');
                // $dynamic_data['dynamic']  = '号外！号外！我加入跑步钱进了，大家一起走路领红包吧！';
                $dynamic_data['images'][] = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_d.png';
                $dynamic_data['images']   = serialize($dynamic_data['images']);
                $dynamic_data['create_time'] = time();

                $result = Db::name('dynamic')->insert($dynamic_data);
            }

            // 提交事务
            Db::commit();
            // return $this->sendSuccess(0, 'success', 200);
            return $this->sendSuccess(0, '注册成功', 200);
        } catch (Exception $e) {
            Db::rollback();    // 回滚事务
            return $this->sendError(1, '录入邀请码失败', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'getMyInviter' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
                'page'   => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '当前页码',
                    'range'   => ''
                ],
                'pagesize'   => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '每页显示数量',
                    'range'   => ''
                ],
            ],
            'save' => [
                'icode' => [
                    'name'    => 'icode', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '邀请码（通过获取邀请码接口获取）', 
                    'range'   => '',
                ],
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
            ],
            'inviteMsg' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'phones' => [
                    'name'    => 'phones', 
                    'type'    => 'array', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '手机号码，数组，["13192881326","13192881327","1319288132"]', 
                    'range'   => '',
                ],
            ],
            'postRegister' => [
                'r' => [
                    'name'    => 'r', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '引荐人ID',
                    'range'   => '',
                ],
                'p' => [
                    'name'    => 'p', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '注册的手机号码', 
                    'range'   => '',
                ],
                'c' => [
                    'name'    => 'c', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '验证码', 
                    'range'   => '',
                ],
                'w' => [
                    'name'    => 'w', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '密码', 
                    'range'   => '',
                ]
            ],
            'getMyCode' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
