<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:45
// +----------------------------------------------------------------------
// | TITLE: 段位数据接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;

/**
 * Class  UserLevel
 * @title 段位数据接口
 * @url   v1/userlevel
 * @desc  获取段位列表
 * @version 1.0
 */
class UserLevel extends Base
{
    /**
     * @title 获取段位列表
     * @return int id 段位id
     * @return string level  段位级别
     * @return int target  段位需要步数
     * @return int number 达标人数
     * @desc获取段位列表，请求方式：GET <br/>地址：v1/userlevel
     */
    public function index()
    {
        $level = db('user_level')
               ->field(true)
               ->select();
        
        foreach ($level as $key => $value) {
            $levelid = $level[$key]['id'];
            
            $number = Db::name('user')
            ->where('levelid',$levelid)
            ->count();

            $level[$key]['number'] = $number;
        }

        if($level){
            return $this->sendSuccess($level, 'success', 200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }
    /**
     * @title 根据用户ID, 获取段位
     * @author chenjie 2018-02-08
     * @return int id 段位id
     * @return string level  段位级别
     * @return int target  段位需要步数
     * @return int number 达标人数
     * @return int total_step_number 用户总步数
     * @return int beat 打败人数百分比
     * @desc获取段位列表，请求方式：GET <br/>地址：v1/userlevel/1
     */
    public function read($id){
        $user = Db::name('user')->where('id',$id)->find();
        if(!$user){
            $this->sendError(-1, '用户不存在', 200);
        }

        // 用户段位信息
        $userLevel = Db::name('user')
        ->alias('user')
        ->join('user_level','user_level.id = user.levelid')
        ->field('user_level.*')
        ->where('user.id',$id)
        ->find();

        // 用户总步数
        $userLevel['total_step_number'] = Db::name('user_step')
        ->where('userid',$id)
        ->sum('step_number');

        // 段位达标人数
        $userLevel['number'] = Db::name('user')
        ->where(['levelid'=>['<=', $userLevel['id']]])
        ->count();

        // 打败百分比
        $totalNumber = Db::name('user')->count();
        $userLevel['beat'] = round($userLevel['number']/$totalNumber*100);

        if($userLevel){
            return $this->sendSuccess($userLevel, 'success', 200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }
    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'read' => [
                'id'    =>  [
                    'name' => 'id', 
                    'type' => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc' => '用户ID', 
                    'range' => '',
                ],
            ],
        ];
        
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
