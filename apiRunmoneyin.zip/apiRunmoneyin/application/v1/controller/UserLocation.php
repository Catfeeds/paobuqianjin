<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/04/10 15:00
// +----------------------------------------------------------------------
// | TITLE: 用户位置接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use think\Validate;
// use app\v1\extend\AliyunSms;

// // 指定允许其他域名访问  
// header('Access-Control-Allow-Origin:*');  
// // 响应类型  
// header('Access-Control-Allow-Methods:POST');  
// // 响应头设置  
// header('Access-Control-Allow-Headers:x-requested-with,content-type');  

/**
 * Class  UserLocation
 * @title 用户位置接口
 * @url   v1/UserLocation
 * @desc  邀请好友接口相关接口：邀请达人排行榜、获取我的邀请人数、发短信邀请好友（手机通讯录）、网页注册
 * @version 1.0
 */
class UserLocation extends Base
{
    // // 跳过验证方法
    // protected $skipAuthActionList = ['setLocation'];

    // 附加方法
    protected $extraActionList = ['setLocation'];

    protected $rule = [
        'userid'    => 'require',
        'longitude' => 'require|between:-180,180',
        'latitude'  => 'require|between:-90,90',
    ];

    protected $msg = [
        'userid.require'    => '用户ID必填',
        'longitude.require' => '经度必填',
        'longitude.between' => '经度必须在-180~180之间',
        'latitude.require'  => '纬度必填',
        'latitude.between'  => '纬度必须在-90~90之间',
    ];

    /**
     * @title  用户位置记录
     * @return int      error   错误码
     * @return string   massage 错误信息
     * @desc  请求方式：POST <br/>地址：v1/UserLocation/setLocation
     */
    public function setLocation(Request $request)
    {
        $data = input('post.');

        // 验证字段
        $validate = new Validate($this->rule, $this->msg);
        $validate_result = $validate->check($data);

        if (empty($validate_result)) {
            return $this->sendError(-1, $validate->getError(), 400);
        }

// self::statisticsLocation($data['userid']);
// exit();

        $location_INSERT = [
            'userid'      => $data['userid'],
            'longitude'   => round($data['longitude'], 6),
            'latitude'    => round($data['latitude'], 6),
            'ip'          => $request->ip(),
            'create'      => date('Y-m-d H:i:s'),
            'create_time' => time(),
        ];

        Db::startTrans();

        try {
            // 添加用户位置记录
            $Locationid = db('user_location')->insertGetId($location_INSERT);

            // 更新用户现在的位置
            $user_UPDATE['n_long']       = round($data['longitude'], 6);
            $user_UPDATE['n_lat']        = round($data['latitude'], 6);
            $user_UPDATE['n_updatetime'] = time();

            $User_res = db('user')->where('id', $data['userid'])->update($user_UPDATE);

            // // 计算用户的家-公司位置
            // self::statisticsLocation($data['userid']);

            Db::commit();
            return $this->sendSuccess('', 'success', 200);

        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(-1, 'error', 400);
        }
    }

    /**
     * @title  计算用户的家-公司位置
     * @return int    error   错误码
     * @return string massage 错误信息
     * @desc  请求方式：POST <br/>地址：v1/UserLocation/statisticsLocation
     */
    private function statisticsLocation($Userid = 0)
    {   
        $Userid = intval($Userid);

        if (empty($Userid)) {
            $Userid = input('post.userid');
        }

        if (empty($Userid)) {
            $Userid = input('get.userid');
        }

        if (empty($Userid)) {
            return false;
        }

        $Locationdata = db('user_location')->field(true)->where('userid', $Userid)->select();

        if (empty($Locationdata)) {
            return false;
        }

        // 执行运算处理数据，算出家-公司位置
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'setLocation' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
                'longitude' => [
                    'name'    => 'longitude', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '经度（-180~180之间）', 
                    'range'   => '',
                ],
                'latitude' => [
                    'name'    => 'latitude', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '纬度（-90~90之间）', 
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
