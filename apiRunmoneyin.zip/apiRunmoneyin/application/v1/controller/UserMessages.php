<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:45
// +----------------------------------------------------------------------
// | TITLE: 用户消息接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Validate;

/**
 * Class  Messages
 * @title 用户消息接口
 * @url   v1/usermessages
 * @desc  消息相关接口：获取消息列表、发送消息、获取消息详情
 * @version 1.0
 */
class UserMessages extends Base
{
    //附加方法
    protected $extraActionList = ['detail'];

    /**
     * @title 获取消息列表
     * @return int    id          消息id
     * @return int    dynamicid   动态ID
     * @return int    from_userid 发送方用户ID
     * @return string from_userid 发送方用户ID
     * @return string to_userid   接收方用户ID
     * @return string title       消息标题
     * @return string content     消息内容
     * @return int    create_time 发送时间dynamicdata
     * @return array  dynamicdata 原动态的数据
     * @desc 请求方式：GET <br/>地址：v1/usermessages?userid=1&typeid=1
     */
    public function index()
    {
        $data     = input('get.');
        $userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $userid   = isset($data['userid']) ? intval($data['userid']) : 0;
        $typeid   = isset($data['typeid']) ? intval($data['typeid']) : 0;
        $page     = input('get.page') ? input('get.page') : 1;
        $pagesize = input('get.pagesize') ? input('get.pagesize') : 10;

        if (empty($userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        if ($typeid == 0) {

            for ($i=2; $i <= 4; $i++) {
                if ($i == 2) {
                    $array_key = 'comment';    
                    $map['typeid'] = 2; 
                } else if ($i == 3) {
                    $array_key = 'praise';    
                    $map['typeid'] = 3; 
                } else if ($i == 4) {
                    $array_key = 'system';    
                    $map['typeid'] = 4; 
                }
                
                $map['to_userid'] = $userid;

                // 获取消息信息
                $user_messages[$array_key] = db('user_messages')
                    ->alias('user_messages')
                    ->join('user','user.id = user_messages.from_userid', 'left')
                    ->join('user user2','user2.id = user_messages.to_userid', 'left')
                    ->join('dynamic','dynamic.id = user_messages.dynamicid', 'left')
                    ->where($map)
                    ->field('
                        user_messages.id,
                        user_messages.dynamicid,
                        user_messages.from_userid,
                        user.nickname as from_nickanme,
                        user.avatar as from_avatar,
                        user_messages.to_userid,
                        user2.nickname as to_nickanme,
                        user_messages.typeid,
                        user_messages.title,
                        user_messages.content,
                        dynamic.dynamic,
                        dynamic.images,
                        user_messages.create_time
                    ')
                    ->order('user_messages.create_time', 'desc')
                    ->limit(1)
                    ->find();
            }

            foreach ($user_messages as $key => $value) {
                if ($user_messages[$key]['images']) {
                    $user_messages[$key]['images'] = unserialize($user_messages[$key]['images']);
                } else {
                    $user_messages[$key]['images'] = array();
                }

                if ($value['dynamicid'] > 0) {
                    $user_messages[$key]['dynamicdata'] = db('dynamic')
                        ->alias('dynamic')
                        ->field('
                            dynamic.id,
                            dynamic.userid,
                            user.avatar,
                            user.nickname,
                            dynamic.dynamic,
                            dynamic.images,
                            dynamic.city,
                            dynamic.vote,
                            dynamic.comment,
                            dynamic.create_time
                        ')
                        ->join('user','user.id = dynamic.userid')
                        ->where('dynamic.id', $value['dynamicid'])
                        ->find();

                    if ($user_messages[$key]['dynamicdata']['images']) {
                        $user_messages[$key]['dynamicdata']['images'] = unserialize($value['images']);   // 反序列化
                    } else {
                        $user_messages[$key]['dynamicdata']['images'] = [];
                    }
                } else {
                    $user_messages[$key]['dynamicdata'] = [];
                }
            }
            unset($key, $value);

// dump($user_messages);
// exit();   

            if ($user_messages) {
                return $this->sendSuccess($user_messages, 'success', 200);
            } else {
                return $this->sendError(1, 'Not found Data', 200);
            }

        } else {
            if (($typeid < 0) || ($typeid > 4)) {
                return $this->sendError(-1, '类型ID未填，或者类型出错', 400);
            }

            // 条件拼接
            $map['typeid']    = $typeid;
            $map['to_userid'] = $userid;

            // 获取消息总数
            $totalCount = db('user_messages')
                ->where($map)
                ->field('id,dynamicid,from_userid,to_userid,typeid,title,content,create_time')
                ->order('create_time','desc')
                ->count();

            if ($totalCount <= 0) {
                return $this->sendError(1, 'Not found Data', 200);
            }

            // 获取消息信息
            $user_messages = db('user_messages')
                ->alias('user_messages')
                ->join('user','user.id = user_messages.from_userid', 'left')
                ->join('user user2','user2.id = user_messages.to_userid', 'left')
                ->join('dynamic','dynamic.id = user_messages.dynamicid', 'left')
                ->where($map)
                ->field('
                    user_messages.id,
                    user_messages.dynamicid,
                    user_messages.from_userid,
                    user.nickname as from_nickanme,
                    user.avatar as from_avatar,
                    user_messages.to_userid,
                    user2.nickname as to_nickanme,
                    user_messages.typeid,
                    user_messages.title,
                    user_messages.content,
                    dynamic.dynamic,
                    dynamic.images,
                    user_messages.create_time
                ')
                ->order('user_messages.create_time', 'desc')
                ->page($page, $pagesize)
                ->select();

    // dump($user_messages);

            foreach ($user_messages as $key => $value) {
                if ($user_messages[$key]['images']) {
                    $user_messages[$key]['images'] = unserialize($user_messages[$key]['images']);
                } else {
                    $user_messages[$key]['images'] = array();
                }

                if ($value['dynamicid'] > 0) {
                    $user_messages[$key]['dynamicdata'] = db('dynamic')
                        ->alias('dynamic')
                        ->field('
                            dynamic.id,
                            dynamic.userid,
                            user.avatar,
                            user.nickname,
                            dynamic.dynamic,
                            dynamic.images,
                            dynamic.city,
                            dynamic.vote,
                            dynamic.comment,
                            dynamic.create_time
                        ')
                        ->join('user','user.id = dynamic.userid')
                        ->where('dynamic.id', $value['dynamicid'])
                        ->find();

                    if ($user_messages[$key]['dynamicdata']['images']) {
                        $user_messages[$key]['dynamicdata']['images'] = unserialize($value['images']);   // 反序列化
                    } else {
                        $user_messages[$key]['dynamicdata']['images'] = [];
                    }

                    // 判断我是否点赞过
                    $uservote = db('dynamic_vote')->where('userid', $userid )->where('dynamicid', $value['dynamicid'])->find();

                    if (empty($uservote)) {
                        $user_messages[$key]['dynamicdata']['is_vote'] = 0;
                    } else {
                        $user_messages[$key]['dynamicdata']['is_vote'] = 1;
                    }

                } else {
                    $user_messages[$key]['dynamicdata'] = [];
                }

            }
            unset($key, $value);

    // dump($map);
    // dump($totalCount);
    // dump($user_messages);
    // exit();

            $retData = returnData($page, $pagesize, $totalCount, $user_messages);

            if ($user_messages) {
                return $this->sendSuccess($retData, 'success', 200);
            } else {
                return $this->sendError(1, 'Not found Data', 200);
            }
        }
    }

    /**
     * @title 发送消息
     * @desc 请求方式：POST <br/>地址：v1/usermessages
     */
    public function save()
    {
        $data   = input('post.');
        $typeid = isset($data['typeid']) ? $data['typeid'] : 0;

        $data['create_time'] = time();

        if (!$typeid) {
            return $this->sendError(-1, '类型ID必填!', 400);
        }

        if ($typeid == 1 || $typeid == 2 || $typeid ==3) {
            $rule = [
                'dynamicid'   => 'require',
                'from_userid' => 'require',
                'to_userid'   => 'require',
            ];

            $msg = [
                'dynamicid.require'   => '动态ID必填',
                'from_userid.require' => '发送方用户ID必填',
                'to_userid.require'   => '接受方用户ID必填',
            ];

            if ($typeid == 1) {
                $data['content'] = '在TA的动态中@了你';
            } else if ($typeid == 2) {
                $data['content'] = '在TA的动态中评论了你';
            } else if ($typeid == 3) {
                $data['content'] = '在TA的动态中点赞了你';
            }
        } else {
            $rule = [
                'title'   => 'require',
                'content' => 'require'
            ];

            $msg = [
                'title.require'   => '消息标题必填',
                'content.require' => '消息内容必填'
            ];
        }

        // 字段验证
        $validate = new Validate($rule, $msg);
        $result   = $validate->check($data);

        if (!$result) {
            return $this->sendError(-1, $validate->getError(), 400);
        }

        if (!empty($data['content'])) {
            $result = db('user_messages')->insert($data);

            if($result) {
                return $this->sendSuccess(0, '发送成功', 200);
            } else {
                return $this->sendError(-1, '发送失败', 400);
            }
        } else {
            return $this->sendError(-1, '发送内容不能为空', 400);
        }
    }

    /**
     * @title 获取消息详情
     * @return int userid 接收方用户id
     * @return int from 发送方用户id
     * @return string title 消息标题
     * @return string content 消息内容
     * @return int create_time 发送消息时间
     * @desc 请求方式：GET <br/>地址：v1/usermessages/detail?id=1
     */
    public function detail()
    {
        $id     = input('get.id');
        $detail = db('user_messages')
            ->where('id', $id)
            ->field('id,typeid', true)
            ->find();

        if ($detail) {
            return $this->sendSuccess($detail, 'success', 200);
        } else {
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
                'typeid' => [
                    'name'    => 'typeid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '消息类型id: 0消息页面数据（comment，praise，system）|1@我的|2评论|3点赞|4系统消息', 
                    'range'   => '',
                ],
            ],
            'save' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '接收方id', 
                    'range'   => '',
                ],
                'from_userid' => [
                    'name'    => 'from_userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '发送方id', 
                    'range'   => '',
                ],
                'typeid' => [
                    'name'    => 'typeid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '消息类型id', 
                    'range'   => '',
                ],
                'title' => [
                    'name'    => 'title', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '消息标题', 
                    'range'   => '',
                ],
                'content' => [
                    'name'    => 'content', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '消息内容', 
                    'range'   => '',
                ],

            ],
            'detail' => [
                'id' => [
                    'name'    => 'id', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '消息id', 
                    'range'   => '',
                ],
            ]
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
