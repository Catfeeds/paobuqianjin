<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:50
// +----------------------------------------------------------------------
// | TITLE: 消息类型接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;

/**
 * Class  MessagesType
 * @title 消息类型接口
 * @url   v1/UserMessagesType
 * @desc  消息类型相关接口：获取消息类型列表
 * @version 1.0
 */
class UserMessagesType extends Base
{
    /**
     * @title 获取消息类型列表
     * @return int id 消息类型id
     * @return string typename 消息类型名称
     * @desc获取消息类型列表，请求方式：get，<br/>地址：v1/UserMessagesType
     */
    public function index()
    {
        $messagesType = db('user_messages_type')->select();

        if($messagesType){
            return $this->sendSuccess($messagesType, 'success', 200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [],
        ];
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }

}
