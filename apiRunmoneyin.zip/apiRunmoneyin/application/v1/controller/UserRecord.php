<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:50
// +----------------------------------------------------------------------
// | TITLE: 用户位置接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Validate;
use think\Db;

/**
 * Class  UserRecord
 * @title 用户位置接口
 * @url   v1/UserRecord
 * @desc  用户登陆记录：获取用户登陆记录、用户登录记录
 * @version 1.0
 * @readme
 */
class UserRecord extends Base
{
    // 附加方法
    protected $extraActionList = ['userLocation'];
    
    protected $rule = [
        'userid'    => 'require',
        'longitude' => 'require',
        'latitude'  => 'require',
    ];

    protected $msg = [
        'userid.require'    => '用户ID必填',
        'longitude.require' => '经度必填',
        'latitude.require'  => '纬度必填',
    ];

    /**
     * @title 获取用户位置记录列表
     * @return string id           用户登录记录id
     * @return string userid       用户id
     * @return string longitude    用户登录位置经度
     * @return string latitude     用户登录位置纬度
     * @return string create_time  用户登录时间
     * @desc  请求方式：GET <br/> v1/UserRecord?id=2&pag=1&pagesize=10
     */
    public function index()
    {
        $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = input('get.userid');
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        if (!$Userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        $login_list = db('user_log')
            ->field('ip,agent', true)
            ->order('update', 'desc')
            ->where('userid', $Userid)
            ->page($page, $pageSize)
            ->select();

        // 处理登陆情况
        if (!$login_list) {
            return $this->sendError(1, 'Not found Data', 200);
        } else {
            return $this->sendSuccess($login_list, 'success', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
    
}
