<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:52
// +----------------------------------------------------------------------
// | TITLE: 用户步数接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;

/**
 * Class  UserStep
 * @title 用户步数接口
 * @url   v1/userstep
 * @desc  用户步数接口：获取当前用户行走步数、更新用户步数信息
 * @version 1.0
 */
class UserStep extends Base
{
    protected $extraActionList = ['getDayStep', 'updateStep'];

    /**
     * @title 获取用户累计步数
     * @return int sum_step_number 用户步数
     * @desc 请求方式: GET <br/>请求示例：v1/UserStep?userid=1(用户ID)
     */
    public function index()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid = input('get.userid');

        if (!$Userid) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        $sum_step = Db::name('user_step')->where('userid', $Userid)->sum('step_number');

        return $this->sendSuccess(array('sum_step_number' => $sum_step), 'success', 200);
    }

    /**
     * @title  根据时间获取用户当天步数
     * @return array sum_step 用户当天的步数数据
     * @desc 请求方式: GET <br/>请求示例：v1/UserStep/getDayStep?userid=1&day=2018-04-16
     */
    public function getDayStep()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid = intval(input('get.userid'));
        $Day    = input('get.day');

        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        if (empty($Day)) {
            return $this->sendError(-1, '时间必填', 400);
        }

        if (strlen($Day) != 10) {
            return $this->sendError(-1, '时间格式出错', 400);
        }

        $tahtday = date('Y-m-d', strtotime($Day));

        if (empty($tahtday)) {
            return $this->sendError(-1, '时间格式出错', 400);
        }

        $sum_step = Db::name('user_step')->field(true)->where('userid', $Userid)->where('create_day', $tahtday)->find();

        if (empty($sum_step)) {
            return $this->sendError(-1, 'Not Found Data', 200);
        } else {
            return $this->sendSuccess($sum_step, 'success', 200);
        }
    }

    /**
     * @title 获取用户当前步数信息
     * @return int error 错误代码 0成功 -1失败
     * @return string message 消息提醒
     * @return int id 主键ID
     * @return int userid 用户ID
     * @return int step_number 用户当前步数
     * @return int update_time 更新时间
     * @return int create_time 创建时间
     * @desc 请求方式: GET <br/>请求示例：v1/UserStep/1(用户ID)
     */
    public function read($id)
    {
        $Userid = intval($id) ? intval($id) : intval($this->userId);

        $sameDay = strtotime('today');    // 当日时间戳
        $nextDay = $sameDay + 86399;      // 次日时间戳

        $user_step = db('user_step')
           ->field(true)
           ->where(['userid' => $Userid, 'create_time' => ['between', [$sameDay, $nextDay]]])
           ->find();

        if ($user_step) {
            return $this->sendSuccess($user_step, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }

    /**
     * @title  更新用户步数信息
     * @return int error 错误代码 0成功 1失败
     * @return string message 消息提醒
     * @desc  请求方式：POST <br/>地址：v1/UserStep/updateStep
     */
    public function updateStep()
    {
        $data        = input('post.');
        $Userid      = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid      = isset($data['userid']) ? intval($data['userid']) : 0;
        $step_number = isset($data['step_number']) ? intval($data['step_number']) : 0;

        $sameDay     = strtotime('today');    // 当日时间戳
        $nextDay     = $sameDay + 86399;      // 次日时间戳
        $today       = date('Y-m-d', $sameDay );    // 当日日期

        // if (empty($Userid)) {
        //     return $this->sendError(-1, '用户ID必填', 400);
        // }

        if (empty($step_number)) {
            return $this->sendError(1, '用户步数必填', 200);
        }

        if ($step_number < 0) {
            return $this->sendError(1, '用户步数不能小于0', 200);
        }

        // Mysql 存在既更新，不存在就添加（sql语句）
        // replace into t(id, update_time) values(1, now());

        $user_step = db('user_step')
            ->field(true)
            ->where([
                'userid'      => $Userid,
                'create_day'  => $today,
            ])
            ->order('id desc')
            ->find();

// dump($step_number);
// dump($user_step['step_number']);
// die;
        if ($step_number <= $user_step['step_number']) {
            return $this->sendError(1, '用户步数不能小于已经生成的', 200);
        }

        // 用户步数不存在写入数据
        if ($user_step <= 0) {
            $data = array(
                'userid'      => $Userid,
                'step_number' => $step_number,
                'create_day'  => $today,
                'create_time' => time(),
                'update_time' => time(),
            );

            $result = db('user_step')->insert($data);

        } else {    // 用户步数存在，更新用户步数
            $result = db('user_step')
                ->where([
                    'userid'     => $Userid,
                    'create_day' => $today,
                ])
                ->update([
                    'update_time' => time(), 
                    'step_number' => $step_number
                ]);
        }

// dump($user_step);
// dump($result);
// exit();

        // 提升段位并记录提升记录
        if (!empty($result) && ($step_number > $user_step['step_number'])) {
            // 获取总步数
            $total_step_number = db('user_step')->where('userid', $Userid)->sum('step_number');

            // 根据步数查询所在段位
            $user_level = db('user_level')
                // ->field(true)
                ->where('target', '<=', $total_step_number)
                ->where('end', '>', $total_step_number)
                // ->fetchSql(true)
                ->value('id');
            
            // 获取用户当前段位
            $user_now_level = db('user_level')
                ->where('id', $Userid)
                ->value('id');
            
            // 判断是否要更新段位
            if ($user_now_level < $user_level) {
                // 更新段位
                $updat_level = db('user')
                    ->where('id', $Userid)
                    ->where('levelid', '<', $user_level)
                    ->setField(['levelid' => $user_level]);

                // 添加段位达标时间
                $level_log = db('user_level_record')
                    ->where([
                        'userid'  => $Userid,
                        'levelid' => $user_level,
                    ])
                    ->find();

                // 添加段位达标时间
                if (!$level_log) {
                    $level_log = db('user_level_record')
                        ->insert([
                            'userid'      => $Userid,
                            'levelid'     => $user_level,
                            'create_time' => time(),
                        ]);
                }
            }
        }

        if ($result) {
            return $this->sendSuccess('', 'success', 200);
        } else {
            return $this->sendError(1, 'error', 400);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
            ],
            'getDayStep' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'day' => [
                    'name'    => 'day', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '时间（格式：2018-04-16）', 
                    'range'   => '',
                ],
            ],
            'read' => [
                'id' => [
                    'name'    => 'id', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
            ],
            'updateStep' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
                'step_number' => [
                    'name'    => 'step_number', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户步数', 
                    'range'   => '',
                ]
            ]
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
    
}
