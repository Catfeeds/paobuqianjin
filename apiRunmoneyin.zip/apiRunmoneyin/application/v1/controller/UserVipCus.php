<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/05/19 15:40
// +----------------------------------------------------------------------
// | TITLE: 商户会员接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;

/**
 * Class  UserVipCus
 * @title vip接口
 * @url   v1/UserVipCus
 * @desc  充值成为商户会员
 * @version 1.0
 */
class UserVipCus extends Base
{
    // 附加方法
    protected $extraActionList = [];

    // 商户会员价格（原价）
    // protected $cusVipMoney = 1999.99;
    
    // 商户会员价格
    protected $cusVipMoney = 25.00;

    // 默认商户会员开通时间
    protected $defaultDay  = 365;

    /**
     * @title  获取所有商户会员
     * @return int    error   错误代码：0失败 1成功
     * @return string message 消息提醒
     * @desc 请求方式: GET <br/>请求示例：v1/UserVipCus
     */
    // @desc 请求方式: GET <br/>请求示例：v1/UserVipCus?userid=1(用户ID)
    // public function index()
    // {
    //     $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
    //     // $Userid = input('get.userid');

    //     if (!$Userid) {
    //         return $this->sendError(-1, '用户ID必填', 400);
    //     }

    //     $sum_step = Db::name('user_step')->where('userid', $Userid)->sum('step_number');

    //     return $this->sendSuccess(array('sum_step_number' => $sum_step), 'success', 200);
    // }

    /**
     * @title  充值成为商户会员
     * @return int    error     错误代码：0成功 1失败
     * @return string message   消息提醒
     * @return array  data      返回数组
     * @return string cvip_no   商户会员充值编号
     * @desc 请求方式: POST <br/>请求示例：v1/UserVipCus
     */
    public function save()
    {
        $Adminid = intval(input('userid')) ? intval(input('userid')) : intval($this->userId);
        $Day     = intval(input('day')) ? intval(input('day')) : intval($this->defaultDay);
        $Userids = input('userids');
        $Spend   = round(input('spend'), 2);

        if (empty($Userids)) {
            $Userids = $Adminid;
            $vip_INSERT['type'] = 1;
        }

        if (round($Spend, 2) <= 0.00) {
            return $this->sendError(1, '花费必填', 200);
        }

        $Useridarray = explode(',', $Userids);
        $Useridarray = array_filter($Useridarray);
        $Useridarray = array_unique($Useridarray);
        $Useridarray = array_merge($Useridarray);

        if (empty($Useridarray)) {
            return $this->sendError(1, '需要充值的用户数据填写错误', 200);
        } elseif (count($Useridarray) == 1) {
            if ($Useridarray[0] == $Adminid) {
                $vip_INSERT['type'] = 1;
            }
        }

        // 判断是否已经是vip
        $record_WHERE['id']        = ['in', $Useridarray];
        $record_WHERE['delete_id'] = 0;
        $record_WHERE['cusvip']    = 1;
        
        $Oldvip = Db::name('user')->field('id,no,vip,cusvip')->where($record_WHERE)->select();

        $diffarray = [];
        if (count($Oldvip) > 0) {
            $Oldarray = array_column($Oldvip, 'id');
            $Oldarray = array_unique($Oldarray);

            if (count($Oldarray) > 0) {
                $diffarray = array_diff($Useridarray, $Oldarray);

                if (empty($diffarray) || (count($diffarray) != count($Useridarray))) {
                    return $this->sendError(1, '花费与人数不符(1)', 200);
                }
            }
        }

        if (empty($Useridarray)) {
            return $this->sendError(1, '充值用户id必填', 200);
        }

        if (($this->cusVipMoney * count($Useridarray)) != $Spend) {
            return $this->sendError(1, '花费与人数不符(2)', 200);
        }

        $Cvipno = date("Ymdhis").rand(1000, 9999); // 订单编号，18位

        Db::startTrans();
        try {
            // 添加充值vip记录
            $vip_INSERT['addid']       = $Adminid;
            $vip_INSERT['cvip_no']     = $Cvipno;
            $vip_INSERT['spend']       = $Spend;
            $vip_INSERT['day']         = $Day;
            $vip_INSERT['create_day']  = date('Y-m-d');
            $vip_INSERT['create_time'] = time();
            $vip_INSERT['end_time']    = time() + $Day * 24 * 60 * 60;


            $Cvid = Db::name('user_vipcus')->insertGetId($vip_INSERT);

            $vip_record_INSERT = [];
            foreach ($Useridarray as $key => $value) {
                $vip_record_INSERT[$key]['userid']      = $value;
                $vip_record_INSERT[$key]['cvip_no']     = $Cvipno;
                $vip_record_INSERT[$key]['spend']       = $this->cusVipMoney;
                $vip_record_INSERT[$key]['day']         = $Day;
                $vip_record_INSERT[$key]['create_day']  = $vip_INSERT['create_day'];
                $vip_record_INSERT[$key]['create_time'] = $vip_INSERT['create_time'];
                $vip_record_INSERT[$key]['end_time']    = $vip_INSERT['end_time'];
            }
            unset($key, $value);

            Db::name('user_vipcus_record')->insertAll($vip_record_INSERT);

            Db::commit();
            return $this->sendSuccess(['cvip_no' => $Cvipno], 'success', 200);
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(1, 'error', 200);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
            ],
            'read' => [
                'id' => [
                    'name'    => 'id', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID', 
                    'range'   => '',
                ],
            ],
            'save' => [
                'userids' => [
                    'name'    => 'userids', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户ID逗号隔开（例：1,56,5），不传的时候默认为自己充值', 
                    'range'   => '',
                ],
                'spend' => [
                    'name'    => 'spend', 
                    'type'    => 'float', 
                    'require' => 'true',
                    'default' => '', 
                    'desc'    => '充值花费（单位：元，例：5.20）', 
                    'range'   => '',
                ],
                'day' => [
                    'name'    => 'day', 
                    'type'    => 'int', 
                    'require' => 'false',
                    'default' => '365（一年）', 
                    'desc'    => '天数',
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }
    
    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
