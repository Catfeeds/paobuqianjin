<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:52
// +----------------------------------------------------------------------
// | TITLE: 我的提现接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;  
use think\Validate;
use think\Db;
use Payment\Common\PayException;
use Payment\Client\Transfer;
use Payment\Config;
use app\v1\extend\HelibaoInt;

/**
 * Class  WithDraw
 * @title 我的提现接口
 * @url   v1/withdraw
 * @desc  我的提现接口：添加提现记录、获取用户提现信息
 * @version 1.0
 */
class WithDraw extends Base
{
    // 附加方法
    protected $extraActionList = ['rechargeList', 'withdrawOld'];

    // 跳过验证方法
    //protected $skipAuthActionList = ['save'];

    /**
     * @title 获取提现记录
     * @author chenjie 2018-02-06
     * @return int    userid        用户id
     * @return string typeid        提现类型id 1微信 2支付宝 3银行卡
     * @return string amount        提现金额
     * @return int    actual_amount 实际到账金额
     * @return int    status        0提现审核中 1提现成功
     * @return string create_time   提现时间
     * @desc 请求方式: get <br/> 请求示例: v1/withdraw?userid=1
     */
    public function index()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = input('get.userid');
        $page     = input('get.page') ? intval(input('get.page')) : 1;           // 当前分页
        $pageSize = input('get.pagesize') ? intval(input('get.pagesize')) : 10;  // 每页显示数量

        if (!$Userid) {
            return $this->sendError(-1, '用户ID必填');
        }

        $totalCount = Db::name('withdraw')->where('userid', $Userid)->count();

        $withdraw = Db::name('withdraw')
            ->where('userid', $Userid)
            ->order('id desc')
            ->page($page, $pageSize)
            ->select();

        $type = [
            '1'=>'微信',
            '2'=>'支付宝',
            '3'=>'银行卡',
        ];

        foreach ($withdraw as &$v){
            $v['type_name'] = '提现到'.$type[$v['typeid']];
        }

        $retData = returnData($page, $pageSize, $totalCount, $withdraw);

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }

    /**
     * @title  获取用户充值记录
     * @author wensen 2018-03-21
     * @return int    userid      用户id
     * @return int    otype       订单类型: 0圈子 1用户 2任务
     * @return int    ptype       支付方式: 1钱包 2微信 3支付宝
     * @return string nickname    用户名
     * @return string avatar      用户头像
     * @return float  total_fee   充值金额
     * @return string order_no    订单编号
     * @return int    status      0没充值成功 1充值成功 2取消订单
     * @return string create_time 充值时间
     * @desc 请求方式: POST <br/> 请求示例: v1/withdraw/rechargeList
     */
    public function rechargeList()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        // $Userid   = intval(input('post.userid'));
        $page     = input('post.page') ? intval(input('post.page')) : 1;           // 当前分页
        $pageSize = input('post.pagesize') ? intval(input('post.pagesize')) : 10;  // 每页显示数量

        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填');
        }

        $totalCount = Db::name('order')
            ->alias('order')
            ->field('distinct order.userid,user.userid,total_fee,order.create_time')
            ->join('user', 'user.id = order.userid', 'left')
            ->join('order_recharge_record', 'order_recharge_record.order_no = order.order_no', 'left')
            ->where('order.userid', $Userid)
            ->where('order.status', 1)
            // ->group('order.userid')
            ->count();

        $order = Db::name('order')
            ->alias('order')
            ->field('
                distinct 
                order.id,
                order_type as otype,
                payment_type as ptype,
                order.order_no,
                order.userid,
                user.nickname,
                user.avatar,
                total_fee,
                order.create_time
            ')
            ->join('user','user.id = order.userid', 'left')
            ->join('order_recharge_record','order_recharge_record.order_no = order.order_no', 'left')
            ->where('order.userid', $Userid)
            ->where('order.status', 1)
            // ->group('order.userid')
            ->order('order.create_time desc')
            ->page($page, $pageSize)
            ->select();
        $payment_type = [
            '1'=>'钱包支付',
            '2'=>'微信充值',
            '3'=>'支付宝充值',
            '4'=>'小程序充值',
            '5'=>'任务退款',
            '6'=>'云闪付',
            '7'=>'苹果内购',
        ];

        $order_type = [
            '圈子充值',
            '用户钱包',
            '任务红包',
            '充值会员',
            '商家红包',
            '退款',
            '充值商户会员',
        ];

        foreach ($order as $k => &$v) {
            $v['ptype'] == 1 && $v['total_fee'] = sprintf("%01.2f",-1*$v['total_fee']);;
            $v['pay_name'] = $payment_type[$v['ptype']].'-'.$order_type[$v['otype']];
        }

// dump($totalCount);
// dump($order);
// exit();

        $retData = returnData($page, $pageSize, $totalCount, $order);

        if ($totalCount > 0) {
            return $this->sendSuccess($retData, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }

    /**
     * @title  用户提现(微信/银行卡提现)
     * @param  int    id            提现记录id
     * @return int    userid        用户id
     * @return string type          提现类型 1微信 2支付宝 3银行卡 
     * @return string amount        提现金额
     * @return int    actual_amount 实际到账金额
     * @return int    status        0提现审核中 1提现成功
     * @return string create_time   提现时间
     * @desc 请求方式：POST <br/>请求示例：v1/withdraw
     */
    public function save(Request $request) 
    {
        $versionLimit = 5;      // APP版本功能支持限制

        {   // 数据验证
            $Typeid   = input('typeid') ? intval(input('typeid')) : 1;
            $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
            $Wxopenid = input('wx_openid');
            $Camount  = (round(input('amount'), 2) > 0) ? round(input('amount'), 2) : 0;
            $Cardid   = input('cardid');          // 选择的银行卡id

            $versionName = input('limit_version_name') ? intval(input('limit_version_name')) : '';

            if(empty($versionName) || $versionName<$versionLimit) {
                return $this->sendError(1, '你当前APP版本暂不支持此功能', 200);            
            }

            if ($Typeid == 1) {                    // 提现到微信
                return $this->sendError(1, '微信提现功能开发中', 200);

                if (empty($Wxopenid)) {
                    return $this->sendError(1, '微信openid必填', 200);
                }
            } elseif ($Typeid == 2) {    // 提现到银行卡
                return $this->sendError(1, '支付宝提现功能开发中', 200);
            } elseif ($Typeid == 3) {    // 提现到银行卡
                if (empty($Cardid)) {
                    return $this->sendError(1, '银行卡id必填', 200);
                }
            }

            if (empty($Camount)) {
                return $this->sendError(1, '提现金额必填', 200);
            }

            // if ($Camount < 10 || $Camount > 200) {
            //     return $this->sendError(1, '每日提现金额须在10-200之间', 200);
            // }

            if ($Camount < 2 || $Camount > 3) {
                return $this->sendError(1, '测试期间提现金额在2-3之间', 200);
            }
        }

        // 提现缓存不能连续提现（一天能提现两次）
        $old_withdraw = cache('withdraw_' . $Userid);
        if (empty($old_withdraw) || ($old_withdraw <= 0)) {
            $old_withdraw = 0;
        } elseif ($old_withdraw >= 2) {
            return $this->sendError(1, '每天只能提现两次', 200);
        }
        
// {   // 增加提现次数
//     $endday  = mktime(0, 0, 0, date('m'), date('d') + 1, date('Y'));
//     $expires = $endday - time();
//     cache('withdraw_' . $Userid, ++$old_withdraw, $expires);
// }
// dump($old_withdraw);
// die;

        if ($Typeid == 3) {
            /* 是否实名制 */
            $is_authen = db('user_authentication')
                ->where([
                    'userid' => $Userid,
                    'status' => 1,
                    ])
                ->find();

            if (!$is_authen) {
                return $this->sendError(1, '当前用户未实名', 200);
            }

            /* 该用户的卡是否存在/绑定 */
            $user_card = db('user_bank')
                ->where([
                    'id'      => $Cardid,
                    'userid'  => $Userid,
                    'is_bind' => 1,     // 是否绑定 1.绑定 2.解绑
                ])
                ->find();

            if (!$user_card) {
                return $this->sendError(1, '当前银行卡未绑定', 200);
            }
        }

        // 查询用户数据(余额)
        $Userdata = Db::name('user')->field('id,nickname,balance')->where('id', $Userid)->where('delete_id', 0)->find();

        if ($Userdata['balance'] < $Camount) {
            return $this->sendError(1, '余额不足, 提现失败', 200);
        }

        // 查询提现上限
        $old_sum_amount = Db::name('withdraw')
            ->where(['userid' => $Userid, 'create_time'=>[">", strtotime("today")]])
            ->sum('amount');

        // 提现金额上限
        if (($old_sum_amount + $Camount) > 200) {
            return $this->sendError(1, '目前单日提现最高限额200元', 200);
        }


        /***查询用户提现表账号****/
        // $user_bank_card = Db::name('withdraw_log')->field(true)->where(['userid' => $Userid])->find();

        if ($Typeid == 3) {      
            $bank_card_INSERT['realname']    = $user_card['account_name'];
            $bank_card_INSERT['bank_card']   = $user_card['bank_card'];
        } else {             // 微信提现
            $bank_card_INSERT['realname']    = $Userdata['nickname'];
            $bank_card_INSERT['bank_card']   = $Wxopenid;
        }

        $bank_card_INSERT['order_no']    = date('YmdHis') . rand(100000, 999999);
        $bank_card_INSERT['typeid']      = $Typeid;
        $bank_card_INSERT['userid']      = $Userid;
        $bank_card_INSERT['create_time'] = time();

        $new_withdraw_log = Db::name('withdraw_log')->insert($bank_card_INSERT);
        if (empty($new_withdraw_log))  {
            return $this->sendError(1, '系统出错', 200);
        }
        /***查询用户提现表账号****/

        $orderNo = $bank_card_INSERT['order_no'];       // 提现订单编号☆☆☆☆☆☆

        $Feemoney  = round(($Camount * 0.01 + 1), 2);   // 手续费
        $Realmoney = round(($Camount - $Feemoney), 2);  // 实际到账金额

        // 提现记录信息
        $insert_data = array(
            'userid'        => $Userid,
            'typeid'        => $Typeid,
            'amount'        => $Realmoney,
            'actual_amount' => $Camount,
            'feemoney'      => $Feemoney,
            'status'        => 1,
            'create_time'   => time(),
        );

// dump($insert_data);
// dump($Camount);
// dump($Feemoney);
// dump($Realmoney);
// exit();

        // 提现金额大于200元,审核
        if ($Camount > 200) {
            $insert_data['status'] = 0;
        } else {
            $insert_data['status'] = 1;

            // 微信提现
            if ($Typeid == 1) {
                $type   = Config::WX_TRANSFER;
                $config = config('pay.wx');
                $transfer_data = [
                    'trans_no'    => time(),
                    'openid'      => $Wxopenid,
                    // 'userid'      => $Wxopenid,
                    'check_name'  => 'NO_CHECK',// NO_CHECK：不校验真实姓名  FORCE_CHECK：强校验真实姓名   
                    'terminal_id' => 'APP',
                    'amount'      => $Realmoney,
                    'desc'        => '提现',
                    'spbill_create_ip' => Request::instance()->ip(),
                ];

                try {
                    $ret = Transfer::run($type, $config, $transfer_data);
                } catch (PayException $e) {
                    Db::rollback();
                    return $this->sendError(1, $e->errorMessage(), 200);
                }

            } else if ($Typeid == 2) {    // 支付宝提现
                $type   = Config::ALI_TRANSFER;
                $config = config('pay.alipay');
                $transfer_data = [
                    'trans_no'        => time(),
                    'payee_type'      => 'ALIPAY_LOGONID',
                    'payee_account'   => $Wxopenid,
                    'amount'          => $Realmoney,
                    'remark'          => '提现',
                    'payer_show_name' => '跑步钱进网络科技有限公司',
                ];

                try {
                    $ret = Transfer::run($type, $config, $transfer_data);
                } catch (PayException $e) {
                    Db::rollback();
                    return $this->sendError(1, $e->errorMessage(), 200);
                }

            } else if($Typeid == 3) {       // 提现到银行卡(合利宝代付)
                $withDrawArr['orderNo'] = $orderNo;
                // $withDrawArr['orderNo'] = date('YmdHis') . rand(100000, 999999);     // 订单编号
                $withDrawArr['amount']   = $Realmoney;                                  // 提现金额
                $withDrawArr['bankCode'] = $user_card['bank_code'];                     // 银行编码
                $withDrawArr['bankCard'] = $user_card['bank_card'];                     // 银行卡号
                $withDrawArr['account']  = $user_card['account_name'];                  // 银行户主名
                // $withDrawArr['bankUnionCode'] = '105584000208';                      // 银行联行号
                $withDrawArr['remark']   = '结算';                                      // 打款备注

                $helibao_obj = new HelibaoInt();                           // 合利宝集成类
                $withDrawRes = $helibao_obj->transfer($withDrawArr);       // 单笔代付(param1:银行卡信息，param2:是否对公账户[默认false])
                
                if (!$withDrawRes) {
                    return $this->sendError(1, '提现错误', 200);
                }

// dump($withDrawRes);
// die;

                if ($withDrawRes['rt2_retCode'] != '0000') {     
                    $insert_data['status'] = 3;     // 提现失败(卡号户主不符，商户账号余额不足)
                    return $this->sendError(1, $withDrawRes['rt3_retMsg'], 200);
                }

                // 合利宝代付成功
                $insert_data['order_no']       = $withDrawArr['orderNo'];
                $insert_data['transaction_no'] = $withDrawRes['rt6_serialNumber'];      // 流水号

                Db::name('withdraw_log')->where('order_no', $withDrawArr['orderNo'])->update(['status'=>1]);     // 修改

// var_dump($withDrawRes);
// die;

            } else {
                Db::rollback();
                return $this->sendError(1, '提现类型错误', 200);
            }
        }

        // if (empty($old_withdraw)) 
        {   // 增加提现次数
            $endday  = mktime(0, 0, 0, date('m'), date('d') + 1, date('Y'));
            $expires = $endday - time();
            cache('withdraw_' . $Userid, ++$old_withdraw, $expires);
        }
        
        // 提现写入记录并更新余额
        Db::startTrans();
        try {
            Db::name('withdraw')->insert($insert_data);
            Db::name('user')->where('id', $Userid)->setDec('balance', $Camount);
            Db::commit();

            if ($insert_data['status'] == 0) {
                return $this->sendSuccess(0, '提现审核中', 200);
            } else {
                return $this->sendSuccess(0, '提现成功', 200);
            }
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(1, $e->getMessage(), 200);
        }
    }

    /**
     * @title  用户提现(无银行卡提现)（微信提现限制1-20000）
     * @param  int    id            提现记录id
     * @return int    userid        用户id
     * @return string type          提现类型 1微信 2支付宝 3银行卡 
     * @return string amount        提现金额
     * @return int    actual_amount 实际到账金额
     * @return int    status        0提现审核中 1提现成功
     * @return string create_time   提现时间
     * @desc 请求方式：POST <br/>请求示例：v1/withdraw
     */
    public function saveBackup()
    {
        return $this->sendError(1, '提现功能调试中', 200);

        // $data = input('post.');
        // $data['id'] = empty($data['id']) ? $Userid : $data['id'];
        
        {   // 数据验证
            $Typeid   = input('typeid') ? intval(input('typeid')) : 1;
            $Userid   = input('userid') ? intval(input('userid')) : intval($this->userId);
            $Wxopenid = input('wx_openid');
            $Camount  = (round(input('amount'), 2) > 0) ? round(input('amount'), 2) : 0;

            if (empty($Wxopenid)) {
                return $this->sendError(1, '微信openid必填', 200);
            }

            if (empty($Camount)) {
                return $this->sendError(1, '提现金额必填', 200);
            }

            if ($Camount < 10) {
                return $this->sendError(1, '每日提现金额须在10-200之间', 200);
            }
        }

        // 提现缓存不能连续提现（一天只能提一次）
        $old_withdraw = cache('withdraw_' . $Userid);

        if (!empty($old_withdraw)) {
            return $this->sendError(1, '每天只能提现一次', 200);
        }

        // 查询用户数据
        $Userdata = Db::name('user')->field('id,nickname,balance')->where('id', $Userid)->where('delete_id', 0)->find();

        // 查询用户提现表账号
        $bank_card_WHERE['typeid'] = 1;
        $bank_card_WHERE['userid'] = $Userid;
        $user_bank_card = Db::name('withdraw_log')->field(true)->where(['userid' => $Userid])->find();

        // 没有则添加
        if (empty($user_bank_card)) {
            $bank_card_INSERT['typeid']      = 1;
            $bank_card_INSERT['userid']      = $Userid;
            $bank_card_INSERT['realname']    = $Userdata['nickname'];
            $bank_card_INSERT['bank_card']   = $Wxopenid;
            $bank_card_INSERT['create_time'] = time();

            $new_bank_card = Db::name('withdraw_log')->insert($bank_card_INSERT);
        } else {
            if ($user_bank_card['bank_card'] != $Wxopenid) {
                $bank_card_UPDATE['bank_card'] = $Wxopenid;
                $new_bank_card = Db::name('withdraw_log')->where(['userid' => $Userid])->update($bank_card_UPDATE);
            }
        }

        if ($Userdata['balance'] < $Camount) {
            return $this->sendError(1, '余额不足, 提现失败', 200);
        }

        // // 查询提现上限
        // $Userdataid = $user_bank_card['userid'];     // 用户ID
        // $typeid     = $user_bank_card['typeid'];     // 提现方式
        // $bank_card  = $user_bank_card['bank_card'];  // 提现账号
        // $amount     = $Camount;

        // 查询提现上限
        $old_sum_amount = Db::name('withdraw')
            ->where(['userid' => $Userid, 'create_time'=>[">", strtotime("today")]])
            ->sum('amount');

        // 提现金额上限
        if (($old_sum_amount + $Camount) > 200) {
            return $this->sendError(1, '目前单日提现最高限额200元', 200);
        }

        // 提现记录信息
        $insert_data = array(
            'userid'        => $Userid,
            'typeid'        => 1,
            'amount'        => $Camount,
            'actual_amount' => $Camount,
            'status'        => 1,
            'create_time'   => time(),
        );

        // 提现金额大于200元,审核
        if ($Camount > 200) {
            $insert_data['status'] = 0;
        } else {    // 提现金额不大于100，免审核
            $insert_data['status'] = 1;

            // 微信提现
            if ($Typeid == 1) {
                $type   = Config::WX_TRANSFER;
                $config = config('pay.wx');
                $transfer_data = [
                    'trans_no'    => time(),
                    'openid'      => $Wxopenid,
                    // 'userid'      => $Wxopenid,
                    'check_name'  => 'NO_CHECK',// NO_CHECK：不校验真实姓名  FORCE_CHECK：强校验真实姓名   OPTION_CHECK：针对已实名认证的用户才校验真实姓名
                    //'payer_real_name' => '陈杰',
                    'terminal_id' => 'APP',
                    'amount'      => $Camount,
                    'desc'        => '提现',
                    'spbill_create_ip' => Request::instance()->ip(),
                ];
            } else if ($Typeid == 2) {    // 支付宝提现
                $type   = Config::ALI_TRANSFER;
                $config = config('pay.alipay');
                $transfer_data = [
                    'trans_no'        => time(),
                    'payee_type'      => 'ALIPAY_LOGONID',
                    'payee_account'   => $Wxopenid,
                    'amount'          => $Camount,
                    'remark'          => '提现',
                    'payer_show_name' => '跑步钱进网络科技有限公司',
                ];
            } else {
                Db::rollback();
                return $this->sendError(1, '提现类型错误', 200);
            }

            try {
                $ret = Transfer::run($type, $config, $transfer_data);
            } catch (PayException $e) {
                Db::rollback();
                return $this->sendError(1, $e->errorMessage(), 200);
            }
        }

        if (empty($old_withdraw)) {
            $endday  = mktime(0, 0, 0, date('m'), date('d') + 1, date('Y'));
            $expires = $endday - time();

            cache('withdraw_' . $Userid, $Camount, $expires);
        }
        
        // 提现写入记录并更新余额
        Db::startTrans();
        try {
            // Db::name('withdraw')->lock(true)->insert($insert_data);
            // Db::name('user')->where('id', $Userid)->lock(true)->setDec('balance', $Camount);
    
            Db::name('withdraw')->insert($insert_data);
            Db::name('user')->where('id', $Userid)->setDec('balance', $Camount);
            Db::commit();

            if ($insert_data['status'] == 0) {
                return $this->sendSuccess(0, '提现审核中', 200);
            } else {
                return $this->sendSuccess(0, '提现成功', 200);
            }
        } catch (\Exception $e) {
            Db::rollback();
            return $this->sendError(1, $e->getMessage(), 200);
        }
    }

    /**
     * @title 添加提现记录
     * @param  int id 提现记录id
     * @return int userid 用户id
     * @return string type 提现类型 1微信 2支付宝 3银行卡 
     * @return string amount 提现金额
     * @return int actual_amount 实际到账金额
     * @return int status 0提现审核中 1提现成功
     * @return string creat_time 提现时间
     * @desc 请求方式：POST <br/>请求示例：http://119.29.10.64/v1/withdrawOld
     */
    public function withdrawOld()
    {
        $data = input('post.');

        $rule = [
            'id'     => 'require',
            'amount' => 'require',
        ];

        $msg = [
            'id.require'     => '提现方式ID',
            'amount.require' => '提现金额必须',
        ];

        //添加提现记录到数据库
        $validate = new Validate($rule,$msg);
        $result   = $validate->check($data);
        if($result){
            $user_bank_card = Db::name('withdraw_log')
            ->where(['id'=>$data['id']])
            ->find();

            if(!$user_bank_card){
                return $this->sendError(-1, '绑定的提现账号没有找到', 400);
            }

            $user = Db::name('user')
            ->where('id',$user_bank_card['userid'])
            ->find();

            if($user['balance'] < $data['amount']){
                return $this->sendError(-1, '余额不足, 提现失败', 400);
            }

            $userid = $user_bank_card['userid'];  //用户ID
            $typeid = $user_bank_card['typeid'];  //提现方式
            $bank_card = $user_bank_card['bank_card'];  //提现账号
            $amount = $data['amount'];

            $sum_amount = Db::name('withdraw')
            ->where(['userid' => $userid, 'create_time'=>[">",strtotime("today")]])
            ->sum('amount');
 
            // 提现金额上限
            if($sum_amount > 1000){
                return $this->sendError(-1, '单日提现最高限额1000元', 400);
            }

            $insert_data = array(
                'userid' => $userid,
                'typeid' => $typeid,
                'amount' => $data['amount'],
                'actual_amount' => $data['amount'],
                'status' => 1,
                'create_time' => time(),
            );

            // 提现金额大于100元,审核
            if($amount > 100){
                $insert_data['status'] = 0;
            }
            // 提现金额小于100,免审核
            else{
                $insert_data['status'] = 1;

                // 微信提现
                if($typeid == 1){
                    $type = Config::WX_TRANSFER;
                    $config = config('pay.wx');
                    $transfer_data = [
                        'trans_no' => time(),
                        'openid' => $bank_card,
                        'check_name' => 'NO_CHECK',// NO_CHECK：不校验真实姓名  FORCE_CHECK：强校验真实姓名   OPTION_CHECK：针对已实名认证的用户才校验真实姓名
                        //'payer_real_name' => '陈杰',
                        'terminal_id' => 'APP',
                        'amount' => $amount,
                        'desc' => '提现',
                        'spbill_create_ip' => Request::instance()->ip(),
                    ];
                }
                // 支付宝提现
                else if($typeid == 2){
                    $type = Config::ALI_TRANSFER;
                    $config = config('pay.alipay');
                    $transfer_data = [
                        'trans_no' => time(),
                        'payee_type' => 'ALIPAY_LOGONID',
                        'payee_account' => $bank_card,
                        'amount' => $amount,
                        'remark' => '提现',
                        'payer_show_name' => '跑步钱进网络科技有限公司',
                    ];
                }else{
                    return $this->sendError(-1, '提现类型错误', 400);
                }

                try {
                    $ret = Transfer::run($type, $config, $transfer_data);
                } catch (PayException $e) {
                    return $this->sendError(-1, $e->errorMessage(), 400);
                }
            }

            // 提现写入记录并更新余额
            Db::startTrans();
            try{
                Db::name('withdraw')->insert($insert_data);
                Db::name('user')->where('id',$userid)->setDec('balance', $amount);
                Db::commit();
                if($insert_data['status'] == 0){
                    return $this->sendSuccess('', '提现审核中', 200);
                }else{
                    return $this->sendSuccess('', '提现成功', 200);
                }
            } catch (\Exception $e) {
                Db::rollback();
                return $this->sendError(-1, $e->getMessage(), 400);
            }
            
        }else{
            return $this->sendError(-1, $validate->getError(), 400);
        }
    }

    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [
                'userid' => [
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
            ],
            'rechargeList' => [
                'userid' =>[
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
                'page' =>[
                    'name'    => 'page', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '页数', 
                    'range'   => '',
                ],
                'pagesize' =>[
                    'name'    => 'pagesize', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '每页条目', 
                    'range'   => '',
                ],
            ],
            'save' => [
                'userid' =>[
                    'name'    => 'userid', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户ID（最好别填）', 
                    'range'   => '',
                ],
                'typeid' =>[
                    'name'    => 'typeid', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '提现方式：1微信|2支付宝|3银行卡', 
                    'range'   => '',
                ],
                'amount' => [
                    'name'    => 'amount', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '提现金额', 
                    'range'   => '',
                ],
                'wx_openid' =>[
                    'name'    => 'wx_openid', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => 'app对应的openid（备注：微信提现必填）', 
                    'range'   => '',
                ],
                'ali_openid' =>[
                    'name'    => 'ali_openid', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => 'app对应的openid（备注：支付宝提现必填）', 
                    'range'   => '',
                ],
                'cardid' => [
                    'name'    => 'cardid', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '银行卡id：在个人银行卡列表中获取(备注：银行卡提现必填)', 
                    'range'   => '',
                ],
            ],
            'read' => [
                'id' => [
                    'name'    => 'id', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '用户id', 
                    'range'   => '',
                ],
            ]
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
