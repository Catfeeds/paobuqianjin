<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:52
// +----------------------------------------------------------------------
// | TITLE: 提现类型接口
// +----------------------------------------------------------------------

namespace app\v1\controller;
use think\Request;

/**
 * Class  WithDrawType
 * @title 提现类型接口
 * @url   v1/withdrawtype
 * @desc  提现类型相关接口：获取提现类型列表
 * @version 1.0
 */
class WithDrawType extends Base
{
    /**
     * @title 获取提现类型列表
     * @param  int id 提现类型id
     * @return string name 提现类型名称
     * @desc 请求方式：GET <br/>地址：v1/withdrawtype
     */
    public function index()
    {
        $res = db('withdraw_type')->field(true)->select();

        if($res){
            return $this->sendSuccess($res, 'success', 200);
        }else{
            return $this->sendError(1, 'Not found Data', 200);
        }
    }

    /**
     * 参数规则
     * @name 字段名称
     * @type 类型
     * @require 是否必须
     * @default 默认值
     * @desc 说明
     * @range 范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'index' => [],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
