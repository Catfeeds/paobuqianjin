<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/04/17 17:55
// +----------------------------------------------------------------------
// | TITLE: 小程序接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use app\v1\location\Location;
use think\Cache;
use \app\v1\auth\AccessToken;
use \app\v1\extend\Loginlog;

/**
 * Class  Wxsmall
 * @title 复合接口
 * @url   v1/Wxsmall
 * @desc  小程序接口包含：小程序登录
 * @version 1.0
 */
class Wxsmall extends Base
{
    // 附加方法
    protected $extraActionList = ['smallLogin', 'getUserStep', 'getQrcode', 'mobileCodeRegister', 'getSwitch', 'getShare'];

    // 跳过验证方法
    protected $skipAuthActionList = ['smallLogin', 'mobileCodeRegister', 'getSwitch', 'getShare'];

    // appid
    protected $appid = 'wx4c0e1852239664b4';

    // secret
    protected $secret = '4ed69d7114fbf7b1de094ab5c4d0bd8b';

    // 默认头像路径
    protected $defultHead = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_h.png';

    /**
     * @title 小程序登录（post）
     * @return int    error        错误代码：0成功 1失败
     * @return string message      消息提醒
     * @return array  data         用户信息
     * @return int    id           用户id
     * @return int    no           用户编号
     * @return int    wx_unionid   微信unionid
     * @return int    xcx_openid   微信小程序openid
     * @return int    nickname     昵称
     * @return string avatar       头像地址
     * @return string levelid      段位ID  具体查看获取段位接口 
     * @return string sex          性别
     * @return string vip          会员：0否|1是
     * @return string user_token   秘钥
     * @return string xcx_qr_img   我的二维码
     * @desc 请求方式：POST 请求地址：v1/Wxsmall/smallLogin
     */
    public function smallLogin(Request $request)
    {
        // return $this->sendError(1, 'error', 400);

        $Side      = 3;
        $Pattern   = 2;
        $Code      = trim(input('code'));
        $Iv        = trim(input('iv'));
        $Encrypted = trim(input('encrypted'));

        if (empty($Code)) {
            return $this->sendError(-1, 'code必填', 200);
        }

        $LoginData = self::getLoginData($Code);

        // $LoginData = [
        //   "session_key" => "iFmIGY+dnGhAiLXdKsgxlw==",
        //   "openid" => "oVJrD5AhQnkmRRAgfW1JFFBOw8BM",
        //   "unionid" => "oOR3P1Nxn6e0EA8rY0wdSlMogB0c",
        // ];

        if (empty($LoginData['unionid']) || empty($LoginData['openid'])) {
            return $this->sendError(-1, '获取openid或者unionid失败', 200);
        }

        $Wxuserdata = self::getUserInfo($LoginData['session_key'], $Encrypted, $Iv);

        // 新数据
        $user_INSERT = [
            'wx_unionid' => $LoginData['unionid'],
            'xcx_openid' => $LoginData['openid'],
            'nickname'   => empty($Wxuserdata['nickName']) ? '' : $Wxuserdata['nickName'],
            'avatar'     => empty($Wxuserdata['avatarUrl']) ? $this->defultHead : $Wxuserdata['avatarUrl'],
            'province'   => empty($Wxuserdata['province']) ? ' ' : $Wxuserdata['province'],
            'city'       => empty($Wxuserdata['city']) ? ' ' : $Wxuserdata['city'],
            'sex'        => empty($Wxuserdata['gender']) ? ' ' : $Wxuserdata['gender'],
            'levelid'    => 1,
        ];

// dump($LoginData);
// dump($Userdata);
// exit();

        // 判断用户是否已经注册
        $Userdata = db('user')
            // ->field(true)
            ->field('id,no,wx_unionid,xcx_openid,nickname,avatar,province,city,sex,levelid,create_time,logintimes,is_perfect,vip,xcx_qr_img')
            ->where('wx_unionid', $LoginData['unionid'])
            ->find();

        if (empty($Userdata)) {    // 用户不存在（添加新用户）
            $user_INSERT['create_time'] = time();
            $user_INSERT['is_perfect']  = 0;
            // $user_INSERT['id']          = getNewUserid();
            $user_INSERT['no']          = getNewUserNo();

// var_dump($Wxuserdata);
// var_dump($user_INSERT);
// exit();
            $Newuserid = db('user')->insertGetId($user_INSERT);

            if (empty($Newuserid)) {
                return $this->sendError(-1, '登录错误', 400);
            } else {
                $Userdata = $user_INSERT;
                $Userdata['is_perfect'] = 0;
                $Userdata['id']         = $Newuserid;
                $Userdata['vip']        = 0;
                $Userdata['xcx_qr_img'] = '';
            }

            {   // 注册成功发表动态
                $dynamic_data['userid']   = $Newuserid;
                $dynamic_data['dynamic']  = base64_encode('号外！号外！我加入跑步钱进了，大家一起走路领红包吧！');
                // $dynamic_data['dynamic']  = '号外！号外！我加入跑步钱进了，大家一起走路领红包吧！';
                $dynamic_data['images'][] = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_d.png';
                $dynamic_data['images']   = serialize($dynamic_data['images']);
                $dynamic_data['create_time'] = time();
                
                @$result = @Db::name('dynamic')->insert($dynamic_data);
            }

        } else {                  // 用户已存在（增加登录次数）
            $user_UPDATE['logintimes'] = $Userdata['logintimes'] + 1;
            if (($user_INSERT['avatar'] != $Userdata['avatar']) && ($user_INSERT['avatar'] != $this->defultHead)) {
                $user_UPDATE['avatar'] = $user_INSERT['avatar'];
            }

            if (isset($LoginData['openid']) && ($LoginData['openid'] != $Userdata['xcx_openid'])) {
                $user_UPDATE['xcx_openid'] = $LoginData['openid'];
            }

            db('user')->where('id', $Userdata['id'])->update($user_UPDATE);
        }

        // 生成用户token（token处理类）
        $accessToken = new AccessToken();
        $accessToken = $accessToken->getToken($Userdata['id']);
        if (empty($accessToken)) {
            return $this->sendError(-1, '秘钥生成失败', 400);
        } else {
            $Userdata['user_token'] = $accessToken;
        }

        // 记录缓存时间为7天
        cache('sessionKey_' . $Userdata['id'], $LoginData['session_key'], 7*24*60*60);

        // 写入用户登录记录
        @$Userlog = new Loginlog();
        @$Userlog->addLog($Userdata['id'], 1, $Side, $Pattern, $data['unionid']);

        return $this->sendSuccess($Userdata, 'success', 200);
    }

    // 根据code获取session_key、openid、unionid【辅助函数】
    private function getLoginData($Code)
    {
        // $url = 'https://api.weixin.qq.com/sns/jscode2session?appid=APPID&secret=SECRET&js_code=JSCODE&grant_type=authorization_code';
        $wx_small_login_url = 'https://api.weixin.qq.com/sns/jscode2session?';

        $Wechatdata['js_code']    = $Code;
        $Wechatdata['appid']      = 'wx4c0e1852239664b4';
        $Wechatdata['secret']     = '4ed69d7114fbf7b1de094ab5c4d0bd8b';
        $Wechatdata['grant_type'] = 'authorization_code';
        
        foreach ($Wechatdata as $key => $value) {
            $wx_small_login_url .= $key . '=' . $value . '&';
        }

        $wx_small_login_url = substr($wx_small_login_url, 0, -1);

        // $data = file_get_contents('http://share.runmoneyin.com/in.html');
        $data  = file_get_contents($wx_small_login_url);
        $Wxres = json_decode($data, true);

        return $Wxres;
    }

    // 根据encrypted和iv获取微信第三方数据【辅助函数】
    private function getUserInfo($sessionKey, $encryptedData, $iv)
    {        
        vendor('wxbiz.wxBizDataCrypt');
        
        $pc = new \wxBizDataCrypt($this->appid, $sessionKey);
        $errCode = $pc->decryptData($encryptedData, $iv, $data);

        if ($errCode == 0) {
            return json_decode($data, true);
        } else {
            return false;
        }
    }

    /**
     * @title 手机验证码登录（并注册）
     * @return int    error        错误代码：0成功 1失败
     * @return string message      错误信息
     * @return array  data         返回数组
     * @return int    id           用户id
     * @return int    no           用户编号
     * @return string nickname     用户昵称
     * @return string mobile       手机号
     * @return string avatar       头像地址
     * @return string vip          会员：0否|1是
     * @return string levelid      段位ID（具体查看获取段位接口）
     * @return string user_token   秘钥
     * @desc 请求方式：POST 请求地址：v1/Wxsmall/mobileCodeRegister
     */
    public function mobileCodeRegister()
    {
        {   // 数据过滤
            $Mobile = input('post.mobile');
            $Code   = input('post.code');
            $Wxcode = input('post.code1');
            $Side   = (intval(input('post.side')) > 0) ? intval(input('post.side')) : 3;

            if (!preg_match("/^1[34578]\d{9}$/", $Mobile)) {
                return $this->sendError(1, '手机号格式错误', 200);
            }

            if (!preg_match("/^\d{6}$/", $Code)) {
                return $this->sendError(1, '验证码格式错误', 200);
            }
        }

        // 根据小程序code获取相关秘钥
        $LoginData = self::getLoginData($Wxcode);
        // $LoginData = [
        //   "session_key" => "iFmIGY+dnGhAiLXdKsgxlw==",
        //   "openid" => "oVJrD5AhQnkmRRAgfW1JFFBOw8BM",
        //   "unionid" => "oOR3P1Nxn6e0EA8rY0wdSlMogB0c",
        // ];

        // $Old_code = cache($Mobile . '_code', '123456', 60);

        // 匹配验证码 
        $Old_code = cache($Mobile . '_code');

        if ($Old_code != $Code) {
            return $this->sendError(1, '验证码错误', 200);
        }

        // 判断是否有对应的手机号
        $Olduser = db('user')->field('id,no,xcx_openid,mobile,nickname,avatar,vip,logintimes')->where('mobile', $Mobile)->find();

        if (empty($Olduser)) {    // 不存在，添加用户
            // 新数据
            $user_INSERT = [
                'no'       => getNewUserNo(),
                // 'wx_unionid' => $LoginData['unionid'] ? $LoginData['unionid'] : '',
                // 'xcx_openid' => isset($LoginData['openid']) ? $LoginData['openid'] : '',
                'mobile'     => $Mobile,
                'avatar'     => 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_h.png',
                'nickname'   => 'rm_' . $Mobile,
                'levelid'    => 1,
            ];

            $Newuserid = db('user')->insertGetId($user_INSERT);
            
            if (empty($Newuserid)) {
                return $this->sendError(1, '添加用户出错', 200);
            } else {
                $Olduser = $user_INSERT;
                $Olduser['id']  = $Newuserid;
                $Olduser['vip'] = 0;

                {   // 注册成功发表动态
                    $dynamic_data['userid']   = $Newuserid;
                    $dynamic_data['dynamic']  = base64_encode('号外！号外！我加入跑步钱进了，大家一起走路领红包吧！');
                    // $dynamic_data['dynamic']  = '号外！号外！我加入跑步钱进了，大家一起走路领红包吧！';
                    $dynamic_data['images'][] = 'https://rumcdn-1255484416.cos.ap-chengdu.myqcloud.com/img/d_d.png';
                    $dynamic_data['images']   = serialize($dynamic_data['images']);
                    $dynamic_data['create_time'] = time();
                    
                    @$result = @Db::name('dynamic')->insert($dynamic_data);
                }
            }
        } else {    // 存在，登录
            $here_UPDATE['logintimes'] = $Olduser['logintimes'] + 1;

            if (isset($LoginData['openid']) && ($LoginData['openid'] != $Olduser['xcx_openid'])) {
                $here_UPDATE['xcx_openid'] = $LoginData['openid'];
            }

            db('user')->where('mobile', $Mobile)->update($here_UPDATE);
        }

        // token处理类
        $accessToken = new AccessToken();
        $accessToken = $accessToken->getToken($Olduser['id']);
        
        if (empty($accessToken)) {
            return $this->sendError(1, '秘钥生成失败', 200);
        } else {
            $Olduser['user_token'] = $accessToken;
        }

        // 记录缓存时间为7天
        cache('sessionKey_' . $Olduser['id'], $LoginData['session_key'], 7*24*60*60);

        // 写入用户登录记录
        @$Userlog = new Loginlog();
        @$Userlog->addLog($Olduser['id'], 1, $Side, 4, $mobile);

        return $this->sendSuccess($Olduser, '登录成功', 200);
    }


    /**
     * @title 根据encrypted和iv获取数据
     * @return int    error    错误代码：0成功 1失败
     * @return string message  消息提醒
     * @return array  data     步数数据
     * @desc 请求方式：POST 请求地址：v1/Wxsmall/getUserStep
     */
    public function getUserStep()
    {   
        $Userid = input('post.userid') ? intval(input('post.userid')) : intval($this->userId);
        // $Userid        = input('post.userid');
        $encryptedData = input('post.encrypted');
        $iv            = input('post.iv');
// dump($encryptedData);
// dump($iv);
// dump($this->userId);
// exit();
        vendor('wxbiz.wxBizDataCrypt');

        $sessionKey = cache('sessionKey_' . $Userid);
        if (empty($sessionKey)) {
            return $this->sendError(-1, 'error', 200);
        }

        $pc = new \wxBizDataCrypt($this->appid, $sessionKey);
        $errCode = $pc->decryptData($encryptedData, $iv, $data);

// dump($encryptedData);
// dump($iv);
// dump($sessionKey);
// dump($errCode);
// dump($data);

        if ($errCode == 0) {
            return $this->sendSuccess($data, 'success', 200);
        } else {
            return $this->sendError(-1, 'error', 200);
        }
    }


    /**
     * @title  获取用户的小程序二维码（A类）
     * @return int    error        错误代码：0成功 1失败
     * @return string message      消息提醒
     * @return array  data         二维码数据
     * @return string xcx_qr_img   二维码链接（服务器，非腾讯云）
     * @desc 请求方式：POST 请求地址：v1/Wxsmall/getQrcode
     */
    public function getQrcode()
    {   
        $Userid = input('post.userid') ? intval(input('post.userid')) : intval($this->userId);

        // 判断用户是否存在
        $Userdata = db('user')->field('password', true)->where('id', $Userid)->find(); 
        if (empty($Userdata)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        // 存在二维码，直接返回
        if (!empty($Userdata['xcx_qr_img'])) {
            $res['xcx_qr_img'] = $Userdata['xcx_qr_img'];
            return $this->sendSuccess($res, 'success', 200);
        }

        // 获取AccessToken
        $access_token = self::getAccessToken();

        $path      = "pages/home/home?no=" . $Userdata['no'];
        $width     = 430;
        $post_data = '{"path":"' . $path . '","width":' . $width . '}';
        $url       = "https://api.weixin.qq.com/wxa/getwxacode?access_token=" . $access_token;  // A类
        $result    = $this->api_notice_increment($url, $post_data);
        $file_url  = './qrcode/' . date('Ymd') . '/' . $Userid . '.jpg';
        
        // 创建文件夹
        $dir = iconv("UTF-8", "GBK", './qrcode/' . date('Ymd'));
        if (!file_exists($dir)) {
            mkdir ($dir, 0777, true);
        }

        // 保存文件
        file_put_contents($file_url, $result);

        if (!file_exists($file_url)) {
            return $this->sendError(1, '保存二维码失败', 200);
        }

        $request = Request::instance();
        $domain  = $request->domain();

        $qr_UPDATE['xcx_qr_img']  = $domain . $file_url;
        $qr_UPDATE['xcx_qr_time'] = time();
// dump($qr_UPDATE['xcx_qr_img'])
        //判断用户是否存在
        $res = db('user')->where('id', $Userid)->update($qr_UPDATE); 

        if (empty($res)) {
            return $this->sendError(1, 'error', 200);
        } else {
            $date['xcx_qr_img'] = $qr_UPDATE['xcx_qr_img'];
            return $this->sendSuccess($date, 'success', 200);
        }
    }

    // 获取AccessToken【辅助函数】
    private function getAccessToken()
    {
        $tokenUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" . $this->appid . "&secret=" . $this->secret;
        $getArr   = array();
        $tokenArr = json_decode($this->send_post($tokenUrl,$getArr, "GET"));
        $access_token = $tokenArr->access_token;

        return $access_token;
    }

    // 设置方法【辅助函数】
    private function send_post($url, $post_data, $method='POST')
    {
        $postdata = http_build_query($post_data);
        $options = array(
            'http' => array(
                'method' => $method, //or GET
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );

        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);

        return $result;
    }

    // 抓取图片数据【辅助函数】
    private function api_notice_increment($url, $data)
    {
        header("Content-Type: text/html; charset=utf-8");

        $ch = curl_init();
        $header = "Accept-Charset: utf-8";      

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        // curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $tmpInfo = curl_exec($ch);

        if (curl_errno($ch)) {
            return false;
        } else {
            return $tmpInfo;
        }
    }

    /**
     * @title  获取分享的模板
     * @return int    error    错误代码：0成功 1失败
     * @return string message  消息提醒
     * @return array  data     返回数据
     * @desc 请求方式：GET 请求地址：v1/Wxsmall/getShare
     */
    public function getShare()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        $here_WHERE['delete_id'] = 0;

        $Sharelist = Db::name('xcx_share')->where($here_WHERE)->select();

        if (empty($Sharelist)) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        shuffle($Sharelist);
 
        return $this->sendSuccess($Sharelist[0], 'success', 200);
    }

    /**
     * @title  小程序开关
     * @return int    error    错误代码：0成功 1失败
     * @return string message  消息提醒
     * @return array  data     代码：1开 0关
     * @desc 请求方式：GET 请求地址：v1/Wxsmall/getSwitch
     */
    public function getSwitch()
    {
        // $status = 1;
        $status = 2;
        // $status = 3;

        return $this->sendSuccess($status, 'success', 200);
    }


    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return  array
     */
    public static function getRules()
    {
        $rules = [
            'smallLogin' => [
                'code'    =>  [
                    'name'    => 'code', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信登录code', 
                    'range'   => '',
                ],
                'iv'    =>  [
                    'name'    => 'iv', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信登录iv', 
                    'range'   => '',
                ],
                'encrypted'    =>  [
                    'name'    => 'encrypted', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信登录encrypted', 
                    'range'   => '',
                ],
            ],
            'getSmallLogin' => [
                'code'    =>  [
                    'name'    => 'code', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信登录code', 
                    'range'   => '',
                ],
                'iv'    =>  [
                    'name'    => 'iv', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信登录iv', 
                    'range'   => '',
                ],
                'encrypted'    =>  [
                    'name'    => 'encrypted', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信登录encrypted', 
                    'range'   => '',
                ],
            ],
            'getUserStep' => [
                'userid'    =>  [
                    'name'    => 'userid', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信登录code', 
                    'range'   => '',
                ],
                'iv'    =>  [
                    'name'    => 'iv', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信登录iv', 
                    'range'   => '',
                ],
                'encrypted'    =>  [
                    'name'    => 'encrypted', 
                    'type'    => 'string', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信登录encrypted', 
                    'range'   => '',
                ],
            ],
            'getQrcode' => [
                'useri'    =>  [
                    'name'    => 'useri', 
                    'type'    => 'string', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户id必填', 
                    'range'   => '',
                ],
            ],
            'mobileCodeRegister' => [
                'mobile'    =>  [
                    'name'    => 'mobile', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '电话号码', 
                    'range'   => '',
                ],
                'code'    =>  [
                    'name'    => 'code', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '手机验证码', 
                    'range'   => '',
                ],
                'code1'    =>  [
                    'name'    => 'code1', 
                    'type'    => 'int', 
                    'require' => 'true', 
                    'default' => '', 
                    'desc'    => '微信小程序code', 
                    'range'   => '',
                ],
                'side'    =>  [
                    'name'    => 'side', 
                    'type'    => 'int', 
                    'require' => 'false', 
                    'default' => '', 
                    'desc'    => '用户端：0未知|1ios|2android|3小程序|4web', 
                    'range'   => '',
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
