<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:55
// +----------------------------------------------------------------------
// | TITLE: 复合接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use app\v1\extend\AliyunWeather;


/**
 * Class  Zcomposite
 * @title 复合接口
 * @url   v1/Zcomposite
 * @desc  用于整合App单页面的多请求：首页数据、圈子数据、任务数据、榜单数据、我的数据
 * @version 1.0
 */
class Zcomposite extends Base
{
    // 附加方法
    protected $extraActionList = ['homePage', 'circleData', 'taskData', 'rankData', 'rankCircleData', 'myData', 'ouserData'];

    // 跳过验证方法
    protected $skipAuthActionList = [];

    /**
     * @title  首页数据
     * @return array  weatherdatas 天气数据
     * @return string weather      天气
     * @return int    img          天气图片代码
     * @return string temp         温度
     * @return string city         城市（市级）
     * @return string citycode     城市代码
     * @return array  aqi          空气质量数据
     * @return array  userdata     用户数据
     * @return array  icomedata    用户收益数据
     * @desc 请求方式：POST <br/>地址：v1/Zcomposite/homePage
     */
    public function homePage(Request $request)
    {
        $data   = input('post.');
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

// dump($data);
// exit();

        $longitude = isset($data['longitude']) ? $data['longitude'] : 0;  // 经度
        $latitude  = isset($data['latitude']) ? $data['latitude'] : 0;    // 纬度

        $res = [];    // 返回数据
        $res['weatherdatas'] = [];

        // 获取天气
        if (!empty($longitude) && !empty($latitude)) {
            $config['AppCode'] = 'ff5736e074164fa39b3d970536cff56e';
            $aliyunWeather = new AliyunWeather($config);
            $result = $aliyunWeather->WeatherQuery($longitude, $latitude);

            if (empty($result)) {
                $res['weatherdatas'] = [];
            }

            $Weather = $aliyunWeather->data;

            $Weatherdata = array(
                'weather'  => $Weather['weather'],
                'img'      => $Weather['img'],
                'temp'     => $Weather['temp'],
                'city'     => $Weather['city'],
                'citycode' => $Weather['citycode'],
                'aqi'      => $Weather['aqi']
            );

            if (empty($Weatherdata['weather'])) {
                $res['weatherdatas'] = [];
            } else {
                $res['weatherdatas'] = $Weatherdata;
            }
        }

        {   // 获取用户的数据
            $Userdata = Db::name('user')
                ->field('id as userid,nickname,avatar,province,city,sex,levelid,target_step')
                ->where('id', $Userid)
                ->find();

            if (empty($Userdata)) {
                $res['userdata'] = [];
            } else {
                $res['userdata'] = $Userdata;
            }
        }

        {   // 获取用户收益
            $Stoday = strtotime('today');
            $Etoday = $Stoday + 24 * 60 * 60;

            $res['icomedata']['allin']   = 0.00;
            $res['icomedata']['todayin'] = 0.00;

            $Incomedata = Db::name('income')
                ->field(true)
                ->where('userid', $Userid)
                ->where('typeid', 'neq', 6)
                ->select();

            foreach ($Incomedata as $key => $value) {
                $res['icomedata']['allin'] += round($value['amount'], 2);

                if (($value['create_time'] >= $Stoday) && ($value['create_time'] <= $Etoday)) {
                    $res['icomedata']['todayin'] += round($value['amount'], 2);
                }

                $Incomedata[$key]['day_time'] = date('Y-m-d H:i:s', $value['create_time']);
            }

            $res['icomedata']['allin']   = round($res['icomedata']['allin'], 2);
            $res['icomedata']['todayin'] = round($res['icomedata']['todayin'], 2);

            unset($key, $value);
        }
        
// dump($Stoday);
// dump($Etoday);
// dump($Userdata);
// dump($Incomedata);
// dump($res);

        if (empty($res)) {
            return $this->sendError(-1, 'error', 200);
        } else {
            return $this->sendSuccess($res, 'success', 200);
        }
    }   

    /**
     * @title  圈子数据
     * @return array incircle       我加入的圈子数组
     * @return array selectedcircle 精选圈子数组
     * @return array circleactivity 圈子活动数组
     * @desc 请求方式：POST <br/>地址：v1/Zcomposite/circleData
     */
    public function circleData()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Today  = date('Y-m-d');

        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        // 获取用户步数
        $setp_WHERE['userid']     = $Userid;
        $setp_WHERE['create_day'] = $Today;
        $Userstep = Db::name('user_step')->where($setp_WHERE)->value('step_number');
        if (empty($Userstep)) {
            $Userstep = 0;
        } else {
            $Userstep = intval($Userstep);
        }

// dump($Userstep);

        $res  = [];
        $sign = 0;

        // 我所在全部圈子
        $Incircle = Db::name('circle_member')
            ->alias('cm')
            ->field('
                circle.id,circle.name,circle.logo,circle.city,circle.is_recharge,
                circle.total_amount,circle.red_packet_amount,circle_target.target
            ')
            ->join('circle','circle.id=cm.circleid')
            ->join('circle_target','circle.targetid=circle_target.id')
            ->where('circle.delete_id', 0)
            ->where('cm.userid', $Userid)
            ->group('cm.circleid')
            ->order('cm.id desc')
            ->limit(3)
            ->select();

        if (empty($Incircle)) {
            $res['incircle'] = [];
            ++$sign;
        } else {
            foreach ($Incircle as $key => $value) {
                $Incircle[$key]['is_red_packet'] = 0;
                if (($value['is_recharge'] == 1) && ($value['total_amount'] >= $value['red_packet_amount'])) {  // 圈子总金额大于每日红包金额
                    // 用户步数 大于 圈子目标 有红包
                    if ($Userstep > $value['target']) {
                        $map = array();
                        $map['circleid']    = $value['id'];
                        // $map['userid']      = $Userid;
                        $map['create_time'] = ['>=', strtotime('today')];

                        // 判断是否领过红包
                        $Incircle_record = db('circle_record')->where($map)->find();
                        
// dump($Incircle_record);
                        if (empty($Incircle_record)) {
                            $Incircle[$key]['is_red_packet'] = 1;
                        }
                    }
                }
            }

            unset($key, $value);
            $res['incircle'] = $Incircle;
        }

        // 精选圈子（后期加上用户的定位）
        // 获取圈子人员数据（子查询）
        $subQuery = Db::name('circle_member')
            ->field(true)
            ->where('delete_id', 0)
            ->group('circleid,userid')
            ->buildSql(); 

        $totalCount = Db::table($subQuery.' a')
            ->group('circleid')
            ->count();

        // 精选圈子（后期加上用户的定位）
        $Selectedcircle = Db::table($subQuery.' cm')
            ->field('circleid,cm.userid,count(cm.id) as member_number,name,logo,city,circle.is_pwd')
            ->join('circle','circle.id=cm.circleid')
            ->where('cm.delete_id', 0)
            ->where('circle.delete_id', 0)
            ->group('circleid')
            ->order('count(cm.id) desc')
            ->limit(10)
            // ->buildSql();
            ->select();


        //在精选圈子数据中添加“is_join”字段；--bug:404圈子缺少字段
        if (empty($Selectedcircle)) {
            $res['selectedcircle'] = [];
            ++$sign;
        } else {
            foreach ($Selectedcircle as $key => $value) {
                $userincircle = Db::name('circle_member')
                    ->where('userid', $Userid)
                    ->where('circleid', $value['circleid'])
                    ->where('delete_id', 0)
                    ->find();
// dump($userincircle);
                if (!empty($userincircle)) {
                    $Selectedcircle[$key]['is_join'] = 1;
                } else {
                    $Selectedcircle[$key]['is_join'] = 0;
                }
            }

            $res['selectedcircle'] = $Selectedcircle;
        }

// dump($Selectedcircle);
// exit();

        // 精选活动
        $Circleactivity = Db::name('activity')
            ->alias('activity')
            ->field('
                id,target,title,conver,starttime,endtime,
                remote_url,read_total,create_time,number,allmoney
            ')
            ->where('delete_id', 0)
            ->order('activity.id desc')
            ->limit(2)
            ->select();

        if (empty($Circleactivity)) {
            $res['circleactivity'] = [];
            ++$sign;
        } else {
            foreach ($Circleactivity as $key => $value) {
                // $Circleactivity[$key]['remote_url'] = $value['remote_url'].'&uid='.$Userid;

                $Circleactivity[$key]['starttime']   = date("Y-m-d H:i:s", $value['starttime']);
                $Circleactivity[$key]['endtime']     = date("Y-m-d H:i:s", $value['endtime']);
                $Circleactivity[$key]['create_time'] = date("Y-m-d H:i:s", $value['create_time']);
                $Circleactivity[$key]['remote_url']  = $value['remote_url'].'&uid='.$Userid;

                if ($value['starttime'] > time()) {    
                    $Circleactivity[$key]['is_process'] = 0;  // 未开始
                } elseif (($value['starttime'] < time()) && ($value['endtime'] >= time())) {
                    $Circleactivity[$key]['is_process'] = 1;  // 进行中
                } else {
                    $Circleactivity[$key]['is_process'] = 2;  // 已结束 
                }

                // 已经领奖人数
                $Sumactred = db('activity_record')->where('activityid', $value['id'])->count('id');
                if ($Sumactred >= $value['number']) {
                    $Circleactivity[$key]['is_process'] = 3;  // 已经被领完 
                }

                $Circleactivity[$key]['is_number'] = intval($Sumactred);

                $mystatus_WHERE['activityid'] = $value['id'];
                $mystatus_WHERE['userid'] = $Userid;
                $mystatus = db('activity_record')->field(true)->where($mystatus_WHERE)->find();

                if (empty($mystatus)) {
                    $Circleactivity[$key]['is_receive'] = 0;
                } else {
                    $Circleactivity[$key]['is_receive'] = 1;
                }

                if ($Userstep >= $value['target']) {
                    $Circleactivity[$key]['is_step'] = 1;
                } else {
                    $Circleactivity[$key]['is_step'] = 0;
                }
            }

            $res['circleactivity'] = $Circleactivity;
        }

// dump($Circleactivity);
// die;
        if ($sign >= 3) {
            return $this->sendError(1, 'Not Found Data', 200);
        } else {
            return $this->sendSuccess($res, 'success', 200);
        }
    }

    /**
     * @title  任务数据
     * @author wensen  2018-03-27
     * @return array  data    任务数据
     * @return int    error   状态码：-1失败|0成功
     * @return string message 相应描述
     * @desc 请求方式：POST <br/>地址：v1/Zcomposite/taskData
     */
    public function taskData()
    {

    }

    /**
     * @title  榜单数据
     * @author wensen  2018-03-27
     * @return array  data    榜单数据
     * @return int    error   状态码：-1失败|0成功
     * @return string message 相应描述
     * @desc 请求方式：POST <br/>地址：v1/Zcomposite/rankData
     */
    public function rankData()
    {
        
    }

    /**
     * @title  圈子榜单榜单数据
     * @author wensen  2018-03-27
     * @return array  data    圈子榜单数据
     * @return int    error   状态码：-1失败|0成功
     * @return string message 相应描述
     * @desc 请求方式：POST <br/>地址：v1/Zcomposite/rankCircleData
     */
    public function rankCircleData()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);
        $Today  = date('Y-m-d');

        if (empty($Userid)) {
            return $this->sendError(-1, '用户ID必填', 400);
        }

        // 获取用户步数
        // $setp_WHERE['userid']     = $Userid;
        // $setp_WHERE['create_day'] = $Today;
        // $Userstep = Db::name('user_step')->where($setp_WHERE)->find();
        // if (empty($Userstep)) {
        //     $Userstep = 0;
        // }

        // $res['userdata']['userid']    = $Userid;
        // $res['userdata']['user_step'] = $Userstep;

        // 获取所有圈子数据
        $Allcircle = Db::name('circle_member')
            ->alias('cm')
            ->field('circle.id,circle.name,circle.logo,circle.city,circle.is_recharge,circle.total_amount,circle.red_packet_amount,circle_target.target')
            ->join('circle','circle.id=cm.circleid')
            ->join('circle_target','circle.targetid=circle_target.id')
            ->where('circle.delete_id', 0)
            ->where('cm.userid', $Userid)
            ->group('cm.circleid')
            ->order('cm.circleid desc')
            ->select();

        if (empty($Allcircle)) {
            return $this->sendError(1, 'Not Found Data', 200);
        }

        // 遍历数组获取子集数据
        foreach ($Allcircle as $key => $value) {
            $all_user = Db::name('user')
                ->alias('user')
                ->join('circle_member', 'circle_member.userid = user.id')
                ->field('user.id as userid,user.nickname,user.avatar,vip')
                ->where('circleid', $value['id'])
                ->where('user.delete_id', 0)
                ->group('user.id')
                ->order('user.id asc')
                ->select();

            $Userida = array_column($all_user, 'userid');
            $Userida = array_filter($Userida);
            sort($Userida);
            $Userids = implode(',', $Userida);

            $subQuery = Db::table('rm_user_step')
                ->alias('user_step')
                ->field('id,userid,step_number')
                ->where('create_day', $Today)
                ->where('userid', 'in', $Userids)
                ->buildSql();

            $UserStepRank = Db::name('user')
                ->alias('user')
                ->field('
                    user.id as userid,
                    user.nickname,
                    user.avatar,
                    user.vip,
                    user.cusvip,
                    IFNULL(user_step.step_number, 0) as step_number
                ')
                ->join($subQuery . ' as user_step', 'user.id=user_step.userid', 'left')
                ->where('user.id', 'in', $Userids)
                ->order('step_number desc, user.id asc')
                // ->limit(3)
                ->select();

            // 抓取前三
            if (empty($UserStepRank)) {
                return $this->sendError(1, 'Not Found Data', 200);
            } else {
                $Allcircle[$key]['threedata']     = array_slice($UserStepRank, 0, 3);
                $Allcircle[$key]['member_number'] = count($UserStepRank);
            }

            // 获取我的名次
            foreach ($UserStepRank as $k => $v) {
                if ($v['userid'] == $Userid) {
                    $Allcircle[$key]['mydata'] = $v;
                    $Allcircle[$key]['mydata']['rank'] = $k + 1;

                    break;
                }
            }
            unset($k, $v);

            unset($all_user, $Userida, $Userids, $subQuery, $UserStepRank);
        }
        unset($key, $value);

        return $this->sendSuccess($Allcircle, 'success', 200);
    }

    /**
     * @title  我的数据
     * @author wensen 2018-03-27
     * @return int    error   状态码：0成功 1失败
     * @return string message 相应描述
     * @return array  data    用户数据
     * @desc 请求方式：POST <br/>地址：v1/Zcomposite/myData
     */
    public function myData()
    {
        $Userid = input('userid') ? intval(input('userid')) : intval($this->userId);

    }

    /**
     * @title  用户主页（id和no都有，id优先）
     * @author wensen 2018-03-27
     * @return int    error        状态码：0成功 1失败
     * @return string message      相应描述
     * @return array  data         返回数据
     * @return array  user_data    用户数据
     * @return int    is_follow    关注状态：0否 1是
     * @return array  dynamic_data 动态数据（可分页）
     * @desc 请求方式：POST <br/>地址：v1/Zcomposite/ouserData
     */
    public function ouserData()
    {
        $Adminid = input('adminid') ? intval(input('adminid')) : intval($this->userId);
        $Userid  = intval(input('userid'));
        $Userno  = intval(input('userno'));

        $page     = input('get.page') ? input('get.page') : 1;          // 分页页数
        $pagesize = input('get.pagesize') ? input('get.pagesize') : 10; // 分页条数

        if (empty($Adminid)) {
            return $this->sendError(1, 'error', 200);
        }

        if (empty($Userid) && empty($Userno)) {
            return $this->sendError(1, '用户ID或用户编号选填一个', 200);
        }

        $res['user_data']    = [];
        $res['is_follow']    = 0;
        $res['dynamic_data'] = [];

        // 获取个人信息
        $fields = '
            id,no,wx_unionid,qq_unionid,
            wx_openid,xcx_openid,qq_openid,mobile,avatar,nickname,
            levelid,sex,birthyear,birthmonth,birthday,height,weight,
            type,province,city,balance,credit,status,is_perfect,
            create_time,delete_time,logintimes,vip,cusvip,
            CASE WHEN target_step<5000 THEN 5000 ELSE target_step END as target_step
        ';

        if ($Userid > 0) {
            $Userdata = Db::name('user')->field($fields)->where('id', $Userid)->where('delete_id', 0)->find();
        } elseif ($Userno > 0) {
            $Userdata = Db::name('user')->field($fields)->where('no', $Userno)->where('delete_id', 0)->find();
        }

// dump($Userid);
// dump($Userno);
// dump($Userdata);
// die;

        if (empty($Userdata)) {
            return $this->sendError(1, '用户不存在', 200);
        }

        $res['user_data']  = $Userdata;


        // 获取关注信息
        $user_follow = Db::name('user_follow')
            ->where([
                'userid'   => $Adminid, 
                'followid' => $Userdata['id']
            ])
            ->find();

        if (!empty($user_follow)) {
            $res['is_follow'] = 1;
        }


        // 获取动态信息
        $totalCount = db('dynamic')
            ->where('userid', $Userdata['id'])
            ->count();

        if ($totalCount <= 0) {
            $res['dynamic_data'] = returnData($page, $pagesize, 0, []);
            return $this->sendSuccess($res, 'success', 200);
        }

        //获取个人动态
        $user_dynamic = db('dynamic')
            ->alias('dynamic')
            ->join('user','user.id = dynamic.userid')
            ->field('
                dynamic.id,
                dynamic.userid,
                user.avatar,
                user.nickname,
                user.vip,
                user.cusvip,
                dynamic.dynamic,
                dynamic.images,
                dynamic.city,
                dynamic.country,
                dynamic.province,
                dynamic.county,
                dynamic.village,
                dynamic.position,
                dynamic.vote,
                dynamic.comment,
                dynamic.create_time
            ')
            ->where('userid', $Userdata['id'])
            ->order('create_time','desc')
            ->page($page, $pagesize)
            ->select();

        // 追加评论
        if ($user_dynamic) {
            foreach ($user_dynamic as $key => $value) {
                $dynamic_comment = Db::name('dynamic_comment')
                    ->alias('dynamic_comment')
                    ->field('dynamic_comment.*,user.nickname')
                    ->join('user','user.id = dynamic_comment.userid')
                    ->where('dynamicid', $value['id'])
                    ->limit(1)
                    ->find();

                $newDynamic[] = $value;
                if ($value['images']) {
                    $newDynamic[$key]['images'] = unserialize($value['images']);
                } else {
                    $newDynamic[$key]['images'] = array();
                }

                if ($dynamic_comment) {
                    $newDynamic[$key]['one_comment'] = $dynamic_comment;
                } else {
                    $newDynamic[$key]['one_comment'] = (object)array();
                }

                //追加是否点赞
                $dynamic_vote = Db::name('dynamic_vote')
                    ->where([
                        'userid'    => $Adminid,
                        'dynamicid' => $value['id']
                    ])
                    ->find();

                if ($dynamic_vote) {
                    $newDynamic[$key]['is_vote'] = 1;
                } else {
                    $newDynamic[$key]['is_vote'] = 0;
                }

                // $newDynamic[$key]['dc'] = base64_decode($value['dynamic']);
            }
        }

        $retData = returnData($page, $pagesize, $totalCount, $newDynamic);

        $res['dynamic_data'] = $retData;

        return $this->sendSuccess($res, 'success', 200);
    }


    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return  array
     */
    public static function getRules()
    {
        $rules = [
            'homePage' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
                'longitude'   => [
                    'name'    => 'longitude',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '经度',
                    'range'   => ''
                ],
                'latitude'   => [
                    'name'    => 'latitude',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '纬度',
                    'range'   => ''
                ],
            ],
            'circleData' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
            ],
            'taskData' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
            ],
            'rankData' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
            ],
            'rankCircleData' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
            ],
            'myData' => [
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '用户id',
                    'range'   => ''
                ],
            ],
            'ouserData' => [
                'adminid'   => [
                    'name'    => 'adminid',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '获取者的用户ID（可以根据秘钥获取）',
                    'range'   => ''
                ],
                'userid'   => [
                    'name'    => 'userid',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '用户id（id和编号必填一个）',
                    'range'   => ''
                ],
                'userno'   => [
                    'name'    => 'userno',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '',
                    'desc'    => '用户编号（id和编号必填一个）',
                    'range'   => ''
                ],
                'page' => [
                    'name'    => 'page',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '1',
                    'desc'    => '动态分页当前页码',
                    'range'   => ''
                ],
                'pagesize' => [
                    'name'    => 'pagesize',
                    'type'    => 'int',
                    'require' => 'false',
                    'default' => '10',
                    'desc'    => '动态分页每页显示数量',
                    'range'   => ''
                ],
            ],
        ];

        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }
}
