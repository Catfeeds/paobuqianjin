<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2010/03/29 16:55
// +----------------------------------------------------------------------
// | TITLE: 协议文档接口
// +----------------------------------------------------------------------

namespace app\v1\controller;

use think\Request;
use think\Db;
use app\v1\extend\HelibaoInt;


/**
 * Class  Zfile
 * @title 协议文档接口
 * @url   v1/Zfile
 * @desc  获取各个跑钱的协议
 * @version 1.0
 */
class Zfile extends Base
{   
    // 附加方法
    protected $extraActionList = ['getFile', 'testLook'];

    // 跳过验证方法
    protected $skipAuthActionList = ['getFile', 'testLook', 'test'];

    /**
     * @title  获取协议
     * @param  int action     协议类型：1用户协议|2邀请协议|3兑换协议|4提现协议
     * @return string error   错误码：-1失败|0成功|1没数据
     * @return string message 错误内容
     * @return array  data    协议内容数据
     * @desc 请求方式：POST <br/>地址：v1/Zfile/getFile
     */
    public function getFile()
    {
        $Data   = input('post.');
        $action = intval($Data['action']);

        if (empty($action) || ($action > 4) || ($action < 1)) {
            return $this->sendError(-1, 'Not Found Action', 200);
        }

        $here_WHERE['file_id']   = $action;
        $here_WHERE['delete_id'] = 0;

        $res = db('file')->field(true)->where($here_WHERE)->find();

        if ($res) {
            return $this->sendSuccess($res, 'success', 200);
        } else {
            return $this->sendError(1, 'Not Found Data', 200);
        }
    }

    public function test()
    {
        $serverurlprefix = config('serverurlprefix');
        $config[] = config('pay.wx');
        $config[] = config('pay.alipay');
        $config[] = config('pay.wxxcx');

        dump($serverurlprefix);
        dump($config);

        dump('test');
        exit();

        // $order_no = '201805250844434254';
        $order_no = '201805250844447254';

        Db::startTrans();

        $order_recharge_record = Db::name('order_recharge_record')
            ->where('order_no', $order_no)
            ->find();

        $task_ok_UPDATE['ok']      = 1;
        $task_ok_UPDATE['ok_time'] = time();

        // 更新任务表
        Db::name('user_vip')
            ->where('vip_no', $order_recharge_record['vip_no'])
            ->update($task_ok_UPDATE);

        // 更新任务详细记录表
        Db::name('user_vip_record')
            ->where('vip_no', $order_recharge_record['vip_no'])
            ->update($task_ok_UPDATE);

        // 改用户表
        $Vipuserid = Db::name('user_vip_record')->field(true)->where('vip_no', $order_recharge_record['vip_no'])->select();

        $user_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
        Db::name('user')->where($user_WHERE)->update(['vip' => 1]);

        // 生成系统消息给用户
        $SelfCheck = Db::name('user_vip')->field(true)->where('vip_no', $order_recharge_record['vip_no'])->find();

// dump($order_no);
// dump($order_recharge_record);
// dump($SelfCheck);
// exit();

        if ($SelfCheck['type'] == 0) {   // 给别人充
            $admin_WHERE['id'] = $SelfCheck['addid'];
            $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

            // $needToUserids  = [];
            $message_INSERT = [];
            foreach ($Vipuserid as $key => $value) {
                $message_INSERT[$key]['create_time'] = time();
                $message_INSERT[$key]['to_userid']   = $value['userid'];
                $message_INSERT[$key]['typeid']      = 4;
                $message_INSERT[$key]['title']       = '恭喜你成为跑步钱进APP会员';
                $message_INSERT[$key]['content']     = '你的好友' . $admindata['nickname'] . '为你充值了会员，恭喜你成为跑步钱进APP会员';
            }

            $need_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
            $needtoname = Db::name('user')->field('id,nickname')->where($need_WHERE)->select();

            $needtonamearray = array_column($needtoname, 'nickname');
            $needtonames = implode(',', $needtonamearray);

            $message_INSERT[$key + 1]['create_time'] = time();
            $message_INSERT[$key + 1]['to_userid']   = $admindata['id'];
            $message_INSERT[$key + 1]['typeid']      = 4;
            $message_INSERT[$key + 1]['title']       = '你成功为你的好友充值会员';
            $message_INSERT[$key + 1]['content']     = '你已成功为你的好友' . $needtonames . '充值会员';

            Db::name('user_messages')->insertAll($message_INSERT);

        } else {                         // 给自己充
            $admin_WHERE['id'] = $SelfCheck['addid'];
            $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

            $message_INSERT['create_time'] = time();
            $message_INSERT['to_userid']   = $admindata['id'];
            $message_INSERT['typeid']      = 4;
            $message_INSERT['title']       = '恭喜你成功充值跑步钱进APP会员';
            $message_INSERT['content']     = '恭喜你成功充值跑步钱进APP会员';

            Db::name('user_messages')->insert($message_INSERT);
        }

        dump('success');


        Db::commit();
    }

    /**
     * @title  表情服务器测试
     * @return string error   错误码：0成功|1失败
     * @return string message 错误内容
     * @return array  data    返回数据
     * @desc 请求方式：POST <br/>地址：v1/Zfile/testLook
     */
    public function testLook()
    {   

// $show = cache('xiaocxces');
$show = cache('xcxcs');
dump($show);
die;

        $userid = intval(input('id'));

        if (empty($userid)) {
            return 0;
        }

        $token = cache('paobuqianjin_Token_' . $userid);
        dump($userid . ':' . $token);
        die;

        $Userid  = input('userid') ? intval(input('userid')) : intval($this->userId);
        $content = input('content') ? input('content') : '';

        $res = db('ztest')->insert(['content' => $content]);

        $resdata = db('ztest')->field(true)->limit(1)->order('id desc')->find();
        return $this->sendSuccess($resdata['content'], '返回数据成功', 200);

        // $newcontent = '\U5475\U5475\Ud83d\Ude04\Ud83d\Ude04\Ud83d\Ude04\Ud83d\Ude04,/d/d';
        // // $newcontent = 'U5475U5475Ud83dUde04Ud83dUde04Ud83dUde04Ud83dUde04';

        // dump($newcontent);

        // echo json_encode($newcontent, JSON_UNESCAPED_SLASHES);

        // return $this->sendSuccess($content, '返回数据成功', 200);
    }


    // 地址：v1/Zfile/te
    public function te()
    {   
        $here = new HelibaoInt();                      // 合利宝集成类

dump('wensen');

    }


    /**
     * 参数规则
     * @name    字段名称
     * @type    类型
     * @require 是否必须
     * @default 默认值
     * @desc    说明
     * @range   范围
     * @return array
     */
    public static function getRules()
    {
        $rules = [
            'getFile' => [
                'action'   => [
                    'name'    => 'action',
                    'type'    => 'int',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '1用户协议|2邀请协议|3兑换协议|4提现协议',
                    'range'   => ''
                ],
            ],
            'testLook' => [
                'content'   => [
                    'name'    => 'content',
                    'type'    => 'string',
                    'require' => 'true',
                    'default' => '',
                    'desc'    => '带表情的内容',
                    'range'   => ''
                ],
            ],
        ];
        //可以合并公共参数
        return $rules;
    }

    /**
     * @name 敏感词忽略字段
     * @deprecated array("method"=>array(request field 1,request field 2,....)) 区分大小写
     * @return array
     */
    public static function getIgnoreFields()
    {
        return [];
    }

}
