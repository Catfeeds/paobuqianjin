<?php
/**
 * 阿里云短信验证码发送类
 */
namespace app\v1\extend;

use Flc\Dysms\Client;
use Flc\Dysms\Request\SendSms;

class AliyunSms {
    // 保存错误信息
    public $error;
    // Access Key ID
    private $accessKeyId = '';
    // Access Access Key Secret
    private $accessKeySecret = '';
    // 签名
    private $signName = '';
    // 模版ID
    private $templateCode = '';
    //短信模板中参数
    private $templatePara = '';
    
    public function __construct($config = array())
    {
        $this->accessKeyId     = $config ['accessKeyId'];
        $this->accessKeySecret = $config ['accessKeySecret'];
        $this->signName        = $config ['signName'];
        $this->templateCode    = $config ['templateCode'];
        $this->templatePara    = $config ['templatePara'];
    }
    
    /**
     * 发送验证码
     * @param unknown $mobile            
     * @param unknown $verify_code            
     */
    public function send_verify($mobile, $verify_code)
    {
        $config = [
            'accessKeyId'     => $this->accessKeyId,
            'accessKeySecret' => $this->accessKeySecret,
        ];

        $client  = new Client($config);
        $sendSms = new SendSms;
        
        $sendSms->setPhoneNumbers($mobile);
        $sendSms->setSignName($this->signName);
        $sendSms->setTemplateCode($this->templateCode);
        $sendSms->setTemplateParam([$this->templatePara => $verify_code]);

        $result = $client->execute($sendSms);

        if ($result->Code != "OK") {
            //测试阶段可以开启，然后调取getErrorMessage方法获取具体错误信息
            $this->error = $this->getErrorMessage($result->Code);
            return false;
        }
        
        return true;
    }

    /**
     * 发送邀请短信
     * @param array Mobiles  手机号码数组
     * @param int   Userid   邀请人ID
     */
    public function sendInviteMsg($Mobiles, $Userid)
    {
        $config = [
            'accessKeyId'     => $this->accessKeyId,
            'accessKeySecret' => $this->accessKeySecret,
        ];

        $client  = new Client($config);
        $sendSms = new SendSms;

        $res = [];
        foreach ($Mobiles as $key => $value) {

            $sendSms->setPhoneNumbers($value);
            $sendSms->setSignName($this->signName);
            $sendSms->setTemplateCode($this->templateCode);
            $sendSms->setTemplateParam([$this->templatePara => $Userid]);

            $result[$key] = $client->execute($sendSms);

            if ($result[$key]->Code != "OK") {
                //测试阶段可以开启，然后调取getErrorMessage方法获取具体错误信息
                $this->error = $this->getErrorMessage( $result->Code );
                $res[$value] = false;
            } else {
                $res[$value] = true;
            }
        }

        // if ($result->Code != "OK") {
        //     //测试阶段可以开启，然后调取getErrorMessage方法获取具体错误信息
        //     $this->error = $this->getErrorMessage( $result->Code );
        //     return false;
        // }
        
        return true;
    }

    /**
    * 获取详细错误信息
    *
    * @param unknown $status            
    */
    public function getErrorMessage($status)
    {
        $message = array (
            'isp.RAM_PERMISSION_DENY'         => 'RAM权限DENY',
            'isv.OUT_OF_SERVICE'              => '业务停机',
            'isv.PRODUCT_UN_SUBSCRIPT'        => '未开通云通信产品的阿里云客户',
            'isv.PRODUCT_UNSUBSCRIBE'         => '产品未开通',
            'isv.ACCOUNT_NOT_EXISTS'          => '账户不存在',
            'isv.ACCOUNT_ABNORMAL'            => '账户异常',
            'isv.SMS_TEMPLATE_ILLEGAL'        => '短信模板不合法',
            'isv.SMS_SIGNATURE_ILLEGAL'       => '短信签名不合法',
            'isv.INVALID_PARAMETERS'          => '参数异常',
            'isp.SYSTEM_ERROR'                => '系统错误',
            'isv.MOBILE_NUMBER_ILLEGAL'       => '非法手机号',
            'isv.MOBILE_COUNT_OVER_LIMIT'     => '手机号码数量超过限制',
            'isv.TEMPLATE_MISSING_PARAMETERS' => '模板缺少变量',
            'isv.BUSINESS_LIMIT_CONTROL'      => '业务限流',
            'isv.INVALID_JSON_PARAM'          => 'JSON参数不合法，只接受字符串值',
            'isv.BLACK_KEY_CONTROL_LIMIT'     => '黑名单管控',
            'isv.PARAM_LENGTH_LIMIT'          => '参数超出长度限制',
            'isv.PARAM_NOT_SUPPORT_URL'       => '不支持URL',
            'isv.AMOUNT_NOT_ENOUGH'           => '账户余额不足',
        );

        if (isset ($message[$status])) {
            return $message[$status];
        }

        return $status;
    }
}
