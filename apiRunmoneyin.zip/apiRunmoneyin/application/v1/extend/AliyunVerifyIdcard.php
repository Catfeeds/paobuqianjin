<?php
/**
 * 阿里云身份证实名认证类
 */
namespace app\v1\extend;

class AliyunVerifyIdcard {
    // 保存错误信息
    public $error;
    // 保存的数据
    public $data;
    // AppCode
	private $AppCode = '';

    public function __construct($config = array()) {
        $this->AppCode = $config ['AppCode'];
    }
    /**
     * 身份证实名认证查询
     * @author chenjie 2018-02-06
     * @param  string $realname 真实姓名
     * @param  string $idcard   身份证号码
     */
    public function IdcardQuery($realname,$idcard){
	    $host = "https://1.api.apistore.cn";
	    $path = "/idcard3";
	    $method = "POST";
	    $appcode = $this->AppCode;
	    $headers = array();
	    array_push($headers, "Authorization:APPCODE " . $appcode);
	    $querys = "";
	    $bodys = "cardNo=".$realname."&realName=".$idcard;
	    $url = $host . $path . "?" . $querys;

	    $curl = curl_init();
	    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
	    curl_setopt($curl, CURLOPT_URL, $url);
	    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($curl, CURLOPT_FAILONERROR, false);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($curl, CURLOPT_HEADER, false);
	    if (1 == strpos("$".$host, "https://"))
	    {
	        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	    }
	    curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
	    $result = curl_exec($curl);

        if (!$result['result']['isok']) {
            return false;
        }

        $this->data = $result['result'];
        return true;
    }
}