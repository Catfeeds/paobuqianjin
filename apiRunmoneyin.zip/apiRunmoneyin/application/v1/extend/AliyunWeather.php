<?php
/**
 * 阿里云全国天气预报查询类
 */
namespace app\v1\extend;

class AliyunWeather {
    // 保存错误信息
    public $error;
    // 保存的数据
    public $data;
    // AppCode
	private $AppCode = '';

    public function __construct($config = array()) {
        $this->AppCode = $config ['AppCode'];
    }

    /**
     * 经度纬度查询天气
     * @author chenjie 2018-02-05
     * @param  double $longitude 经度
     * @param  double $latitude  纬度
     */
    public function WeatherQuery($longitude,$latitude){
        $host = "http://jisutqybmf.market.alicloudapi.com";

	    $headers = array();
	    array_push($headers, "Authorization:APPCODE " . $this->AppCode);

	    $params = array(
	    	'location' => $latitude.','.$longitude
	    );

	    $url = $host."/weather/query?". http_build_query($params);

	    $curl = curl_init();
	    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
	    curl_setopt($curl, CURLOPT_URL, $url);
	    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($curl, CURLOPT_FAILONERROR, false);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($curl, CURLOPT_HEADER, false);
	    if (1 == strpos("$".$host, "https://"))
	    {
	        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	    }
	    $result = curl_exec($curl);
	    curl_close ( $curl );

	    $result = json_decode ( $result, true );
        
        if (intval($result['status']) !== 0) {
			//测试阶段可以开启，然后调取getErrorMessage方法获取具体错误信息
            $this->error = $this->getErrorMessage ( $result ['status'] );
            return false;
        }

        $this->data = $result['result'];
        return true;
    }

    /**
     * 获取详细错误信息
     *
     * @param unknown $status            
     */
    public function getErrorMessage($status){
         $message = array (
                 '201' => '城市和城市ID和城市代号都为空',
                 '202' => '城市不存在',
                 '203' => '此城市没有天气信息',
                 '210' => '没有信息'
         );
         if (isset ( $message [$status] )) {
             return $message [$status];
         }
         return $status;
    }
}