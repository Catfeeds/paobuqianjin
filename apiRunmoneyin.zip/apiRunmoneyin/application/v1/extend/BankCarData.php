<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/05/28 21:40
// +----------------------------------------------------------------------
// | TITLE: 获取银行卡详细信息
// +----------------------------------------------------------------------

namespace app\v1\extend;


class BankCarData
{
    // /**
    //  * @var string 银行卡联行号查询路径
    //  */
    // static private $carCoupletUrl = 'http://lhh.market.alicloudapi.com/lhh';

    /**
     * @var string 银行卡银行编号查询路径
     */
    static private $carCodeUrl = 'http://api43.market.alicloudapi.com/api/c43';

    /**
     * @var string 编号
     */
    static private $appKey = '24794885';

    /**
     * @var string 编码
     */
    static private $appCode = 'ff5736e074164fa39b3d970536cff56e';

    /**
     * @var string 秘钥
     */
    static private $AppSecret = '288110c0b924be05b1369228be311cee';

    /**
     * @var array 银行卡数据
     */
    static private $bankData = [];

//     /**
//      * 获取联行号
//      */
//     public function getCoupletNo($Carno = '')
//     {
// dump('getCoupletNo');

//         $host    = self::carCoupletUrl;
//         $method  = "GET";
//         $appcode = self::$appCode;

//         $headers = array();
//         array_push($headers, "Authorization:APPCODE " . $appcode);

//         // $querys = "bankcard=bankcard&bankname=bankname&city=city&district=district&keyword=keyword&page=page&province=province";
//         $querys = "bankcard=" . $Carno;
//         $bodys = "";
//         $url = $host . "?" . $querys;

// dump($querys);
// dump($url);

//         $curl = curl_init();
//         curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
//         curl_setopt($curl, CURLOPT_URL, $url);
//         curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
//         curl_setopt($curl, CURLOPT_FAILONERROR, false);
//         curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//         // curl_setopt($curl, CURLOPT_HEADER, true);

//         if (1 == strpos("$".$host, "https://")) {
//             curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
//             curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
//         }
        
//         //返回内容
//         $callbcak = curl_exec($curl);

//         $resdata  = json_decode($callbcak, true);

// dump($callbcak);
// dump($resdata);
// die;

//         if ($callbcak == 200) {
//             return json_decode($callbcak, true);
//         } else {
//             return json_decode($callbcak, true);
//         }
//     }

    /**
     * 获取银行编号
     */
    static public function getBankCode($Carno = '')
    {   
        // http格式
        header("Content-type: text/html; charset=utf-8");
        
        $url     = self::$carCodeUrl; // 接口地址
        $appCode = self::$appCode;    // 编码

        $params['apiversion'] = '2.0.5';
        $params['bankcard']   = $Carno;

        // // 发送远程请求;
        // $result = self::$APISTORE($url, $params, $appCode, "GET");

        $method = 'GET';

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $method == "POST" ? $url : $url . '?' . http_build_query($params));
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Authorization:APPCODE ' . $appCode
        ));

        // 如果是https协议
        if (stripos($url, "https://") !== FALSE) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
            //CURL_SSLVERSION_TLSv1
            curl_setopt($curl, CURLOPT_SSLVERSION, 1);
        }

        // 超时时间
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 60);
        curl_setopt($curl, CURLOPT_TIMEOUT, 60);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        // 通过POST方式提交
        if ($method == "POST") {
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params));
        }

        // 返回内容
        $callbcak = curl_exec($curl);

        // http status
        $CURLINFO_HTTP_CODE = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        // 关闭
        curl_close($curl);

        // //如果返回的不是200,请参阅错误码 https://help.aliyun.com/document_detail/43906.html
        // if ($CURLINFO_HTTP_CODE == 200) {
        //     $res = json_decode($callbcak, true);

        //     if (!empty($res['result']['abbreviation'])) {
        //         return $res['result']['abbreviation'];
        //     }
        // }
        // else if ($CURLINFO_HTTP_CODE == 403)
        //     return array("error_code" => $CURLINFO_HTTP_CODE, "reason" => "剩余次数不足");
        // else if ($CURLINFO_HTTP_CODE == 400)
        //     return array("error_code" => $CURLINFO_HTTP_CODE, "reason" => "APPCODE错误");
        // else
        //     return array("error_code" => $CURLINFO_HTTP_CODE, "reason" => "APPCODE错误");
        
        if ($CURLINFO_HTTP_CODE == 200) {
            $res = json_decode($callbcak, true);
            if (!empty($res['result']['abbreviation'])) {
                self::$bankData = $res['result'];
                return $res['result']['abbreviation'];
            }
        }

        return false;
    }

    /**
     * 获取银行卡信息
     */
    static public function getBankCardData($Carno = '')
    {   
        // http格式
        header("Content-type: text/html; charset=utf-8");
        
        $url     = self::$carCodeUrl; // 接口地址
        $appCode = self::$appCode;    // 编码

        $params['apiversion'] = '2.0.5';
        $params['bankcard']   = $Carno;

        // // 发送远程请求;
        // $result = self::$APISTORE($url, $params, $appCode, "GET");

        $method = 'GET';

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $method == "POST" ? $url : $url . '?' . http_build_query($params));
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Authorization:APPCODE ' . $appCode
        ));

        // 如果是https协议
        if (stripos($url, "https://") !== FALSE) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
            //CURL_SSLVERSION_TLSv1
            curl_setopt($curl, CURLOPT_SSLVERSION, 1);
        }

        // 超时时间
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 60);
        curl_setopt($curl, CURLOPT_TIMEOUT, 60);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        // 通过POST方式提交
        if ($method == "POST") {
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params));
        }

        // 返回内容
        $callbcak = curl_exec($curl);

        // http status
        $CURLINFO_HTTP_CODE = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        // 关闭
        curl_close($curl);

        // //如果返回的不是200,请参阅错误码 https://help.aliyun.com/document_detail/43906.html
        // if ($CURLINFO_HTTP_CODE == 200) {
        //     $res = json_decode($callbcak, true);

        //     if (!empty($res['result']['abbreviation'])) {
        //         return $res['result']['abbreviation'];
        //     }
        // }
        // else if ($CURLINFO_HTTP_CODE == 403)
        //     return array("error_code" => $CURLINFO_HTTP_CODE, "reason" => "剩余次数不足");
        // else if ($CURLINFO_HTTP_CODE == 400)
        //     return array("error_code" => $CURLINFO_HTTP_CODE, "reason" => "APPCODE错误");
        // else
        //     return array("error_code" => $CURLINFO_HTTP_CODE, "reason" => "APPCODE错误");
        
        if ($CURLINFO_HTTP_CODE == 200) {
            $res = json_decode($callbcak, true);

            return $res['result'];
        }

        return false;
    }
    
    /**
     * 获取银行名
     */
    static public function getBankname()
    {
        return self::$bankData['bankname'] ? self::$bankData['bankname'] : false;
    }

}
