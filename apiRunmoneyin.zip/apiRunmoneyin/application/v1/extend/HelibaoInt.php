<?php

/**
 * @author: fuchao
 * @createTime: 2018-05-21 18:02
 * @description: 合利宝功能集成类
 */

namespace app\v1\extend;
use app\v1\extend\DES3;
use app\v1\extend\RsaEncrypt;
use helibao\Crypt_RSA;
use think\Config;

header("content-type:text/html;charset=utf-8");

class HelibaoInt {

    protected $desKey   = 'uMPE00c86bPWWyjLhBUlkA82';   // des加密密钥
    protected $cusNum   = 'C1800275339';                // 合利宝商户号
    protected $authType = '0040';                       // 鉴权认证类型[卡号+户名+证件+手机号]

    protected $aptitudeCode = 'BM00119952';             // 合利宝分配资质编码

    /*鉴权*/
    protected $authHost = 'http://test.trx.helipay.com/trx/authentication/interface.action';    
    protected $authSignKey = '8dXI0AqcXRTQDfKi74ah1Th3vaWD6HIY';                                

    /*支付[通用]*/
    protected $wapPayUrl = 'http://test.trx.helipay.com/trx/app/interface.action';       
    protected $paySignKey = 'B5zb9NFUJarkxEgBzTOWDJSuUuY4kulD';       

    /*代付*/
    protected $transferUrl = 'http://test.trx.helipay.com/trx/transfer/interface.action';       
    protected $transferSignKey = '1dzHHKZ1t2Q6OeNcsTyiKmijRwVWpJ2E';

    /*云闪付*/
    protected $baseUrl = 'http://test.trx.helipay.com/trx';
    protected $SDKsignKey = 'D5waKUkqliHQgDQn8sKIQwyEQkrHl7pw';

    protected $appIdAndri = 'c7317c6c84f3c13999fe3eb15abf564f';             // 安卓包签名
    protected $appIdIos = 'come.runMoney';                                  // IOS包签名

    // /*回调地址*/
    // protected $quickNotifyUrl = 'https://api.runmoneyin.com/v1/Pay/quickPayNotify';      // 云闪付回调
    // protected $wxWapNotifyUrl = 'https://api.runmoneyin.com/v1/Pay/wxWapPayNotify';      // 微信wap回调

    /*回调地址*/
    protected $quickNotifyUrl = '';      // 云闪付回调
    protected $wxWapNotifyUrl = '';      // 微信wap回调


    public function __construct() {

        $serverPrefix = config('serverurlprefix');
        $this->quickNotifyUrl = $serverPrefix . 'v1/Pay/quickPayNotify';      // 云闪付回调
        $this->wxWapNotifyUrl = $serverPrefix . 'v1/Pay/wxWapPayNotify';      // 微信wap支付回调
    }


    /**
     * *云闪付统一下单
     */
    public function quickSdkMerchant($quickArr) {

        $quickOrderUrl = $this->baseUrl.'/quickSdkMerchant/unifiedOrder.action';

        if(empty($quickArr)) {
            return array('code'=>'PARAM_LACK','message'=>'参数不足');
        }

        if($quickArr['deviceType'] == 1) {        // 安卓
            $appId = $this->appIdAndri;
            $terminalType = 'IMEI';
        }elseif($quickArr['deviceType'] == 2) {   // IOS
            $appId = $this->appIdIos;
            $terminalType = 'UUID';
        }else {
            return array('code'=>'TERMIN_ERROR','message'=>'终端标识必填');
        }

        $parameters = array(
            "amount"    =>  $quickArr['amount'],                            // 支付金额
            "appId"     =>  $appId,                                         // 包签名
            "currency"  =>  "CNY",                                          // 交易币种
            "goodsDesc" =>  $quickArr['goodsDesc'],                         // 商品描述
            "goodsName" =>   $quickArr['goodsName'],                        // 商品名称
            //"idCardNo"  =>    "440881198810101832",                         // 身份证号码(非必填)
            "merchantNo"    =>  $this->cusNum,                              // 商户号
            "orderIp"   => $_SERVER['REMOTE_ADDR'],                         // 下单ip
            "orderNum"  =>    $quickArr['orderNo'],                         // 订单编号
            //"payerName" =>   "罗日章",                                      // 下单人实名(非必填)
            "serverCallBackUrl" =>  $this->quickNotifyUrl,                  // 异步通知地址
            "terminalId"    =>  $quickArr['terminalId'],                    // 终端标识 MAC或IMEI地址
            "terminalType"  =>  $terminalType,                              // 终端类型(IMEI("IMEI") MAC("MAC") UUID("IOS") OTHER("其他"))
            "trxTime"   => date('YmdHis'),                                  // 订单时间
            "aptitudeCode" => $this->aptitudeCode,                          // 资质编码
            "userId"    =>  $quickArr['userid'],                            // 用户系统id
        );

        $quickResult = $this->quickPayRequest($parameters,$quickOrderUrl);     // 调起公共请求

        // $pararData = base64_encode(json_encode($parameters));               // 转为json并编码
        // $quickSign = md5($pararData.'&'.$this->SDKsignKey);                 // 闪付签名生成

        // $commParam = array(                                                 // 公共请求参数
        //     'merchantNo'    => $this->cusNum,
        //     'data'          => $pararData,
        //     'sign'          => $quickSign,
        //     'signType'      => 'MD5',
        //     'version'       => '1.0',
        // );

        // $commParamJson = json_encode($commParam);
        // $quickRes = $this->curl_post_json($quickOrderUrl,$commParamJson);
        
        return json_decode($quickResult,true);
        // return json_decode($quickRes,true);
        
        //return $parameters;
    }

    /**
     * 云闪付订单查询
     * @param [string] $[orderNo] [订单编号]
     * @return [description]
    */
    public function quickPayQuery($orderNo) {
        $quickQueryUrl = $this->baseUrl.'/quickSdkMerchant/tradeQuery.action';

        $parameters = array(
            "merchantNo"    =>  $this->cusNum,                              // 商户号
            "orderNum"  =>    $orderNo,                                     // 订单编号
        );

        $quickResult = $this->quickPayRequest($parameters,$quickQueryUrl);    // 调起公共请求
        
        return json_decode($quickResult,true);
    }


    /**
     * *云闪付请求公用
    */
    public function quickPayRequest($params,$reqUrl) {

        $pararData = base64_encode(json_encode($params));               // 转为json并编码

        $quickSign = md5($pararData.'&'.$this->SDKsignKey);             // 闪付签名生成

        $commParam = array(                                             // 公共请求参数
            'merchantNo'    => $this->cusNum,
            'data'          => $pararData,
            'sign'          => $quickSign,
            'signType'      => 'MD5',
            'version'       => '1.0',
        );

        $commParamJson = json_encode($commParam);

        $quickRes = $this->curl_post_json($reqUrl,$commParamJson);

        return $quickRes;
    }


    /**
     * *curl发起post请求
     * @param [string] $[url] [请求地址]
     * @param [array] $[params] [请求参数集]
     * @return  [返回结果集]
     */
    protected function curl_post_json($url,$params) {
        $ch = curl_init();  // 初始化curl
        curl_setopt($ch,CURLOPT_URL,$url);              // 抓取指定网页
        //curl_setopt($ch, CURLOPT_HEADER, 0);            // 设置header
        curl_setopt ( $ch, CURLOPT_HTTPHEADER, array (
            'Content-Type: application/json; charset=utf-8;',
            'Content-Length: ' . strlen ( $params )
            ) );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);    // 要求结果为字符串且输出到屏幕上
        // curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, 1);              // post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        $data = curl_exec($ch); // 运行curl
        curl_close($ch);
        return($data);          // 输出结果            
    }


    /**
     * *鉴权请求
     * @param [array] $[authParam] [绑卡基本信息输入]
     * @return [array] [接口信息反馈]
     */
    public function verifyAuth($authParam) {

        if (empty($authParam)) {
            return false;
        }

        $Des3 = new DES3();      // 实例Des加密类

        $paramReq = array(
            'P1_bizType'        => 'Authentication',            // 交易类型
            'P2_customerNumber' => $this->cusNum,               // 商户编号
            'P3_orderId'        => $authParam['orderNum'],      // 商户请求流水号
            'P4_timestamp'      => date('YmdHis'),              // 时间戳
            'P5_verifyType'     => $this->authType,             // 认证类型
            'P6_payerName'      => $authParam['payerName'],     // 姓名
            'P7_idCardType'     => 'IDCARD',                    // 证件类型
            'P8_idCardNo'       => $Des3->encrypt($authParam['idCardNo'],$this->desKey),     // 证件号码
            'P9_cardNo'         => $Des3->encrypt($authParam['cardNo'],$this->desKey),       // 银行卡号
            'P10_year'          => $authParam['cyear'],                                      // 信用卡有效期年份
            'P11_month'         => $authParam['cday'],                                       // 信用卡有效期月份
            'P12_cvv2'          => $authParam['ccode'],                                      // 信用卡安全码
            'P13_phone'         => $Des3->encrypt($authParam['phoneNo'],$this->desKey),      // 手机号码
        );

        $preSignArr = array();
        foreach($paramReq as $keys => $vals) {
            $preSignArr[] = $vals;
        }

        // 组装签名
        $paramReq['sign'] = $this->buildAuthSign($preSignArr, $this->authSignKey);

        // 发起鉴权请求
        $authReault = $this->curl_post($this->authHost, $paramReq);

        return json_decode($authReault, true);     // 返回请求结果
    }

    /**
     * *WAP，合利宝支付方法(微信wap支付)
     */
    public function wapPay() {

         // 调起支付
        $unifiedorder = $this->unifiedorder();

        return $unifiedorder;
        die;

        // // 统一下单出错，参数出错等原因
        // if($unifiedorder['return_code'] == 'FAIL') {
        //     $retrunInfo['code'] = 0;
        //     $retrunInfo['msg'] = $unifiedorder['return_msg'];
        //     return $retrunInfo;
        // }
        // $parameters = array(
        //     'appId' => $this->appid,                                // ID
        //     'timeStamp' => '' . time() . '',                        // 时间戳
        //     'nonceStr' => $this->createNoncestr(),                  // 随机串
        //     'package' => 'prepay_id=' . $unifiedorder['prepay_id'], // 数据包
        //     'signType' => 'MD5'                                     // 签名方式
        // );

        // $parameters['paySign'] = $this->getSign($parameters);

        // // 成功返回
        // $retrunInfo['code'] = 1;
        // $retrunInfo['msg'] = $parameters;
        // return $retrunInfo;
    }


    // 微信wap支付接口请求
    private function unifiedorder() {

        $parameters = array(
            'P1_bizType' => 'AppPayH5WFT',                              // 交易类型
            'P2_orderId' => date('YmdHis') . rand(100000, 999999),      // 商户订单号
            'P3_customerNumber' => $this->cusNum,                       // 商户编号
            'P4_orderAmount' => '2.00',                                 // 支付金额(单位分)
            'P5_currency' => 'CNY',                                     // 货币类型
            'P6_orderIp' => $_SERVER['REMOTE_ADDR'],                    // 商户IP      
            'P7_notifyUrl'=> $this->wxWapNotifyUrl,                     // 异步通知

            'P8_appPayType' => 'WXPAY',                                 // 客户端类型
            'P9_payType' => 'WAP',                                      // 支付类型
            'P10_appName' => '跑步钱进',                                // 应用名称
            'P11_deviceInfo' => 'iOS_SDK',                              // 应用类型  
            'P12_applicationId' => 'come.runMoney',                     // 应用标识 

            'P13_goodsName' => '会员充值',                              // 商品名称
            'P14_goodsDetail' => '充值2员',                             // 商品描述
            'P15_desc' => '备注123',                                    // 备注
        );

        //签名
        $parameters['sign'] = $this->buildAuthSign($parameters,$this->paySignKey);

        // 发起WFT扫码支付接口
        $payReturn = $this->curl_post($this->wapPayUrl,$parameters);

        return $payReturn;
    }


    /**主扫 and 被扫*/
    public function scanPay() {

        $parameters = array(
            'P1_bizType' => 'AppPay',                                   // 交易类型
            'P2_orderId' => date('YmdHis') . rand(100000, 999999),      // 商户订单号
            'P3_customerNumber' => $this->cusNum,                       // 商户编号
            'P4_payType' => 'SCAN',                                     // 支付金额(单位分)
            'P5_orderAmount' => '2.00',                                 // 金额
            'P6_currency' => 'CNY',                                     // 商户IP      
            'P7_authcode'=> '1',

            'P8_appType' => 'WXPAY',                                    // 客户端类型
            'P9_notifyUrl' => 'http://wap.helipay.com/notify.php',                                      // 支付类型
            'P10_successToUrl' => 'http://wap.helipay.com/success.php',                                 // 应用名称

            'P11_orderIp' => $_SERVER['REMOTE_ADDR'],                              // 应用类型
            'P12_goodsName' => '商品名称',                      // 商品名称 

            'P13_goodsDetail' => '商品描述',                    // 商品描述
            'P14_desc' => '备注测试',                           // 商品描述
        );

        //签名
        $parameters['sign'] = $this->buildAuthSign($parameters,$this->paySignKey);

        $payReturn = $this->curl_post($this->wapPayUrl,$parameters);

        return $payReturn;
    }

    /**扫码分账支付*/
    public function routingPay() {

        $parameters = array(
            'P1_bizType' => 'AppPay',                                    // 交易类型
            'P2_orderId' => date('YmdHis') . rand(100000, 999999),       // 商户订单号
            'P3_customerNumber' => $this->cusNum,                        // 商户编号
            'P4_payType' => 'WAP',                                       // 支付类型
            'P5_orderAmount' => '2.00',                                  // 金额
            'P6_currency' => 'CNY',                                      // 商户IP      
            'P7_authcode'=> '1',

            'P8_appType' => 'WXPAY',                                     // 客户端类型
            'P9_notifyUrl' => 'http://wap.helipay.com/notify.php',       // 支付类型
            'P10_successToUrl' => 'http://wap.helipay.com/success.php',  // 应用名称

            'P11_orderIp' => $_SERVER['REMOTE_ADDR'],                    // 应用类型
            'P12_goodsName' => '商品名称',                               // 商品名称 

            'P13_goodsDetail' => '商品描述',                             // 商品描述
            'P14_desc' => '备注测试',                                    // 商品描述
        );

        //签名
        $parameters['sign'] = $this->buildAuthSign($parameters,$this->paySignKey);

        $payReturn = $this->curl_post($this->wapPayUrl,$parameters);

        return $payReturn;
    }


    /**
     * *代付，零钱提现到个人银行卡
     * @param [int] $[orderNo] [订单编号]
     * @param [int] $[isCorporate] [是否对公账户]
     * @param [float] $[amount] [提现金额]
     * @return [type] [description]
     */
    public function transfer($transferArr,$isCorporate=false) {
        
        if(empty($transferArr)) {
            return false;
        }

        // 对公账户
        if($isCorporate) {
            if(!isset($transferArr['bankUnionCode'])) return false;

            $bankUnionCode = $transferArr['bankUnionCode'];
            $bizs = 'B2B';
        }else {
            $bankUnionCode = '';
            $bizs = 'B2C';
        }

        $parameters = array(
            'P1_bizType' => 'Transfer',                                 // 交易类型
            'P2_orderId' => $transferArr['orderNo'],                    // 商户订单号
            'P3_customerNumber' => $this->cusNum,                       // 商户编号
            'P4_amount' => $transferArr['amount'],                      // 提现金额(单位元)
            'P5_bankCode' => $transferArr['bankCode'],                  // 银行编码
            'P6_bankAccountNo' => $transferArr['bankCard'],             // 银行卡号      
            'P7_bankAccountName'=> $transferArr['account'],             // 银行账户名

            'P8_biz' => $bizs,                                          // 业务类型
            'P9_bankUnionCode' => $bankUnionCode,                       // 银行联行号
            
            'P10_feeType' => 'PAYER',                                   // 手续费收取方式[payer付款方]

            'P11_urgency' => true,                                      // 是否加急
            'P12_summary' => $transferArr['remark'],                    // 打款备注 
        );

// var_dump($parameters);
// return $parameters;
// die;
        
        $helibao_config = config('pay.helibao');                            // 合利宝配置文件
        $privatekeyPath = $helibao_config['rsa_private_key'];               // 代付RSA非对称加密私钥

        $parameters['sign'] = $this->buildRsaSign($parameters,$privatekeyPath);     // RSA私钥签名

        $withDrawReturn = $this->curl_post($this->transferUrl,$parameters);     

        $resArr = json_decode($withDrawReturn,true);                                // 代付请求结果转为数组

        $is_pass = $this->checkResSign($resArr,$this->transferSignKey);             // 响应参签名是否一致

        if($is_pass) {      // 签名匹配失败

            // 单笔代付查询开始
            $queryRes = $this->transferQuery($resArr['rt5_orderId']);
            return $queryRes;

        }else {
            return false;
        }

    }

    /**
     * 单笔代付查询
     * @param [string] $[orderNo] [订单编号]
     * @return  [查询结果数组]
     */
    public function transferQuery($orderNo) {

        $parameters = array(
            'P1_bizType' => 'TransferQuery',                                 // 交易类型
            'P2_orderId' => $orderNo,                                        // 商户订单号
            'P3_customerNumber' => $this->cusNum,                            // 商户编号
        );

        $helibao_config = config('pay.helibao');                            // 合利宝配置文件
        $privatekeyPath = $helibao_config['rsa_private_key'];               // 代付RSA非对称加密私钥

        $parameters['sign'] = $this->buildRsaSign($parameters,$privatekeyPath);     // RSA私钥签名

        $transferQueryRes = json_decode($this->curl_post($this->transferUrl,$parameters),true);
        $transferQueryRes['checkResult'] = $this->checkResSign($transferQueryRes,$this->transferSignKey,true);        // 响应参签名是否一致

        return $transferQueryRes;
        //return json_decode($transferQueryRes,true);
    }



/*****************助手方法******************************************************/
    /**
     * *返回参数签名匹配
     * @param [array] $[resArr] [返回参数数组]
     * @param [string] $[signKey] [签名密钥]
     * @param [boolean] $[isQuery] [是否为查询]
     * @return  [是否匹配]
     */
    protected function checkResSign($resArr,$signKey,$isQuery=false) {
        $temp_arr = array();

        // 去除不用的参
        foreach ($resArr as $key => $value) {

            if(!$isQuery) {
                if($key != "sign" && $key != "rt3_retMsg") {
                    $temp_arr[$key] = $value;
                }
            }else {
                if($key != "sign" && $key != "rt3_retMsg" && $key != "rt8_reason") {
                    $temp_arr[$key] = $value;
                }
            }
        }
        ksort($temp_arr);   

        $temp_sign = $this->buildAuthSign($temp_arr,$signKey);      // 根据返回参签名(sign,rt3_retMsg除外)

        if($resArr['sign'] != $temp_sign) {
            return false;
        }else {
            return true;
        }

        //return $temp_sign;    
    }

    /**
     * *生成RSA签名
     * @param [array] $[parames] [参数集]
     * @param [string] $[key] [密钥]
     * @return  [RSA签名串]
    */
    protected function buildRsaSign($parames,$key) {

        $reqStr = "";
        foreach($parames as $keys=>$vals) {
            $reqStr .= '&'.$vals;
        }

        $rsa = new RsaEncrypt();
        $signStr = $rsa->rsaSign($parames,$key);

        // $rsa = new Crypt_RSA();
        // $rsa->setHash('md5');
        // $rsa->setSignatureMode(CRYPT_RSA_SIGNATURE_PKCS1);
        // $rsa->loadKey($key);
        // $signStr = base64_encode($rsa->sign($reqStr));

        return $signStr;
    }
    
    /**
     * *生成鉴权请求签名
     * @param [array] $[authParam] [鉴权参数集]
     * @return [string] [md5签名串]
     */
    protected function buildAuthSign($authParam,$signKey) {

        $reqStr = "";
        foreach($authParam as $keys=>$vals) {
            $reqStr .= '&'.$vals;
        }

        // if(!$key) {
        //     return md5($reqStr);
        //     die;
        // }
        // return $key;
        // die;
        
        //$newSign = $reqStr.'&'.$signKey;
        $newSign = md5($reqStr.'&'.$signKey);
        return $newSign;
    }

    /**
     * *curl发起post请求
     * @param [string] $[url] [请求地址]
     * @param [array] $[params] [请求参数集]
     * @return  [返回结果集]
     */
    protected function curl_post($url,$params) {
        $ch = curl_init();  // 初始化curl
        curl_setopt($ch,CURLOPT_URL,$url);              // 抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);            // 设置header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);    // 要求结果为字符串且输出到屏幕上
        // curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, 1);              // post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        $data = curl_exec($ch); // 运行curl
        curl_close($ch);
        return($data);          // 输出结果            
    }


    /**
     * *curl发起get请求
     * @param [string] $[url] [请求地址]
     * @param [type] $[name] [description]
     */
    protected function curl_get($url, array $params = array(),$timeout=5) {
        $ch = curl_init(); 
        curl_setopt ($ch, CURLOPT_URL, $url);            
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);            
        curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);             
        $file_contents = curl_exec($ch);             
        curl_close($ch);
        return $file_contents;      
    }

    /**
     * [curl_get_https description]
     * @param  [type] $url [description]
     * @return [type]      [description]
     */
    protected function curl_get_https($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.1 Safari/537.11');
        $res = curl_exec($ch);
        $rescode = curl_getinfo($ch, CURLINFO_HTTP_CODE); 
        curl_close($ch) ;
        return $res;
    }

}
