<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/04/10 20:16
// +----------------------------------------------------------------------
// | TITLE: 用户登录-退出记录
// +----------------------------------------------------------------------

namespace app\v1\extend;

use think\Request;
use think\Db;

class Loginlog
{
    /**
     * @title 用户登录记录
     * @param int Userid  用户id
     * @param int Type    登录类型：1登录，2退出，3扫码登录;
     * @param int Side    用户端：  0未知，1ios，2android，3小程序，4web
     * @param int Pattern 登录方式：1手机密码，2微信，3qq，4手机验证码
     * @param int Remark  登录的附加数据：手机号，openid
     * @return bool
     */
    public function addLog($Userid, $Type = 1, $Side = 0, $Pattern = 1, $Remark = '')
    {
        $Userid = intval($Userid);
        $Type   = intval($Type);
        $Side   = intval($Side);

        if (empty($Userid)) {
            return false;
        }

        @$request = Request::instance();
        
        // 获取用户名（昵称）
        @$Username = db('user')->where('id', $Userid)->value('nickname');

        // 写入用户记录
        $log_INSERT['type']     = $Type;
        $log_INSERT['side']     = $Side;
        $log_INSERT['userid']   = $Userid;
        $log_INSERT['username'] = $Username;
        $log_INSERT['pattern']  = $Pattern;
        $log_INSERT['remark']   = $Remark;
        $log_INSERT['ip']       = $request->ip();

        $Agent = @self::getServerAgent();

        if (!empty($Agent)) {
            $Browser   = @self::getBrowser();
            $Lang      = @self::getLang();
            $Address   = @self::getaddressAliyun($log_INSERT['ip']);
            $Equipment = @self::mobileOrComputer();
            $Port      = @self::getServerPort();

            $log_INSERT['mc']      = $Equipment['mc'];
            $log_INSERT['os']      = $Equipment['os'];
            $log_INSERT['lang']    = $Lang;
            $log_INSERT['browser'] = $Browser;
            $log_INSERT['addron']  = $Address['country'] ? $Address['country'] : '';
            $log_INSERT['addrtw']  = $Address['region'] ? $Address['region'] : '';
            $log_INSERT['addrth']  = $Address['city'] ? $Address['city'] : '';
            $log_INSERT['port']    = $Port;
            $log_INSERT['agent']   = $Agent;
            $log_INSERT['brand']   = $Equipment['brand'];
        }

        @$res = db('user_log')->insert($log_INSERT);

        if ($res) {
            return true;
        } else {
            return false;
        }
    }

    // 获得访客对应的服务端口号
    private function getServerPort()
    {
        if (!empty($_SERVER['SERVER_PORT'])) {
            return $_SERVER['SERVER_PORT'];
        } else {
            return '';
        }
    }

    // 获得访客引擎的信息
    private function getServerAgent()
    {
        if (!empty($_SERVER['HTTP_USER_AGENT'])) {
            return $_SERVER['HTTP_USER_AGENT'];
        } else {
            return '';
        }
    }

    // 获得访客浏览器类型
    private function getBrowser() 
    {
        if (!empty($_SERVER['HTTP_USER_AGENT'])) {
            $data = $_SERVER['HTTP_USER_AGENT'];
            if (preg_match('/MicroMessage/i', $data)) {
                $data = 'Weixin';
            } elseif (preg_match('/Firefox/i', $data)) {
                $data = 'Firefox';
            } elseif (preg_match('/Chrome/i', $data)) {
                $data = 'Chrome';
            } elseif (preg_match('/Safari/i', $data)) {
                $data = 'Safari';
            } elseif (preg_match('/Opera/i', $data)) {
                $data = 'Opera';
            } elseif (preg_match('/Edge/i', $data)) {
                $data = 'Edge';
            } elseif  (preg_match('/MSIE/i', $data)) {    
                $data = 'MSIE';
            } else {
                $data = 'notknow';
            }
        } else {
            $data = "fail";
        }

        return $data;
    }

    // 获得访客浏览器语言
    private function getLang()
    {
        if (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $data = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
            $data = substr($data, 0, 5);

            if(preg_match("/zh-cn/i", $data)) {
                $data = "简体中文";
            } elseif (preg_match("/zh/i", $data)) {
                $data = "繁体中文";
            } else {
                $data = "English";
            }
        } else {
            $data = "fail";
        }

        return $data;
    }

    // 获得访客真实ip
    private function getClientIp() 
    {
        if (!empty($_SERVER["HTTP_CLIENT_IP"])) {   
            $ip = $_SERVER["HTTP_CLIENT_IP"];
        }

        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {    //获取代理ip
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        }

        if ($ip) {
            $ips = array_unshift($ips, $ip); 
        }

        $count = count($ips);
        for ($i=0; $i<$count; $i++) {   
            if (!preg_match("/^(10|172\.16|192\.168)\./i", $ips[$i])) {    // 排除局域网ip
                $ip = $ips[$i];
                break;
            }
        }

        $tip = empty($_SERVER['REMOTE_ADDR']) ? $ip : $_SERVER['REMOTE_ADDR'];

        if (($tip == "127.0.0.1") || ($tip == "::1") || strstr($tip, '192.168.0')) {
            return '120.25.88.86';
        } else {
            return $tip; 
        }
    }

    // 根据ip获得访客所在地地名
    private function getaddressAliyun($ip = '') 
    {
        if (empty($ip)) {
            $ip = self::getClientIp();
        }

        $host    = "https://dm-81.data.aliyun.com";
        $path    = "/rest/160601/ip/getIpInfo.json";
        $method  = "GET";
        $appcode = "443a12351fe04b849c4c79974808ffa1";
        $headers = array();

        array_push($headers, "Authorization:APPCODE " . $appcode);

        $querys = "ip=" . $ip;
        $bodys = "";
        $url = $host . $path . "?" . $querys;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        // curl_setopt($curl, CURLOPT_HEADER, true);

        if (1 == strpos("$" . $host, "https://")) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }

        $string   = curl_exec($curl);
        $addrdata = json_decode($string, true);
        
        return $addrdata['data'];
    }

    // 判断移动端和电脑端
    private function mobileOrComputer()
    { 
        $user_agent = $_SERVER['HTTP_USER_AGENT'];

        $mobile_agents = Array("
            240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com",
            "applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird",
            "blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch",
            "fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei",
            "hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5",
            "lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu",
            "mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia",
            "nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-",
            "qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp",
            "siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca",
            "telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda",
            "voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"
        );

        $is_mobile = false;

        foreach ($mobile_agents as $device) { 
            if (stristr($user_agent, $device)) { 
                $is_mobile = true;
                $data['brand'] = self::getMobileType();
                $data['mc'] = 'mobile';
                $data['os'] = self::getMobileOsType();
                return $data; 
            } 
        }

        if ($is_mobile == false) {
            $data['brand'] = '';
            $data['mc'] = 'computer';
            $data['os'] = self::getOperatingSystem();
        }

        return $data;
    } 

    // 获取访客手机操作系统（iphone、androi、notknow）
    private function getMobileOsType()
    {
        $agent = strtolower($_SERVER['HTTP_USER_AGENT']);    //全部变成小写字母 
        $type = 'notknow';

        if (strpos($agent, 'iphone')) {
            $type = 'ios'; 
        } elseif (strpos($agent, 'ipad')) {
            $type = 'ipad'; 
        } elseif (strpos($agent, 'android')) {
            $type = 'android'; 
        }

        return $type;
    }

    // 获取访客手机操作系统（iphone、androi、notknow）
    private function getMobileType()
    {   
        $agent = $_SERVER['HTTP_USER_AGENT'];    //全部变成小写字母 

        if (stripos($agent, "iPhone")) {
            $brand = 'iPhone';
        } elseif (stripos($agent, "SAMSUNG") || stripos($agent, "Galaxy") || strpos($agent, "GT-") || strpos($agent, "SCH-") || strpos($agent, "SM-")) {
            $brand = '三星';
        } elseif (stripos($agent, "Huawei") || stripos($agent, "Honor") || stripos($agent, "H60-") || stripos($agent, "H30-")) {
            $brand = '华为';
        } elseif (stripos($agent, "Lenovo")) {
            $brand = '联想';
        } elseif (strpos($agent, "MI-ONE") || strpos($agent, "MI 1S") || strpos($agent, "MI 2") || strpos($agent, "MI 3") || strpos($agent, "MI 4") || strpos($agent, "MI-4") || strpos($agent, "MI 5") || strpos($agent, "MI 5s")) {
            $brand = '小米';
        } elseif (strpos($agent, "HM NOTE") || strpos($agent, "HM201")) {
            $brand = '红米';
        } elseif (stripos($agent, "Coolpad") || strpos($agent, "8190Q") || strpos($agent, "5910")) {
            $brand = '酷派';
        } elseif (stripos($agent, "ZTE") || stripos($agent, "X9180") || stripos($agent, "N9180") || stripos($agent, "U9180")) {
            $brand = '中兴';
        } elseif (stripos($agent, "OPPO") || strpos($agent, "X9007") || strpos($agent, "X907") || strpos($agent, "X909") || strpos($agent, "R831S") || strpos($agent, "R827T") || strpos($agent, "R821T") || strpos($agent, "R811") || strpos($agent, "R2017")) {
            $brand = 'OPPO';
        } elseif (strpos($agent, "HTC") || stripos($agent, "Desire")) {
            $brand = 'HTC';
        } elseif (stripos($agent, "vivo")) {
            $brand = 'vivo';
        } elseif (stripos($agent, "K-Touch")) {
            $brand = '天语';
        } elseif (stripos($agent, "Nubia") || stripos($agent, "NX50") || stripos($agent, "NX40")) {
            $brand = '努比亚';
        } elseif (strpos($agent, "M045") || strpos($agent, "M032") || strpos($agent, "M355")) {
            $brand = '魅族';
        } elseif (stripos($agent, "DOOV")) {
            $brand = '朵唯';
        } elseif (stripos($agent, "GFIVE")) {
            $brand = '基伍';
        } elseif (stripos($agent, "Gionee") || strpos($agent, "GN")) {
            $brand = '金立';
        } elseif (stripos($agent, "HS-U") || stripos($agent, "HS-E")) {
            $brand = '海信';
        } elseif (stripos($agent, "Nokia")) {
            $brand = '诺基亚';
        } else {
            $brand = 'notknow';
        }

        return $brand;
    }

    // 获取访客电脑操作系统
    private function getOperatingSystem() 
    {
        $agent = $_SERVER['HTTP_USER_AGENT'];  
        $os = false;  
      
        if (preg_match('/win/i', $agent) && strpos($agent, '95')) {  
            $os = 'Windows 95';
        } elseif (preg_match('/win 9x/i', $agent) && strpos($agent, '4.90')) {
            $os = 'Windows ME';
        } elseif (preg_match('/win/i', $agent) && preg_match('/98/i', $agent)) {
            $os = 'Windows 98';
        } elseif (preg_match('/win/i', $agent) && preg_match('/nt 6.0/i', $agent)) {
            $os = 'Windows Vista';
        } elseif (preg_match('/win/i', $agent) && preg_match('/nt 6.1/i', $agent)) {
            $os = 'Windows 7';
        } elseif (preg_match('/win/i', $agent) && preg_match('/nt 6.2/i', $agent)) {
            $os = 'Windows 8';
        } elseif (preg_match('/win/i', $agent) && preg_match('/nt 10.0/i', $agent)) {
            $os = 'Windows 10';#添加win10判断  
        } elseif (preg_match('/win/i', $agent) && preg_match('/nt 5.1/i', $agent)) {
            $os = 'Windows XP';
        } elseif (preg_match('/win/i', $agent) && preg_match('/nt 5/i', $agent)) {
            $os = 'Windows 2000';
        } elseif (preg_match('/win/i', $agent) && preg_match('/nt/i', $agent)) {
            $os = 'Windows NT';
        } elseif (preg_match('/win/i', $agent) && preg_match('/32/i', $agent)) {
            $os = 'Windows 32';
        } elseif (preg_match('/linux/i', $agent)) {
            $os = 'Linux';
        } elseif (preg_match('/unix/i', $agent)) {
            $os = 'Unix';
        } elseif (preg_match('/sun/i', $agent) && preg_match('/os/i', $agent)) {
            $os = 'SunOS';
        } elseif (preg_match('/ibm/i', $agent) && preg_match('/os/i', $agent)) {
            $os = 'IBM OS/2';
        } elseif (preg_match('/Mac/i', $agent) && preg_match('/PC/i', $agent)) {
            $os = 'Macintosh';
        } elseif (preg_match('/PowerPC/i', $agent)) {
            $os = 'PowerPC';
        } elseif (preg_match('/AIX/i', $agent)) {
            $os = 'AIX';
        } elseif (preg_match('/HPUX/i', $agent)) {
            $os = 'HPUX';
        } elseif (preg_match('/NetBSD/i', $agent)) {
            $os = 'NetBSD';
        } elseif (preg_match('/BSD/i', $agent)) {
            $os = 'BSD';
        } elseif (preg_match('/OSF1/i', $agent)) {
            $os = 'OSF1';
        } elseif (preg_match('/IRIX/i', $agent)) {
            $os = 'IRIX';
        } elseif (preg_match('/FreeBSD/i', $agent)) {
            $os = 'FreeBSD';
        } elseif (preg_match('/teleport/i', $agent)) {
            $os = 'teleport';
        } elseif (preg_match('/flashget/i', $agent)) {
            $os = 'flashget';
        } elseif (preg_match('/webzip/i', $agent)) {
            $os = 'webzip';
        } elseif (preg_match('/offline/i', $agent)) {
            $os = 'offline';
        } else {  
            $os = 'notknow';
        } 

        return $os;
    }

}