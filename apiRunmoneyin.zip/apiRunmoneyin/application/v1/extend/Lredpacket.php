<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018/05/08 19:22
// +----------------------------------------------------------------------
// | TITLE: 红包辅助类
// +----------------------------------------------------------------------

namespace app\v1\extend;

use think\Request;
use think\Db;

class Lredpacket
{
    // 上级邀请人数
    protected $upInviterNumber = 0;

    // 普通用户邀请提成金额
    protected $userLimit = 30;

    // 会员用户邀请提成金额
    protected $vipLimit = 30;

    // 实际使用的提成金额
    protected $iLimit = 0;

    // 红包扣取比率
    protected $redRatio = 0.20;

    // 推荐人红包扣取比率
    protected $iRedRatio = 0.16;

    // 公司红包扣取比率
    protected $cRedRatio = 0.04;

    // 用户数据
    protected $userData = [];

    // 红包和红包记录数据
    protected $canLenRed = [];

    // 商家红包分红记录数据
    public $bonus_INSERT = [];

    // 用户收益
    public $income_INSERT = [];

    // 邀请人收益
    public $income_i_INSERT = [];

    // 领取到实际红包总金额
    public $allRedMoney = 0;

    // 领取红包记录id数组
    public $allRedArray = [];

    // 领取红包记录数据
    public $record_UPDATE = [];

    // 用户返现给邀请人的金额
    protected $inviterMoney = 0.0;

    // 更新用户数据
    public $user_UPDATE = [];

    /**
     * @title  获取用户数据
     * @param  int   Userid   用户id
     * @return array Userdata 用户数据
     */
    public function getUserData($Userid)
    {
        $Userdata = Db::name('user')
            ->alias('user')
            ->field('
                user.id as userid,user.nickname,user.levelid,user.sex,user.education,
                concat_ws("-",user.birthyear,user.birthmonth,user.birthday) as birthday,
                user.height,user.weight,user.province,user.city,user.n_long,user.n_lat,user.n_updatetime,
                user.inviter_id,user.inviter_money,
                u.vip as ivip
            ')
            ->join('user u', 'u.id=user.inviter_id', 'left')
            ->where('user.id', $Userid)
            ->where('user.delete_id', 0)
            ->find();

        if (empty($Userdata)) {
            return $this->sendError(-1, '用户不存在必填', 400);
        }

        // 获取用户当天步数
        $userstep = Db::name('user_step')
            ->where('create_day', date('Y-m-d'))
            ->where('userid', $Userid)
            ->value('step_number');

        if (empty($userstep)) {
            $Userdata['step'] = 0;
        } else {
            $Userdata['step'] = intval($userstep);
        }

        // 计算年龄
        $Userdata['age'] = calcAge($Userdata['birthday']);

        $this->inviterMoney = round($Userdata['inviter_money'], 2);

        return $this->userData = $Userdata;
    }


    /**
     * @title  检测用户红包状态
     * @param  int         Userid 用户id
     * @return bool|string data   返回数据
     */
    public function chcekUserRedStatus($Userid)
    {   // 判断用户领取红包上限
        $Alluserredpacket = Db::name('business_record')
            ->alias('br')
            ->field(true)
            ->where('userid', $Userid)
            ->where('create_day', date('Y-m-d'))
            // ->whereTime('create_day', 'today')
            // ->fetchSql(true)
            ->select();

        // 判断个人是否达到每日个数上限（12个）
        if (count($Alluserredpacket) > 12) {
            return '已经达到每天个数上限';
        }

        // 判断个人是否达到每日金额上限（50元）
        $sum = 0;
        foreach ($Alluserredpacket as $value) {
            $sum += round($value['money'], 2);
        }
        unset($value);

        if ($sum > 50.00) {
            return '已经达到每天金额上限';
        }

        return true;
    }

    /**
     * @title  检测用户红包状态
     * @param  array Redidarray 红包id数组
     * @return array data       红包和红包记录数据
     */
    public function getCanLenRed($Redidarray, $Longitude, $Latitude)
    {
        // 获取红包和店铺信息
        $red_WHERE['red_id'] = ['in', $Redidarray];
        $red_WHERE['redpacket.delete_id'] = 0;
        $red_WHERE['business.delete_id']  = 0;

        $business = Db::name('redpacket')
            ->alias('redpacket')
            ->field('
                red_id,businessid,red_name,business.name,red_content,step,number,money,sex,
                age_min,age_max,education,distance,trading_area,s_time,e_time,
                business.longitude,business.latitude
            ')
            ->join('business', 'redpacket.businessid=business.id', 'left')
            ->where($red_WHERE)
            ->select();

        $badsign = 0;
        $Conditions = [];           // 满足条件的红包
        foreach ($business as $key => $value) {
            // 计算商户和客户之间的距离
            $realdistance = intval(calcDistance($Latitude, $Longitude, $value['latitude'], $value['longitude']) * 1000);
            $business[$key]['realdistance'] = $realdistance;
            $business[$key]['is_redpacket'] = 0; // 红包领取状态：0领取成功|1已被领完|2已领过|3条件不符
            $business[$key]['ms_redpacket'] = '可以领取';
            $business[$key]['is_statue']    = 1; // 红包状态：0领取成功|1领取失败

            // 判断时间是否符合
            if (($value['e_time'] > 0) && ($value['e_time'] < time()) && ($value['s_time'] > time())) {
                $business[$key]['is_redpacket'] = 3;
                $business[$key]['ms_redpacket'] = '时间不符合';
                ++$badsign;
                // continue;
            }

            // 判断距离是否符合
            if (($value['distance'] > 0) && ($realdistance > $value['distance'])) {
                $business[$key]['is_redpacket'] = 3;
                $business[$key]['ms_redpacket'] = '距离不符合';
                ++$badsign;
                // continue;
            }

            // 判断性别是否符合
            if (($value['sex'] > 0) && ($this->userData['sex'] != $value['sex'])) {
                $business[$key]['ms_redpacket'] = '性别不符合';
                $business[$key]['is_redpacket'] = 3;
                ++$badsign;
                // continue;
            }

            // 判断年龄是否符合
            if (($value['age_max'] > 0) && (($this->userData['age'] < $value['age_min']) || ($this->userData['age'] > $value['age_max']))) {
                $business[$key]['is_redpacket'] = 3;
                $business[$key]['ms_redpacket'] = '年龄不符合';
                ++$badsign;
                // continue;
            }
            
            // 判断步数是否符合
            if (($value['step'] > 0) && ($this->userData['step'] < $value['step'])) {
                // unset($business[$key]);
                $business[$key]['ms_redpacket'] = '步数不符合';
                $business[$key]['is_redpacket'] = 3;
                ++$badsign;
                // continue;
            }

            // 商家今天所有的红包数据 
            $Allbusredpacket = Db::name('business_record')
                ->alias('br')
                ->field(true)
                ->where('business_id', $value['businessid'])
                ->where('red_id', $value['red_id'])
                ->where('create_day', date('Y-m-d'))
                ->select();

            // 判断今天商家是否有红包余量 
            if ((count($Allbusredpacket) > 0)) {
                $Isreceive = array_column($Allbusredpacket, 'is_receive');
                $Isreceive = array_filter($Isreceive);

                if (count($Isreceive) >= count($Allbusredpacket)) {
                    $business[$key]['ms_redpacket'] = '红包数量不足';
                    $business[$key]['is_redpacket'] = 1;
                    ++$badsign;
                    // continue;
                }
            } else {
                $business[$key]['ms_redpacket'] = '红包数量不足';
                $business[$key]['is_redpacket'] = 1;
                ++$badsign;
                // continue;
            }

            // 判断今天是否领过该商家红包 
            if ((count($Allbusredpacket) > 0)) {
                $Myreceive = array_column($Allbusredpacket, 'userid');
                $Myreceive = array_filter($Myreceive);

                if ((count($Myreceive) > 0) && (in_array($this->userData['userid'], $Myreceive))) {
                    $business[$key]['ms_redpacket'] = '已经领过';
                    $business[$key]['is_redpacket'] = 2;
                    ++$badsign;
                    // continue;
                }
            }

            $Conditions[$key] = $business[$key];

            // 获取一个未领的红包记录
            if ($business[$key]['is_redpacket'] == 0) {
                foreach ($Allbusredpacket as $k => $v) {
                    if (($v['is_receive'] <= 0) && ($v['userid'] <= 0)) {
                        // $Redpacket_record[] = $v;
                        $Conditions[$key]['redpacket'] = $v;
                        break;
                    }
                }
                unset($k, $v);
            }
        }
        unset($key, $value);

        $this->canLenRed = $Conditions;
        $res['resdata']  = $Conditions;

        if ($badsign >= 4) {
            $res['status'] = false;
        } else {
            $res['status'] = true;
        }

        return $res;
    }


    /**
     * @title  整理需要添加或者修改的数据
     * @param  int   Userid     用户id
     * @return array Conditions 领取完后的数据
     */
    public function getArrangeData($Userid, $Longitude, $Latitude) 
    {
        $Conditions = array_merge($this->canLenRed);

        self::getUpInviterNumber();

// dump($this->upInviterNumber);
// die;        

        if (($this->userData['inviter_id'] > 0) && ($this->userData['ivip'] > 0)) {
            $this->iLimit = $this->vipLimit;
        } elseif (($this->userData['inviter_id'] > 0) && ($this->userData['ivip'] == 0)) {
            $this->iLimit = $this->userLimit;
        }

        if ($this->inviterMoney >= $this->iLimit) {
            $sign = 0;   // 提成标志：0提够了|1继续提
        } else {
            $sign = 1;   // 提成标志：0提够了|1继续提
        }

// dump($Conditions);
// dump($this->iLimit);
// dump($this->inviterMoney);

        $ResConditions = [];
        foreach ($Conditions as $key => $value) {
            // 过滤相同的红包
            if (isset($value['redpacket']) && !in_array($value['redpacket']['id'], $this->allRedArray) && ($this->upInviterNumber <= 60000)) {
                $this->allRedArray[] = $value['redpacket']['id'];

                if (($sign == 1) && ($this->inviterMoney < $this->iLimit)) {
                    // 更新红包数据
                    $this->record_UPDATE[$key]['id']         = $value['redpacket']['id'];
                    // $this->record_UPDATE[$key]['money']      = $value['redpacket']['money'];
                    $this->record_UPDATE[$key]['actually']   = round($value['redpacket']['money'] * (1 - $this->redRatio), 2);
                    $this->record_UPDATE[$key]['ratio']      = 1 - $this->redRatio;
                    $this->record_UPDATE[$key]['userid']     = $Userid;
                    $this->record_UPDATE[$key]['is_receive'] = 1;
                    $this->record_UPDATE[$key]['is_time']    = time();
                    $this->record_UPDATE[$key]['longitude']  = $Longitude;
                    $this->record_UPDATE[$key]['latitude']   = $Latitude;

                    // 用户收益
                    $this->income_INSERT[$key]['userid']      = $Userid;
                    $this->income_INSERT[$key]['create_time'] = time();
                    $this->income_INSERT[$key]['amount']      = $this->record_UPDATE[$key]['actually'];
                    $this->income_INSERT[$key]['typeid']      = 3;
                    $this->income_INSERT[$key]['source_id']   = $value['red_id'];

                    // 邀请人收益
                    $this->income_i_INSERT[$key]['userid']      = $this->userData['inviter_id'];
                    $this->income_i_INSERT[$key]['create_time'] = time();
                    $this->income_i_INSERT[$key]['amount']      = round($value['redpacket']['money'] * $this->iRedRatio, 2);
                    $this->income_i_INSERT[$key]['typeid']      = 7;
                    $this->income_i_INSERT[$key]['source_id']   = $value['red_id'];

                    $this->bonus_INSERT[$key]['red_id']      = $value['redpacket']['red_id'];
                    $this->bonus_INSERT[$key]['record_id']   = $value['redpacket']['id'];
                    $this->bonus_INSERT[$key]['bonus']       = $this->income_i_INSERT[$key]['amount'];
                    $this->bonus_INSERT[$key]['ratio']       = $this->iRedRatio;
                    $this->bonus_INSERT[$key]['cbonus']      = round($value['redpacket']['money'] - $this->record_UPDATE[$key]['actually'] - $this->bonus_INSERT[$key]['bonus'], 2);
                    $this->bonus_INSERT[$key]['cratio']      = $this->cRedRatio;
                    $this->bonus_INSERT[$key]['type']        = 1;
                    $this->bonus_INSERT[$key]['userid']      = $this->userData['inviter_id'];
                    $this->bonus_INSERT[$key]['edid']        = $this->userData['userid'];
                    $this->bonus_INSERT[$key]['create_time'] = time();


                    $this->inviterMoney += $this->bonus_INSERT[$key]['bonus'];
                    if ($this->inviterMoney > $this->iLimit) {
                        $more_money = $this->inviterMoney - $this->iLimit;

                        // $this->record_UPDATE[$key]['actually'] += $more_money;
                        // $this->record_UPDATE[$key]['ratio']    = round($this->record_UPDATE[$key]['actually'] / $value['redpacket']['money'], 2);
                        // $this->income_INSERT[$key]['amount']   = $this->record_UPDATE[$key]['actually'];

                        $this->income_i_INSERT[$key]['amount'] -= $more_money;

                        $this->bonus_INSERT[$key]['bonus']     = $this->income_i_INSERT[$key]['amount'];
                        $this->bonus_INSERT[$key]['ratio']     = round($this->bonus_INSERT[$key]['bonus'] / $value['redpacket']['money'], 2);
                        $this->bonus_INSERT[$key]['cbonus']    = round($value['redpacket']['money'] - $this->record_UPDATE[$key]['actually'] - $this->bonus_INSERT[$key]['bonus'], 2);
                        $this->bonus_INSERT[$key]['cratio']    = round($this->bonus_INSERT[$key]['cbonus'] / $value['redpacket']['money'], 2);

                        $this->inviterMoney = $this->iLimit;
                    }
                } else {
                    $this->record_UPDATE[$key]['id']         = $value['redpacket']['id'];
                    // $this->record_UPDATE[$key]['money']      = $value['redpacket']['money'];
                    $this->record_UPDATE[$key]['actually']   = $value['redpacket']['money'];
                    $this->record_UPDATE[$key]['ratio']      = 1;
                    $this->record_UPDATE[$key]['userid']     = $Userid;
                    $this->record_UPDATE[$key]['is_receive'] = 1;
                    $this->record_UPDATE[$key]['is_time']    = time();
                    $this->record_UPDATE[$key]['longitude']  = $Longitude;
                    $this->record_UPDATE[$key]['latitude']   = $Latitude;

                    $this->income_INSERT[$key]['userid']      = $Userid;
                    $this->income_INSERT[$key]['create_time'] = time();
                    $this->income_INSERT[$key]['amount']      = $value['redpacket']['money'];
                    $this->income_INSERT[$key]['typeid']      = 3;
                    $this->income_INSERT[$key]['source_id']   = $value['red_id'];
                }

                // 红包总金额
                $this->allRedMoney += round($this->record_UPDATE[$key]['actually'], 2);

                $ResConditions[$key] = $value;
                $ResConditions[$key]['is_statue'] = 0;
                // $Conditions[$key]['is_statue'] = 0; // 红包状态：0领取成功|1领取失败

                if ($this->income_INSERT[$key]['amount'] >= 50) {
                    break;
                }
            }
        }
        unset($key, $value);

        self::arrangeIncomeInsert();

        return $this->canLenRed = array_merge($ResConditions);
    }

    // 整合提成数据
    private function arrangeIncomeInsert() 
    {
        if (!empty($this->income_INSERT)) {
            $cache = $this->income_INSERT;
            $this->income_INSERT = [];

            $this->income_INSERT['userid']   = $this->userData['userid'];
            $this->income_INSERT['allmoney'] = 0;
            foreach ($cache as $value) {
                $this->income_INSERT['allmoney'] += $value['amount'];
            }

            $this->income_INSERT['alldata'] = array_merge($cache);
            unset($key, $value, $cache);
        } else {
            $this->income_INSERT['allmoney'] = 0;
            $this->income_INSERT['alldata']  = [];
        }

        if (!empty($this->income_i_INSERT)) {
            $cache = $this->income_i_INSERT;
            $this->income_i_INSERT = [];

            $this->income_i_INSERT['userid'] = $this->userData['inviter_id'];;
            $this->income_i_INSERT['allmoney'] = 0;
            foreach ($cache as $value) {
                $this->income_i_INSERT['allmoney'] += $value['amount'];
            }
            
            $this->income_i_INSERT['alldata'] = array_merge($cache);
            unset($key, $value, $cache);
        } else {
            $this->income_i_INSERT['allmoney'] = 0;
            $this->income_i_INSERT['alldata']  = [];
        }

        if (($this->inviterMoney > 0) && ($this->inviterMoney != $this->userData['inviter_money'])) {
            $this->user_UPDATE['inviter_money'] = $this->inviterMoney;
        }
    }

    // 获取上级邀请人数或邀请获得总金额
    private function getUpInviterNumber()
    {
        // $here_WHERE['inviterid'] = $this->userData['userid'];

        // $Invitersum = Db::name('user_inviter')
        //     // ->alias('redpacket')
        //     ->field(true)
        //     ->where($here_WHERE)
        //     ->group('userid')
        //     ->count();

        $here_WHERE['userid'] = $this->userData['userid'];
        $Invitersum = Db::name('inviter_bonus')
            ->where($here_WHERE)
            ->sum('bonus');

        if (!empty($Invitersum)) {
            $this->upInviterNumber = intval($Invitersum);
        }
    }
}
