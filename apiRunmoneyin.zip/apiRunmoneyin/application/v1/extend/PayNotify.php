<?php
namespace app\v1\extend;

use think\Db;
use think\log;
use Payment\Notify\PayNotifyInterface;
use Payment\Config;

/**
 * 客户端需要继承该接口，并实现这个方法，在其中实现对应的业务逻辑
 * Class TestNotify
 * anthor helei
 */
class PayNotify implements PayNotifyInterface
{
    public function notifyProcess(array $data)
    {
        $order_no = $data['order_no'];
        
        // 查询订单信息
        $order = Db::name('order')
            ->field('userid,status,order_type')
            ->where('order_no', $order_no)
            ->find();

        if ($order['status'] == 1) {
            return true;
        }
        
        Db::startTrans();

        try {
            //更新订单状态
            Db::name('order')
                ->where('order_no', $order_no)
                ->update(['transaction_no' => $data['transaction_id'], 'status' => 1]);

            // 更新圈子总金额
            if ($order['order_type'] == 0) {
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $order_no)
                    ->find();

                Db::name('circle')
                    ->where('id', $order_recharge_record['circleid'])
                    ->setInc('total_amount', $data['amount']);

            } else if ($order['order_type'] == 1) {    // 更新用户金额
                Db::name('user')
                    ->where('id', $order['userid'])
                    ->setInc('balance', $data['amount']);

            } else if ($order['order_type'] == 2) {    // 更新任务状态
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $order_no)
                    ->find();

                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新任务表
                Db::name('task')
                    ->where('task_no', $order_recharge_record['taskno'])
                    ->update($task_ok_UPDATE);

                // 更新任务详细记录表
                Db::name('task_record')
                    ->where('task_no', $order_recharge_record['taskno'])
                    ->update($task_ok_UPDATE);
            } else if ($order['order_type'] == 3) {    // 更新vip状态
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $order_no)
                    ->find();

                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新任务表
                Db::name('user_vip')
                    ->where('vip_no', $order_recharge_record['vip_no'])
                    ->update($task_ok_UPDATE);

                // 更新任务详细记录表
                Db::name('user_vip_record')
                    ->where('vip_no', $order_recharge_record['vip_no'])
                    ->update($task_ok_UPDATE);

                // 改用户表
                $Vipuserid = Db::name('user_vip_record')->field(true)->where('vip_no', $order_recharge_record['vip_no'])->select();

                $user_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                Db::name('user')->where($user_WHERE)->update(['vip' => 1]);

                // 生成系统消息给用户
                $SelfCheck = Db::name('user_vip')->field(true)->where('vip_no', $order_recharge_record['vip_no'])->find();

                if ($SelfCheck['type'] == 0) {   // 给别人充
                    $admin_WHERE['id'] = $SelfCheck['addid'];
                    $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

                    // $needToUserids  = [];
                    $message_INSERT = [];
                    foreach ($Vipuserid as $key => $value) {
                        $message_INSERT[$key]['create_time'] = time();
                        $message_INSERT[$key]['to_userid']   = $value['userid'];
                        $message_INSERT[$key]['typeid']      = 4;
                        $message_INSERT[$key]['title']       = '恭喜你成为跑步钱进APP会员';
                        $message_INSERT[$key]['content']     = '你的好友' . $admindata['nickname'] . '为你充值了会员，恭喜你成为跑步钱进APP会员';
                    }

                    $need_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                    $needtoname = Db::name('user')->field('id,nickname')->where($need_WHERE)->select();

                    $needtonamearray = array_column($needtoname, 'nickname');
                    $needtonames = implode(',', $needtonamearray);

                    $message_INSERT[$key + 1]['create_time'] = time();
                    $message_INSERT[$key + 1]['to_userid']   = $admindata['id'];
                    $message_INSERT[$key + 1]['typeid']      = 4;
                    $message_INSERT[$key + 1]['title']       = '你成功为你的好友充值会员';
                    $message_INSERT[$key + 1]['content']     = '你已成功为你的好友' . $needtonames . '充值会员';

                    Db::name('user_messages')->insertAll($message_INSERT);

                } else {                         // 给自己充
                    $admin_WHERE['id'] = $SelfCheck['addid'];
                    $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

                    $message_INSERT['create_time'] = time();
                    $message_INSERT['to_userid']   = $admindata['id'];
                    $message_INSERT['typeid']      = 4;
                    $message_INSERT['title']       = '恭喜你成功充值跑步钱进APP会员';
                    $message_INSERT['content']     = '恭喜你成功充值跑步钱进APP会员';

                    Db::name('user_messages')->insert($message_INSERT);
                }
                
            } else if ($order['order_type'] == 6) {    // 更新cvip状态
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $order_no)
                    ->find();

                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新任务表
                Db::name('user_vipcus')
                    ->where('cvip_no', $order_recharge_record['cvip_no'])
                    ->update($task_ok_UPDATE);

                // 更新任务详细记录表
                Db::name('user_vipcus_record')
                    ->where('cvip_no', $order_recharge_record['cvip_no'])
                    ->update($task_ok_UPDATE);

                // 改用户表
                $Vipuserid = Db::name('user_vipcus_record')->field(true)->where('cvip_no', $order_recharge_record['cvip_no'])->select();

                $user_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                Db::name('user')->where($user_WHERE)->update(['cvip_no' => 1]);

                // 生成系统消息给用户
                $SelfCheck = Db::name('user_vipcus')->field(true)->where('cvip_no', $order_recharge_record['cvip_no'])->find();

                if ($SelfCheck['type'] == 0) {   // 给别人充
                    $admin_WHERE['id'] = $SelfCheck['addid'];
                    $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

                    // $needToUserids  = [];
                    $message_INSERT = [];
                    foreach ($Vipuserid as $key => $value) {
                        $message_INSERT[$key]['create_time'] = time();
                        $message_INSERT[$key]['to_userid']   = $value['userid'];
                        $message_INSERT[$key]['typeid']      = 4;
                        $message_INSERT[$key]['title']       = '恭喜你成为跑步钱进APP商户会员';
                        $message_INSERT[$key]['content']     = '你的好友' . $admindata['nickname'] . '为你充值了商户会员，恭喜你成为跑步钱进APP商户会员';
                    }

                    $need_WHERE['id'] = ['in', array_column($Vipuserid, 'userid')];
                    $needtoname = Db::name('user')->field('id,nickname')->where($need_WHERE)->select();

                    $needtonamearray = array_column($needtoname, 'nickname');
                    $needtonames = implode(',', $needtonamearray);

                    $message_INSERT[$key + 1]['create_time'] = time();
                    $message_INSERT[$key + 1]['to_userid']   = $admindata['id'];
                    $message_INSERT[$key + 1]['typeid']      = 4;
                    $message_INSERT[$key + 1]['title']       = '你成功为你的好友充值商户会员';
                    $message_INSERT[$key + 1]['content']     = '你已成功为你的好友' . $needtonames . '充值商户会员';

                    Db::name('user_messages')->insertAll($message_INSERT);

                } else {                         // 给自己充
                    $admin_WHERE['id'] = $SelfCheck['addid'];
                    $admindata = Db::name('user')->field('id,nickname')->where($admin_WHERE)->find();

                    $message_INSERT['create_time'] = time();
                    $message_INSERT['to_userid']   = $admindata['id'];
                    $message_INSERT['typeid']      = 4;
                    $message_INSERT['title']       = '恭喜你成功充值跑步钱进APP商户会员';
                    $message_INSERT['content']     = '恭喜你成功充值跑步钱进APP商户会员';

                    Db::name('user_messages')->insert($message_INSERT);
                }
                
            } else if ($order['order_type'] == 4) {    // 更新红包状态
                $order_recharge_record = Db::name('order_recharge_record')
                    ->where('order_no', $order_no)
                    ->find();

                $task_ok_UPDATE['ok']      = 1;
                $task_ok_UPDATE['ok_time'] = time();

                // 更新任务表
                Db::name('redpacket')
                    ->where('red_id', $order_recharge_record['red_id'])
                    ->update($task_ok_UPDATE);

                // 更新任务表
                Db::name('business_record')
                    ->where('red_id', $order_recharge_record['red_id'])
                    ->update($task_ok_UPDATE);
            }

            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            Log::write('错误信息:'.$e->getMessage(),'debug');
            return false;
        }

        return true;
    }
}
