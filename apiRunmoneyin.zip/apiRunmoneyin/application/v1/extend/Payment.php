<?php
namespace app\v1\extend;

use think\Request;
use DawnApi\facade\ApiController;
use Payment\Client\Charge;

class Payment extends ApiController
{
	/**
	 * 创建订单
	 * @author chenjie 2018-02-01
	 * @param  string $channel 支付通道
	 * @param  array  $data    生成订单参数
	 * @return array $result   调起支付参数
	 */
	public function createOrder($channel = 'wx', $data = array())
	{
        $payData = [
            'body'            => $data['body'],
            'subject'         => $data['subject'],
            'order_no'        => $data['order_no'],
            'amount'          => $data['amount'],
            'timeout_express' => time() + 600
        ];

		if ($channel == 'wx') {
	        $config  = config('pay.wx');
	        $channel = 'wx_app';
	        $payData['client_ip'] = Request::instance()->ip();
		} else if($channel == 'ali') {
		    $config  = config('pay.alipay');
		    $channel = 'ali_app';
		} else if($channel == 'wxxcx') {
			$config  = config('pay.wxxcx');
			$payData['openid'] = $data['openid'];

		    $channel = 'wx_lite';
		}
// dump($data);
// dump($config);
// exit();
        try {
            $retData = Charge::run($channel, $config, $payData);
            return $retData;
        } catch (PayException $e) {
        	return $this->sendError(-1, $e->errorMessage(), 400);
        }
	}
}