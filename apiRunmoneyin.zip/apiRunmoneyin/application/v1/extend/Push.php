<?php
/**
 * name:消息推送token存储刷新,及账号异常登录推送提示
 * Created by PhpStorm.
 * User: lixinhe
 * Date: 2018/6/8
 * Time: 下午3:13
 */

namespace app\v1\extend;

use think\Cache;
use think\Db;

class Push
{
    private static $oldToken = null;
    private static $token = null;
    private static $timeOut = 0;
    private static $userId = null;
    private static $isCheckLogin = false;

    private static function _instance()
    {
        self::$token = request()->header('push_token') ? request()->header('push_token') : null;

    }

    public static function login($userId, $isCheckLogin = false, $timeOut = 0)
    {
        self::_instance();
        self::$userId = $userId;
        self::$timeOut = $timeOut;
        if ($isCheckLogin)
        {
            self::$isCheckLogin = $isCheckLogin;
            !Cache::has('push_token_' . self::$userId) && self::resetCache();
            if (Cache::has('push_token_' . self::$userId))
                self::$token == Cache::get('push_token_' . self::$userId) ? self::save() : self::pushMessage();
        } else
        {
            self::save();
        }
    }

    private static function save()
    {
        Db::startTrans();
        $sava = Db::name('user')->where(array('id' => self::$userId))->update(array('push_token' => self::$token));
        if ($sava)
        {
            Db::commit();
            Cache::set('push_token_' . self::$userId, self::$token, self::$timeOut);
        } else
        {
            Db::rollback();
        }
    }

    private static function resetCache()
    {
        $cache = db('user')->where(array('id' => self::$userId))->value('push_token');
        $cache && Cache::set('push_token_' . self::$userId, $cache, self::$timeOut);
    }


    private static function pushMessage()
    {
        self::$isCheckLogin && self::save();
        //todo....
    }

}