<?php
namespace app\v1\extend;

class RsaEncrypt {
	
    /*
     * RSA 加密begin
     */
    public static function rsaSign($array_data,$privatekey) {
        $data = self::buildQuery($array_data);

        $priKey = file_get_contents($privatekey);

        $res = openssl_get_privatekey($priKey);
        openssl_sign($data, $sign, $res, OPENSSL_ALGO_MD5);
        openssl_free_key($res);
        $sign = base64_encode($sign);
        return $sign;
    }

    // public static function rsaEncrypt($array_data,$privatekey) {
    //     $data = self::buildQuery($array_data);
    //     // 读取公钥文件
    //     $pubKey = file_get_contents(LIBDIR . "/PayLib/helipay/cert/publickey.pem");
    //     // 转换为openssl格式密钥
    //     $res = openssl_get_publickey($pubKey);
    //     $maxlength = self::getMaxEncryptBlockSize($res);
    //     $output = '';
    //     while ( strlen($data) ) {
    //         $input = substr($data, 0, $maxlength);
    //         $data = substr($data, $maxlength);
    //         openssl_public_encrypt($input, $encrypted, $pubKey);
    //         $output .= $encrypted;
    //     }
    //     $encryptedData = base64_encode($output);
    //     return $encryptedData;
    // }

    // public static function rsaDecrypt($data,$privatekey) {
    //     // 读取私钥文件
    //     $priKey = file_get_contents(LIBDIR . "/PayLib/helipay/cert/privatekey.pem");
    //     // 转换为openssl格式密钥
    //     $res = openssl_get_privatekey($priKey);
    //     $data = base64_decode($data);
    //     $maxlength = self::getMaxDecryptBlockSize($res);
    //     $output = '';
    //     while ( strlen($data) ) {
    //         $input = substr($data, 0, $maxlength);
    //         $data = substr($data, $maxlength);
    //         openssl_private_decrypt($input, $out, $res);
    //         $output .= $out;
    //     }
    //     return $output;
    // }

    public static function getMaxEncryptBlockSize($keyRes) {
        $keyDetail = openssl_pkey_get_details($keyRes);
        $modulusSize = $keyDetail['bits'];
        return $modulusSize / 8 - 11;
    }

    public static function getMaxDecryptBlockSize($keyRes) {
        $keyDetail = openssl_pkey_get_details($keyRes);
        $modulusSize = $keyDetail['bits'];
        return $modulusSize / 8;
    }

    /*
     * RSA 加密end
     */
    

    public static function md5sign(array $data, $sign_key) {
        $str = self::buildQuery($data);
        $str .= "&$sign_key";           // signKey
        return strtoupper(md5($str));
    }

    public static function des3Encrypt($str){
	return openssl_encrypt($str, 'des-ede3', self::DES_KEY); // 3des
    }

    public static function checkEmpty($value) {
        if (! isset($value))
            return true;
        if ($value === null)
            return true;
        
        return false;
    }

    public static function buildQuery($params, $needEncode = FALSE) {
        // ksort($params);
        $stringToBeSigned = "";
        foreach ($params as $k=>$v) {
            if (false === self::checkEmpty($v)) {
                if ($needEncode) {
                    $v = urlencode($v);
                }
                $stringToBeSigned .= "&$v";
            }
        }
        unset($k, $v);
        return $stringToBeSigned;
    }
}

