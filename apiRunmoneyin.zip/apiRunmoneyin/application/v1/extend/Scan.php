<?php
/**
 * Created by PhpStorm.
 * User: lixinhe
 * Date: 2018/6/9
 * Time: 下午5:07
 */

namespace app\v1\extend;

use think\Config;
use think\Request;
use think\Db;

class Scan
{
    private static $isScan = true;
    private static $scanLog = false;
    private static $scanAction = array();
    private static $result = array();
    private static $namespace = null;
    private static $class = null;
    private static $controller = null;
    private static $action = null;
    private static $userId = 0;

    private static function _instance($namespace)
    {
        self::$isScan = Config::get("scan_content.text");
        self::$namespace = $namespace;
        self::$controller = Request::instance()->controller();
        self::$action = Request::instance()->action();
        self::$class = "\\" . self::$namespace . "\\" . self::$controller;

    }

    public static function scanRequestContent($namespace)
    {
        self::_instance($namespace);
        if (self::$isScan)
        {
            if (!is_array(self::getIgnoreFields()))
            {
                self::sendMessage(-1, "配置缺失", 200);
            }

            $data = input(strtolower(request()->method() . "."));
            if (isset(self::getIgnoreFields()[self::$action]) && !empty(self::getIgnoreFields()[self::$action])){
                foreach (self::getIgnoreFields()[self::$action] as $item)
                {
                    if (isset($data[$item]))
                    {
                        unset($data[$item]);
                    }
                }
            }
            if (!empty($data))
            {
                $text = array();
                foreach ($data as $key => $value)
                {

                    $value != "" && array_push($text, array('content' => $value, 'fields' => $key, 'userId' => self::$userId));
                }

                !empty($text) && self::$result = \aliyuncs\Green\Check::textScan($text);
            }
            self::toResults();
        }
    }


    /**
     * @name 获取忽略字段
     * @return mixed|array
     */
    public static function getIgnoreFields()
    {
        return method_exists(self::$class, "getIgnoreFields") ? (self::$class)::getIgnoreFields() : false;
    }

    /**
     * @name 设置用户ID
     * @param $userId 用户id
     */
    public static function setUserId($userId)
    {
        self::$userId = $userId;
    }

    public static function setScanAction(array $action = array())
    {
        foreach ($action as $value)
        {
            switch (strtolower($value))
            {
                case 'post':
                    array_push(self::$scanAction, self::isPost());
                    break;
                case 'get':
                    array_push(self::$scanAction, self::isGet());
                    break;
                case 'put':
                    array_push(self::$scanAction, self::isPut());
                    break;
                case 'delete':
                    array_push(self::$scanAction, self::isDelete());
                    break;
                case 'head':
                    array_push(self::$scanAction, self::isHead());
                    break;
                case 'opetion':
                    array_push(self::$scanAction, self::isOptions());
                    break;
                case 'patch':
                    array_push(self::$scanAction, self::isPatch());
                    break;
                default:
                    break;

            }
        }

        empty(self::$scanAction) && self::$isScan = false;
        self::$isScan = in_array(true, self::$scanAction) ? true : false;
    }

    public static function setScanLog($scanLog)
    {
        self::$scanLog = $scanLog;
    }

    /**
     * @name 记录鉴别结果
     */
    private static function sacnLog()
    {
        Db::startTrans();
        $log = Db::name('scan_log')->insertGetId(array('user_id' => self::$userId, 'content' => json_encode(self::$result), 'create_time' => date('Y-m-d H:i:s')));
        if ($log)
        {
            Db::commit();
        } else
        {
            Db::rollback();
        }
    }

    /**
     * @name 处理结果
     */
    private static function toResults()
    {
        self::$scanLog && self::sacnLog();
        foreach (self::$result as $value)
        {
            !$value['auto_scan'] && self::sendMessage(-1, $value['fields'] . '字段内容不符合相关规范', 200);
        }
    }

    /**
     * @name 返回警告信息
     * @param $error
     * @param $message
     * @param $code
     * @param array $data
     */
    private static function sendMessage($error, $message, $code, array $data = array())
    {
        $error = array("error" => $error, "message" => $message, "code" => $code, "data" => $data);
        exit(json_encode($error, JSON_UNESCAPED_UNICODE));
    }

    /**
     * 是否为GET请求
     * @access private
     * @return bool
     */
    private static function isGet()
    {
        return Request::instance()->isGet();
    }

    /**
     * 是否为POST请求
     * @access private
     * @return bool
     */
    private static function isPost()
    {
        return Request::instance()->isPost();
    }

    /**
     * 是否为PUT请求
     * @access private
     * @return bool
     */
    private static function isPut()
    {
        return Request::instance()->isPut();
    }

    /**
     * 是否为DELTE请求
     * @access private
     * @return bool
     */
    private static function isDelete()
    {
        return Request::instance()->isDelete();
    }

    /**
     * 是否为HEAD请求
     * @access private
     * @return bool
     */
    private static function isHead()
    {
        return Request::instance()->isHead();
    }

    /**
     * 是否为PATCH请求
     * @access private
     * @return bool
     */
    private static function isPatch()
    {
        return Request::instance()->isPatch();
    }

    /**
     * 是否为OPTIONS请求
     * @access private
     * @return bool
     */
    private static function isOptions()
    {
        return Request::instance()->isOptions();
    }


}