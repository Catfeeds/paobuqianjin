<?php
// old，modify by wensen on 20180403
// return [
// 	'accessKeyId'     => 'LTAIpSQX9t1xK9ji',
// 	'accessKeySecret' => 'oakQeBuJLUJV8znUY9Uw631HTMGLmf',
// 	'signName'        => '跑步钱进',
// 	'templateCode'    => 'SMS_123739546',
// 	'templatePara'    => 'code',
// ];

return [
	'sms1' => [
		'accessKeyId'     => 'LTAIpSQX9t1xK9ji',
		'accessKeySecret' => 'oakQeBuJLUJV8znUY9Uw631HTMGLmf',
		'signName'        => '跑步钱进',
		'templateCode'    => 'SMS_129748623',
		'templatePara'    => 'code',
	],
	'sms2' => [
		'accessKeyId'     => 'LTAIpSQX9t1xK9ji',
		'accessKeySecret' => 'oakQeBuJLUJV8znUY9Uw631HTMGLmf',
		'signName'        => '跑步钱进1',
		'templateCode'    => 'SMS_129748623',
		'templatePara'    => 'code',
	],
];
