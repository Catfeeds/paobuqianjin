<?php

return [
    'wx' => [
        'app_id'            => 'wx1ed4ccc9a2226a73',
        'mch_id'            => '1495263342',
        'md5_key'           => '3FN8WHOH9e2PXmJRZiPnNoJ576AxMmwQ',
        'app_cert_pem'      => APP_PATH.'v1/wechat_cert/apiclient_cert.pem',
        'app_key_pem'       => APP_PATH.'v1/wechat_cert/apiclient_key.pem',
        'sign_type'         => 'MD5',// MD5  HMAC-SHA256
        'limit_pay'         => [
        ],
        'fee_type'          => 'CNY',// 货币类型  当前仅支持该字段
        'notify_url'        => config('serverurlprefix') . 'v1/Pay/WxNotify',
        // 'notify_url'        => 'https://api.runmoneyin.com/v1/Pay/WxNotify',
        'redirect_url'      => '',
        'return_raw'        => false,
    ],
    'alipay' =>[
        'use_sandbox'       => false,
        'partner'           => '2088921462461308',
        'app_id'            => '2018012502070042',
        'sign_type'         => 'RSA2',
        'ali_public_key'    => APP_PATH.'v1/alipay_cert/ali_public_key.pem',
        'rsa_private_key'   => APP_PATH.'v1/alipay_cert/rsa_private_key.pem',
        'limit_pay'         => [
        ],
        'notify_url'        => config('serverurlprefix') . 'v1/Pay/AliNotify',
        // 'notify_url'        => 'https://api.runmoneyin.com/v1/Pay/AliNotify',
        'return_url'        => '',
        'return_raw'        => false,
    ],
    'wxxcx' =>[
        'app_id'            => 'wx4c0e1852239664b4',
        'mch_id'            => '1495263342',
        'md5_key'           => '3FN8WHOH9e2PXmJRZiPnNoJ576AxMmwQ',
        'app_cert_pem'      => APP_PATH.'v1/wechat_cert/apiclient_cert.pem',
        'app_key_pem'       => APP_PATH.'v1/wechat_cert/apiclient_key.pem',
        'sign_type'         => 'MD5',// MD5  HMAC-SHA256
        'limit_pay'         => [
        ],
        'fee_type'          => 'CNY',// 货币类型  当前仅支持该字段
        'notify_url'        => config('serverurlprefix') . 'v1/Pay/notifyUrlApi',
        // 'notify_url'        => 'https://api.runmoneyin.com/v1/Pay/notifyUrlApi',
        'redirect_url'      => '',
        'return_raw'        => false,
    ],

    'helibao' =>[
        'rsa_private_key'   => APP_PATH.'v1/wechat_cert/hlb_rsa_private_key.pem',
    ],

    'sevenpay' =>[      // 七分钱支付
        'qifenqian_private_key'   => APP_PATH.'v1/wechat_cert/qifenqian_private_key.pem',
        'qifenqian_public_key'   => APP_PATH.'v1/wechat_cert/qifenqian_public_key.pem',
    ],

     // 服务器
    'serverurlprefix' => 'https://api.runmoneyin.com/',

];
