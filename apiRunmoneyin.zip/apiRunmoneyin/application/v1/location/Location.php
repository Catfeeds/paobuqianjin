<?php
// +----------------------------------------------------------------------
// | When work is a pleasure, life is a joy!
// +----------------------------------------------------------------------
// | User: wensen  |  Email:wensenwen@foxmail.com | Time:2018-05-22 18:00
// +----------------------------------------------------------------------
// | TITLE: 定位用户辅助
// +----------------------------------------------------------------------

namespace app\v1\location;

use think\Db;

class Location
{
    /**
     * 根据经纬度和半径计算出范围    半径范围单位是米
     * @param string $lat 纬度
     * @param String $lng 经度
     * @param float $radius 半径  单位是米
     * @return Array 范围数组
     */
    private function calcScope($lat, $lng, $radius)
    {
        $degree = (24901*1609)/360.0;
        $dpmLat = 1/$degree;

        $radiusLat = $dpmLat*$radius;
        $minLat = $lat - $radiusLat;       // 最小纬度
        $maxLat = $lat + $radiusLat;       // 最大纬度

        $mpdLng = $degree*cos($lat * (3.14/180));
        $dpmLng = 1 / $mpdLng;
        $radiusLng = $dpmLng*$radius;
        $minLng = $lng - $radiusLng;      // 最小经度
        $maxLng = $lng + $radiusLng;      // 最大经度

        /** 返回范围数组 */
        $scope = array(
            'minLat'    =>  $minLat,
            'maxLat'    =>  $maxLat,
            'minLng'    =>  $minLng,
            'maxLng'    =>  $maxLng
            );
        return $scope;
    }

     /**
     * 获取两个经纬度之间的距离（单位：千米）
     * @param  string $lat1 纬一
     * @param  String $lng1 经一
     * @param  String $lat2 纬二
     * @param  String $lng2 经二
     * @return float  返回两点之间的距离
     */
    public function calcDistance($lat1, $lng1, $lat2, $lng2)
    {
        /** 转换数据类型为 double */
        $lat1 = doubleval($lat1);
        $lng1 = doubleval($lng1);
        $lat2 = doubleval($lat2);
        $lng2 = doubleval($lng2);
        /** 以下算法是 Google 出来的，与大多数经纬度计算工具结果一致 */
        $theta = $lng1 - $lng2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;

        return ($miles * 1.609344);
    }


    /**
     * 根据经纬度和半径查询在此范围内的所有的用户
     * @param  String $lat    纬度
     * @param  String $lng    经度
     * @param  float $radius  半径
     * @return Array          当前中心点的位置范围内的用户
     */
    public function searchByLatAndLng($lat, $lng, $radius)
    {
        $scope = $this->calcScope($lat, $lng, $radius);     // 调用范围计算函数，获取最大最小经纬度
        /** 查询经纬度在 $radius 范围内用户 */
        $maxLat = $scope['maxLat'];
        $minLat = $scope['minLat'];
        $maxLng = $scope['maxLng'];
        $minLng = $scope['minLng'];

        // $user = db('user_record')->field('userid,longitude,latitude,max(logintime) logintime')->page(1,2)->group('userid')->select();
        // return $user;
        //先把用户按登录时间
        $res = db('user_record')
            ->alias('user_record')
            ->where('latitude', 'between', [$minLat, $maxLat])
            ->where('longitude', 'between', [$minLng, $maxLng])
            ->join('user', 'user.id=user_record.userid')
            ->field('user_record.userid,user.avatar,user.nickname,user.sex,user_record.longitude,user_record.latitude,max(user.create_time) as login_time,user.vip')
            ->group('user_record.userid')
            ->limit(50)
            ->select();

        return $res;
    }

    /**
     * 根据经纬度和半径查询在此范围内的实时位置
     * @param  String $lat    纬度
     * @param  String $lng    经度
     * @param  float $radius  半径
     * @return Array          当前中心点的位置范围内的用户
     */
    public function searchNearbyStepSort($lat, $lng, $page, $pageSize)
    {
        $Today = date('Y-m-d');

        // $user = db('user_record')->field('userid,longitude,latitude,max(logintime) logintime')->page(1,2)->group('userid')->select();

        // 附近排序原理：先筛选附近1公里，按最近排序前50个的人，若不足够50个，则继续加1公里筛选，一直往后筛选。
        $max_radius  = 20 * 1000;     // 最大的半径限制（20千米）
        $base_radius = 1000;          // 基准半径（1千米）
        // $user        = [];            // 附近的人
        $userSum     = 0;             // 附近的人数
        while ($max_radius >= $base_radius) {
            $userSum = 0;

            $scope = $this->calcScope($lat, $lng, $base_radius);     // 调用范围计算函数，获取最大最小经纬度

            /** 查询经纬度在 $radius 范围内用户 */
            $maxLat = round($scope['maxLat'], 5);
            $minLat = round($scope['minLat'], 5);
            $maxLng = round($scope['maxLng'], 5);
            $minLng = round($scope['minLng'], 5);

            // 获取用户数据
            $userSum = db('user')
                ->alias('user')
                ->field('
                    id as userid,avatar,nickname,sex,
                    n_lat as latitude,n_long as longitude,vip
                ')
                ->where('n_lat', 'between', [$minLat, $maxLat])
                ->where('n_long', 'between', [$minLng, $maxLng])
                ->count('id');

            if ($userSum >= 50) {
                break;
            } else {
                $base_radius += 1000;
            }
        }

        $retData = [];    // 附近的用户数据

        // 如果人数大于0则获取数据
        if ($userSum > 0) {
            // 获取用户数据
            $user = Db::name('user')
                ->alias('user')
                ->field('
                    id as userid,avatar,nickname,sex,
                    n_lat as latitude,n_long as longitude,vip
                ')
                ->where('n_lat', 'between', [$minLat, $maxLat])
                ->where('n_long', 'between', [$minLng, $maxLng])
                ->limit(50)
                ->select();

            $Userida = array_column($user, 'userid');
            // array_push($Userida, $userid);
            $Userida = array_filter($Userida);
            sort($Userida);
            $Userids = implode(',', $Userida);

            $subQuery = Db::table('rm_user_step')
                ->alias('user_step')
                ->field('id,userid,step_number')
                ->where('create_day', $Today)
                ->where('userid', 'in', $Userids)
                ->buildSql();

            $Userdata = Db::name('user')
                ->alias('user')
                ->field('
                    user.id as userid,
                    user.nickname,
                    user.avatar,
                    user.sex,
                    user.vip,
                    user.cusvip,
                    user.n_lat as latitude,
                    user.n_long as longitude,
                    IFNULL(user_step.step_number, 0) as step_number
                ')
                ->join($subQuery . ' as user_step', 'user.id=user_step.userid', 'left')
                ->where('user.id', 'in', $Userids)
                ->order('step_number desc, user.id asc')
                ->page($page, $pageSize)
                ->select();
            
            $retData = returnData($page, $pageSize, count($user), $Userdata);
        }

        return $retData;
    }

}
