<?php
/**
 * name 阿里云安全检测
 * Created by PhpStorm.
 * User: lixinhe
 * Date: 2018/5/22
 * Time: 上午9:40
 */

namespace aliyuncs\Green;

use aliyuncs\Green\Request\V20170825 as Green;

class Check
{
    private static $client = null;
    private static $request = null;
    private static $results = false;
    private static $scenes = null;
    private static $content = [];
    private static $isBreak = false;//true 跳过鉴权  false 继续执行
    private static $isArray = true;

    private static function instance()
    {
        include_once __DIR__ . '/../aliyun-php-sdk-core/Config.php';
        $ak = parse_ini_file(__DIR__ . '/../aliyun.ak.ini');
        self::$scenes = parse_ini_file(__DIR__ . '/../aliyun.scenes.ini', true);
        date_default_timezone_set('PRC');
        $iClientProfile = \DefaultProfile::getProfile("cn-beijing", $ak["accessKeyId"], $ak["accessKeySecret"]); // TODO
        \DefaultProfile::addEndpoint("cn-beijing", "cn-beijing", "Green", "green.cn-beijing.aliyuncs.com");
        return (new \DefaultAcsClient($iClientProfile));
    }

    /**
     * @name 文本敏感词鉴别
     * @return object
     */
    public static function textScan($text, array $scenes = array())
    {
        self::$client = self::instance();
        self::$request = new Green\TextScanRequest();
        self::$request->setMethod("POST");
        self::$request->setAcceptFormat("JSON");
        empty($scenes) && $scenes = self::$scenes['TEXT'];
        if (is_array($text))
        {
            self::$isArray = true;
            foreach ($text as &$v)
            {
                if (!isset($v['content']) || isset($v['dataId']) || isset($v['time']))
                {
                    self::$isBreak = true;
                    break;
                }
                $v['dataId'] = uniqid();
                $v['time'] = round(microtime(true) * 1000);
            }
        } else
        {
            self::$isArray = false;
            $text = array('content' => $text, 'dataId' => uniqid(), 'time' => round(microtime(true) * 1000));
        }

        self::$content = $text;
        $content = json_encode(array("scenes" => $scenes, "bizType" =>self::$scenes['BIZTYPE'], "tasks" => self::$content));
        self::$request->setContent($content);
        return self::toArray();
    }

    /**
     * @name 图片鉴定
     * @param array|string $images 图片地址|索引数组 http(s)://....|array(0=>array('url'=>"http(s)://...."))
     * @param array $scenes 鉴定规则
     * @return array array('url'=>'http(s)://','auto_scan'=>0|1)|array(0=>array('url'=>"http(s)://....",'auto_scan'=>0|1))
     */
    public static function imageSyncScan($images, array $scenes = array())
    {
        self::$client = self::instance();
        self::$request = new Green\ImageSyncScanRequest();
        self::$request->setMethod("POST");
        self::$request->setAcceptFormat("JSON");
        empty($scenes) && $scenes = self::$scenes['IMAGE'];
        if (is_array($images))
        {
            self::$isArray = true;
            foreach ($images as &$v)
            {
                if (!isset($v['url']) || isset($v['dataId']) || isset($v['time']))
                {
                    self::$isBreak = true;
                    break;
                }
                $v['dataId'] = uniqid();
                $v['time'] = round(microtime(true) * 1000);
            }
        } else
        {
            self::$isArray = false;
            $images = array('url' => $images, 'dataId' => uniqid(), 'time' => round(microtime(true) * 1000));
        }
        self::$content = $images;
        !self::$isBreak && self::$request->setContent(json_encode(array("tasks" => $images, "scenes" => $scenes)));
        return self::toArray();
    }

    private static function toArray()
    {

        !self::$isBreak && self::scanResponse();
        if (!self::$isBreak)
        {
            if (self::$isArray)
            {
                foreach (self::$content as $k => $v)
                {
                    foreach (self::$results as $vv)
                    {
                        if ($v['dataId'] == $vv['dataId'])
                        {
                            self::$content[$k]['auto_scan'] = ($vv['code'] == 200 && $vv['suggestion'] == "pass") ? 1 : 0;
                            unset(self::$content[$k]['dataId']);
                            unset(self::$content[$k]['time']);
                        }
                    }
                }
            } else
            {
                self::$content['auto_scan'] = (self::$results[0]['code'] && self::$results[0]['suggestion'] == "pass") ? 1 : 0;
                unset(self::$content['dataId']);
                unset(self::$content['time']);
            }


        } else
        {
            if (self::$isArray)
            {
                foreach (self::$content as $k => $v)
                {
                    self::$content[$k]['auto_scan'] = 0;
                    unset(self::$content[$k]['dataId']);
                    unset(self::$content[$k]['time']);
                }
            } else
            {
                self::$content['auto_scan'] = 0;
                unset(self::$content['dataId']);
                unset(self::$content['time']);
            }
        }
        return self::$content;
    }


    private static function scanResponse()
    {
        try
        {
            $response = self::$client->getAcsResponse(self::$request);
            if ($response->code == 200)
            {
                $taskResults = $response->data;
                foreach ($taskResults as $key => $taskResult)
                {
                    self::$results[$key]['code'] = $taskResult->code;
                    self::$results[$key]['dataId'] = $taskResult->dataId;
                    self::$results[$key]['suggestion'] = 'pass';
                    if (200 == $taskResult->code)
                    {
                        $sceneResults = $taskResult->results;
                        foreach ($sceneResults as $sceneResult)
                        {
                            if ($sceneResult->suggestion != 'pass')
                            {
                                self::$results[$key]['suggestion'] = $sceneResult->suggestion;
                            }
                        }
                    }
                }
                self::$isBreak = false;
            } else
            {
                self::$isBreak = true;
            }
        } catch (\Exception $e)
        {
            self::$isBreak = true;
        }
    }

}