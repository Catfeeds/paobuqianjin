<?php
/**
 * Created by PhpStorm.
 * User: lixinhe
 * Date: 2018/5/21
 * Time: 上午9:17
 */

namespace checkimages;

use checkimages\QcloudImage\CIClient;
use think\Config;

class CheckImages
{
    protected static $client;

    /**
     * @param array $array 索引数组图片地址 array('url1',url2,...)
     * @param string $type urls/files字段,判断图片资源类型
     * @param int $timeOut 过期时间
     * @return bool
     */
    public static function checkImages(array $array, $type = 'urls', $timeOut = 30)
    {
        $config = Config::get('qcloud');
        self::$client = new CIClient($config['appid'], $config['secretId'], $config['secretKey'], $config['bucket']);
        if ($type != 'urls' && $type != 'files')
        {
            return FALSE;
        }
        $so = array($type => $array);
        self::$client->setTimeout($timeOut);
        $re = self::$client->pornDetect($so);
        return $re;
    }
}