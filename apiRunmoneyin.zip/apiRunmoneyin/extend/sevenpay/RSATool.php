<?php
/**
 * Created by sublime.
 * User: fuchao
 * Date: 2018/6/14
 * Time: 下午6:21
 */
namespace sevenpay;

use think\Config;


final class RSATool
{
    // //商户私钥
    // private static $privateKeyStr = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALys+oYaxqv4FYju".
    // "8C1poM6qmHLjWPnXzqEJT0NxyFXgdaK/Qe9DcpcASod9mIAdlLIxJEyYNlWeonAJ".
    // "VYW8pQ+pTVGwI9n0iaT71ldWQzcMN3Dvi/+zpgw3HxxO7HJtEIlR84pvILv1yceC".
    // "ZCqqQ4O/4SemsG00oTiTyD3SM2ZvAgMBAAECgYBLToeX6ywNC7Icu7Hljll+45yB".
    // "jri+0CJLKFoYw1uA21xYnxoEE9my54zX04uA502oafDhGYfmWLDhIvidrpP6oalu".
    // "URb/gbV5Bdcm98gGGVgm6lpK+G5N/eawXDjP0ZjxXb114Y/Hn/oVFVM9OqcujFSV".
    // "+Wg4JgJ4Mmtdr35gYQJBAPbhx030xPcep8/dL5QQMc7ddoOrfxXewKcpDmZJi2ey".
    // "381X+DhuphQ5gSVBbbunRiDCEcuXFY+R7xrgnP+viWcCQQDDpN8DfqRRl+cUhc0z".
    // "/TbnSPJkMT/IQoFeFOE7wMBcDIBoQePEDsr56mtc/trIUh/L6evP9bkjLzWJs/kb".
    // "/i25AkEAtoOf1k/4NUEiipdYjzuRtv8emKT2ZPKytmGx1YjVWKpyrdo1FXMnsJf6".
    // "k9JVD3/QZnNSuJJPTD506AfZyWS6TQJANdeF2Hxd1GatnaRFGO2y0mvs6U30c7R5".
    // "zd6JLdyaE7sNC6Q2fppjmeu9qFYq975CKegykYTacqhnX4I8KEwHYQJAby60iHMA".
    // "YfSUpu//f5LMMRFK2sVif9aqlYbepJcAzJ6zbiSG5E+0xg/MjEj/Blg9rNsqDG4R".
    // "ECGJG2nPR72O8g==";
    
    //商户私钥
    private static $privateKeyStr = "MIICXQIBAAKBgQDVPyL1EYvpuPvX1GkKFghbHcjeo6bU5r1u4lZ7ajefDrmVdKcD".
    "7RyIeG2FC/g8J2vreB2KtcFbyBo0lNMAPFD2F5Sd6U6JkgXXp7xWLvlZdFd70myG".
    "NlDko+x/dsAnc9C3KgqHSUKr1sRvhRGYU/CcyevhLVu8WtiK50xGe1lRGwIDAQAB".
    "AoGAMC7L30PPsUey39mGwlioGq5oLKYdlA1u0BckI06ksrPJCxQIiMKSp+NOG7nQ".
    "pQbjQ5koU6ctwWc9RJQ7+NmoEQkJDDD1KXbrAvvnFsf8nvUrYLlIofTKqhDsjuMI".
    "LzkHV+XYpLLiFpJ3lPsM0b5lHevAcf03xVmMEu0ApPNpq4ECQQD4kasATC4r7KRI".
    "C6sLfCnSjpZtMtOPhaV43uZx6uMl1lz5526oJDVntATazCWIvKiQsKjNBLMTbfTZ".
    "+9ESE9wpAkEA258kP/qR9U25IdUiX1DPEKnz1jIsZzuRrGQKb1fJVOr8DUZ1O1k3".
    "bUxPyelkxP+9KehqWCZPGXmVeu1mRBdrowJBALqJpsicYvH3rvmaOAxwa3pmIyFj".
    "yTyl0R46OLo4yao1iqTIN1Tbh3CBujrwhSJuYhnjWWoyIqlsFRoZTjbAzLECQQDD".
    "Zls1RTX5n7ZYwK29SkOA2wUkjS1uh9R7IeMa32s0z4GEOizxqdYju6K9zZcnozXl".
    "hHChjywPSVrSrUewy3mrAkB072L3RXKnb638vXqg0qCiSajhblgktIZFRriu2lb+".
    "g9SsUmHF3k97Uj73OMbzGn3kazJVvlGkTSHd0b/cZ91K";


    //七分钱公钥
    // private static $sevenPayPublicKeyStr = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4G+OSs43I0Ctw7nxxuJPauTFsPyjMKkfsvYEcw4wqbn82KQWbFiSTy7P5hul4wdoZaFW5lSnHug+lyjn64t0dtCsaViOWefWrpL1gWZNpOc9gk6qNhQ0120ikHLE1SLH//gVStf+TDeVtaW+4Uzs5J7+/shdvfgU5T4+gxBk9jQIDAQAB";
    
    private static $sevenPayPublicKeyStr = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDVPyL1EYvpuPvX1GkKFghbHcjeo6bU5r1u4lZ7ajefDrmVdKcD7RyIeG2FC/g8J2vreB2KtcFbyBo0lNMAPFD2F5Sd6U6JkgXXp7xWLvlZdFd70myGNlDko+x/dsAnc9C3KgqHSUKr1sRvhRGYU/CcyevhLVu8WtiK50xGe1lRGwIDAQAB";

    /**
     * rsa签名
     * originalStr 原始数据
     */
    static function dataRsaSign($originalStr) {

        $str = chunk_split(self::$privateKeyStr, 64, "\n");
        $pStr = "-----BEGIN RSA PRIVATE KEY-----\n$str-----END RSA PRIVATE KEY-----\n";

        $pi_key =  openssl_pkey_get_private($pStr);//这个函数可用来判断私钥是否是可用的，可用返回资源id Resource id
        openssl_sign($originalStr,$sign,$pi_key,OPENSSL_ALGO_SHA1);
        $sign = bin2hex($sign);//最终的签名
        return $sign;
    }

    /**
     * rsa验签
     * $signStr 签名数据
     */
    static function rsaVerify($signStr,$data) {

        $sig = hex2bin($signStr);

        $str = chunk_split(self::$sevenPayPublicKeyStr, 64, "\n");
        $pStr = "-----BEGIN PUBLIC KEY-----\n$str-----END PUBLIC KEY-----\n";

        $res = openssl_pkey_get_public($pStr);

        $result = openssl_verify(SevenPayHelper::createLinkstring($data), $sig, $res,OPENSSL_ALGO_SHA1);

        if ($result == 1)   // 通过验签
        {
            return true;
        }else{
            return false;
        }
    }


}