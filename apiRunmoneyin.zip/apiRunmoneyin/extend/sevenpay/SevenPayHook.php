<?php
/**
 * Created by sublime.
 * User: fuchao
 * Date: 2018/6/14
 * Time: 下午6:21
 */

namespace sevenpay;
use think\Config;

final class SevenPayHook
{
    /**
     * 提交请求,使用curl 只能用get请求，使用post会出现不支持的服务类型错误
     * $params 请求参数数组
     * $sevenPaySubmitUrl 请求url
     * 返回
     */
    static function buildRequest($params,$sevenPaySubmitUrl) {

          $params = http_build_query($params);
          $str = curl_init();
          curl_setopt($str, CURLOPT_URL, $sevenPaySubmitUrl.'?'.$params);
          curl_setopt($str, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($str, CURLOPT_HEADER, 0);
          curl_setopt($str, CURLOPT_SSL_VERIFYPEER, false);
          $output = curl_exec($str);
          curl_close($str);
          return $output;
    }
}




