<?php
/**
 * Created by sublime.
 * User: fuchao
 * Date: 2018/6/14
 * Time: 下午6:21
 * Des: 七分钱支付聚合功能类
 */

namespace sevenpay;

use think\Config;
use sevenpay\RSATool;
use sevenpay\SevenPayConfig;
use sevenpay\SevenPayHook;
use sevenpay\SevenPayUnit;

// include_once "RSATool.php";
include_once "SevenPayConfig.php";
// include_once "SevenPayHelper.php";
// include_once "SevenPayApply.php";

header("content-type:text/html;charset=utf-8");

final class payApplyInt{
   
    
    // 预下单回调地址
    protected $payTargetUrl = 'http://localhost/STC_PRO/pgUrl.php';
    protected $payNotifyUrl = 'http://localhost/STC_PRO/bgUrl.php';

    /**
     * 七分钱预下单
     * @return  [预下单请求结果]
     */
    public function payUnifiedOrder() {
// $res = RSATool::dataRsaSign('123');
// return $res;

// var_dump($res);
// die;

        $output = SevenPayHook::buildRequest(self::buildParams(),AGGREGATEPAY_SUBMIT_H5);
        $outputArray = json_decode($output,true);
        $returnCode = $outputArray["returnCode"];

        return $outputArray;
        die;

        if(strcasecmp($returnCode,"SUCCESS") == 0) {
            $payUrl = $outputArray["payUrl"];
        }else{
            var_dump($output);
        }
    }


    /**
     * 七分钱支付预下单请求参数组装
     * @param [array] $[params] [请求参数集]
     * @return [array] [七分钱发起支付请求参数数组]
     */
    public function buildParams() {

        $params = array();
        $params["mchOrderId"] = date('YmdHis') . rand(100000, 999999);                // 商户订单号
        $params["mchId"] = 'C2018061215114200210';                                    // 商户号
        $params["orderAmt"] = '1.00';                                                 // 订单金额
        $params["prodName"] = '手机';                                                     // 商品名称
        $params["prodDesc"] = '爱疯手机描述';                                                 // 商品描述
        $params["version"] = VERSION;                               // 网关版本(固定值v2.0)
        $params["pageLanguage"] = "1";                              // 网关页面显示语言种类
        $params["inputCharset"] = INPUT_TYPE;                       // 字符集

        //手机测试请将localhost换成本机ip
        $params["pgUrl"] = "http://localhost/STC_PRO/pgUrl.php";                     // 订单完成后返回的商户页面地址
        $params["bgUrl"] = "http://localhost/STC_PRO/bgUrl.php";                     // 订单完成后回调商户后台通知地址
        $params["payType"] = "1";                                   // 支付方式
        $params["orderTimeOut"] = "3600";                           // 交易超时时间
        $params["service"] = H5T_GATEWAY_PAY;                       // 接口类型(固定值/必填)

        if(date_default_timezone_get() != "Asia/Shanghai") {
            date_default_timezone_set("Asia/Shanghai");
        }

        $params["orderTimestamp"] = date("YmdHis");                 // 交易时间戳
        $params["channel"] = 'wx';                                    // 支付通道
        $params["signMsg"] = RSATool::dataRsaSign(SevenPayUnit::createLinkstring($params));   // 签名

        $params["signType"] = SIGN_TYPE;                            // 签名方式

        return $params;
    }

}

?>










