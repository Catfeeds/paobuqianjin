<?php

namespace umeng;

use umeng\notification\android\AndroidBroadcast;
use umeng\notification\android\AndroidUnicast;
use umeng\notification\ios\IOSBroadcast;
use umeng\notification\ios\IOSUnicast;

class UPush
{
    private static $_instance = null;//主体对象实例
    private static $pushKey = null;//推送key
    private static $deviceToken = null;//设备token    ios 64位  android 32位
    private static $deviceType = null; //推送设备类型  android   ios
    private static $displayType = 'notification';//推送类型   notification  message
    private static $body = null;
    public static $productionMode = false;//true 生产环境   false 测试环境


    private static function instance($object)
    {
        self::$_instance = $object;

        if (self::$deviceType == 'ios')
        {
            self::$pushKey = parse_ini_file(__DIR__ . '/push.ini', TRUE)['IOS'];
        } elseif (self::$deviceType == 'android')
        {
            self::$pushKey = parse_ini_file(__DIR__ . '/push.ini', TRUE)['ANDROID'];
        } else
        {
            return false;
        }

        self::$_instance->setAppMasterSecret(self::$pushKey['AppMasterSecret']);
        self::$_instance->setPredefinedKeyValue("appkey", self::$pushKey['Appkey']);
        self::$_instance->setPredefinedKeyValue("timestamp", strval(time()));

    }


    /**
     * @name 推送单体
     * @param $device_tokens
     * @param $title
     * @param null $subtirle
     * @param array $content
     * @param string $type
     * @return string
     */
    public static function sendUnicast($device_tokens, $title, $subtitle = null, $content = "测试", $type = 'go_app')
    {
        try
        {
            self::$deviceToken = $device_tokens;

            if (strlen(self::$deviceToken) == 64)
            {
                self::$deviceType = 'ios';
                self::instance(new IOSUnicast());
                self::$_instance->setPredefinedKeyValue("device_tokens", self::$deviceToken);
                $body = ['title' => $title, $subtitle && 'subtitle' => $subtitle, 'body' => $content,];
                self::$_instance->setPredefinedKeyValue("alert", json_encode($body));
                self::$_instance->setPredefinedKeyValue("badge", 0);
            } elseif (strlen(self::$deviceToken) == 44)
            {
                self::$deviceType = 'android';
                self::instance(new AndroidUnicast());
                self::$_instance->setPredefinedKeyValue("device_tokens", self::$deviceToken);
                self::$_instance->setPredefinedKeyValue("display_type", "message");
                $body = array('start' => 'step');
                self::$_instance->setPredefinedKeyValue("custom", json_encode($body));
                //                self::$_instance->setPredefinedKeyValue("ticker", "Android unicast ticker");
                //                self::$_instance->setPredefinedKeyValue("title", $title);
                //                self::$_instance->setPredefinedKeyValue("text", $content);
                //                self::$_instance->setPredefinedKeyValue("after_open", $type);
            } else
            {
                return false;
            }
            //将“production_mode”设置为“false”，如果它是一个测试设备。
            self::$_instance->setPredefinedKeyValue("production_mode", self::$productionMode);
            self::$_instance->send();
        } catch (\Exception $e)
        {
            return $e->getMessage();
        }
    }

    public static function sendBroadcast($title = 'iosssssssssssssssss', $subtitle = 'iosssssssssssssssss', $content = 'iosssssssssssssssss', $type = 'go_app', $deviceType = 'ios')
    {
        try
        {
            self::$deviceType = strtolower($deviceType);
            if (self::$deviceType == 'android')
            {
                self::instance(new AndroidBroadcast());
                self::$_instance->setPredefinedKeyValue("display_type", "message");
                $body = array('pull_service' => 'step');
                self::$_instance->setPredefinedKeyValue("custom", json_encode($body));
                //                self::$_instance->setPredefinedKeyValue("ticker", "Android broadcast ticker");

                //                self::$_instance->setPredefinedKeyValue("title", $title);
                //                self::$_instance->setPredefinedKeyValue("text", $content);
                //                self::$_instance->setPredefinedKeyValue("after_open", $type);
            } elseif (self::$deviceType == 'ios')
            {
                self::instance(new IOSBroadcast());
                $body = ['title' => $title, $subtitle && 'subtitle' => $subtitle, 'body' => $content,];
                self::$_instance->setPredefinedKeyValue("alert", json_encode($body));
                self::$_instance->setPredefinedKeyValue("badge", 0);

            }

            // Set 'production_mode' to 'false' if it's a test device.
            self::$_instance->setPredefinedKeyValue("production_mode", self::$productionMode);
            self::$_instance->send();

        } catch (\Exception $e)
        {
            return $e->getMessage();
        }
    }


    public static function test()
    {
        $data = parse_ini_file(__DIR__ . "/template.php",true);

        exit(var_dump($data));
    }


}